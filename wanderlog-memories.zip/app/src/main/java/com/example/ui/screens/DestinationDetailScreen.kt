package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.widget.Toast
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.Dialog
import com.example.domain.model.LocationCoordinate
import com.example.domain.model.MapMarker
import com.example.domain.model.Memory
import com.example.domain.model.Trip
import com.example.map.MemoryMapView
import com.example.ui.components.*
import com.example.premium.PremiumManager
import com.example.presentation.Screen
import com.example.presentation.WanderlogViewModel
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import kotlinx.coroutines.launch
import android.net.Uri
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.export.*
import com.example.premium.*
import com.example.cloud.*
import com.example.data.local.WanderlogDatabase

@Composable
fun DestinationDetailScreen(
    trip: Trip,
    memories: List<Memory>,
    viewModel: WanderlogViewModel,
    onAddMemoryClick: () -> Unit,
    onBackClick: () -> Unit,
    onDeleteTripClick: () -> Unit,
    onDeleteMemoryClick: (Memory) -> Unit,
    onAlbumClick: () -> Unit,
    onMemoryClick: (Memory) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Overview 🏠", "Album 📸", "Timeline 📅", "Map 🗺️", "Stats 📊")

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by PremiumManager.isPremium.collectAsState()

    val premiumGate = remember { PremiumGate() }
    val pdfExportViewModel: PdfExportViewModel = viewModel()
    val pdfExportState by pdfExportViewModel.state.collectAsState()
    var showPdfExportSheet by remember { mutableStateOf(false) }
    var showCloudBackupSheet by remember { mutableStateOf(false) }

    val cloudSyncViewModel: CloudSyncViewModel = remember {
        val coordinator = CloudWorkerDependencies.createIncrementalCoordinator(context)
        val cloudRepo = CloudSyncRepository(
            cloudProvider = SupabaseCloudProvider(SupabaseAuthManager()),
            queueStore = RoomSyncQueueStore(WanderlogDatabase.getDatabase(context).syncQueueDao()),
            localDataSource = RoomCloudLocalDataSource(
                tripDao = WanderlogDatabase.getDatabase(context).tripDao(),
                memoryDao = WanderlogDatabase.getDatabase(context).memoryDao(),
                photoDao = WanderlogDatabase.getDatabase(context).albumPhotoDao()
            )
        )
        val backupCoord = CloudBackupCoordinator(
            repository = cloudRepo,
            localDataSource = RoomCloudLocalDataSource(
                tripDao = WanderlogDatabase.getDatabase(context).tripDao(),
                memoryDao = WanderlogDatabase.getDatabase(context).memoryDao(),
                photoDao = WanderlogDatabase.getDatabase(context).albumPhotoDao()
            ),
            settingsRepository = CloudWorkerDependencies.settingsRepository(context)
        )
        CloudSyncViewModel(
            repository = cloudRepo,
            backupCoordinator = backupCoord,
            settingsRepository = CloudWorkerDependencies.settingsRepository(context),
            scheduler = CloudBackupScheduler(context)
        )
    }
    val cloudUiState by cloudSyncViewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        cloudSyncViewModel.refreshPendingCount()
    }
    var paywallReason by remember { mutableStateOf<PremiumPaywallReason?>(null) }
    val tripPhotos by viewModel.selectedTripPhotos.collectAsState()

    val cloudRestoreRepository = remember {
        CloudRestoreDependencies.createRepository(context)
    }
    val cloudRestoreViewModel = remember {
        CloudRestoreViewModel(cloudRestoreRepository)
    }
    val cloudRestoreState by cloudRestoreViewModel.state.collectAsState()

    val coverId = remember(trip.coverImage) {
        context.resources.getIdentifier(trip.coverImage, "drawable", context.packageName)
    }

    // Dynamic stats computation
    val memoriesCount = memories.size
    val favoriteMood = remember(memories) {
        if (memories.isEmpty()) "None"
        else memories.groupBy { it.mood }.maxByOrNull { it.value.size }?.key?.emoji ?: "😊"
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFFF9A9E), // Soft red/pink
                        Color(0xFFFAD0C4), // Peach/rose
                        Color(0xFFA18CD1)  // Soft purple/lavender
                    )
                )
            )
            .testTag("destination_detail_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Immersive Hero Trip Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                if (coverId != 0) {
                    AsyncImage(
                        model = coverId,
                        contentDescription = trip.destinationName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else if (trip.coverImage.isNotEmpty()) {
                    AsyncImage(
                        model = trip.coverImage,
                        contentDescription = trip.destinationName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(getGradient(trip.accentGradientIndex))
                    )
                }

                // Dark elegant gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent, Color.Black.copy(alpha = 0.6f)),
                                startY = 0f
                            )
                        )
                )

                // Back arrow button (iOS style rounded glass)
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .padding(top = 44.dp, start = 16.dp)
                        .shadow(4.dp, CircleShape)
                        .background(Color.White.copy(alpha = 0.7f), CircleShape)
                        .size(38.dp)
                        .testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.DarkGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Top Action Buttons (iOS style rounded glass on top right)
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 44.dp, end = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Export PDF Book button
                    IconButton(
                        onClick = {
                            when (
                                premiumGate.canUseFeature(
                                    feature = PremiumFeature.PDF_EXPORT,
                                    isPremium = isPremium
                                )
                            ) {
                                PremiumGateResult.Allowed -> {
                                    showPdfExportSheet = true
                                }
                                else -> {
                                    paywallReason = PremiumPaywallReason.PDF_EXPORT
                                }
                            }
                        },
                        modifier = Modifier
                            .shadow(4.dp, CircleShape)
                            .background(Color.White.copy(alpha = 0.7f), CircleShape)
                            .size(38.dp)
                            .testTag("export_pdf_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "Export Travel Book",
                            tint = Color(0xFFDD2476),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Album button
                    IconButton(
                        onClick = onAlbumClick,
                        modifier = Modifier
                            .shadow(4.dp, CircleShape)
                            .background(Color.White.copy(alpha = 0.7f), CircleShape)
                            .size(38.dp)
                            .testTag("album_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Photo Album",
                            tint = Color.DarkGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Title and dates bottom alignment
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp)
                ) {
                    Text(
                        text = trip.destinationName,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "📍 ${trip.country}  •  📅 ${trip.startDate} to ${trip.endDate}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }

            // Stats summary panel (Transparent premium ribbon)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.35f))
                    .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)))
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatItem(label = "Memories", value = memoriesCount.toString())
                StatDivider()
                StatItem(label = "Mood", value = favoriteMood)
                StatDivider()
                StatItem(label = "Places", value = memories.distinctBy { it.locationName }.size.toString())
            }

            // Tabs Selector
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White.copy(alpha = 0.3f),
                contentColor = Color(0xFFDD2476),
                edgePadding = 12.dp,
                divider = {},
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = Color(0xFFDD2476)
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedTab == index) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.6f)
                            )
                        }
                    )
                }
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                    0 -> {
                        // Overview Tab
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                GlassCard {
                                    Text(
                                        text = "About this Journey 🗺️",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1C1C1E)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = trip.description,
                                        fontSize = 13.sp,
                                        color = Color.DarkGray,
                                        lineHeight = 18.sp
                                    )
                                }
                            }

                            if (memories.isEmpty()) {
                                item {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 32.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = "✨",
                                            fontSize = 56.sp,
                                            modifier = Modifier.padding(bottom = 12.dp)
                                        )
                                        Text(
                                            text = "Your journey begins here.",
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A),
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Capture your first beautiful memory, upload photos, tag location coordinates automatically, and create a gorgeous personalized diary.",
                                            fontSize = 13.sp,
                                            color = Color(0xFF475569),
                                            lineHeight = 20.sp,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 16.dp)
                                        )
                                        Spacer(modifier = Modifier.height(28.dp))
                                        
                                        Button(
                                            onClick = onAddMemoryClick,
                                            shape = RoundedCornerShape(20.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                            contentPadding = PaddingValues(),
                                            modifier = Modifier
                                                .fillMaxWidth(0.85f)
                                                .height(50.dp)
                                                .shadow(6.dp, RoundedCornerShape(20.dp))
                                                .background(
                                                    Brush.horizontalGradient(listOf(Color(0xFFFF512F), Color(0xFFDD2476))),
                                                    shape = RoundedCornerShape(20.dp)
                                                )
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.Center
                                            ) {
                                                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Add your first memory", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            } else {
                                item {
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedTab = 2 }
                                            .shadow(4.dp, RoundedCornerShape(16.dp)),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.9f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(16.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("View Full Travel Timeline 📅", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                                Text("See your daily scrapbook story and filtered memories in an editorial layout.", fontSize = 11.sp, color = Color.Gray)
                                            }
                                            Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "View", tint = Color(0xFFDD2476))
                                        }
                                    }
                                }

                                item {
                                    Text(
                                        text = "Latest Memories Preview",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A),
                                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                                    )
                                }

                                items(memories.take(2), key = { it.id }) { memory ->
                                    MemoryCard(
                                        memory = memory,
                                        onDelete = { onDeleteMemoryClick(memory) },
                                        onClick = { onMemoryClick(memory) }
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        // Album Tab: Beautiful photo gallery with CTA to manage album
                        val photos by viewModel.selectedTripPhotos.collectAsState()
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Scrapbook Gallery", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${photos.size} photos captured in this travel adventure", fontSize = 12.sp, color = Color(0xFF475569))
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            if (photos.isEmpty()) {
                                Box(
                                    modifier = Modifier.weight(1f).fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("📸", fontSize = 48.sp)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("No photos in this journey's scrapbook yet.", color = Color.Gray, fontSize = 13.sp)
                                        Text("Add memories with images to populate your gallery.", color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                            } else {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(3),
                                    modifier = Modifier.weight(1f).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(photos) { photo ->
                                        AsyncImage(
                                            model = photo.localUri,
                                            contentDescription = null,
                                            modifier = Modifier
                                                .aspectRatio(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)), RoundedCornerShape(12.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Button(
                                onClick = onAlbumClick,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .shadow(4.dp, RoundedCornerShape(14.dp)),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF52A8FF))
                            ) {
                                Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Open Full Photo Organizer", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    2 -> {
                        // Timeline Tab
                        TimelineScreen(
                            trip = trip,
                            viewModel = viewModel,
                            onAddMemoryClick = onAddMemoryClick,
                            onMemoryClick = onMemoryClick,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    3 -> {
                        // Complete OpenStreetMap Engine Integration
                        JourneyMapTab(
                            trip = trip,
                            viewModel = viewModel.mapViewModel,
                            onOpenMemory = { memoryId ->
                                val mem = memories.firstOrNull { it.id == memoryId }
                                if (mem != null) {
                                    onMemoryClick(mem)
                                } else {
                                    viewModel.selectMemory(memoryId)
                                    viewModel.navigateTo(Screen.MemoryDetail(memoryId))
                                }
                            },
                            onOpenPhoto = { _ ->
                                selectedTab = 1
                            },
                            onAddMemoryClick = onAddMemoryClick,
                            onAlbumClick = { selectedTab = 1 },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    4 -> {
                        // Details/Stats Tab: General trip information, description & settings
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(24.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                GlassCard {
                                    Text(
                                        text = "About this Journey",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1C1C1E)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = trip.description,
                                        fontSize = 13.sp,
                                        color = Color.DarkGray,
                                        lineHeight = 20.sp
                                    )
                                }
                            }

                            item {
                                GlassCard {
                                    Text(
                                        text = "Map Area Configuration",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1C1C1E)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Center Coordinate: Lat: ${trip.latitude}, Lon: ${trip.longitude}",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "OpenStreetMap Tile Caching: ENABLED",
                                        fontSize = 11.sp,
                                        color = Color(0xFF3AD29F),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }

                             item {
                                GlassCard {
                                    Text(
                                        text = "Wonderlog Premium",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1C1C1E)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // 1. PDF Export
                                    PremiumFeaturePreviewRow(
                                        icon = Icons.Default.PictureAsPdf,
                                        title = "Export PDF Travel Book",
                                        subtitle = "Save a gorgeous printable scrapbook copy",
                                        isPremium = isPremium,
                                        onClick = {
                                            when (
                                                premiumGate.canUseFeature(
                                                    feature = PremiumFeature.PDF_EXPORT,
                                                    isPremium = isPremium
                                                )
                                            ) {
                                                PremiumGateResult.Allowed -> {
                                                    showPdfExportSheet = true
                                                }
                                                else -> {
                                                    paywallReason = PremiumPaywallReason.PDF_EXPORT
                                                }
                                            }
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // 2. Cloud Backup
                                    PremiumFeaturePreviewRow(
                                        icon = Icons.Default.CloudUpload,
                                        title = "Secure Cloud Backup",
                                        subtitle = "Protect and restore your travel journal",
                                        isPremium = isPremium,
                                        onClick = {
                                            when (
                                                premiumGate.canUseFeature(
                                                    feature = PremiumFeature.CLOUD_BACKUP,
                                                    isPremium = isPremium
                                                )
                                            ) {
                                                PremiumGateResult.Allowed -> {
                                                    showCloudBackupSheet = true
                                                }
                                                else -> {
                                                    paywallReason = PremiumPaywallReason.CLOUD_BACKUP
                                                }
                                            }
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // 3. Offline Maps
                                    PremiumFeaturePreviewRow(
                                        icon = Icons.Default.Map,
                                        title = "Offline Maps",
                                        subtitle = "Keep Journey maps useful away from connectivity",
                                        isPremium = isPremium,
                                        onClick = {
                                            if (!isPremium) {
                                                PremiumManager.showUpgrade()
                                            } else {
                                                Toast.makeText(context, "🗺️ Offline map cache downloaded!", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    )
                                }
                            }

                            item {
                                Button(
                                    onClick = onDeleteTripClick,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 16.dp),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Delete Entire Trip", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating plus button (to add memory to this trip)
        if (selectedTab == 0 || selectedTab == 1 || selectedTab == 2) {
            FloatingActionButton(
                onClick = onAddMemoryClick,
                containerColor = Color(0xFFFF69B4), // Romantic rose colorful FAB
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 24.dp, end = 20.dp)
                    .shadow(8.dp, CircleShape)
                    .testTag("add_memory_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Memory",
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        // PDF Export Options Bottom Sheet
        if (showPdfExportSheet) {
            PdfExportOptionsSheet(
                onDismiss = { showPdfExportSheet = false },
                onExport = { options ->
                    showPdfExportSheet = false
                    val exportPhotos = tripPhotos.map { photo ->
                        ExportPhoto(
                            uri = Uri.parse(photo.localUri.ifBlank { photo.originalUri }),
                            caption = photo.locationName.ifBlank { null },
                            date = null,
                            location = photo.locationName.ifBlank { null }
                        )
                    }

                    val exportMemories = memories.map { mem ->
                        ExportMemory(
                            title = mem.title,
                            journalText = mem.journalText.ifBlank { mem.note },
                            date = mem.date,
                            location = mem.locationName.ifBlank { null },
                            mood = mem.mood.label,
                            photoUris = if (mem.image.isNotBlank()) listOf(Uri.parse(mem.image)) else emptyList()
                        )
                    }

                    val exportData = JourneyExportData(
                        journeyId = trip.id.toLongOrNull() ?: trip.id.hashCode().toLong(),
                        title = trip.title.ifBlank { trip.destinationName },
                        destination = trip.destinationName,
                        country = trip.country,
                        startDate = trip.startDate,
                        endDate = trip.endDate,
                        description = trip.description,
                        coverPhotoUri = if (trip.coverImage.isNotBlank()) Uri.parse(trip.coverImage) else null,
                        accentColorArgb = null,
                        photos = exportPhotos,
                        memories = exportMemories
                    )

                    pdfExportViewModel.export(exportData, options)
                }
            )
        }

        // PDF Export Progress / Result Dialog
        if (pdfExportState !is PdfExportState.Idle) {
            PdfExportProgressDialog(
                state = pdfExportState,
                onDismiss = { pdfExportViewModel.reset() },
                onShare = { result ->
                    PdfShareManager.share(context, result.filePath)
                }
            )
        }

        // Contextual Paywall if feature locked
        paywallReason?.let { reason ->
            WonderlogPremiumPaywall(
                reason = reason,
                onDismiss = { paywallReason = null },
                onUnlockPremium = {
                    paywallReason = null
                    PremiumManager.showUpgrade()
                }
            )
        }

        // Cloud Backup Sheet
        if (showCloudBackupSheet) {
            CloudBackupSheet(
                state = cloudUiState.sync,
                settings = cloudUiState.settings,
                onDismiss = { showCloudBackupSheet = false },
                onSyncNow = {
                    cloudSyncViewModel.backupNow()
                },
                onSettingsChanged = { updated ->
                    cloudSyncViewModel.updateSettings(updated)
                },
                onRestoreClick = {
                    cloudRestoreViewModel.restore()
                }
            )
        }

        when (
            val restore =
                cloudRestoreState
        ) {
            RestoreState.Idle -> {
                Unit
            }

            is RestoreState.Running -> {
                Dialog(
                    onDismissRequest = {}
                ) {
                    GlassCard {
                        Column(
                            modifier =
                                Modifier.padding(
                                    24.dp
                                ),
                            horizontalAlignment =
                                Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator()

                            Spacer(
                                Modifier.height(
                                    16.dp
                                )
                            )

                            Text(
                                text =
                                    restore
                                        .progress
                                        .message,
                                fontWeight =
                                    FontWeight.Bold
                            )
                        }
                    }
                }
            }

            is RestoreState.Success -> {
                LaunchedEffect(
                    restore
                ) {
                    val summary =
                        restore.summary

                    Toast.makeText(
                        context,
                        "Restore complete: " +
                            "${summary.journeysInserted} Journeys, " +
                            "${summary.memoriesInserted} Memories, " +
                            "${summary.photosInserted} photos.",
                        Toast.LENGTH_LONG
                    ).show()

                    cloudRestoreViewModel
                        .reset()
                }
            }

            is RestoreState.Error -> {
                LaunchedEffect(
                    restore
                ) {
                    Toast.makeText(
                        context,
                        restore.message,
                        Toast.LENGTH_LONG
                    ).show()

                    cloudRestoreViewModel
                        .reset()
                }
            }
        }
    }
}

@Composable
fun PremiumFeaturePreviewRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    isPremium: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(Color.White.copy(alpha = 0.5f), CircleShape)
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFFDD2476),
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.Gray
            )
        }

        Icon(
            imageVector = if (isPremium) Icons.Default.CheckCircle else Icons.Default.Lock,
            contentDescription = if (isPremium) "Unlocked" else "Locked",
            tint = if (isPremium) Color(0xFF10B981) else Color(0xFF64748B),
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = Color(0xFF52A8FF)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label.uppercase(),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.LightGray,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun StatDivider() {
    Box(
        modifier = Modifier
            .height(24.dp)
            .width(1.dp)
            .background(Color.LightGray.copy(alpha = 0.5f))
    )
}
