package com.example.presentation

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.local.WanderlogDatabase
import com.example.data.repository.WanderlogRepositoryImpl
import com.example.domain.model.Memory
import com.example.domain.model.Trip
import com.example.domain.model.AlbumPhoto
import com.example.domain.repository.WanderlogRepository
import com.example.domain.model.TimelineSort
import com.example.domain.model.TimelineFilter
import com.example.domain.model.Mood
import com.example.domain.repository.TimelineRepository
import com.example.data.repository.TimelineRepositoryImpl
import com.example.premium.SubscriptionConfig
import com.example.premium.PremiumManager
import com.example.storage.AlbumPhotoManager
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class WanderlogViewModel(application: Application) : AndroidViewModel(application) {

    private val db: WanderlogDatabase = WanderlogDatabase.getDatabase(application)

    val repository: WanderlogRepository = WanderlogRepositoryImpl(
        db.tripDao(),
        db.memoryDao(),
        db.albumPhotoDao()
    )

    val mapRepository: com.example.domain.repository.MapRepository = com.example.map.OpenStreetMapRepository(
        db.locationPlaceDao(),
        db.geocodingCacheDao(),
        db.offlineMapRegionDao()
    )

    val mapViewModel: com.example.map.MapViewModel = com.example.map.MapViewModel(
        application,
        mapRepository,
        db
    )

    val smartJourneyRepository: com.example.smartjourney.SmartJourneyRepository =
        com.example.smartjourney.SmartJourneyIntegrationRepository(
            application,
            com.example.smartjourney.WonderlogSmartJourneyAdapter(
                application,
                repository,
                mapRepository
            )
        )

    val smartJourneyViewModel: com.example.smartjourney.SmartJourneyViewModel =
        com.example.smartjourney.SmartJourneyViewModel(smartJourneyRepository)

    val keepsakeRepository: com.example.capture.TravelKeepsakeRepository =
        com.example.capture.TravelKeepsakeRepositoryImpl(application, db.memoryAttachmentDao())

    val captureRepository: com.example.capture.CaptureRepository =
        com.example.capture.WonderlogCaptureRepository(
            application,
            repository,
            keepsakeRepository
        )

    val captureViewModel: com.example.capture.CaptureViewModel =
        com.example.capture.CaptureViewModel(captureRepository)

    fun resetSmartJourney() {
        smartJourneyViewModel.reset()
    }

    private val _selectedTripId = MutableStateFlow<String?>(null)
    val selectedTripId: StateFlow<String?> = _selectedTripId.asStateFlow()

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Onboarding)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Exposed Flows from Room
    val trips: StateFlow<List<Trip>> = repository.getAllTrips()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMemories: StateFlow<List<Memory>> = repository.getAllMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedTrip: StateFlow<Trip?> = selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getTripById(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedTripMemories: StateFlow<List<Memory>> = selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getMemoriesForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedTripMemoriesWithPhotos: StateFlow<List<com.example.domain.model.MemoryWithPhotos>> = selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getMemoriesWithPhotosForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedMemoryId = MutableStateFlow<String?>(null)

    val selectedMemoryWithPhotos: StateFlow<com.example.domain.model.MemoryWithPhotos?> = selectedMemoryId
        .flatMapLatest { id ->
            if (id != null) repository.getMemoryWithPhotosById(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedTripPhotos: StateFlow<List<AlbumPhoto>> = selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getPhotosForJourney(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _importProgress = MutableStateFlow(0f)
    val importProgress: StateFlow<Float> = _importProgress.asStateFlow()

    private val timelineRepository: TimelineRepository = TimelineRepositoryImpl()

    private val _timelineSort = MutableStateFlow(TimelineSort.OLDEST_FIRST)
    val timelineSort: StateFlow<TimelineSort> = _timelineSort.asStateFlow()

    private val _timelineFilter = MutableStateFlow(TimelineFilter())
    val timelineFilter: StateFlow<TimelineFilter> = _timelineFilter.asStateFlow()

    val timelineUiState: StateFlow<TimelineUiState> = combine(
        selectedTrip,
        selectedTripMemoriesWithPhotos,
        _timelineSort,
        _timelineFilter
    ) { trip, memoriesWithPhotos, sort, filter ->
        if (trip == null) {
            TimelineUiState()
        } else {
            TimelineUiState(
                days = timelineRepository.generateTimeline(trip, memoriesWithPhotos, sort, filter),
                sections = timelineRepository.generateSections(memoriesWithPhotos, sort, filter),
                sort = sort,
                filter = filter
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TimelineUiState())

    fun onTimelineEvent(event: TimelineEvent) {
        when (event) {
            is TimelineEvent.ChangeSort -> {
                _timelineSort.value = event.sort
            }
            is TimelineEvent.SetFilter -> {
                _timelineFilter.value = event.filter
            }
            is TimelineEvent.ToggleFavoriteFilter -> {
                _timelineFilter.value = _timelineFilter.value.copy(showOnlyFavorites = event.onlyFavorites)
            }
            is TimelineEvent.SelectMoodFilter -> {
                _timelineFilter.value = _timelineFilter.value.copy(selectedMood = event.mood)
            }
            is TimelineEvent.SelectTagFilter -> {
                _timelineFilter.value = _timelineFilter.value.copy(selectedTag = event.tag)
            }
            is TimelineEvent.SelectLocationFilter -> {
                _timelineFilter.value = _timelineFilter.value.copy(selectedLocation = event.locationName)
            }
            is TimelineEvent.SetDateRangeFilter -> {
                _timelineFilter.value = _timelineFilter.value.copy(dateRangeStart = event.start, dateRangeEnd = event.end)
            }
            is TimelineEvent.SetPhotoFilter -> {
                _timelineFilter.value = _timelineFilter.value.copy(hasPhotosOnly = event.hasPhotosOnly, noPhotosOnly = event.noPhotosOnly)
            }
            is TimelineEvent.ClearFilters -> {
                _timelineFilter.value = TimelineFilter()
            }
        }
    }

    init {
        // Initial mock populating
        viewModelScope.launch {
            repository.populateMockDataIfEmpty()
        }
    }

    fun selectTrip(tripId: String?) {
        _selectedTripId.value = tripId
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun addTrip(trip: Trip) {
        viewModelScope.launch {
            repository.insertTrip(trip)
        }
    }

    fun updateTrip(trip: Trip) {
        viewModelScope.launch {
            repository.updateTrip(trip)
        }
    }

    fun archiveTrip(trip: Trip, archive: Boolean) {
        viewModelScope.launch {
            repository.updateTrip(trip.copy(archived = archive, updatedAt = System.currentTimeMillis()))
        }
    }

    fun favoriteTrip(trip: Trip, favorite: Boolean) {
        viewModelScope.launch {
            repository.updateTrip(trip.copy(favorite = favorite, updatedAt = System.currentTimeMillis()))
        }
    }

    fun duplicateTrip(trip: Trip) {
        viewModelScope.launch {
            val duplicated = trip.copy(
                id = "trip_${java.util.UUID.randomUUID()}",
                destinationName = "${trip.destinationName} (Copy)",
                title = "${trip.title} (Copy)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                favorite = false,
                archived = false
            )
            repository.insertTrip(duplicated)
        }
    }

    fun renameTrip(trip: Trip, newName: String) {
        viewModelScope.launch {
            repository.updateTrip(trip.copy(
                destinationName = newName,
                title = newName,
                destination = newName,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    fun changeTripTheme(trip: Trip, selectedGradientIndex: Int) {
        viewModelScope.launch {
            repository.updateTrip(trip.copy(
                accentGradientIndex = selectedGradientIndex,
                accentTheme = "Preset_$selectedGradientIndex",
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    fun changeTripCover(trip: Trip, path: String) {
        viewModelScope.launch {
            repository.updateTrip(trip.copy(
                coverImage = path,
                coverPhotoId = path,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    fun addMemory(memory: Memory) {
        viewModelScope.launch {
            repository.insertMemory(memory)
        }
    }

    fun selectMemory(memoryId: String?) {
        selectedMemoryId.value = memoryId
    }

    fun saveMemoryWithPhotos(memory: Memory, selectedPhotos: List<AlbumPhoto>) {
        viewModelScope.launch {
            repository.insertMemory(memory)
            repository.deleteCrossRefsForMemory(memory.id)
            selectedPhotos.forEachIndexed { index, photo ->
                repository.insertMemoryPhotoCrossRef(
                    com.example.domain.model.MemoryPhotoCrossRef(
                        memoryId = memory.id,
                        albumPhotoId = photo.id,
                        displayOrder = index,
                        isHeroPhoto = index == 0
                    )
                )
            }
        }
    }

    fun updateMemoryWithPhotos(memory: Memory, selectedPhotos: List<AlbumPhoto>) {
        viewModelScope.launch {
            repository.insertMemory(memory.copy(updatedAt = System.currentTimeMillis()))
            repository.deleteCrossRefsForMemory(memory.id)
            selectedPhotos.forEachIndexed { index, photo ->
                repository.insertMemoryPhotoCrossRef(
                    com.example.domain.model.MemoryPhotoCrossRef(
                        memoryId = memory.id,
                        albumPhotoId = photo.id,
                        displayOrder = index,
                        isHeroPhoto = index == 0
                    )
                )
            }
        }
    }

    fun toggleFavoriteMemory(memoryId: String, currentFavorite: Boolean) {
        viewModelScope.launch {
            val memories = selectedTripMemoriesWithPhotos.value
            val match = memories.find { it.memory.id == memoryId }
            if (match != null) {
                repository.insertMemory(match.memory.copy(favorite = !currentFavorite, updatedAt = System.currentTimeMillis()))
            } else {
                // If not in selected trip flow, fetch directly
                repository.getAllMemories().first().find { it.id == memoryId }?.let { m ->
                    repository.insertMemory(m.copy(favorite = !currentFavorite, updatedAt = System.currentTimeMillis()))
                }
            }
        }
    }

    fun toggleFavoriteMemory(memory: Memory) {
        viewModelScope.launch {
            repository.insertMemory(memory.copy(favorite = !memory.favorite, updatedAt = System.currentTimeMillis()))
        }
    }

    fun insertPhotos(photos: List<AlbumPhoto>) {
        viewModelScope.launch {
            repository.insertPhotos(photos)
        }
    }

    fun deleteTrip(trip: Trip) {
        viewModelScope.launch {
            repository.deleteTrip(trip)
            if (selectedTripId.value == trip.id) {
                _selectedTripId.value = null
            }
            try {
                val journeyFolder = java.io.File(getApplication<Application>().filesDir, "journeys/${trip.id}")
                if (journeyFolder.exists()) {
                    journeyFolder.deleteRecursively()
                }
            } catch (e: Exception) {
                Log.e("WanderlogViewModel", "Error deleting trip folder: ${e.message}")
            }
        }
    }

    fun deleteMemory(memory: Memory) {
        viewModelScope.launch {
            repository.deleteMemory(memory)
        }
    }

    // --- Album Engine Actions ---

    fun importPhotos(context: Context, journeyId: String, uris: List<Uri>) {
        viewModelScope.launch {
            _isImporting.value = true
            _importProgress.value = 0f
            val total = uris.size.toFloat()
            val currentPhotos = selectedTripPhotos.value
            val isPremiumUser = PremiumManager.isPremium.value
            val maxLimit = SubscriptionConfig.getLimits(isPremiumUser).albumPhotosLimit
            
            var addedCount = 0
            for ((index, uri) in uris.withIndex()) {
                if (currentPhotos.size + addedCount >= maxLimit) {
                    PremiumManager.showUpgrade()
                    break
                }
                try {
                    val photo = AlbumPhotoManager.importPhoto(
                        context = context,
                        journeyId = journeyId,
                        uri = uri,
                        displayOrder = currentPhotos.size + addedCount,
                        existingPhotos = currentPhotos
                    )
                    if (photo != null) {
                        repository.insertPhoto(photo)
                        // Auto-set cover: If trip cover is blank or placeholder, use the first imported photo
                        val trip = selectedTrip.value
                        if (trip != null && (trip.coverImage.isBlank() || trip.coverImage.startsWith("img_") || trip.coverPhotoId.isBlank() || trip.coverPhotoId.startsWith("img_"))) {
                            repository.updateTrip(trip.copy(
                                coverImage = photo.localUri,
                                coverPhotoId = photo.id,
                                updatedAt = System.currentTimeMillis()
                            ))
                            repository.updatePhoto(photo.copy(isCoverPhoto = true))
                        }
                        addedCount++
                    }
                } catch (pie: com.example.storage.PhotoImportException) {
                    withContext(Dispatchers.Main) {
                        val msg = when (pie.reason) {
                            com.example.storage.PhotoImportException.ImportReason.DUPLICATE -> "Skipped duplicate photo."
                            com.example.storage.PhotoImportException.ImportReason.UNSUPPORTED_FORMAT -> "Unsupported image format."
                            com.example.storage.PhotoImportException.ImportReason.STORAGE_FULL -> "Cannot import: Storage is full."
                            com.example.storage.PhotoImportException.ImportReason.FILE_COPY_FAILED -> "Failed to copy photo to private storage."
                            com.example.storage.PhotoImportException.ImportReason.CORRUPTED -> "Skipped corrupted photo."
                            com.example.storage.PhotoImportException.ImportReason.UNKNOWN -> "Failed to import photo."
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                _importProgress.value = (index + 1) / total
            }
            _isImporting.value = false
            _importProgress.value = 0f
        }
    }

    fun deletePhoto(photo: AlbumPhoto) {
        viewModelScope.launch {
            repository.deletePhoto(photo)
            try {
                java.io.File(photo.localUri).delete()
                java.io.File(photo.thumbnailUri).delete()
            } catch (e: Exception) {}

            val trip = selectedTrip.value
            if (trip != null && (trip.coverPhotoId == photo.id || trip.coverImage == photo.localUri)) {
                val remaining = selectedTripPhotos.value.filter { it.id != photo.id }
                if (remaining.isNotEmpty()) {
                    val nextCover = remaining.first()
                    repository.updateTrip(trip.copy(
                        coverImage = nextCover.localUri,
                        coverPhotoId = nextCover.id,
                        updatedAt = System.currentTimeMillis()
                    ))
                    repository.updatePhoto(nextCover.copy(isCoverPhoto = true))
                } else {
                    repository.updateTrip(trip.copy(
                        coverImage = "",
                        coverPhotoId = "",
                        updatedAt = System.currentTimeMillis()
                    ))
                }
            }
        }
    }

    fun deletePhotos(photos: List<AlbumPhoto>) {
        viewModelScope.launch {
            repository.deletePhotos(photos)
            for (photo in photos) {
                try {
                    java.io.File(photo.localUri).delete()
                    java.io.File(photo.thumbnailUri).delete()
                } catch (e: Exception) {}
            }
            val trip = selectedTrip.value ?: return@launch
            val remaining = selectedTripPhotos.value.filter { p -> p.id !in photos.map { it.id } }
            val isCoverDeleted = photos.any { it.id == trip.coverPhotoId || it.localUri == trip.coverImage }
            if (isCoverDeleted) {
                if (remaining.isNotEmpty()) {
                    val nextCover = remaining.first()
                    repository.updateTrip(trip.copy(
                        coverImage = nextCover.localUri,
                        coverPhotoId = nextCover.id,
                        updatedAt = System.currentTimeMillis()
                    ))
                    repository.updatePhoto(nextCover.copy(isCoverPhoto = true))
                } else {
                    repository.updateTrip(trip.copy(
                        coverImage = "",
                        coverPhotoId = "",
                        updatedAt = System.currentTimeMillis()
                    ))
                }
            }
        }
    }

    fun toggleFavoritePhoto(photo: AlbumPhoto) {
        viewModelScope.launch {
            repository.updatePhoto(photo.copy(favorite = !photo.favorite, updatedAt = System.currentTimeMillis()))
        }
    }

    fun setAsJourneyCover(photo: AlbumPhoto) {
        viewModelScope.launch {
            val trip = selectedTrip.value ?: return@launch
            val photos = selectedTripPhotos.value
            for (p in photos) {
                if (p.isCoverPhoto && p.id != photo.id) {
                    repository.updatePhoto(p.copy(isCoverPhoto = false))
                }
            }
            repository.updatePhoto(photo.copy(isCoverPhoto = true, updatedAt = System.currentTimeMillis()))
            repository.updateTrip(trip.copy(
                coverImage = photo.localUri,
                coverPhotoId = photo.id,
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    fun movePhotoOrder(photo: AlbumPhoto, up: Boolean) {
        viewModelScope.launch {
            val photos = selectedTripPhotos.value.toList()
            val index = photos.indexOfFirst { it.id == photo.id }
            if (index == -1) return@launch
            val targetIndex = if (up) index - 1 else index + 1
            if (targetIndex in photos.indices) {
                val targetPhoto = photos[targetIndex]
                repository.updatePhoto(photo.copy(displayOrder = targetPhoto.displayOrder, updatedAt = System.currentTimeMillis()))
                repository.updatePhoto(targetPhoto.copy(displayOrder = photo.displayOrder, updatedAt = System.currentTimeMillis()))
            }
        }
    }
}

sealed class Screen {
    object Onboarding : Screen()
    object Home : Screen()
    data class DestinationDetail(val tripId: String) : Screen()
    object CreateTrip : Screen()
    data class AddMemory(val tripId: String) : Screen()
    data class EditMemory(val memoryId: String) : Screen()
    data class MemoryDetail(val memoryId: String) : Screen()
    object Premium : Screen()
    data class Album(val tripId: String) : Screen()
    object SmartJourneyImport : Screen()
    object SmartJourneyDraft : Screen()
    object Capture : Screen()
}
