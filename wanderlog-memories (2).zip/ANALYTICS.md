# ANALYTICS.md

## 1. Purpose
This document establishes our standardized mobile telemetry and analytics tracking framework. Proper analytics logs allow product stakeholders to track engagement rates, measure premium conversion triggers, locate application bottlenecks, and evaluate overall retention.

## 2. Standard Telemetry Categories

### A. Onboarding & Funnels
* `onboarding_started`: Fired when the splash or welcome screen displays.
* `onboarding_page_view`: Tracks which step of the carousel is visible.
* `onboarding_completed`: Fired when the user signs up, sets initial preferences, and lands on the home tab.

### B. Core Feature Engagement
* `resource_created`: Tracks name, category, and options of added assets (e.g., creating a trip or folder).
* `interaction_detail`: Captures user visits to sub-screens or maps.
* `search_performed`: Tracks localized search queries or filtered tags.

### C. Monetization Funnel & Conversion
* `paywall_impression`: Logged when the upgrade modal or premium sub-screen displays. Capture the entry point (e.g., adding a 4th trip, choosing a locked theme).
* `premium_purchase_tapped`: Fired when the "Unlock Premium" button is clicked.
* `premium_purchase_success`: Triggered when the payment gateway confirms subscription activation.
* `premium_purchase_canceled`: Tracks user abandonment on the payment sheets.

### D. System Diagnostics
* `error_boundary_triggered`: Captures system exceptions, database migrations failures, or network timeouts.

## 3. Privacy-Safe Telemetry Rules
* **No PII**: Under no circumstances should Personally Identifiable Information (PII) like names, email addresses, phone numbers, or coordinates be logged inside telemetry payloads.
* **Anonymization**: Use random, rotating UUID values for user analytics identifiers to guarantee compliance with global GDPR standards.
