# PREMIUM.md

## 1. Purpose
This document provides standard technical specifications on implementing premium state controls, managing subscription checks, and configuring usage limits across our applications.

## 2. Technical Standard: SubscriptionConfig Pattern

All applications using this framework must implement a centralized configurable subscription rules engine:

```kotlin
data class SubscriptionLimits(
    val mainResourceLimit: Int,
    val subResourceLimit: Int
)

object SubscriptionConfig {
    val freeLimits = SubscriptionLimits(
        mainResourceLimit = 3,
        subResourceLimit = 5
    )

    val premiumLimits = SubscriptionLimits(
        mainResourceLimit = Int.MAX_VALUE,
        subResourceLimit = Int.MAX_VALUE
    )

    fun getLimits(isPremium: Boolean): SubscriptionLimits {
        return if (isPremium) premiumLimits else freeLimits
    }
}
```

## 3. Implementation Rules

### A. Zero Inline Hardcoded Logic
* **No Inline Values**: Never write inline check statements like `if (items.size > 5)` inside Composable screens. Always evaluate limits against `SubscriptionConfig.getLimits(isPremium)`.
* **Central ViewModel Evaluation**: Screen flows must query repositories and compare current item lists against boundaries in the active configuration object, alerting the `PremiumManager` to show the upgrade modal if boundaries are crossed.

### B. Smooth, Non-Disruptive Purchase Flow
* **StateFlow Triggers**: State engines must monitor purchase results via safe reactive flows (e.g., `PremiumManager.isPremium`).
* **Instant Recomposition**: When a purchase succeeds, the UI must recompose instantly, updating all locked states smoothly without needing a manual app restart.

### C. Luxury Premium Aesthetics
* Upgrading to premium must feel rewarding. The paywall or dialog must utilize elegant typography, high-contrast linear gradients, and a clear grid comparing benefits to build visual delight.
