# Wonderlog Subscription & Monetization Model 💳

Wonderlog uses a highly deliberate, non-intrusive, value-first monetization framework. By providing robust utility for 2-3 travels, the user naturally understands the product's premium value and upgrades naturally at the 4th journey, rather than feeling blocked on day one.

---

## 1. Feature Breakdown by Tier

| Category / Feature | Free Tier | Premium Tier | Why It Drives Conversion |
| :--- | :--- | :--- | :--- |
| **Journeys (Viaggi)** | **3 Journeys** | **Unlimited** | Hits a hard block naturally on the 4th vacation. |
| **Album Photos** | **5 Photos per Journey** | **100 Photos per Journey** | Curating 5 is fun, but real travelers want full galleries. |
| **Memories (Memorie)** | **5 Memories per Journey** | **Unlimited** | Users hit limits after writing memories for 5 days of a trip. |
| **Storage Type** | Local storage only | Secure Cloud Backup (Supabase) | Peace of mind that years of memories are safe. |
| **AI Features (🤖)** | None | Poetic Stories & Captions | Speeds up entry, adds high-perceived intelligence value. |
| **Maps (🗺️)** | Standard online maps | Full Offline Maps | Vital for travelers off-grid with no cellular roaming. |
| **Export Options (📖)** | None | High-Fidelity PDF Book | Creates a tangible, printable travel coffee-table book. |
| **Themes (🎨)** | Standard Light/Dark | Premium Luxury Themes | High visual appeal for Aesthetic Curators. |

---

## 2. Technical Subscription Config Parameters
These limits are managed dynamically in `com.example.premium.SubscriptionConfig` and are **never** hardcoded directly in UI screens:

```kotlin
object SubscriptionConfig {
    val freeLimits = SubscriptionLimits(
        journeysLimit = 3,
        albumPhotosLimit = 5,
        memoriesLimit = 5
    )

    val premiumLimits = SubscriptionLimits(
        journeysLimit = Int.MAX_VALUE,
        albumPhotosLimit = 100,
        memoriesLimit = Int.MAX_VALUE
    )
}
```

---

## 3. Premium Upgrade Prompts UX Rules
To maximize user conversion, Wonderlog follows strict design principles:

### A. Non-Intrusive Locked Indicators
* Show lock badges (e.g., small custom lock icons) on premium theme options, PDF export buttons, and offline map toggles.
* When a user taps a locked item, display the Premium Upgrade Dialog immediately, rather than showing a generic "Not Available" message.

### B. High-Fidelity Comparison Dialog
* Use a beautiful glassmorphic modal containing side-by-side comparative bullet columns.
* Utilize the luxurious **Sunset Gradient** (Orange to Magenta) on the primary "Unlock Unlimited Wanderlust" call-to-action button to command visual attention.
* Trigger a gentle, satisfying haptic success click when the payment is validated and premium is unlocked on-screen.
