# Wonderlog Future Product Expansions 🚀

This document acts as a strategic roadmap for the technical and functional evolution of Wonderlog beyond its initial release phases, ensuring new integrations fit neatly into our modular architecture.

---

## 1. Cloud Continuity with Supabase (Wanderlust 2.0)

To transition from an offline-only local database into a robust cloud-backed system, Wonderlog's architecture is prepared for a **Supabase** backend:

```
                      ┌────────────────────────┐
                      │  WONDERLOG LOCAL APP   │
                      │ (Room SQLite database) │
                      └───────────┬────────────┘
                                  │ Real-time flow
                                  ▼
                      ┌────────────────────────┐
                      │    SUPABASE SDK / API  │
                      │ (GraphQL / REST client)│
                      └───────────┬────────────┘
                                  │ Secure SSL
                                  ▼
                      ┌────────────────────────┐
                      │   SUPABASE POSTGRES    │
                      │ (Single source in cloud)│
                      └────────────────────────┘
```

### Key Migration Steps:
1. **Enable Supabase Auth**: Implement modern, secure OAuth2 and magic-link registration directly into the Settings and Profile flows.
2. **Setup Realtime Sync**: Leverage PostgREST synchronization protocols to replicate local Room tables directly to PostgreSQL schemas.
3. **Storage Buckets**: Link the custom Photo System pipeline to write WebP files to Supabase S3 Storage buckets.

---

## 2. Multi-User Shared Albums

Allow friends, families, or couples to contribute simultaneously to a single chronological itinerary.
* **Challenge**: Handing offline sync conflicts when two users add memories to the same journey at different times.
* **Architecture Solution**: Standardize on Conflict-Free Replicated Data Types (CRDTs) or Last-Write-Wins (LWW) resolution strategies inside our core Repository layers.

---

## 3. Printable Physical Travel Books

Provide users with the ability to turn their digital memory books into beautiful, premium, linen-bound physical coffee-table scrapbooks.
* **Architecture Solution**: Expand the current PDF Export module, configuring layout engines to output high-resolution CMYK print files that match the standard dimensions and guidelines of major printing and shipping API partners.
