# Wonderlog Functional Modules & Features 🛠️

Wonderlog is structured around eleven independent, decoupled, and highly cohesive modules. This ensures maximum code quality, clean separations, and frictionless scalability for future feature sets.

---

## 1. Journey Module
* **Goal**: Manage travel events and container parameters.
* **Core Screens**: Journey List (Dashboard), Create/Edit Journey, Journey Dashboard.
* **Key Actions**:
  * Set destination name, start/end dates, cover image.
  * Auto-calculate total elapsed days.
  * Show beautiful custom-animated empty state if no journeys exist.

---

## 2. Album (Photo) Module
* **Goal**: Provide image ingestion, caching, and curation.
* **Core Screens**: Grid Gallery, Expanded Photo Detail.
* **Key Actions**:
  * Photo Picker multi-selection.
  * Camera capture interface.
  * Real-time metadata (EXIF) extraction for latitude, longitude, and timestamps.
  * WebP compression logic to minimize local disk footprint.

---

## 3. Memory Module
* **Goal**: The emotional core. Capture stories and context.
* **Core Screens**: Add/Edit Memory, Memory Detail View.
* **Key Actions**:
  * Record memory title, date, mood index (Peaceful, Adventurous, Reflective, Lost, Tired, etc.).
  * Input rich text reflections.
  * Save draft states automatically to avoid data loss.

---

## 4. Timeline Module
* **Goal**: Provide a linear chronological story layout of a journey.
* **Core Screens**: Chronological Feed Card Layout.
* **Key Actions**:
  * Staggered media-centric timeline view.
  * Group items dynamically by calendar date.
  * Filter timeline entries by mood tag, location, or search keywords.

---

## 5. Map Module (OpenStreetMap Integration)
* **Goal**: Render geographic routes, markers, and pin clusters.
* **Core Screens**: Journey Interactive Route Map, Global Wanderlust Map.
* **Key Actions**:
  * Draw connected travel routes connecting memories chronologically.
  * Support pin clustering on high-density location nodes.
  * Reverse geocode coordinates to pull local town and country names using Nominatim APIs.
  * Support offline caching maps using OpenStreetMap offline tile engines.

---

## 6. Statistics Module
* **Goal**: Provide analytical travel insights.
* **Core Screens**: Stats Dashboard.
* **Key Actions**:
  * Compute total kilometers traveled across all journeys.
  * Visualize primary emotional states using dynamic Canvas-drawn donut charts.
  * Calculate count of unique cities and countries visited.

---

## 7. AI Module (Gemini Integration)
* **Goal**: Enhance creative journaling via localized AI integrations.
* **Core Screens**: AI Story Assistant, Smart Caption Generator.
* **Key Actions**:
  * **AI Journal**: Synthesize simple bullet notes into premium travel stories.
  * **AI Captions**: Suggest beautiful emotional caption texts for curated photos.
  * **AI Duplicate Detector**: Scan newly added images to find and filter out duplicate or blurry shots.

---

## 8. Premium Module
* **Goal**: Enforce application business rules and subscription purchases.
* **Core Screens**: Luxury Glassmorphic Upgrade Paywall.
* **Key Actions**:
  * Central limit evaluations matching constraints declared in `SubscriptionConfig`.
  * Manage active premium status (`isPremium: Boolean`).
  * Process purchases with Google Play Billing / RevenueCat.

---

## 9. Search & Filter Module
* **Goal**: Fast retrieval of past memories.
* **Core Screens**: Filter Panel.
* **Key Actions**:
  * Full-text search querying SQLite databases directly.
  * Multi-tag filtering matching specific mood indexes and calendar years.

---

## 10. Settings Module
* **Goal**: Core app controls and customization.
* **Core Screens**: Settings Sheet.
* **Key Actions**:
  * Swap premium themes (Cosmic Dark, Warm Sunset, Lavender Fog).
  * Purge local databases, trigger manually forced cloud syncs.
  * Adjust photo compression quality levels.

---

## 11. Profile & Statistics Module
* **Goal**: Reflect the user's travel legacy.
* **Core Screens**: Personal Travel Passport.
* **Key Actions**:
  * Show summary statistics (total journeys, memories, countries, lifetime stamps).
  * Display a beautiful visual passport layout where each country visited receives a unique custom-designed visual stamp.
