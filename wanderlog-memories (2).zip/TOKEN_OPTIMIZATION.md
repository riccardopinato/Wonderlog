# TOKEN_OPTIMIZATION.md

## 1. Purpose
This document provides specific instructions for AI Agents to optimize workspace token usage, ensuring blazing-fast response times, clear communications, and highly economical API transactions.

## 2. Token-Saving Rules for AI Agents

### Rule 1: Surgical File Inspection
* **Only View What's Vital**: Do not perform broad, non-selective file scans. Call `view_file` only on lines directly related to the modification scope.
* **Target Line Ranges**: Use line ranges (e.g., `StartLine` and `EndLine`) instead of displaying massive class files.

### Rule 2: Minimal Explanations
* **Less Talk, More Code**: Keep technical justifications conversational, objective, and short. Skip lengthy greetings, sales pitches, or repetitive planning notes between incremental edits.
* **Proportional Summaries**: For simple updates, keep final overviews to 1-2 quick paragraphs.

### Rule 3: Avoid Redundant Audits
* Only perform system audits, architectural cleanups, or code-standard sweeps if explicitly asked by the user. Do not waste context bandwidth refactoring stable code.

### Rule 4: Context Preservation in Edits
* Ensure target patterns inside `edit_file` calls are highly precise, short, and distinct.
* Avoid replacing entire file contents with new blocks when a simple contiguous edit of 5 lines is sufficient.
