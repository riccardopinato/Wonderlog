# DESIGN_SYSTEM.md

## 1. Purpose
This document specifies our premium mobile Design System framework. Functional applications are not enough; our product must feel incredibly polished, modern, tactile, and luxurious to use. We use Material 3 as a baseline technical container, but customize typography, gradients, glassmorphism, and transitions to produce a highly distinctive visual identity.

## 2. Core Aesthetic Pillars

### A. Colors & High-Contrast Gradients
* **Core Base**: Deep neutral slate tones (`0xFF0F172A`, `0xFF1E293B`) to establish rich visual density and eye-safe background structures.
* **Premium Accents**: Rich luxury gradients (e.g., Cherry-to-Orange gradients, Cosmic purples, Lavender and Peach watercolors) applied to high-importance actionable items like upgrade triggers and call-to-actions.
* **Semantic Colors**: Emerald Green for Success, Crimson Red for Errors, Amber Yellow for Warnings.

### B. Typography Hierarchy
* **Headings**: Use elegant Serif or Geometric Sans-serif display families with custom letter-spacing to build architectural hierarchy.
* **Body / Meta**: Use crisp, highly legible monospaced or modern sans-serif fonts (e.g., JetBrains Mono, Inter) to maximize scanning comprehension.

### C. Glassmorphism & Translucency
To deliver an iOS-inspired, premium layer effect, implement semi-translucent glass containers (GlassCards):
* Background blur and color opacity (e.g., `Color.White.copy(alpha = 0.5f)`).
* Semi-translucent light borders (e.g., `BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))`).
* Delicate drop shadows (`shadow(elevation = 6.dp, shape = RoundedCornerShape(24.dp))`).

### D. Tactile Interaction & Haptics
* Add Material ripples (`rememberRipple()`) to all clickable areas.
* Standardize touch targets to at least **48.dp x 48.dp**.
* Provide subtle haptic feedback triggers (e.g., `LocalHapticFeedback.current.performHapticFeedback()`) upon key interactions like successful saving, premium unlocking, or toggle transitions.

### E. Motion & Fluid Transitions
* Avoid static state changes. Wrap list additions, layout expands, and sheet visibility in AnimatedVisibility, Crossfade, or spring-based animateDpAsState animations.
* Apply subtle parallax scrolling transitions to background wallpapers or onboarding graphics to establish perceived depth.

## 3. Standard UI Components

### 1. Primary Premium Button
* Rounded pill shape (20.dp to 24.dp corner radius).
* Gradient filled background.
* Prominent visual elevation shadow.

### 2. Glass Cards (Containers)
* Used to display grouped information elements (e.g., individual memories, statistics, or list items) without producing heavy visual noise.

### 3. Glass Floating Bottom Navigation
* Floating glass navigation bar anchored above the bottom screen insets with soft border stroke, background blurring, and active-state high-contrast tinting.

## 4. Accessibility & Semantics
* Never use decorative items with missing `contentDescription` properties.
* Ensure clear color contrast ratios (at least 4.5:1) for all user-facing content strings.
