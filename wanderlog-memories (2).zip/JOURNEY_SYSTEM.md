# Wonderlog Journey System 🧭

A Journey is the macro-level container of a user's travel experience. In Wonderlog, journeys behave like physical visual books, collecting memories, statistics, and coordinates to form cohesive chapters of a user's travel history.

---

## 1. Journey Model Structure

```kotlin
data class Journey(
    val id: String,               // UUID string
    val title: String,            // Title: "Roaming Andalusía"
    val destination: String,      // Destination: "Spain"
    val startDate: Long,          // Epoch timestamp
    val endDate: Long,            // Epoch timestamp
    val coverPhotoPath: String?,  // Path to local WebP cover image
    val isPremiumTheme: Boolean,  // Flag for luxury theme layout
    val themeName: String         // Selected custom aesthetic theme name
)
```

---

## 2. Dynamic Journey Statistics (Auto-Calculated)
Instead of forcing the user to input statistical data, the Journey Module automatically computes insights by querying related database models in real-time:

* **Duration**: Auto-calculate difference between `startDate` and `endDate` in days.
* **Geographic Spread**: Count of unique `locationName` values linked to memories inside the journey.
* **Emotional Dominance**: Analyzes the mood tags of all memories inside the journey, returning the most frequent mood (e.g., *"This journey was primarily Adventurous"*).
* **Media Volume**: Total count of images in the album.

---

## 3. Empty State Design Guidelines
The first impression of a journey workspace sets the emotional tone of the application.
* **The Problem**: A blank screen with a grey "+" icon feels sterile and administrative.
* **The Solution**: Render a beautiful watercolor canvas with a fading hero banner, paired with inviting, emotional copy:
  * *"Where is your heart wandering? Touch below to capture your first memory in Venice."*
  * Followed by a smooth, spring-animated floating action button (FAB) that draws the user's attention.
