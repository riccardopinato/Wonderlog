# Wonderlog Product Structure 📦

## 1. Core Architecture Model (Containment Hierarchy)

In Wonderlog, data is strictly organized around a hierarchical cascade to ensure logical cohesion and zero orphan records:

```
┌────────────────────────────────────────────────────────┐
│                        JOURNEY                         │
│ (Container: Destination, Start/End Dates, Cover Photo) │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                         ALBUM                          │
│     (Curated photo gallery linked to the journey)       │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                         MEMORY                         │
│  (Emotional Heart: Title, Date, Mood, Text Reflection) │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                        LOCATION                        │
│ (Geographic anchor: Lat/Lng, Map Marker, Town Name)    │
└────────────────────────────────────────────────────────┘
```

---

## 2. Core Components Defined

### A. Journey (The Container)
* **Definition**: A distinct travel event with a defined destination (e.g., "Sailing in Greece 2026"), starting and ending dates, an elegant cover image, and metadata statistics.
* **Database Representation**: `JourneyEntity`.

### B. Album (The Gallery)
* **Definition**: A collection of high-fidelity, compressed, locally cached travel photos curated by the user during the journey. Under the hood, photos are linked to specific journeys and/or specific memories.
* **Database Representation**: `PhotoEntity`.

### C. Memory (The Heart)
* **Definition**: The primary entry point of emotional expression. Includes a bold title, a calendar date, a specific emotional mood tag (e.g., Inspired, Peaceful, Lost, Nostalgic), and a rich prose reflection block.
* **Database Representation**: `MemoryEntity`.

### D. Location (The Map Coordinate)
* **Definition**: A latitude and longitude coordinate associated with a memory. Used by the OpenStreetMap engine to render interactive map paths and pin clusters.
* **Database Representation**: Embedded inside `MemoryEntity` or as `LocationCoordinateEntity`.

### E. Statistics & Analytics
* **Definition**: Auto-calculated journey insights (e.g., total kilometers traveled, primary mood registered, number of memories compiled, count of cities visited).
* **UI Representation**: Minimalist, card-based stats dashboard.

---

## 3. Product Guardrails & Scope Boundaries

* **No Bulk Photo Uploads**: Users cannot select 500 photos and upload them raw. They must select meaningful photos and associate them with a curated album or specific memories.
* **Automatic Exif Geocoding**: When importing a photo, the app automatically extracts GPS coordinates from the EXIF metadata to suggest the pin location, saving the user from tedious manual coordinate lookup.
* **Editable Draft States**: Every AI story or caption starts as an editable draft. The user always maintains creative control over what is saved.
