# SECURITY.md

## 1. Purpose
This document defines security and privacy specifications that must be implemented in all products built using this framework. Ensuring user trust, protecting private data, and securing server integrations are core pillars of our engineering principles.

## 2. Security Directives

### A. Zero Secret Commits
* **Secrets Gradle Plugin**: Securely inject API keys, endpoint configurations, and connection credentials at build time via `BuildConfig`.
* **Ignore Secrets**: Ensure all local secret files (like `.env`, `local.properties`, private keystores) are added to `.gitignore` to prevent committing them to Git history.

### B. Secure Storage of Sensitive Data
* **EncryptedSharedPreferences**: Use Jetpack Security components (EncryptedSharedPreferences) for writing authorization tokens, subscription receipts, or private user configs on the local disk.
* **Database Encryption**: Utilize SQLCipher wrappers on Room databases if the app holds extremely sensitive or compliance-restricted personal data.

### C. Permissions Minimization
* **Least Privilege**: Only request system permissions that are absolutely vital to the features currently active.
* **Explain & Request**: Implement dynamic, user-friendly request flows in Jetpack Compose explaining *why* a permission is needed before triggering the Android system authorization sheet.

### D. User Privacy & GDPR Compliance
* **Data Minimization**: Avoid storing unnecessary personal telemetry or sensitive demographics.
* **Local Option**: Enable users to purge their local database, clear cache files, and completely opt out of telemetry or background synchronization.
* **HTTPS Transport**: Ensure all remote connections require strict HTTPS configurations with modern TLS cipher suites and standard SSL pinning if required.
