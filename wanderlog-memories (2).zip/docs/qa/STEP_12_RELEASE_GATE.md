# Wonderlog — Step 12 Release Gate Checklist & Validation Report

## 1. Release Build Hardening
- **ProGuard / R8 Rules (`app/proguard-rules.pro`)**:
  - Enforces line numbers and source attributes for obfuscated crash traces (`SourceFile`, `LineNumberTable`).
  - Keeps Kotlin Serialization serializers, Moshi generated adapters, Retrofit annotations, and Room database implementations.
  - Keeps Android Parcelable `CREATOR` instances without wildcard-keeping domain packages.
- **Gradle Release Build Type (`app/build.gradle.kts`)**:
  - `isMinifyEnabled = true`
  - `isShrinkResources = true`
  - `isDebuggable = false`
  - Fully decoupled from Firebase runtime dependencies.
- **Android Auto Backup Disabled (`AndroidManifest.xml`)**:
  - `android:allowBackup="false"` to prevent unencrypted cloud backups of local SQLite / private auth tokens.
- **App Branding (`strings.xml` & `metadata.json`)**:
  - Verified `app_name` set to `Wonderlog`.
  - Platform metadata set to `Wonderlog`.

## 2. Photo Engine Hardening
- **Memory-Safe Bitmap Sampling (`com.example.storage.BitmapSampling`)**:
  - Calculates power-of-two `inSampleSize` based on target max dimensions.
  - Master full-size images scaled to max dimension `1600px`.
  - Thumbnails scaled to max dimension `320px`.
- **Isolated EXIF Reader (`com.example.storage.PhotoMetadataReader`)**:
  - Reads timestamp and GPS coordinates via stream input without decoding entire bitmaps.
  - Safe error recovery returning `PhotoSourceMetadata` defaults upon malformed files.
- **Album Import Hardening (`com.example.storage.AlbumPhotoManager`)**:
  - Streamlined pipeline using `PhotoMetadataReader` and `BitmapSampling`.
  - Automatic duplicate checks and reverse geocoding with custom application identity.

## 3. Unified Network Identity
- **Centralized Identity (`com.example.network.WonderlogNetworkIdentity`)**:
  - Constant User-Agent header: `Wonderlog/1.0 Android`.
  - Constant Accept-Language header: `en`.
  - Adopted across `AlbumPhotoManager`, `ExifMetadataReader`, `LocationSearchService`, and `OpenStreetMapRepository`.
  - All developer email references removed from HTTP headers.

## 4. Cloud Backup Hardening
- **Retry & Classification (`com.example.network.NetworkResultClassifier`)**:
  - Distinguishes transient network errors (`SocketTimeoutException`, `UnknownHostException`, `IOException`) from non-retryable errors.
- **Worker Hardening (`com.example.cloud.CloudBackupWorker`)**:
  - Validates active authentication and user preferences before sync.
  - Uses `NetworkResultClassifier` to retry transient failures and fail permanently on fatal errors.
  - Caps maximum retry count at 5 attempts.
- **Scheduler Safeguards (`CloudBackupScheduler` & `SharedPreferencesCloudBackupSettingsRepository`)**:
  - Minimum periodic backup interval enforced to 6 hours (`coerceAtLeast(6L)`).
  - WorkManager exponential backoff configured.
- **Cloud Gate (`com.example.cloud.CloudSyncGuard`)**:
  - Pre-flight authorization ensuring only authenticated premium users can trigger cloud backup and restore.

## 5. Automated Test Matrix
- `DatabaseMigrationTest`: Validates Room version transitions.
- `CloudIdFactoryTest`: Asserts deterministic UUID generation and entity namespace uniqueness.
- `CloudMergeEngineTest`: Asserts conflict resolution rules (inserts, updates, local preservation, conflicts, tombstones).
- `PremiumGateTest`: Verifies feature gating for free vs. premium accounts.
- `BitmapSamplingTest`: Verifies power-of-two image downscaling boundaries.
- `CloudSyncGuardTest`: Verifies state combinations for cloud operations.
- `SubscriptionConfigTest`: Verifies default subscription constants and identifiers.

## 6. Pre-AAB Device Verification Checklist
1. **Fresh Install Test**: Install APK on clean device, create trip, add memories, and verify album creation.
2. **Offline Photo Import**: Import high-resolution (>12MP) images in airplane mode to verify out-of-memory avoidance.
3. **Location Search & Geocoding**: Search for places while connected to verify OSM Nominatim responses with `Wonderlog/1.0 Android`.
4. **Subscription Paywall Flow**: Verify that RevenueCat loads real store packages and handles purchase / restore gracefully.
5. **Supabase Auth & Backup**: Sign in with an account, enable automatic backup, and verify WorkManager schedule execution.
6. **R8 Obfuscation Run**: Launch the release build (`assembleRelease`), verify no missing reflection class crashes.
