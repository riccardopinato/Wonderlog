# Wonderlog Design Language & Visual System 🎨

Wonderlog rejects standard, flat Android Material Design defaults. We aim to construct an **iPhone-inspired luxury travel experience** that feels incredibly polished, tactile, cohesive, and visually beautiful. Our visual system is influenced by premium apps like Apple Journal, Airbnb, Pinterest, and Cosmos.

---

## 1. Visual Pillars & Aesthetic Direction

### A. Deep Cosmic Slate Canvas
* **Backgrounds**: Utilize dark, rich slate and obsidian tones (`0xFF0F172A`, `0xFF1E293B`) combined with radial background watercolor blooms. This provides visual depth and allows photos to stand out vibrantly.
* **Containers (Glassmorphic Cards)**:
  * Soft translucent background fill: `Color.White.copy(alpha = 0.08f)`.
  * Multi-layer shadow effects: `shadow(elevation = 8.dp, shape = RoundedCornerShape(24.dp))`.
  * Delicate semi-translucent borders to simulate glass sheen: `BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))`.

### B. Dynamic Watercolor Gradients
To highlight high-perceived value elements (such as premium prompts, active filters, and save buttons), we use custom linear gradients:
* **Sunset Horizon**: `Brush.linearGradient(listOf(Color(0xFFF43F5E), Color(0xFFFB923C)))` (Rose to Orange).
* **Aurora Borealis**: `Brush.linearGradient(listOf(Color(0xFF2DD4BF), Color(0xFF818CF8)))` (Teal to Blue-Purple).

### C. Elegant Geometric Typography
* **Display Headers**: Pair distinct, widely-spaced display headings (Geometric Sans-Serif or Serif) with substantial negative space to create an editorial feel.
* **Body & Indicators**: Use monospaced fonts (e.g., JetBrains Mono) for status indicators, date labels, and statistics to maximize visual scanning and maintain design consistency.

---

## 2. Microinteractions & Animation Systems

### A. Spring-Driven Layout Transitions
* Avoid harsh layout shifts or blinking lists. Wrap all expand/collapse states, cards, and modal sheets in spring-based Compose animations (`spring(stiffness = Spring.StiffnessLow)`).
* Stagger list item entries with a 50ms sequential delay to create a cascading entrance ripple.

### B. Tactile Haptic Feedback
* Standardize tactile interaction clicks. Trigger subtle haptic vibrations (`LocalHapticFeedback.current.performHapticFeedback()`) upon key user actions:
  * Successful database save events.
  * Accessing locked premium previews.
  * Toggling emotional mood icons.

---

## 3. Empty State Design Pattern
A dry empty list is a design failure.
* All empty states must display a customized, translucent vector illustration paired with clean, emotionally-rich copy and a prominent spring-animated action button.
* *Example Copy*: *"No memories in Tokyo yet. Tap below to capture your first story."*
