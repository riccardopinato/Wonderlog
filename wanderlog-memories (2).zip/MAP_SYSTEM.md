# Wonderlog Map System Architecture 🗺️

Wonderlog uses **OpenStreetMap (OSM)** as its primary mapping engine. By choosing OSM, we guarantee absolute local privacy, offline map caching, and avoid the commercial dependencies and API cost structures of Google Maps.

---

## 1. Map System Components

```
┌────────────────────────────────────────────────────────┐
│                      MAP WIDGET                        │
│ (Compose wrapper over osmdroid / MapView tile rendering)│
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                   PROVIDER INTERFACE                   │
│ (Abstract MapProvider: plots paths, renders markers)   │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                      REVERSE GEOCODER                  │
│ (Nominatim API: Translates Lat/Lng to City, Country)   │
└────────────────────────────────────────────────────────┘
```

---

## 2. Core Mapping Features

### A. Chronological Journey Routing
* When displaying a Journey Map, extract all memories containing coordinates, sorting them chronologically.
* Render interactive map pins on coordinate nodes and draw a continuous, visual route path (Polyline) connecting them to trace the physical path of the traveler.

### B. Pin Clustering
* On high-density location nodes (e.g., several memories written around Tokyo), cluster pins dynamically into single clustered groups, expanding into individual markers upon pinch-to-zoom gestures.

### C. Reverse Geocoding with Nominatim
* To avoid manual user text entry, coordinates are resolved via Nominatim HTTP APIs:
  ```kotlin
  interface GeocoderService {
      @GET("reverse?format=json")
      suspend fun reverseGeocode(
          @Query("lat") lat: Double,
          @Query("lon") lon: Double
      ): Response<GeocodeResponseDTO>
  }
  ```
* Map results are mapped to pure domain models, extraction only the essential town, city, or country name (e.g., *"Florence, Italy"*).

---

## 3. Offline Maps Strategy (Premium Tier)
* **On-Demand Cache Pre-download**: Allow premium users to choose a region and pre-download map tiles before departure.
* **Storage**: Cache downloaded tiles in an internal device database or folder. Set the OSM library to query local cache files first, ensuring fluid, zero-network rendering during off-grid travels.
