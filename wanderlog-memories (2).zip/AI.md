# AI.md

## 1. Purpose
This document specifies standard guidelines for integrating Artificial Intelligence (AI) models and generative capabilities into our mobile products.

## 2. AI Integration Rules

### A. Core UX Over AI Dependency
* **Core Value Remains Pure**: AI features must serve as visual enhancers or productivity assistants, never as functional bottlenecks. The fundamental usefulness of the app must remain active even without any network connectivity or AI availability.
* **Failures Must Not Block**: If an AI request times out or fails, the application must fallback smoothly to manual user-driven workflows without throwing errors or locking UI components.

### B. Isolate AI Provider Logic
* Avoid hardcoding direct API routes or provider-specific SDK bindings throughout your screens.
* Route generative requests through isolated interfaces, allowing development teams to swap providers (e.g., Gemini, OpenAI, Anthropic, or Local On-Device models) by modifying a single data repository module:

```kotlin
interface GenerativeTextRepository {
    suspend fun generateSummary(input: String): Result<String>
}
```

### C. Generative Content Must Be Editable
* Never treat generated output as static, permanent records.
* Always present generated text (such as travel descriptions, captions, or summaries) inside editable text fields or preview screens, allowing the user to customize or refine the text before committing it to the database.

### D. Graceful Error Handling
* Always display loading animations (like translucent progress indicators) during generative calls.
* Implement default local template fallbacks to guarantee a high-fidelity presentation if a network or quota exception occurs.
