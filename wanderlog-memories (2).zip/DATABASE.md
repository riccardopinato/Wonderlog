# DATABASE.md

## 1. Purpose
This document specifies standard practices for local data persistence using Room and SQLite. Proper database architectures minimize memory footprints, preserve relational integrity, and simplify future migrations.

## 2. Structural Database Guidelines

### A. Entity Definition Standards
* Class naming must clearly reflect storage models (e.g., `MemoryEntity`).
* All entities must use primary key definitions and provide unique UUID strings as identifiers rather than local auto-incrementing integers, making future cloud replication conflict-free.

### B. Relational Integrity & Cascade Rules
* Define explicit foreign key constraints (`ForeignKey`) linking secondary models back to primary records.
* Use `onDelete = ForeignKey.CASCADE` to clean up sub-items automatically and prevent orphan records from bloating storage tables.

### C. Migration Management
* Never alter schema columns without updating the active Database version integer.
* Write structured SQL migrations or declare automated migrations (`@Database(autoMigrations = [...])`) to prevent application crashes when existing users update their apps.

### D. Soft Deletes
* For high-importance tables, use a `deleted` boolean flag rather than executing raw SQL deletes. This enables clean "Undo" actions and prevents sync corruption.

### E. Indexing Strategies
* Apply unique indices on composite keys and foreign keys that are frequently scanned or sorted to accelerate performance.
