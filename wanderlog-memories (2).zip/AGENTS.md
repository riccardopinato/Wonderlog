# AGENTS.md

## 1. Purpose
This document establishes the official AI Agent Operating Model and rules for all present and future AI assistants collaborating on this codebase. It is designed to maximize code quality, architectural consistency, and token efficiency while eliminating over-engineering, logic duplication, and regressions.

## 2. Permanent Core Rules
* **Read-Before-Write**: Always call `view_file` on target files to inspect exact existing imports, code signatures, and formatting before editing. Never assume layout or content.
* **No Code Duplication**: Always look for existing utilities, components, helper functions, and database queries. If logic exists, reuse or adapt it.
* **Preserve Current Functionality**: Unless explicitly ordered to change or remove a feature, keep all existing features fully working. 
* **Minimum Surgical Edits**: Make precise, contiguous edits. Do not rewrite large swaths of code unless a complete structural refactor is explicitly requested.
* **Zero Placeholders**: Never insert placeholders like `// TODO: Implement later` or `// other code remains same` in actual source files. All generated code must be complete and compile-ready.
* **Lint & Compile Verification**: After any code changes, verify using `compile_applet` to ensure there are no compilation errors. Do not ignore linter warnings that can degrade long-term code health.

## 3. Collaboration with Other Documents
* **ARCHITECTURE.md**: Ensure any modified logic complies with the Clean Architecture MVVM/Repository boundary definitions.
* **PROJECT_RULES.md**: Follow strict naming conventions, module structure, and coding standards.
* **TOKEN_OPTIMIZATION.md**: Avoid reading unnecessary files and keep explanations short to conserve workspace token budget.

## 4. Execution Workflow for AI Agents
1. **Analyze Context**: Understand the user request. Identify if a specific "Skill" applies.
2. **Examine files**: List directories and view files to get absolute ground truth on the target code.
3. **Draft Plan**: Outline a concise plan if requested or if the change is highly complex.
4. **Surgical Edit**: Apply changes.
5. **Verify**: Build with `compile_applet`.
6. **Report**: Summarize modified files and outcomes without system-internal IDs or paths.
