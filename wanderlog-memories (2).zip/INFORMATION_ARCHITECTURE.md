# Wonderlog Information Architecture 🗺️

Wonderlog maintains a highly clean, structured, and deep layout model. This ensures quick retrieval, clear separation of states, and intuitive cross-navigation between visual timelines, interactive maps, and memory cards.

---

## 1. App Navigation Structure (Sitemap)

The application flow and screen tree are organized as follows:

```text
/ (Root Application Screen Container)
├── Onboarding / Welcome Carousel (If first launch)
├── Main Bottom Navigation Shell
│   ├── 1. Dashboard Tab (Journeys List)
│   │   ├── Journey Detail Dashboard (Selected Journey)
│   │   │   ├── Timeline Screen (Chronological Card List)
│   │   │   ├── Album Grid Screen (Visual Masonry Grid)
│   │   │   │   └── Full-Screen Image Detail (Pinch-to-zoom)
│   │   │   ├── Journey Map Screen (OSM Paths & Pins)
│   │   │   └── Add/Edit Memory Form
│   │   └── Create Journey Dialog / Sheet
│   │
│   ├── 2. Global Wanderlust Map Tab
│   │   └── Global map plotting every memory across all journeys
│   │
│   ├── 3. Personal Passport Tab (Profile & Statistics)
│   │   ├── Stats Breakdown Card Screen
│   │   ├── Digital Passport Stamps Sheet
│   │   └── Export PDF Travel Book Screen
│   │
│   └── 4. Application Settings Tab
│       ├── Premium Theme Selector
│       ├── Local Backup / Database Purge Settings
│       └── About / Licenses Screen
│
└── Premium Upgrade Sheet / Paywall (Launched as bottom modal or overlay)
```

---

## 2. Key Multi-Screen Transitions & Backstacks

To ensure natural iOS-like visual continuity, Wonderlog strictly manages backstacks and routing paths:

* **Journey Detail Dashboard Entry**: Fades in the journey cover photo from a compact dashboard item to a full-screen parallax header.
* **Adding a Memory within a Journey**: Opens the entry sheet over the active screen context. Upon saving, it returns the backstack to the Journey Timeline, smoothly adding the new element with a spring-staggered insert animation.
* **Paywall Intercept**: The Upgrade paywall is modal. Once purchased, it unlocks premium capabilities inline, allowing the user to resume their interrupted activity (e.g., adding a 6th photo) without resetting the backstack.
