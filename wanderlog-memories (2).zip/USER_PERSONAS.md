# Wonderlog User Personas 👥

Wonderlog is crafted for travelers who prioritize depth, design, and privacy over social validation and automated cloud dumps. Our product decisions are guided by three distinct user personas:

---

## 1. Persona A: The Aesthetic Curator (The "Instagram Rejector")

```
   ┌────────────────────────────────────────────────────────┐
   │  "I want to remember my travels beautifully, but I'm  │
   │  tired of the noisy, public social media hamster wheel."│
   └────────────────────────────────────────────────────────┘
```
* **Name**: Elena, 31, Editorial Designer.
* **Traits**: Creative, privacy-conscious, highly organized, values typography and negative space.
* **Pain Points**:
  * Instagram feels toxic, bloated, and ad-ridden.
  * Apple Photos is a chaotic pile of receipts, work screenshots, and duplicate pictures.
  * Existing journals look clinical, like a technical spreadsheet or a plain database tracker.
* **Motivations for Wonderlog**:
  * Loves the elegant, iOS-inspired glassmorphism and geometric typography.
  * Wants to create a beautiful, private digital coffee-table book of her journeys.
  * Relies on the PDF travel book export to print high-fidelity physical booklets for her shelf.

---

## 2. Persona B: The Emotional Wanderer (The "Slow Traveler")

```
   ┌────────────────────────────────────────────────────────┐
   │  "Travel is a spiritual experience for me. I don't     │
   │  just want to track where I went; I want to save how   │
   │  I felt at that precise corner in Tokyo."             │
   └────────────────────────────────────────────────────────┘
```
* **Name**: Marcus, 26, Freelance Writer & Backpacker.
* **Traits**: Reflective, adventurous, values offline capabilities, spends time in remote/rural regions.
* **Pain Points**:
  * Standard travel apps require continuous internet connections, causing data drainage and battery drain when off-grid.
  * Hard to track emotional states alongside simple geographic maps.
  * Writing long entries on a phone screen can feel tedious.
* **Motivations for Wonderlog**:
  * Relies on the rock-solid Offline-First architecture during remote treks.
  * Uses the Mood Tagging system to chart his emotional journey alongside his GPS coordinates.
  * Leverages the Gemini-powered AI Journal & Caption assistant to turn short notes into poetic, novel-grade descriptions.

---

## 3. Persona C: The Frequent Premium Explorer (The "Subscription Catalyst")

```
   ┌────────────────────────────────────────────────────────┐
   │  "I travel 5-6 times a year. I value premium cloud      │
   │  reliability, offline maps, and absolute security     │
   │  for my multi-year collection of life experiences."     │
   └────────────────────────────────────────────────────────┘
```
* **Name**: David, 42, International Consultant.
* **Traits**: High income, tech-savvy, pragmatic, values efficiency, expects absolute reliability.
* **Pain Points**:
  * Afraid of losing years of memories if his physical device is lost or stolen.
  * Needs quick, reliable data backups that sync across multiple devices seamlessly.
  * Likes visual statistics to look back on his lifetime travel reach.
* **Motivations for Wonderlog**:
  * Quickly exceeds the free 3-journey limit and upgrades to Premium naturally, seeing immediate, long-term value.
  * Relies on secure cloud backup to safeguard thousands of curated photos and locations.
  * Uses the premium offline vector maps to explore new metropolitan cities without cellular roaming.
