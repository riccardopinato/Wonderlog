package com.example.presentation

import com.example.domain.model.*

data class TimelineUiState(
    val days: List<TimelineDay> = emptyList(),
    val sections: List<TimelineSection> = emptyList(),
    val sort: TimelineSort = TimelineSort.OLDEST_FIRST,
    val filter: TimelineFilter = TimelineFilter(),
    val isLoading: Boolean = false,
    val error: String? = null
)

sealed class TimelineEvent {
    data class ChangeSort(val sort: TimelineSort) : TimelineEvent()
    data class SetFilter(val filter: TimelineFilter) : TimelineEvent()
    data class ToggleFavoriteFilter(val onlyFavorites: Boolean) : TimelineEvent()
    data class SelectMoodFilter(val mood: Mood?) : TimelineEvent()
    data class SelectTagFilter(val tag: String?) : TimelineEvent()
    data class SelectLocationFilter(val locationName: String?) : TimelineEvent()
    data class SetDateRangeFilter(val start: String?, val end: String?) : TimelineEvent()
    data class SetPhotoFilter(val hasPhotosOnly: Boolean, val noPhotosOnly: Boolean) : TimelineEvent()
    object ClearFilters : TimelineEvent()
}
