package com.example.storage

import android.graphics.BitmapFactory
import kotlin.math.max

object BitmapSampling {

    fun calculateInSampleSize(
        width: Int,
        height: Int,
        targetMaxDimension: Int
    ): Int {

        if (
            width <= 0 ||
            height <= 0 ||
            targetMaxDimension <= 0
        ) {
            return 1
        }

        val largestDimension =
            max(
                width,
                height
            )

        var sampleSize =
            1

        while (
            largestDimension /
            (sampleSize * 2) >=
            targetMaxDimension
        ) {

            sampleSize *=
                2
        }

        return sampleSize
            .coerceAtLeast(
                1
            )
    }

    fun boundsOptions():
        BitmapFactory.Options {

        return BitmapFactory
            .Options()
            .apply {

                inJustDecodeBounds =
                    true
            }
    }
}
