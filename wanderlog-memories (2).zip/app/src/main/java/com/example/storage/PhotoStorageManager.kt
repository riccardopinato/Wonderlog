package com.example.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object PhotoStorageManager {
    private const val TAG = "PhotoStorageManager"

    /**
     * Copies selected photos from external URIs into private app storage,
     * compressing/downscaling them to prevent OOMs and return the local files' paths.
     */
    suspend fun saveUriToPrivateStorage(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            if (inputStream == null) {
                Log.e(TAG, "Failed to open input stream for URI: $uri")
                return@withContext null
            }

            // Create target subfolder inside files directory
            val storageDir = File(context.filesDir, "wanderlog_memories")
            if (!storageDir.exists()) {
                storageDir.mkdirs()
            }

            // Create unique file name
            val fileName = "img_${UUID.randomUUID()}.jpg"
            val targetFile = File(storageDir, fileName)

            // Read the image as Bitmap to downscale/compress it
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            // First decode bounds only
            BitmapFactory.decodeStream(contentResolver.openInputStream(uri), null, options)
            
            // Calculate scale factor (target max dimension of 1080px for high quality yet optimized size)
            val maxDimension = 1080
            var scale = 1
            if (options.outHeight > maxDimension || options.outWidth > maxDimension) {
                val heightScale = options.outHeight / maxDimension
                val widthScale = options.outWidth / maxDimension
                scale = heightScale.coerceAtLeast(widthScale)
            }

            // Decode the actual downscaled bitmap
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = scale
            }
            val bitmap = BitmapFactory.decodeStream(contentResolver.openInputStream(uri), null, decodeOptions)

            if (bitmap != null) {
                // Save compressed image to target location
                FileOutputStream(targetFile).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
                }
                bitmap.recycle()
                Log.d(TAG, "Successfully saved optimized photo: ${targetFile.absolutePath}")
                return@withContext targetFile.absolutePath
            } else {
                // Fallback: Copy directly if decoding failed
                Log.w(TAG, "Bitmap decoding failed, falling back to direct stream copy")
                FileOutputStream(targetFile).use { outputStream ->
                    val buffer = ByteArray(4 * 1024)
                    var read: Int
                    val fallbackInputStream = contentResolver.openInputStream(uri)
                    if (fallbackInputStream != null) {
                        while (fallbackInputStream.read(buffer).also { read = it } != -1) {
                            outputStream.write(buffer, 0, read)
                        }
                        fallbackInputStream.close()
                    }
                }
                return@withContext targetFile.absolutePath
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving photo to private storage: ${e.message}", e)
            return@withContext null
        }
    }

    /**
     * Saves a captured Bitmap directly into private app storage and returns its file path.
     */
    suspend fun saveBitmapToPrivateStorage(context: Context, bitmap: Bitmap): String? = withContext(Dispatchers.IO) {
        try {
            val storageDir = File(context.filesDir, "wanderlog_memories")
            if (!storageDir.exists()) {
                storageDir.mkdirs()
            }
            val fileName = "img_${UUID.randomUUID()}.jpg"
            val targetFile = File(storageDir, fileName)
            FileOutputStream(targetFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }
            Log.d(TAG, "Successfully saved camera photo bitmap: ${targetFile.absolutePath}")
            return@withContext targetFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Error saving bitmap to private storage: ${e.message}", e)
            return@withContext null
        }
    }

    /**
     * Save multiple selected URIs and return a comma-separated string of saved paths.
     */
    suspend fun saveMultipleUris(context: Context, uris: List<Uri>): List<String> {
        val savedPaths = mutableListOf<String>()
        for (uri in uris) {
            val path = saveUriToPrivateStorage(context, uri)
            if (path != null) {
                savedPaths.add(path)
            }
        }
        return savedPaths
    }
}
