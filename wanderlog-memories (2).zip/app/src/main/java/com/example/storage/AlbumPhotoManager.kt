package com.example.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.example.domain.model.AlbumPhoto
import com.example.network.WonderlogNetworkIdentity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class PhotoImportException(val reason: ImportReason, message: String) : Exception(message) {
    enum class ImportReason {
        DUPLICATE,
        UNSUPPORTED_FORMAT,
        STORAGE_FULL,
        FILE_COPY_FAILED,
        CORRUPTED,
        UNKNOWN
    }
}

object AlbumPhotoManager {
    private const val TAG = "AlbumPhotoManager"

    /**
     * Imports a photo from a given system Uri to the private app storage structure:
     * - Original: /journeys/{journeyId}/album/originals/{uuid}.jpg
     * - Thumbnail: /journeys/{journeyId}/album/thumbnails/{uuid}.jpg
     *
     * Then extracts EXIF metadata and attempts reverse geocoding if GPS coordinates are present.
     */
    suspend fun importPhoto(
        context: Context,
        journeyId: String,
        uri: Uri,
        displayOrder: Int,
        existingPhotos: List<AlbumPhoto> = emptyList()
    ): AlbumPhoto? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val sourceMetadata = PhotoMetadataReader.read(
                context = context,
                uri = uri
            )

            // Pre-check size & file name
            var sourceSize = 0L
            var displayName = ""
            try {
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIndex != -1) displayName = cursor.getString(nameIndex) ?: ""
                        if (sizeIndex != -1) sourceSize = cursor.getLong(sizeIndex)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error querying metadata for $uri: ${e.message}")
            }

            if (displayName.isEmpty()) {
                displayName = uri.lastPathSegment ?: "unknown_file.jpg"
            }

            // 1. Duplicate pre-check
            val isPreDuplicate = existingPhotos.any { p ->
                p.originalUri == uri.toString() || 
                (p.fileName == displayName && p.fileSize == sourceSize && sourceSize > 0)
            }
            if (isPreDuplicate) {
                Log.w(TAG, "Duplicate photo detected (pre-check): $displayName")
                throw PhotoImportException(PhotoImportException.ImportReason.DUPLICATE, "Photo is already in this album.")
            }

            // Create target folders
            val originalsDir = File(context.filesDir, "journeys/$journeyId/album/originals")
            val thumbnailsDir = File(context.filesDir, "journeys/$journeyId/album/thumbnails")
            
            if (!originalsDir.exists()) {
                if (!originalsDir.mkdirs()) {
                    throw PhotoImportException(PhotoImportException.ImportReason.FILE_COPY_FAILED, "Failed to create directory for originals.")
                }
            }
            if (!thumbnailsDir.exists()) {
                if (!thumbnailsDir.mkdirs()) {
                    throw PhotoImportException(PhotoImportException.ImportReason.FILE_COPY_FAILED, "Failed to create directory for thumbnails.")
                }
            }

            val photoId = "photo_${UUID.randomUUID()}"
            val fileName = "$photoId.jpg"
            
            val originalFile = File(originalsDir, fileName)
            val thumbnailFile = File(thumbnailsDir, fileName)

            // 2. Format & Integrity Check
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, options)
                }
            } catch (e: Exception) {
                throw PhotoImportException(PhotoImportException.ImportReason.CORRUPTED, "Failed to decode photo headers: ${e.message}")
            }

            if (options.outMimeType == null) {
                throw PhotoImportException(PhotoImportException.ImportReason.UNSUPPORTED_FORMAT, "Unsupported image format or corrupted file.")
            }

            val sampleSize = BitmapSampling.calculateInSampleSize(
                width = options.outWidth,
                height = options.outHeight,
                targetMaxDimension = 1600
            )

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val originalBitmap = try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, decodeOptions)
                }
            } catch (e: OutOfMemoryError) {
                try {
                    val largerOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize * 2 }
                    contentResolver.openInputStream(uri)?.use { stream ->
                        BitmapFactory.decodeStream(stream, null, largerOptions)
                    }
                } catch (e2: Exception) {
                    null
                }
            } catch (e: Exception) {
                null
            }

            if (originalBitmap == null) {
                throw PhotoImportException(PhotoImportException.ImportReason.CORRUPTED, "Failed to decode full-size photo.")
            }

            // Save Original with Storage Full checks
            try {
                FileOutputStream(originalFile).use { out ->
                    if (!originalBitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)) {
                        throw PhotoImportException(PhotoImportException.ImportReason.FILE_COPY_FAILED, "Failed to compress original image.")
                    }
                }
            } catch (e: java.io.IOException) {
                if (e.message?.contains("No space") == true) {
                    throw PhotoImportException(PhotoImportException.ImportReason.STORAGE_FULL, "Device storage is full.")
                }
                throw PhotoImportException(PhotoImportException.ImportReason.FILE_COPY_FAILED, "Failed to write image to disk: ${e.message}")
            }

            // 3. Generate and Save Thumbnail (Target max dimension 320px)
            val thumbSampleSize = BitmapSampling.calculateInSampleSize(
                width = options.outWidth,
                height = options.outHeight,
                targetMaxDimension = 320
            )
            val thumbOptions = BitmapFactory.Options().apply { inSampleSize = thumbSampleSize }
            val thumbBitmap = try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, thumbOptions)
                }
            } catch (e: Exception) {
                null
            }

            if (thumbBitmap != null) {
                try {
                    FileOutputStream(thumbnailFile).use { out ->
                        thumbBitmap.compress(Bitmap.CompressFormat.JPEG, 75, out)
                    }
                } catch (e: java.io.IOException) {
                    originalFile.copyTo(thumbnailFile, overwrite = true)
                } finally {
                    thumbBitmap.recycle()
                }
            } else {
                try {
                    originalFile.copyTo(thumbnailFile, overwrite = true)
                } catch (e: Exception) {
                    throw PhotoImportException(PhotoImportException.ImportReason.FILE_COPY_FAILED, "Failed to create thumbnail.")
                }
            }

            // Get file metadata
            val fileSize = originalFile.length()
            val finalWidth = originalBitmap.width
            val finalHeight = originalBitmap.height
            originalBitmap.recycle()

            // 4. Source EXIF Metadata
            var capturedAt = sourceMetadata.capturedAt
            var latitude = sourceMetadata.latitude
            var longitude = sourceMetadata.longitude
            var locationName = ""

            // 5. Deep duplicate check (date + dimensions)
            val isDeepDuplicate = existingPhotos.any { p ->
                capturedAt != null && p.capturedAt == capturedAt && p.width == finalWidth && p.height == finalHeight
            }
            if (isDeepDuplicate) {
                originalFile.delete()
                thumbnailFile.delete()
                throw PhotoImportException(PhotoImportException.ImportReason.DUPLICATE, "A photo with the same timestamp and dimensions already exists.")
            }

            // 6. Reverse Geocoding with OpenStreetMap Nominatim
            if (latitude != null && longitude != null) {
                locationName = reverseGeocode(latitude, longitude)
            }

            // Build complete AlbumPhoto model
            val now = System.currentTimeMillis()
            val mimeType = "image/jpeg"

            return@withContext AlbumPhoto(
                id = photoId,
                journeyId = journeyId,
                localUri = originalFile.absolutePath,
                thumbnailUri = thumbnailFile.absolutePath,
                originalUri = originalFile.absolutePath,
                fileName = displayName,
                mimeType = mimeType,
                width = finalWidth,
                height = finalHeight,
                fileSize = fileSize,
                createdAt = now,
                updatedAt = now,
                capturedAt = capturedAt ?: now,
                gpsLatitude = latitude,
                gpsLongitude = longitude,
                locationName = locationName,
                favorite = false,
                isCoverPhoto = false,
                displayOrder = displayOrder,
                syncStatus = "LOCAL_ONLY",
                futureCloudId = null
            )
        } catch (pie: PhotoImportException) {
            throw pie
        } catch (e: Exception) {
            Log.e(TAG, "Error importing photo: ${e.message}", e)
            throw PhotoImportException(PhotoImportException.ImportReason.UNKNOWN, e.message ?: "Unknown import error.")
        }
    }

    /**
     * Reverse geocoding using Nominatim.
     */
    private suspend fun reverseGeocode(latitude: Double, longitude: Double): String = withContext(Dispatchers.IO) {
        try {
            val urlString = "https://nominatim.openstreetmap.org/reverse?format=json&lat=$latitude&lon=$longitude&zoom=14"
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("User-Agent", WonderlogNetworkIdentity.USER_AGENT)
            }

            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val json = connection.inputStream.bufferedReader().use { it.readText() }
                
                // Simple high-speed robust regex parsers to avoid extra dependencies
                val city = extractFromJson(json, "city")
                    ?: extractFromJson(json, "town")
                    ?: extractFromJson(json, "village")
                    ?: extractFromJson(json, "suburb")
                    ?: extractFromJson(json, "county")

                val country = extractFromJson(json, "country")

                return@withContext when {
                    city != null && country != null -> "$city, $country"
                    city != null -> city
                    country != null -> country
                    else -> {
                        // fallback to a shortened display_name
                        val displayName = extractFromJson(json, "display_name")
                        if (displayName != null) {
                            val parts = displayName.split(",")
                            if (parts.size >= 2) {
                                "${parts[0].trim()}, ${parts[parts.size - 1].trim()}"
                            } else {
                                displayName
                            }
                        } else ""
                    }
                }
            }
            ""
        } catch (e: Exception) {
            Log.e(TAG, "Reverse geocoding failed: ${e.message}")
            ""
        }
    }

    private fun extractFromJson(json: String, key: String): String? {
        // Looks for "key":"value" or "key": "value"
        val regex = "\"$key\"\\s*:\\s*\"([^\"]+)\"".toRegex()
        return regex.find(json)?.groupValues?.get(1)
    }
}
