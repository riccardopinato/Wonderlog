package com.example.storage

import android.content.Context
import android.media.ExifInterface
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

object PhotoMetadataReader {

    suspend fun read(
        context: Context,
        uri: Uri
    ): PhotoSourceMetadata =
        withContext(
            Dispatchers.IO
        ) {

            runCatching {

                context
                    .contentResolver
                    .openInputStream(
                        uri
                    )
                    ?.use {
                        input ->

                        val exif =
                            ExifInterface(
                                input
                            )

                        val capturedAt =
                            readTimestamp(
                                exif
                            )

                        val coordinates =
                            readCoordinates(
                                exif
                            )

                        PhotoSourceMetadata(
                            capturedAt =
                                capturedAt,

                            latitude =
                                coordinates
                                    ?.first,

                            longitude =
                                coordinates
                                    ?.second
                        )
                    }
                    ?: PhotoSourceMetadata()

            }.getOrElse {

                PhotoSourceMetadata()
            }
        }

    private fun readTimestamp(
        exif: ExifInterface
    ): Long? {

        val raw =
            exif.getAttribute(
                ExifInterface
                    .TAG_DATETIME_ORIGINAL
            )
                ?: exif.getAttribute(
                    ExifInterface
                        .TAG_DATETIME_DIGITIZED
                )
                ?: exif.getAttribute(
                    ExifInterface
                        .TAG_DATETIME
                )
                ?: return null

        return runCatching {

            SimpleDateFormat(
                "yyyy:MM:dd HH:mm:ss",
                Locale.US
            )
                .apply {
                    isLenient =
                        false
                }
                .parse(
                    raw
                )
                ?.time

        }.getOrNull()
    }

    private fun readCoordinates(
        exif: ExifInterface
    ): Pair<Double, Double>? {

        val coordinates =
            FloatArray(2)

        if (
            !exif.getLatLong(
                coordinates
            )
        ) {
            return null
        }

        return Pair(
            coordinates[0]
                .toDouble(),

            coordinates[1]
                .toDouble()
        )
    }
}
