package com.example.storage

data class PhotoSourceMetadata(
    val capturedAt: Long? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)
