package com.example.export

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PdfExportViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository:
        PdfExportRepository =
        AndroidPdfExportRepository(
            application
        )

    private val _state =
        MutableStateFlow<PdfExportState>(
            PdfExportState.Idle
        )

    val state:
        StateFlow<PdfExportState> =
        _state.asStateFlow()

    fun export(
        data: JourneyExportData,
        options: PdfExportOptions =
            PdfExportOptions()
    ) {

        if (
            _state.value is
                PdfExportState.Exporting
        ) {
            return
        }

        viewModelScope.launch {

            _state.value =
                PdfExportState.Preparing()

            _state.value =
                PdfExportState.Exporting(
                    currentPage = 0,
                    totalPagesEstimate =
                        estimatePages(
                            data,
                            options
                        )
                )

            repository
                .exportJourney(
                    data,
                    options
                )
                .onSuccess { result ->

                    _state.value =
                        PdfExportState.Success(
                            result
                        )
                }
                .onFailure { error ->

                    _state.value =
                        PdfExportState.Error(
                            error.message
                                ?: "PDF export failed."
                        )
                }
        }
    }

    fun reset() {

        _state.value =
            PdfExportState.Idle
    }

    private fun estimatePages(
        data: JourneyExportData,
        options: PdfExportOptions
    ): Int {

        var pages =
            0

        if (
            options.includeCover
        ) {
            pages++
        }

        if (
            options.includeJourneyDescription &&
            data.description.isNotBlank()
        ) {
            pages++
        }

        if (
            options.includeMemories
        ) {
            pages +=
                data.memories.size
        }

        if (
            options.includeAlbumPhotos
        ) {

            pages +=
                (
                    data.photos.size +
                        3
                    ) / 4
        }

        return pages
            .coerceAtLeast(1)
    }
}
