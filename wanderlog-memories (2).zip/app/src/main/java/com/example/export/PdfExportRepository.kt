package com.example.export

interface PdfExportRepository {

    suspend fun exportJourney(
        data: JourneyExportData,
        options: PdfExportOptions
    ): Result<PdfExportResult>
}
