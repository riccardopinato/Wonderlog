package com.example.export

sealed interface PdfExportState {

    data object Idle :
        PdfExportState

    data class Preparing(
        val message: String = "Preparing your travel book…"
    ) : PdfExportState

    data class Exporting(
        val currentPage: Int,
        val totalPagesEstimate: Int?
    ) : PdfExportState

    data class Success(
        val result: PdfExportResult
    ) : PdfExportState

    data class Error(
        val message: String
    ) : PdfExportState
}
