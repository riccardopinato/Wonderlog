package com.example.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class AndroidPdfExportRepository(
    private val context: Context
) : PdfExportRepository {

    override suspend fun exportJourney(
        data: JourneyExportData,
        options: PdfExportOptions
    ): Result<PdfExportResult> =
        withContext(Dispatchers.IO) {

            runCatching {

                val document =
                    PdfDocument()

                var pageNumber = 1

                if (options.includeCover) {

                    drawCoverPage(
                        document = document,
                        pageNumber = pageNumber++,
                        data = data,
                        options = options
                    )
                }

                if (
                    options.includeJourneyDescription &&
                    data.description.isNotBlank()
                ) {

                    drawIntroductionPage(
                        document = document,
                        pageNumber = pageNumber++,
                        data = data,
                        options = options
                    )
                }

                if (options.includeMemories) {

                    data.memories.forEach { memory ->

                        drawMemoryPage(
                            document = document,
                            pageNumber = pageNumber++,
                            memory = memory,
                            data = data,
                            options = options
                        )
                    }
                }

                if (
                    options.includeAlbumPhotos &&
                    data.photos.isNotEmpty()
                ) {

                    data.photos
                        .chunked(4)
                        .forEach { photos ->

                            drawAlbumPage(
                                document = document,
                                pageNumber = pageNumber++,
                                photos = photos,
                                options = options
                            )
                        }
                }

                val outputDirectory =
                    File(
                        context.filesDir,
                        "exports"
                    ).apply {
                        mkdirs()
                    }

                val safeTitle =
                    data.title
                        .ifBlank {
                            data.destination
                        }
                        .replace(
                            Regex(
                                "[^a-zA-Z0-9-_ ]"
                            ),
                            ""
                        )
                        .trim()
                        .replace(
                            " ",
                            "_"
                        )
                        .ifBlank {
                            "Journey"
                        }

                val fileName =
                    "${safeTitle}_Wonderlog.pdf"

                val outputFile =
                    File(
                        outputDirectory,
                        fileName
                    )

                FileOutputStream(
                    outputFile
                ).use { output ->

                    document.writeTo(
                        output
                    )
                }

                val finalPageCount =
                    pageNumber - 1

                document.close()

                PdfExportResult(
                    filePath =
                        outputFile.absolutePath,

                    fileName =
                        fileName,

                    pageCount =
                        finalPageCount
                )
            }
        }

    private fun drawCoverPage(
        document: PdfDocument,
        pageNumber: Int,
        data: JourneyExportData,
        options: PdfExportOptions
    ) {

        val page =
            createPage(
                document,
                pageNumber
            )

        val canvas =
            page.canvas

        drawBackground(
            canvas,
            data.accentColorArgb
        )

        data.coverPhotoUri
            ?.let { uri ->

                loadBitmap(uri)
                    ?.let { bitmap ->

                        drawCoverImage(
                            canvas,
                            bitmap
                        )

                        bitmap.recycle()
                    }
            }

        val overlay =
            Paint().apply {
                color =
                    Color.argb(
                        150,
                        0,
                        0,
                        0
                    )
            }

        canvas.drawRect(
            0f,
            PAGE_HEIGHT * 0.46f,
            PAGE_WIDTH.toFloat(),
            PAGE_HEIGHT.toFloat(),
            overlay
        )

        drawText(
            canvas = canvas,
            text = data.destination,
            x = MARGIN,
            y = 560f,
            size = 34f,
            color = Color.WHITE,
            bold = true,
            maxWidth =
                PAGE_WIDTH -
                    MARGIN * 2
        )

        drawText(
            canvas = canvas,
            text = data.country,
            x = MARGIN,
            y = 608f,
            size = 17f,
            color =
                Color.argb(
                    220,
                    255,
                    255,
                    255
                )
        )

        if (options.includeDates) {

            drawText(
                canvas = canvas,
                text =
                    "${data.startDate} — ${data.endDate}",
                x = MARGIN,
                y = 645f,
                size = 14f,
                color =
                    Color.argb(
                        190,
                        255,
                        255,
                        255
                    )
            )
        }

        drawText(
            canvas = canvas,
            text = "WONDERLOG",
            x = MARGIN,
            y = 790f,
            size = 11f,
            color =
                Color.argb(
                    180,
                    255,
                    255,
                    255
                ),
            bold = true
        )

        document.finishPage(
            page
        )
    }

    private fun drawIntroductionPage(
        document: PdfDocument,
        pageNumber: Int,
        data: JourneyExportData,
        options: PdfExportOptions
    ) {

        val page =
            createPage(
                document,
                pageNumber
            )

        val canvas =
            page.canvas

        canvas.drawColor(
            Color.rgb(
                248,
                246,
                242
            )
        )

        drawText(
            canvas = canvas,
            text = "The Journey",
            x = MARGIN,
            y = 95f,
            size = 30f,
            color =
                Color.rgb(
                    35,
                    35,
                    40
                ),
            bold = true
        )

        drawParagraph(
            canvas = canvas,
            text = data.description,
            x = MARGIN,
            startY = 150f,
            maxWidth =
                PAGE_WIDTH -
                    MARGIN * 2,
            textSize = 16f,
            color =
                Color.rgb(
                    75,
                    75,
                    82
                )
        )

        drawPageNumber(
            canvas,
            pageNumber,
            options
        )

        document.finishPage(
            page
        )
    }

    private fun drawMemoryPage(
        document: PdfDocument,
        pageNumber: Int,
        memory: ExportMemory,
        data: JourneyExportData,
        options: PdfExportOptions
    ) {

        val page =
            createPage(
                document,
                pageNumber
            )

        val canvas =
            page.canvas

        canvas.drawColor(
            Color.rgb(
                250,
                248,
                245
            )
        )

        var currentY =
            80f

        memory.photoUris
            .firstOrNull()
            ?.let { uri ->

                loadBitmap(uri)
                    ?.let { bitmap ->

                        drawMemoryHero(
                            canvas,
                            bitmap
                        )

                        bitmap.recycle()

                        currentY =
                            390f
                    }
            }

        drawText(
            canvas = canvas,
            text = memory.title,
            x = MARGIN,
            y = currentY,
            size = 25f,
            color =
                Color.rgb(
                    32,
                    32,
                    37
                ),
            bold = true
        )

        currentY +=
            36f

        val metadata =
            buildList {

                if (
                    options.includeDates &&
                    memory.date.isNotBlank()
                ) {
                    add(memory.date)
                }

                if (
                    options.includeLocations &&
                    !memory.location.isNullOrBlank()
                ) {
                    add(memory.location)
                }

                if (
                    !memory.mood.isNullOrBlank()
                ) {
                    add(memory.mood)
                }
            }
                .joinToString(
                    "  •  "
                )

        if (metadata.isNotBlank()) {

            drawText(
                canvas = canvas,
                text = metadata,
                x = MARGIN,
                y = currentY,
                size = 12f,
                color =
                    Color.rgb(
                        115,
                        115,
                        120
                    )
            )

            currentY +=
                32f
        }

        drawParagraph(
            canvas = canvas,
            text = memory.journalText,
            x = MARGIN,
            startY = currentY,
            maxWidth =
                PAGE_WIDTH -
                    MARGIN * 2,
            textSize = 15f,
            color =
                Color.rgb(
                    65,
                    65,
                    72
                )
        )

        drawPageNumber(
            canvas,
            pageNumber,
            options
        )

        document.finishPage(
            page
        )
    }

    private fun drawAlbumPage(
        document: PdfDocument,
        pageNumber: Int,
        photos: List<ExportPhoto>,
        options: PdfExportOptions
    ) {

        val page =
            createPage(
                document,
                pageNumber
            )

        val canvas =
            page.canvas

        canvas.drawColor(
            Color.rgb(
                246,
                244,
                240
            )
        )

        drawText(
            canvas = canvas,
            text = "Photo Album",
            x = MARGIN,
            y = 70f,
            size = 26f,
            color =
                Color.rgb(
                    35,
                    35,
                    40
                ),
            bold = true
        )

        val gap =
            14f

        val cellWidth =
            (
                PAGE_WIDTH -
                    MARGIN * 2 -
                    gap
                ) / 2f

        val cellHeight =
            280f

        photos.forEachIndexed {
                index,
                photo
            ->

            val column =
                index % 2

            val row =
                index / 2

            val left =
                MARGIN +
                    column *
                    (
                        cellWidth +
                            gap
                        )

            val top =
                105f +
                    row *
                    (
                        cellHeight +
                            gap
                        )

            loadBitmap(
                photo.uri
            )?.let { bitmap ->

                drawBitmapCrop(
                    canvas = canvas,
                    bitmap = bitmap,
                    target =
                        RectF(
                            left,
                            top,
                            left + cellWidth,
                            top + cellHeight
                        )
                )

                bitmap.recycle()
            }
        }

        drawPageNumber(
            canvas,
            pageNumber,
            options
        )

        document.finishPage(
            page
        )
    }

    private fun createPage(
        document: PdfDocument,
        pageNumber: Int
    ): PdfDocument.Page {

        val info =
            PdfDocument.PageInfo
                .Builder(
                    PAGE_WIDTH,
                    PAGE_HEIGHT,
                    pageNumber
                )
                .create()

        return document.startPage(
            info
        )
    }

    private fun drawBackground(
        canvas: Canvas,
        accentColorArgb: Long?
    ) {

        val color =
            accentColorArgb
                ?.toInt()
                ?: Color.rgb(
                    45,
                    42,
                    56
                )

        canvas.drawColor(
            color
        )
    }

    private fun drawCoverImage(
        canvas: Canvas,
        bitmap: Bitmap
    ) {

        drawBitmapCrop(
            canvas = canvas,
            bitmap = bitmap,
            target =
                RectF(
                    0f,
                    0f,
                    PAGE_WIDTH.toFloat(),
                    PAGE_HEIGHT.toFloat()
                )
        )
    }

    private fun drawMemoryHero(
        canvas: Canvas,
        bitmap: Bitmap
    ) {

        drawBitmapCrop(
            canvas = canvas,
            bitmap = bitmap,
            target =
                RectF(
                    MARGIN,
                    55f,
                    PAGE_WIDTH -
                        MARGIN,
                    340f
                )
        )
    }

    private fun drawBitmapCrop(
        canvas: Canvas,
        bitmap: Bitmap,
        target: RectF
    ) {

        val bitmapRatio =
            bitmap.width.toFloat() /
                bitmap.height.toFloat()

        val targetRatio =
            target.width() /
                target.height()

        val source =
            if (bitmapRatio > targetRatio) {

                val desiredWidth =
                    (
                        bitmap.height *
                            targetRatio
                        ).toInt()

                val left =
                    (
                        bitmap.width -
                            desiredWidth
                        ) / 2

                android.graphics.Rect(
                    left,
                    0,
                    left + desiredWidth,
                    bitmap.height
                )

            } else {

                val desiredHeight =
                    (
                        bitmap.width /
                            targetRatio
                        ).toInt()

                val top =
                    (
                        bitmap.height -
                            desiredHeight
                        ) / 2

                android.graphics.Rect(
                    0,
                    top,
                    bitmap.width,
                    top + desiredHeight
                )
            }

        canvas.drawBitmap(
            bitmap,
            source,
            target,
            Paint(
                Paint.ANTI_ALIAS_FLAG or
                    Paint.FILTER_BITMAP_FLAG
            )
        )
    }

    private fun drawText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        size: Float,
        color: Int,
        bold: Boolean = false,
        maxWidth: Float? = null
    ) {

        val paint =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {

                textSize = size
                this.color = color

                typeface =
                    if (bold) {
                        Typeface.create(
                            Typeface.DEFAULT,
                            Typeface.BOLD
                        )
                    } else {
                        Typeface.DEFAULT
                    }
            }

        val finalText =
            if (
                maxWidth != null &&
                paint.measureText(text) >
                maxWidth
            ) {

                android.text.TextUtils
                    .ellipsize(
                        text,
                        android.text.TextPaint(
                            paint
                        ),
                        maxWidth,
                        android.text.TextUtils
                            .TruncateAt.END
                    )
                    .toString()

            } else {
                text
            }

        canvas.drawText(
            finalText,
            x,
            y,
            paint
        )
    }

    private fun drawParagraph(
        canvas: Canvas,
        text: String,
        x: Float,
        startY: Float,
        maxWidth: Float,
        textSize: Float,
        color: Int
    ) {

        val paint =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {

                this.textSize =
                    textSize

                this.color =
                    color
            }

        val lineHeight =
            textSize * 1.55f

        var y =
            startY

        text
            .split("\n")
            .forEach { paragraph ->

                val words =
                    paragraph
                        .split(" ")

                var line =
                    ""

                words.forEach { word ->

                    val candidate =
                        if (
                            line.isEmpty()
                        ) {
                            word
                        } else {
                            "$line $word"
                        }

                    if (
                        paint.measureText(
                            candidate
                        ) <= maxWidth
                    ) {

                        line =
                            candidate

                    } else {

                        canvas.drawText(
                            line,
                            x,
                            y,
                            paint
                        )

                        y +=
                            lineHeight

                        line =
                            word
                    }
                }

                if (line.isNotBlank()) {

                    canvas.drawText(
                        line,
                        x,
                        y,
                        paint
                    )

                    y +=
                        lineHeight
                }

                y +=
                    lineHeight * 0.45f
            }
    }

    private fun drawPageNumber(
        canvas: Canvas,
        pageNumber: Int,
        options: PdfExportOptions
    ) {

        if (
            !options.includePageNumbers
        ) {
            return
        }

        drawText(
            canvas = canvas,
            text = pageNumber.toString(),
            x =
                PAGE_WIDTH -
                    MARGIN -
                    8f,
            y =
                PAGE_HEIGHT -
                    28f,
            size = 10f,
            color =
                Color.rgb(
                    145,
                    145,
                    150
                )
        )
    }

    private fun loadBitmap(
        uri: Uri
    ): Bitmap? {

        return runCatching {

            context
                .contentResolver
                .openInputStream(
                    uri
                )
                ?.use {
                    BitmapFactory.decodeStream(
                        it
                    )
                }

        }.getOrNull()
    }

    companion object {

        private const val PAGE_WIDTH =
            595

        private const val PAGE_HEIGHT =
            842

        private const val MARGIN =
            42f
    }
}
