package com.example.export

import android.net.Uri

data class JourneyExportData(
    val journeyId: Long,
    val title: String,
    val destination: String,
    val country: String,
    val startDate: String,
    val endDate: String,
    val description: String,
    val coverPhotoUri: Uri?,
    val accentColorArgb: Long?,
    val photos: List<ExportPhoto>,
    val memories: List<ExportMemory>
)

data class ExportPhoto(
    val uri: Uri,
    val caption: String? = null,
    val date: String? = null,
    val location: String? = null
)

data class ExportMemory(
    val title: String,
    val journalText: String,
    val date: String,
    val location: String?,
    val mood: String?,
    val photoUris: List<Uri>
)

enum class PdfTravelBookStyle {

    CLASSIC,

    EDITORIAL,

    SCRAPBOOK
}

data class PdfExportOptions(
    val style: PdfTravelBookStyle =
        PdfTravelBookStyle.EDITORIAL,

    val includeCover: Boolean = true,

    val includeJourneyDescription: Boolean = true,

    val includeAlbumPhotos: Boolean = true,

    val includeMemories: Boolean = true,

    val includeLocations: Boolean = true,

    val includeDates: Boolean = true,

    val includePageNumbers: Boolean = true
)

data class PdfExportResult(
    val filePath: String,
    val fileName: String,
    val pageCount: Int
)
