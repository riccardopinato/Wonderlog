package com.example.data.local

import androidx.room.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY startDate DESC")
    fun getAllTrips(): Flow<List<Trip>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: Trip)

    @Update
    suspend fun updateTrip(trip: Trip)

    @Delete
    suspend fun deleteTrip(trip: Trip)

    @Query("SELECT * FROM trips WHERE id = :id")
    suspend fun getTripById(id: String): Trip?

    @Query("SELECT * FROM trips")
    suspend fun getAllTripsOnce(): List<Trip>

    @Query(
        """
        UPDATE trips
        SET futureCloudId = :cloudId,
            syncStatus = 'SYNCED'
        WHERE id = :localId
        """
    )
    suspend fun markSynced(
        localId: String,
        cloudId: String
    )

    @Query(
        """
        SELECT id
        FROM trips
        WHERE syncStatus IN (
            'LOCAL_ONLY',
            'PENDING_UPLOAD',
            'ERROR'
        )
        """
    )
    suspend fun getPendingCloudSyncIds(): List<String>

    @Query(
        """
        SELECT *
        FROM trips
        WHERE futureCloudId = :cloudId
        LIMIT 1
        """
    )
    suspend fun getTripByCloudId(
        cloudId: String
    ): Trip?
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY date DESC")
    fun getAllMemories(): Flow<List<Memory>>

    @Query("SELECT * FROM memories WHERE tripId = :tripId ORDER BY date DESC")
    fun getMemoriesForTrip(tripId: String): Flow<List<Memory>>

    @Transaction
    @Query("SELECT * FROM memories ORDER BY date DESC")
    fun getAllMemoriesWithPhotos(): Flow<List<MemoryWithPhotos>>

    @Transaction
    @Query("SELECT * FROM memories WHERE tripId = :tripId ORDER BY date DESC")
    fun getMemoriesWithPhotosForTrip(tripId: String): Flow<List<MemoryWithPhotos>>

    @Transaction
    @Query("SELECT * FROM memories WHERE id = :id")
    fun getMemoryWithPhotosById(id: String): Flow<MemoryWithPhotos?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: Memory)

    @Update
    suspend fun updateMemory(memory: Memory)

    @Delete
    suspend fun deleteMemory(memory: Memory)

    @Query("SELECT * FROM memories WHERE id = :id")
    suspend fun getMemoryById(id: String): Memory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemoryPhotoCrossRef(crossRef: MemoryPhotoCrossRef)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemoryPhotoCrossRefs(crossRefs: List<MemoryPhotoCrossRef>)

    @Query("DELETE FROM memory_photos WHERE memoryId = :memoryId")
    suspend fun deleteCrossRefsForMemory(memoryId: String)

    @Query("SELECT * FROM memories")
    suspend fun getAllMemoriesOnce(): List<Memory>

    @Query(
        """
        UPDATE memories
        SET futureCloudId = :cloudId,
            syncStatus = 'SYNCED'
        WHERE id = :localId
        """
    )
    suspend fun markSynced(
        localId: String,
        cloudId: String
    )

    @Query(
        """
        SELECT id
        FROM memories
        WHERE syncStatus IN (
            'LOCAL_ONLY',
            'PENDING_UPLOAD',
            'ERROR'
        )
        """
    )
    suspend fun getPendingCloudSyncIds(): List<String>

    @Query(
        """
        SELECT *
        FROM memories
        WHERE futureCloudId = :cloudId
        LIMIT 1
        """
    )
    suspend fun getMemoryByCloudId(
        cloudId: String
    ): Memory?

    @Query(
        """
        SELECT *
        FROM memory_photos
        """
    )
    suspend fun getAllMemoryPhotoCrossRefsOnce():
        List<MemoryPhotoCrossRef>
}

@Dao
interface AlbumPhotoDao {
    @Query("SELECT * FROM album_photos WHERE journeyId = :journeyId ORDER BY displayOrder ASC, createdAt DESC")
    fun getPhotosForJourney(journeyId: String): Flow<List<AlbumPhoto>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: AlbumPhoto)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotos(photos: List<AlbumPhoto>)

    @Update
    suspend fun updatePhoto(photo: AlbumPhoto)

    @Delete
    suspend fun deletePhoto(photo: AlbumPhoto)

    @Delete
    suspend fun deletePhotos(photos: List<AlbumPhoto>)

    @Query("DELETE FROM album_photos WHERE journeyId = :journeyId")
    suspend fun deletePhotosForJourney(journeyId: String)

    @Query("SELECT * FROM album_photos WHERE id = :id")
    suspend fun getPhotoById(id: String): AlbumPhoto?

    @Query("SELECT * FROM album_photos")
    suspend fun getAllPhotosOnce(): List<AlbumPhoto>

    @Query(
        """
        UPDATE album_photos
        SET futureCloudId = :cloudId,
            syncStatus = 'SYNCED'
        WHERE id = :localId
        """
    )
    suspend fun markSynced(
        localId: String,
        cloudId: String
    )

    @Query(
        """
        SELECT id
        FROM album_photos
        WHERE syncStatus IN (
            'LOCAL_ONLY',
            'PENDING_UPLOAD',
            'ERROR'
        )
        """
    )
    suspend fun getPendingCloudSyncIds(): List<String>

    @Query(
        """
        SELECT *
        FROM album_photos
        WHERE futureCloudId = :cloudId
        LIMIT 1
        """
    )
    suspend fun getPhotoByCloudId(
        cloudId: String
    ): AlbumPhoto?
}

@Database(
    entities = [
        Trip::class,
        Memory::class,
        AlbumPhoto::class,
        MemoryPhotoCrossRef::class,
        LocationPlace::class,
        GeocodingCache::class,
        OfflineMapRegion::class,
        com.example.cloud.SyncQueueEntity::class,
        com.example.domain.model.MemoryAttachmentEntity::class
    ],
    version = 6,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class WanderlogDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun memoryDao(): MemoryDao
    abstract fun albumPhotoDao(): AlbumPhotoDao
    abstract fun locationPlaceDao(): LocationPlaceDao
    abstract fun geocodingCacheDao(): GeocodingCacheDao
    abstract fun offlineMapRegionDao(): OfflineMapRegionDao
    abstract fun syncQueueDao(): com.example.cloud.SyncQueueDao
    abstract fun memoryAttachmentDao(): MemoryAttachmentDao

    companion object {
        @Volatile
        private var INSTANCE: WanderlogDatabase? = null

        fun getDatabase(context: android.content.Context): WanderlogDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = androidx.room.Room.databaseBuilder(
                    context.applicationContext,
                    WanderlogDatabase::class.java,
                    "wanderlog-memories-db"
                ).addMigrations(
                    DatabaseMigrations.MIGRATION_4_5,
                    DatabaseMigrations.MIGRATION_5_6
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
