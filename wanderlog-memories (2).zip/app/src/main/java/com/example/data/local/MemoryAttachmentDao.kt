package com.example.data.local

import androidx.room.*
import com.example.domain.model.MemoryAttachmentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryAttachmentDao {
    @Query("SELECT * FROM memory_attachments WHERE memoryId = :memoryId ORDER BY createdAt DESC")
    fun getAttachmentsForMemoryFlow(memoryId: String): Flow<List<MemoryAttachmentEntity>>

    @Query("SELECT * FROM memory_attachments WHERE memoryId = :memoryId ORDER BY createdAt DESC")
    suspend fun getAttachmentsForMemory(memoryId: String): List<MemoryAttachmentEntity>

    @Query("SELECT * FROM memory_attachments WHERE id = :id")
    suspend fun getAttachmentById(id: String): MemoryAttachmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: MemoryAttachmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachments(attachments: List<MemoryAttachmentEntity>)

    @Delete
    suspend fun deleteAttachment(attachment: MemoryAttachmentEntity)

    @Query("DELETE FROM memory_attachments WHERE id = :id")
    suspend fun deleteAttachmentById(id: String)

    @Query("DELETE FROM memory_attachments WHERE memoryId = :memoryId")
    suspend fun deleteAttachmentsForMemory(memoryId: String)
}
