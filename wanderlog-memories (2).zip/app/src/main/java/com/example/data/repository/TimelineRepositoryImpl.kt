package com.example.data.repository

import com.example.domain.model.*
import com.example.domain.repository.TimelineRepository
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

class TimelineRepositoryImpl : TimelineRepository {

    override fun generateTimeline(
        trip: Trip,
        memoriesWithPhotos: List<MemoryWithPhotos>,
        sort: TimelineSort,
        filter: TimelineFilter
    ): List<TimelineDay> {
        // 1. Filter the memories
        val filtered = filterMemories(memoriesWithPhotos, filter)

        // 2. Group by Date
        val groupedByDate = filtered.groupBy { it.memory.date }

        // 3. Convert groups to TimelineDays
        val timelineDays = groupedByDate.map { (dateStr, itemsInDay) ->
            // Sort items within the day
            val sortedItems = sortMemories(itemsInDay, sort).map { toTimelineItem(it) }

            val totalPhotos = sortedItems.sumOf { it.photoCount }
            val moodsInDay = sortedItems.map { it.mood }.distinct()
            val locationsInDay = sortedItems.map { it.locationName }.filter { it.isNotEmpty() }.distinct()

            // Calculate Travel Day Number relative to trip.startDate
            val dayNumber = calculateDayNumber(dateStr, trip.startDate)
            val firstMemoryTitle = sortedItems.firstOrNull()?.title ?: ""
            val dayTitle = if (firstMemoryTitle.isNotEmpty()) {
                "Day $dayNumber · $firstMemoryTitle"
            } else {
                "Day $dayNumber · ${formatReadableDate(dateStr)}"
            }

            // Create informative subtitle
            val memoryLabel = if (sortedItems.size == 1) "1 memory" else "${sortedItems.size} memories"
            val photoLabel = if (totalPhotos == 1) "1 photo" else "$totalPhotos photos"
            val locationSummary = if (locationsInDay.isNotEmpty()) "📍 ${locationsInDay.take(2).joinToString(", ")}" else "No locations"
            val daySubtitle = "$memoryLabel · $photoLabel · $locationSummary"

            TimelineDay(
                date = dateStr,
                title = dayTitle,
                subtitle = daySubtitle,
                memories = sortedItems,
                photoCount = totalPhotos,
                moods = moodsInDay,
                locations = locationsInDay
            )
        }

        // 4. Sort the TimelineDays
        return when (sort) {
            TimelineSort.OLDEST_FIRST -> timelineDays.sortedBy { it.date }
            TimelineSort.NEWEST_FIRST -> timelineDays.sortedByDescending { it.date }
            TimelineSort.FAVORITES_FIRST -> timelineDays.sortedByDescending { day ->
                day.memories.any { it.favorite }
            }
            TimelineSort.BY_MOOD -> timelineDays.sortedBy { day ->
                day.memories.firstOrNull()?.mood?.label ?: ""
            }
            TimelineSort.BY_LOCATION -> timelineDays.sortedBy { day ->
                day.memories.firstOrNull()?.locationName ?: ""
            }
        }
    }

    override fun generateSections(
        memoriesWithPhotos: List<MemoryWithPhotos>,
        sort: TimelineSort,
        filter: TimelineFilter
    ): List<TimelineSection> {
        val filtered = filterMemories(memoriesWithPhotos, filter)
        val sorted = sortMemories(filtered, sort)

        // Group by Month & Year for sections
        val groupedByMonth = sorted.groupBy { extractMonthYear(it.memory.date) }

        return groupedByMonth.map { (monthYear, items) ->
            val timelineItems = items.map { toTimelineItem(it) }
            val dates = timelineItems.map { it.date }.sorted()
            val dateRange = if (dates.isNotEmpty()) {
                if (dates.size == 1) formatReadableDate(dates.first())
                else "${formatReadableDate(dates.first())} - ${formatReadableDate(dates.last())}"
            } else {
                monthYear
            }

            TimelineSection(
                sectionId = monthYear,
                dateRange = dateRange,
                items = timelineItems
            )
        }
    }

    private fun filterMemories(
        memories: List<MemoryWithPhotos>,
        filter: TimelineFilter
    ): List<MemoryWithPhotos> {
        return memories.filter { item ->
            val memory = item.memory
            val photos = item.photos

            if (filter.showOnlyFavorites && !memory.favorite) return@filter false

            if (filter.selectedMood != null && memory.mood != filter.selectedMood) return@filter false

            if (filter.selectedTag != null && !memory.tags.contains(filter.selectedTag)) return@filter false

            if (filter.selectedLocation != null && !memory.locationName.contains(filter.selectedLocation, ignoreCase = true)) return@filter false

            if (filter.dateRangeStart != null && memory.date < filter.dateRangeStart) return@filter false
            if (filter.dateRangeEnd != null && memory.date > filter.dateRangeEnd) return@filter false

            val hasPhotos = photos.isNotEmpty() || memory.image.isNotEmpty()
            if (filter.hasPhotosOnly && !hasPhotos) return@filter false
            if (filter.noPhotosOnly && hasPhotos) return@filter false

            true
        }
    }

    private fun sortMemories(
        memories: List<MemoryWithPhotos>,
        sort: TimelineSort
    ): List<MemoryWithPhotos> {
        return when (sort) {
            TimelineSort.OLDEST_FIRST -> memories.sortedWith(
                compareBy<MemoryWithPhotos> { it.memory.date }
                    .thenBy { it.memory.displayOrder }
                    .thenBy { it.memory.createdAt }
            )
            TimelineSort.NEWEST_FIRST -> memories.sortedWith(
                compareByDescending<MemoryWithPhotos> { it.memory.date }
                    .thenByDescending { it.memory.displayOrder }
                    .thenByDescending { it.memory.createdAt }
            )
            TimelineSort.FAVORITES_FIRST -> memories.sortedWith(
                compareByDescending<MemoryWithPhotos> { it.memory.favorite }
                    .thenByDescending { it.memory.date }
            )
            TimelineSort.BY_MOOD -> memories.sortedBy { it.memory.mood.label }
            TimelineSort.BY_LOCATION -> memories.sortedBy { it.memory.locationName }
        }
    }

    private fun toTimelineItem(memoryWithPhotos: MemoryWithPhotos): TimelineItem {
        val memory = memoryWithPhotos.memory
        val photos = memoryWithPhotos.photos
        val heroPhoto = memory.image.ifEmpty { photos.firstOrNull()?.localUri ?: "" }

        return TimelineItem(
            memoryId = memory.id,
            title = memory.title,
            journalPreview = if (memory.journalText.length > 120) {
                memory.journalText.take(117) + "..."
            } else {
                memory.journalText
            },
            date = memory.date,
            locationName = memory.locationName,
            mood = memory.mood,
            heroPhoto = heroPhoto,
            photoCount = photos.size,
            favorite = memory.favorite,
            displayOrder = memory.displayOrder
        )
    }

    private fun calculateDayNumber(memoryDateStr: String, tripStartDateStr: String): Int {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val start = sdf.parse(tripStartDateStr)
            val current = sdf.parse(memoryDateStr)
            if (start != null && current != null) {
                val diff = current.time - start.time
                val days = TimeUnit.MILLISECONDS.toDays(diff).toInt()
                if (days >= 0) days + 1 else 1
            } else {
                1
            }
        } catch (e: Exception) {
            1
        }
    }

    private fun formatReadableDate(dateStr: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val outputFormat = SimpleDateFormat("MMM d, yyyy", Locale.US)
            val date = inputFormat.parse(dateStr)
            if (date != null) outputFormat.format(date) else dateStr
        } catch (e: Exception) {
            dateStr
        }
    }

    private fun extractMonthYear(dateStr: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val outputFormat = SimpleDateFormat("MMMM yyyy", Locale.US)
            val date = inputFormat.parse(dateStr)
            if (date != null) outputFormat.format(date) else "Unknown Period"
        } catch (e: Exception) {
            "Unknown Period"
        }
    }
}
