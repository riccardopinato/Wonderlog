package com.example.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object DatabaseMigrations {

    val MIGRATION_4_5 =
        object : Migration(
            4,
            5
        ) {

            override fun migrate(
                database:
                    SupportSQLiteDatabase
            ) {

                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cloud_sync_queue` (
                        `id` TEXT NOT NULL,
                        `entityType` TEXT NOT NULL,
                        `localEntityId` TEXT NOT NULL,
                        `operation` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `attemptCount` INTEGER NOT NULL,
                        `lastError` TEXT,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )

                database.execSQL(
                    """
                    CREATE UNIQUE INDEX IF NOT EXISTS
                    `index_cloud_sync_queue_entityType_localEntityId_operation`
                    ON `cloud_sync_queue`
                    (
                        `entityType`,
                        `localEntityId`,
                        `operation`
                    )
                    """.trimIndent()
                )
            }
        }

    val MIGRATION_5_6 =
        object : Migration(
            5,
            6
        ) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `memory_attachments` (
                        `id` TEXT NOT NULL,
                        `memoryId` TEXT NOT NULL,
                        `localUri` TEXT NOT NULL,
                        `originalName` TEXT,
                        `mimeType` TEXT NOT NULL,
                        `attachmentType` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`id`),
                        FOREIGN KEY(`memoryId`) REFERENCES `memories`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )

                database.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS `index_memory_attachments_memoryId`
                    ON `memory_attachments` (`memoryId`)
                    """.trimIndent()
                )
            }
        }
}
