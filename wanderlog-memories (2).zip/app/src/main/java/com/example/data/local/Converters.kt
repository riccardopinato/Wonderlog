package com.example.data.local

import androidx.room.TypeConverter
import com.example.domain.model.Mood

class Converters {
    @TypeConverter
    fun fromStringList(value: List<String>): String {
        return value.joinToString(separator = "||")
    }

    @TypeConverter
    fun toStringList(value: String): List<String> {
        if (value.isEmpty()) return emptyList()
        return value.split("||")
    }

    @TypeConverter
    fun fromMood(mood: Mood): String {
        return mood.name
    }

    @TypeConverter
    fun toMood(value: String): Mood {
        return try {
            Mood.valueOf(value)
        } catch (e: Exception) {
            Mood.HAPPY
        }
    }
}
