package com.example.data.repository

import com.example.data.local.MemoryDao
import com.example.data.local.TripDao
import com.example.data.local.AlbumPhotoDao
import com.example.domain.model.Memory
import com.example.domain.model.Mood
import com.example.domain.model.Trip
import com.example.domain.model.AlbumPhoto
import com.example.domain.repository.WanderlogRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow

class WanderlogRepositoryImpl(
    private val tripDao: TripDao,
    private val memoryDao: MemoryDao,
    private val albumPhotoDao: AlbumPhotoDao
) : WanderlogRepository {

    override fun getAllTrips(): Flow<List<Trip>> = tripDao.getAllTrips()

    override fun getTripById(id: String): Flow<Trip?> = flow {
        emit(tripDao.getTripById(id))
    }

    override fun getMemoriesForTrip(tripId: String): Flow<List<Memory>> = 
        memoryDao.getMemoriesForTrip(tripId)

    override fun getAllMemories(): Flow<List<Memory>> = memoryDao.getAllMemories()

    override fun getMemoriesWithPhotosForTrip(tripId: String): Flow<List<com.example.domain.model.MemoryWithPhotos>> =
        memoryDao.getMemoriesWithPhotosForTrip(tripId)

    override fun getAllMemoriesWithPhotos(): Flow<List<com.example.domain.model.MemoryWithPhotos>> =
        memoryDao.getAllMemoriesWithPhotos()

    override fun getMemoryWithPhotosById(id: String): Flow<com.example.domain.model.MemoryWithPhotos?> =
        memoryDao.getMemoryWithPhotosById(id)

    override suspend fun insertMemoryPhotoCrossRef(crossRef: com.example.domain.model.MemoryPhotoCrossRef) {
        memoryDao.insertMemoryPhotoCrossRef(crossRef)
    }

    override suspend fun deleteCrossRefsForMemory(memoryId: String) {
        memoryDao.deleteCrossRefsForMemory(memoryId)
    }

    override suspend fun insertTrip(trip: Trip) {
        tripDao.insertTrip(trip)
    }

    override suspend fun updateTrip(trip: Trip) {
        tripDao.updateTrip(trip)
    }

    override suspend fun insertMemory(memory: Memory) {
        memoryDao.insertMemory(memory)
    }

    override suspend fun deleteTrip(trip: Trip) {
        tripDao.deleteTrip(trip)
    }

    override suspend fun deleteMemory(memory: Memory) {
        memoryDao.deleteMemory(memory)
    }

    override suspend fun populateMockDataIfEmpty() {
        val currentTrips = tripDao.getAllTrips().first()
        if (currentTrips.isEmpty()) {
            val mockTrips = listOf(
                Trip(
                    id = "trip_japan",
                    destinationName = "Japan",
                    country = "Japan",
                    startDate = "2026-04-10",
                    endDate = "2026-04-22",
                    coverImage = "img_dest_japan_1783080879621",
                    description = "A journey through Tokyo neon streets, traditional Kyoto shrines, and breathtaking Mt. Fuji viewpoints.",
                    accentGradientIndex = 0,
                    latitude = 35.6762,
                    longitude = 139.6503
                ),
                Trip(
                    id = "trip_paris",
                    destinationName = "Paris",
                    country = "France",
                    startDate = "2026-10-05",
                    endDate = "2026-10-12",
                    coverImage = "img_dest_paris_1783080892442",
                    description = "The City of Light in beautiful autumn colors. Fine dining, iconic art museums, and cozy cafe corners.",
                    accentGradientIndex = 1,
                    latitude = 48.8566,
                    longitude = 2.3522
                ),
                Trip(
                    id = "trip_iceland",
                    destinationName = "Iceland",
                    country = "Iceland",
                    startDate = "2026-02-15",
                    endDate = "2026-02-22",
                    coverImage = "img_dest_iceland",
                    description = "Chasing the dancing northern lights, bathing in thermal springs, and exploring majestic frozen waterfalls.",
                    accentGradientIndex = 2,
                    latitude = 64.1466,
                    longitude = -21.9426
                ),
                Trip(
                    id = "trip_rome",
                    destinationName = "Rome",
                    country = "Italy",
                    startDate = "2026-05-18",
                    endDate = "2026-05-25",
                    coverImage = "img_dest_rome",
                    description = "Living 'La Dolce Vita' surrounded by ancient ruins, stunning fountains, and incomparable gelato.",
                    accentGradientIndex = 3,
                    latitude = 41.9028,
                    longitude = 12.4964
                ),
                Trip(
                    id = "trip_new_york",
                    destinationName = "New York",
                    country = "United States",
                    startDate = "2026-09-01",
                    endDate = "2026-09-07",
                    coverImage = "img_dest_new_york",
                    description = "The vibrant skyline of Manhattan, morning strolls in Central Park, and the electrifying Broadway theaters.",
                    accentGradientIndex = 4,
                    latitude = 40.7128,
                    longitude = -74.0060
                )
            )

            val mockMemories = listOf(
                Memory(
                    id = "mem_shibuya",
                    tripId = "trip_japan",
                    title = "Shibuya Crossing Lights",
                    note = "Watching the organized chaos of Shibuya crossing at dusk. The vibrant neon signs reflecting off the damp streets created an electric atmosphere that felt straight out of a movie.",
                    image = "img_dest_japan_1783080879621",
                    locationName = "Shibuya, Tokyo",
                    latitude = 35.6580,
                    longitude = 139.7016,
                    date = "2026-04-11",
                    mood = Mood.HAPPY,
                    tags = listOf("Tokyo", "Neon", "RainyNight")
                ),
                Memory(
                    id = "mem_kyoto",
                    tripId = "trip_japan",
                    title = "Arashiyama Bamboo Walk",
                    note = "Woke up at 5:30 AM to walk among the towering bamboo stalks without the crowds. The gentle rustle of leaves in the morning breeze was completely therapeutic.",
                    image = "img_dest_japan_1783080879621",
                    locationName = "Arashiyama, Kyoto",
                    latitude = 35.0156,
                    longitude = 135.6715,
                    date = "2026-04-15",
                    mood = Mood.SERENE,
                    tags = listOf("Kyoto", "Nature", "QuietMorning")
                ),
                Memory(
                    id = "mem_eiffel",
                    tripId = "trip_paris",
                    title = "Twilight Eiffel Tower",
                    note = "Picnicked on the Champ de Mars with warm baguettes and fresh brie. Just as the sun dipped below the horizon, the tower burst into a sparkling gold dance. Magical!",
                    image = "img_dest_paris_1783080892442",
                    locationName = "Champ de Mars, Paris",
                    latitude = 48.8584,
                    longitude = 2.2945,
                    date = "2026-10-06",
                    mood = Mood.ROMANTIC,
                    tags = listOf("Paris", "Glittering", "Croissant")
                ),
                Memory(
                    id = "mem_louvre",
                    tripId = "trip_paris",
                    title = "Louvre Night Stroll",
                    note = "Strolling past the illuminated glass pyramid under a starry Parisian night sky. The contrast of historical architecture and glass is stunning.",
                    image = "img_dest_paris_1783080892442",
                    locationName = "Louvre Museum, Paris",
                    latitude = 48.8606,
                    longitude = 2.3376,
                    date = "2026-10-08",
                    mood = Mood.DREAMY,
                    tags = listOf("Louvre", "ArtNight", "Scenic")
                ),
                Memory(
                    id = "mem_aurora",
                    tripId = "trip_iceland",
                    title = "Dancing Aurora Borealis",
                    note = "Stood out in the freezing arctic wind near Vik, and suddenly the entire sky ignited with ripples of neon green and purple light. A sight I will never forget.",
                    image = "img_travel_onboarding_1783080861284",
                    locationName = "Vik, Southern Iceland",
                    latitude = 63.4186,
                    longitude = -19.0060,
                    date = "2026-02-18",
                    mood = Mood.DREAMY,
                    tags = listOf("Aurora", "Stargazing", "FrozenIceland")
                ),
                Memory(
                    id = "mem_colosseum",
                    tripId = "trip_rome",
                    title = "Colosseum Crimson Sunset",
                    note = "Climbed the steps near the Colosseum just in time to watch the ancient stone capture the warm crimson glow of the fading sun. Absolute history standing proud.",
                    image = "img_dest_paris_1783080892442",
                    locationName = "Colosseum, Rome",
                    latitude = 41.8902,
                    longitude = 12.4922,
                    date = "2026-05-19",
                    mood = Mood.ADVENTUROUS,
                    tags = listOf("Ancient", "Colosseum", "Sunset")
                ),
                Memory(
                    id = "mem_central_park",
                    tripId = "trip_new_york",
                    title = "Central Park Autumn Loop",
                    note = "Rented bikes and looped the entirety of Central Park. The trees were painted in rich amber, gold, and red. Perfect crisp autumn weather.",
                    image = "img_dest_japan_1783080879621",
                    locationName = "Central Park, New York",
                    latitude = 40.7851,
                    longitude = -73.9683,
                    date = "2026-09-02",
                    mood = Mood.ENERGETIC,
                    tags = listOf("Manhattan", "AutumnLoop", "ActiveDay")
                )
            )

            // Insert to DB
            for (trip in mockTrips) {
                tripDao.insertTrip(trip)
            }
            for (memory in mockMemories) {
                memoryDao.insertMemory(memory)
            }
        }
    }

    override fun getPhotosForJourney(journeyId: String): Flow<List<AlbumPhoto>> =
        albumPhotoDao.getPhotosForJourney(journeyId)

    override suspend fun insertPhoto(photo: AlbumPhoto) {
        albumPhotoDao.insertPhoto(photo)
    }

    override suspend fun insertPhotos(photos: List<AlbumPhoto>) {
        albumPhotoDao.insertPhotos(photos)
    }

    override suspend fun updatePhoto(photo: AlbumPhoto) {
        albumPhotoDao.updatePhoto(photo)
    }

    override suspend fun deletePhoto(photo: AlbumPhoto) {
        albumPhotoDao.deletePhoto(photo)
    }

    override suspend fun deletePhotos(photos: List<AlbumPhoto>) {
        albumPhotoDao.deletePhotos(photos)
    }

    override suspend fun deletePhotosForJourney(journeyId: String) {
        albumPhotoDao.deletePhotosForJourney(journeyId)
    }

    override suspend fun getPhotoById(id: String): AlbumPhoto? =
        albumPhotoDao.getPhotoById(id)
}
