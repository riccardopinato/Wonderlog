package com.example.data.local

import androidx.room.*
import com.example.domain.model.LocationPlace
import com.example.domain.model.GeocodingCache
import com.example.domain.model.OfflineMapRegion
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationPlaceDao {
    @Query("SELECT * FROM location_places")
    fun getAllPlaces(): Flow<List<LocationPlace>>

    @Query("SELECT * FROM location_places WHERE id = :id")
    suspend fun getPlaceById(id: String): LocationPlace?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlace(place: LocationPlace)

    @Delete
    suspend fun deletePlace(place: LocationPlace)
}

@Dao
interface GeocodingCacheDao {
    @Query("SELECT * FROM geocoding_cache WHERE `query` = :query")
    suspend fun getCache(query: String): GeocodingCache?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCache(cache: GeocodingCache)

    @Query("DELETE FROM geocoding_cache WHERE cachedAt < :expiryTime")
    suspend fun cleanOldCache(expiryTime: Long)
}

@Dao
interface OfflineMapRegionDao {
    @Query("SELECT * FROM offline_map_regions ORDER BY createdAt DESC")
    fun getAllRegions(): Flow<List<OfflineMapRegion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRegion(region: OfflineMapRegion)

    @Delete
    suspend fun deleteRegion(region: OfflineMapRegion)

    @Query("SELECT * FROM offline_map_regions WHERE id = :id")
    suspend fun getRegionById(id: String): OfflineMapRegion?
}
