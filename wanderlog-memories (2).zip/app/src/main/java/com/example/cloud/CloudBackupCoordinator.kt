package com.example.cloud

class CloudBackupCoordinator(
    private val repository:
        CloudRepository,

    private val localDataSource:
        RoomCloudLocalDataSource,

    private val settingsRepository:
        CloudBackupSettingsRepository? = null,

    private val memoryPhotoCloudLinkBuilder:
        MemoryPhotoCloudLinkBuilder? = null,

    private val cloudProvider:
        CloudProvider? = null
) {

    suspend fun backupEverything():
        Result<SyncSummary> {

        return runCatching {

            val settings =
                settingsRepository?.getSettings()

            /*
             * Journey first because Memory and Photo
             * require the Journey cloud id.
             */

            localDataSource
                .allJourneyIds()
                .forEach {

                    repository
                        .enqueueJourney(
                            it
                        )
                }

            /*
             * First pass uploads Journeys.
             */
            val journeyResult =
                repository
                    .syncNow()
                    .getOrThrow()

            /*
             * Journey futureCloudId now exists locally.
             * We can safely create Memory and Photo payloads.
             */
            localDataSource
                .allMemoryIds()
                .forEach {

                    repository
                        .enqueueMemory(
                            it
                        )
                }

            val includePhotos =
                settings?.includePhotos ?: true

            if (includePhotos) {
                localDataSource
                    .allPhotoIds()
                    .forEach {

                        repository
                            .enqueuePhoto(
                                it
                            )
                    }
            }

            val contentResult =
                repository
                    .syncNow()
                    .getOrThrow()

            if (memoryPhotoCloudLinkBuilder != null && cloudProvider != null) {
                val links = memoryPhotoCloudLinkBuilder.build()
                cloudProvider.uploadMemoryPhotoLinks(links).getOrThrow()
            }

            val summary = SyncSummary(
                uploaded =
                    journeyResult.uploaded +
                        contentResult.uploaded,

                downloaded =
                    journeyResult.downloaded +
                        contentResult.downloaded,

                deleted =
                    journeyResult.deleted +
                        contentResult.deleted,

                conflicts =
                    journeyResult.conflicts +
                        contentResult.conflicts,

                failures =
                    journeyResult.failures +
                        contentResult.failures
            )

            if (summary.failures == 0) {
                settingsRepository?.setLastSuccessfulBackupAt(
                    System.currentTimeMillis()
                )
            }

            summary
        }
    }
}
