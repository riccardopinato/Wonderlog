package com.example.cloud

enum class SyncStatus {

    LOCAL_ONLY,

    PENDING_UPLOAD,

    SYNCED,

    PENDING_DELETE,

    CONFLICT,

    ERROR
}

enum class SyncEntityType {

    JOURNEY,

    MEMORY,

    ALBUM_PHOTO
}

enum class SyncOperation {

    CREATE_OR_UPDATE,

    DELETE
}

data class SyncQueueItem(
    val id: String,
    val entityType: SyncEntityType,
    val localEntityId: String,
    val operation: SyncOperation,
    val createdAt: Long,
    val attemptCount: Int = 0,
    val lastError: String? = null
)

data class SyncSummary(
    val uploaded: Int = 0,
    val downloaded: Int = 0,
    val deleted: Int = 0,
    val conflicts: Int = 0,
    val failures: Int = 0
)

data class CloudSyncState(
    val isEnabled: Boolean = false,
    val isSyncing: Boolean = false,
    val lastSuccessfulSyncAt: Long? = null,
    val pendingItems: Int = 0,
    val progressLabel: String? = null,
    val summary: SyncSummary? = null,
    val errorMessage: String? = null
)
