package com.example.cloud

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CloudRestoreViewModel(
    private val repository:
        CloudRestoreRepository
) : ViewModel() {

    private val _state =
        MutableStateFlow<RestoreState>(
            RestoreState.Idle
        )

    val state:
        StateFlow<RestoreState> =
        _state.asStateFlow()

    fun restore() {

        if (
            _state.value is
                RestoreState.Running
        ) {
            return
        }

        viewModelScope.launch {

            repository
                .restoreEverything { progress ->

                    _state.value =
                        RestoreState.Running(
                            progress
                        )
                }
                .onSuccess {

                    _state.value =
                        RestoreState.Success(
                            it
                        )
                }
                .onFailure {

                    _state.value =
                        RestoreState.Error(
                            it.message
                                ?: "Cloud restore failed."
                        )
                }
        }
    }

    fun reset() {

        _state.value =
            RestoreState.Idle
    }
}
