package com.example.cloud

import com.example.data.local.AlbumPhotoDao
import com.example.data.local.MemoryDao
import com.example.data.local.TripDao
import java.io.File

class RoomCloudLocalDataSource(
    private val tripDao:
        TripDao,

    private val memoryDao:
        MemoryDao,

    private val photoDao:
        AlbumPhotoDao,

    private val authManager:
        SupabaseAuthManager =
        SupabaseAuthManager()
) : CloudLocalDataSource {

    override suspend fun getJourneyForCloud(
        localId: String
    ): CloudJourney? {

        val trip =
            tripDao
                .getTripById(
                    localId
                )
                ?: return null

        val userId =
            authManager
                .currentUserId()
                ?: return null

        val cloudId =
            trip.futureCloudId
                ?: CloudIdFactory.journey(
                    ownerId = userId,
                    localId = trip.id
                )

        return CloudJourney(
            id = cloudId,

            ownerId =
                userId,

            localReferenceId =
                trip.id,

            title =
                trip.title,

            destination =
                trip.destinationName,

            country =
                trip.country,

            description =
                trip.description,

            startDate =
                trip.startDate,

            endDate =
                trip.endDate,

            accentTheme =
                trip.accentTheme,

            coverPhotoCloudId =
                null,

            createdAt =
                trip.createdAt,

            updatedAt =
                trip.updatedAt
        )
    }

    override suspend fun getMemoryForCloud(
        localId: String
    ): CloudMemory? {

        val memory =
            memoryDao
                .getMemoryById(
                    localId
                )
                ?: return null

        val trip =
            tripDao
                .getTripById(
                    memory.tripId
                )
                ?: return null

        val journeyCloudId =
            trip.futureCloudId
                ?: return null

        val userId =
            authManager
                .currentUserId()
                ?: return null

        val cloudId =
            memory.futureCloudId
                ?: CloudIdFactory.memory(
                    ownerId = userId,
                    localId = memory.id
                )

        return CloudMemory(
            id = cloudId,

            ownerId =
                userId,

            journeyCloudId =
                journeyCloudId,

            localReferenceId =
                memory.id,

            title =
                memory.title,

            journalText =
                memory.journalText,

            date =
                memory.date,

            locationName =
                memory.locationName
                    .takeIf {
                        it.isNotBlank()
                    },

            latitude =
                memory.latitude,

            longitude =
                memory.longitude,

            mood =
                memory.mood.name,

            tags =
                memory.tags,

            createdAt =
                memory.createdAt,

            updatedAt =
                memory.updatedAt
        )
    }

    override suspend fun getPhotoForCloud(
        localId: String
    ): CloudAlbumPhoto? {

        val photo =
            photoDao
                .getPhotoById(
                    localId
                )
                ?: return null

        val trip =
            tripDao
                .getTripById(
                    photo.journeyId
                )
                ?: return null

        val journeyCloudId =
            trip.futureCloudId
                ?: return null

        val userId =
            authManager
                .currentUserId()
                ?: return null

        val cloudId =
            photo.futureCloudId
                ?: CloudIdFactory.photo(
                    ownerId = userId,
                    localId = photo.id
                )

        return CloudAlbumPhoto(
            id = cloudId,

            ownerId =
                userId,

            journeyCloudId =
                journeyCloudId,

            localReferenceId =
                photo.id,

            remoteFilePath =
                null,

            fileName =
                photo.fileName,

            mimeType =
                photo.mimeType,

            capturedAt =
                photo.capturedAt,

            latitude =
                photo.gpsLatitude,

            longitude =
                photo.gpsLongitude,

            locationName =
                photo.locationName
                    .takeIf {
                        it.isNotBlank()
                    },

            displayOrder =
                photo.displayOrder,

            isCoverPhoto =
                photo.isCoverPhoto,

            createdAt =
                photo.createdAt,

            updatedAt =
                photo.updatedAt
        )
    }

    override suspend fun getPhotoLocalPath(
        localId: String
    ): String? {

        val photo =
            photoDao
                .getPhotoById(
                    localId
                )
                ?: return null

        return photo.localUri
            .removePrefix(
                "file://"
            )
            .takeIf {
                File(it).exists()
            }
    }

    override suspend fun buildRemotePhotoPath(
        localId: String
    ): String {

        val userId =
            authManager
                .currentUserId()
                ?: error(
                    "User not authenticated."
                )

        val photo =
            photoDao
                .getPhotoById(
                    localId
                )
                ?: error(
                    "Photo not found."
                )

        val extension =
            photo.fileName
                .substringAfterLast(
                    ".",
                    "jpg"
                )
                .lowercase()

        return "$userId/journeys/" +
            "${photo.journeyId}/photos/" +
            "${photo.id}.$extension"
    }

    override suspend fun markJourneySynced(
        localId: String,
        cloudId: String
    ) {

        tripDao.markSynced(
            localId,
            cloudId
        )
    }

    override suspend fun markMemorySynced(
        localId: String,
        cloudId: String
    ) {

        memoryDao.markSynced(
            localId,
            cloudId
        )
    }

    override suspend fun markPhotoSynced(
        localId: String,
        cloudId: String,
        remotePath: String?
    ) {

        photoDao.markSynced(
            localId,
            cloudId
        )
    }

    override suspend fun getJourneyCloudId(
        localId: String
    ): String? {

        return tripDao
            .getTripById(
                localId
            )
            ?.futureCloudId
    }

    override suspend fun getMemoryCloudId(
        localId: String
    ): String? {

        return memoryDao
            .getMemoryById(
                localId
            )
            ?.futureCloudId
    }

    override suspend fun getPhotoCloudDeleteInfo(
        localId: String
    ): PhotoCloudDeleteInfo? {

        val photo =
            photoDao
                .getPhotoById(
                    localId
                )
                ?: return null

        val cloudId =
            photo.futureCloudId
                ?: return null

        return PhotoCloudDeleteInfo(
            cloudId =
                cloudId,

            remoteFilePath =
                buildRemotePhotoPath(
                    localId
                )
        )
    }

    suspend fun allJourneyIds():
        List<String> {

        return tripDao
            .getAllTripsOnce()
            .map {
                it.id
            }
    }

    suspend fun allMemoryIds():
        List<String> {

        return memoryDao
            .getAllMemoriesOnce()
            .map {
                it.id
            }
    }

    suspend fun allPhotoIds():
        List<String> {

        return photoDao
            .getAllPhotosOnce()
            .map {
                it.id
            }
    }
}
