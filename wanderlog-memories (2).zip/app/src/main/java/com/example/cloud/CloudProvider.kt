package com.example.cloud

interface CloudProvider {

    suspend fun isAuthenticated(): Boolean

    suspend fun uploadJourney(
        payload: CloudJourney
    ): Result<CloudJourney>

    suspend fun uploadMemory(
        payload: CloudMemory
    ): Result<CloudMemory>

    suspend fun uploadPhotoMetadata(
        payload: CloudAlbumPhoto
    ): Result<CloudAlbumPhoto>

    suspend fun uploadPhotoFile(
        localPath: String,
        remotePath: String
    ): Result<String>

    suspend fun deleteJourney(
        cloudId: String
    ): Result<Unit>

    suspend fun deleteMemory(
        cloudId: String
    ): Result<Unit>

    suspend fun deletePhoto(
        cloudId: String,
        remoteFilePath: String?
    ): Result<Unit>

    suspend fun fetchJourneys(
        updatedAfter: Long?
    ): Result<List<CloudJourney>>

    suspend fun fetchMemories(
        updatedAfter: Long?
    ): Result<List<CloudMemory>>

    suspend fun fetchPhotos(
        updatedAfter: Long?
    ): Result<List<CloudAlbumPhoto>>

    suspend fun downloadPhotoFile(
        remotePath: String
    ): Result<ByteArray>

    suspend fun uploadMemoryPhotoLinks(
        links: List<CloudMemoryPhotoLink>
    ): Result<Unit>

    suspend fun fetchMemoryPhotoLinks():
        Result<List<CloudMemoryPhotoLink>>
}
