package com.example.cloud

import android.content.Context
import com.example.data.local.WanderlogDatabase

object CloudWorkerDependencies {

    fun createIncrementalCoordinator(
        context: Context
    ): IncrementalCloudSyncCoordinator {

        val applicationContext =
            context.applicationContext

        val database =
            WanderlogDatabase
                .getDatabase(
                    applicationContext
                )

        val settingsRepository =
            SharedPreferencesCloudBackupSettingsRepository(
                applicationContext
            )

        val queueStore =
            RoomSyncQueueStore(
                database.syncQueueDao()
            )

        val authManager =
            SupabaseAuthManager()

        val localCloudDataSource =
            RoomCloudLocalDataSource(
                tripDao =
                    database.tripDao(),

                memoryDao =
                    database.memoryDao(),

                photoDao =
                    database.albumPhotoDao(),

                authManager =
                    authManager
            )

        val cloudRepository =
            CloudSyncRepository(
                cloudProvider =
                    SupabaseCloudProvider(
                        authManager
                    ),

                queueStore =
                    queueStore,

                localDataSource =
                    localCloudDataSource
            )

        val incrementalDataSource =
            RoomIncrementalSyncLocalDataSource(
                tripDao =
                    database.tripDao(),

                memoryDao =
                    database.memoryDao(),

                photoDao =
                    database.albumPhotoDao()
            )

        return IncrementalCloudSyncCoordinator(
            repository =
                cloudRepository,

            localDataSource =
                incrementalDataSource,

            settingsRepository =
                settingsRepository
        )
    }

    fun settingsRepository(
        context: Context
    ): CloudBackupSettingsRepository {

        return SharedPreferencesCloudBackupSettingsRepository(
            context.applicationContext
        )
    }
}
