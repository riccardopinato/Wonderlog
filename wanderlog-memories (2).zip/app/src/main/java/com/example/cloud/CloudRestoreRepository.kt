package com.example.cloud

import android.content.Context
import com.example.data.local.AlbumPhotoDao
import com.example.data.local.MemoryDao
import com.example.data.local.TripDao
import com.example.domain.model.AlbumPhoto
import com.example.domain.model.Memory
import com.example.domain.model.MemoryPhotoCrossRef
import com.example.domain.model.Mood
import com.example.domain.model.Trip
import java.util.UUID

class CloudRestoreRepository(
    context: Context,

    private val cloudProvider:
        CloudProvider,

    private val tripDao:
        TripDao,

    private val memoryDao:
        MemoryDao,

    private val photoDao:
        AlbumPhotoDao
) {

    private val photoStorage =
        RestoredPhotoStorage(
            context
        )

    suspend fun restoreEverything(
        onProgress:
            suspend (
                RestoreProgress
            ) -> Unit
    ): Result<RestoreSummary> {

        return runCatching {

            check(
                cloudProvider
                    .isAuthenticated()
            ) {
                "Sign in before restoring your cloud backup."
            }

            onProgress(
                RestoreProgress(
                    phase =
                        RestorePhase.PREPARING,

                    message =
                        "Checking your cloud backup…"
                )
            )

            val journeys =
                cloudProvider
                    .fetchJourneys(null)
                    .getOrThrow()

            val memories =
                cloudProvider
                    .fetchMemories(null)
                    .getOrThrow()

            val photos =
                cloudProvider
                    .fetchPhotos(null)
                    .getOrThrow()

            val links =
                cloudProvider
                    .fetchMemoryPhotoLinks()
                    .getOrThrow()

            var journeysInserted = 0
            var journeysUpdated = 0
            var memoriesInserted = 0
            var memoriesUpdated = 0
            var photosInserted = 0
            var photosUpdated = 0
            var downloads = 0
            var restoredLinks = 0
            var conflicts = 0
            var skipped = 0
            var failures = 0

            val journeyIdMap =
                mutableMapOf<
                    String,
                    String
                >()

            val memoryIdMap =
                mutableMapOf<
                    String,
                    String
                >()

            val photoIdMap =
                mutableMapOf<
                    String,
                    String
                >()

            /*
             * =========================================
             * JOURNEYS
             * =========================================
             */

            journeys.forEachIndexed {
                    index,
                    cloud
                ->

                onProgress(
                    RestoreProgress(
                        RestorePhase.JOURNEYS,
                        index + 1,
                        journeys.size,
                        "Restoring Journeys…"
                    )
                )

                try {

                    val existing =
                        tripDao
                            .getTripByCloudId(
                                cloud.id
                            )
                            ?: cloud
                                .localReferenceId
                                ?.let {
                                    tripDao
                                        .getTripById(
                                            it
                                        )
                                }

                    val decision =
                        CloudMergeEngine
                            .decide(
                                existing
                                    ?.updatedAt,

                                existing
                                    ?.syncStatus,

                                cloud.updatedAt,

                                cloud.deletedAt
                            )

                    when (decision) {

                        CloudMergeDecision
                            .INSERT_CLOUD -> {

                            val localId =
                                cloud
                                    .localReferenceId
                                    ?.takeIf {
                                        it.isNotBlank()
                                    }
                                    ?: "trip_${
                                        UUID.randomUUID()
                                    }"

                            tripDao.insertTrip(
                                cloud.toTrip(
                                    localId
                                )
                            )

                            journeyIdMap[
                                cloud.id
                            ] = localId

                            journeysInserted++
                        }

                        CloudMergeDecision
                            .APPLY_CLOUD -> {

                            if (
                                existing != null
                            ) {

                                tripDao.updateTrip(
                                    cloud.toTrip(
                                        existing.id,
                                        existing
                                    )
                                )

                                journeyIdMap[
                                    cloud.id
                                ] =
                                    existing.id

                                journeysUpdated++
                            }
                        }

                        CloudMergeDecision
                            .KEEP_LOCAL -> {

                            existing?.let {

                                journeyIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            skipped++
                        }

                        CloudMergeDecision
                            .CONFLICT -> {

                            existing?.let {

                                tripDao.updateTrip(
                                    it.copy(
                                        syncStatus =
                                            "CONFLICT"
                                    )
                                )

                                journeyIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            conflicts++
                        }

                        CloudMergeDecision.SKIP -> {

                            existing?.let {

                                journeyIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            skipped++
                        }
                    }

                } catch (_: Exception) {

                    failures++
                }
            }

            /*
             * =========================================
             * MEMORIES
             * =========================================
             */

            memories.forEachIndexed {
                    index,
                    cloud
                ->

                onProgress(
                    RestoreProgress(
                        RestorePhase.MEMORIES,
                        index + 1,
                        memories.size,
                        "Restoring Memories…"
                    )
                )

                try {

                    val journeyLocalId =
                        journeyIdMap[
                            cloud.journeyCloudId
                        ]
                            ?: run {
                                failures++
                                return@forEachIndexed
                            }

                    val existing =
                        memoryDao
                            .getMemoryByCloudId(
                                cloud.id
                            )
                            ?: cloud
                                .localReferenceId
                                ?.let {
                                    memoryDao
                                        .getMemoryById(
                                            it
                                        )
                                }

                    val decision =
                        CloudMergeEngine
                            .decide(
                                existing
                                    ?.updatedAt,

                                existing
                                    ?.syncStatus,

                                cloud.updatedAt,

                                cloud.deletedAt
                            )

                    when (decision) {

                        CloudMergeDecision
                            .INSERT_CLOUD -> {

                            val localId =
                                cloud
                                    .localReferenceId
                                    ?.takeIf {
                                        it.isNotBlank()
                                    }
                                    ?: "mem_${
                                        UUID.randomUUID()
                                    }"

                            memoryDao
                                .insertMemory(
                                    cloud.toMemory(
                                        localId =
                                            localId,

                                        tripId =
                                            journeyLocalId
                                    )
                                )

                            memoryIdMap[
                                cloud.id
                            ] = localId

                            memoriesInserted++
                        }

                        CloudMergeDecision
                            .APPLY_CLOUD -> {

                            if (
                                existing != null
                            ) {

                                memoryDao
                                    .updateMemory(
                                        cloud.toMemory(
                                            localId =
                                                existing.id,

                                            tripId =
                                                journeyLocalId,

                                            existing =
                                                existing
                                        )
                                    )

                                memoryIdMap[
                                    cloud.id
                                ] =
                                    existing.id

                                memoriesUpdated++
                            }
                        }

                        CloudMergeDecision
                            .KEEP_LOCAL -> {

                            existing?.let {

                                memoryIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            skipped++
                        }

                        CloudMergeDecision
                            .CONFLICT -> {

                            existing?.let {

                                memoryDao
                                    .updateMemory(
                                        it.copy(
                                            syncStatus =
                                                "CONFLICT"
                                        )
                                    )

                                memoryIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            conflicts++
                        }

                        CloudMergeDecision.SKIP -> {

                            existing?.let {

                                memoryIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            skipped++
                        }
                    }

                } catch (_: Exception) {

                    failures++
                }
            }

            /*
             * =========================================
             * PHOTOS
             * =========================================
             */

            photos.forEachIndexed {
                    index,
                    cloud
                ->

                onProgress(
                    RestoreProgress(
                        RestorePhase.PHOTOS,
                        index + 1,
                        photos.size,
                        "Restoring photos…"
                    )
                )

                try {

                    val journeyLocalId =
                        journeyIdMap[
                            cloud.journeyCloudId
                        ]
                            ?: run {
                                failures++
                                return@forEachIndexed
                            }

                    val existing =
                        photoDao
                            .getPhotoByCloudId(
                                cloud.id
                            )
                            ?: cloud
                                .localReferenceId
                                ?.let {
                                    photoDao
                                        .getPhotoById(
                                            it
                                        )
                                }

                    val decision =
                        CloudMergeEngine
                            .decide(
                                existing
                                    ?.updatedAt,

                                existing
                                    ?.syncStatus,

                                cloud.updatedAt,

                                cloud.deletedAt
                            )

                    when (decision) {

                        CloudMergeDecision
                            .INSERT_CLOUD,

                        CloudMergeDecision
                            .APPLY_CLOUD -> {

                            val localId =
                                existing?.id
                                    ?: cloud
                                        .localReferenceId
                                        ?.takeIf {
                                            it.isNotBlank()
                                        }
                                    ?: "photo_${
                                        UUID.randomUUID()
                                    }"

                            var files:
                                RestoredPhotoFiles? =
                                null

                            val remotePath =
                                cloud
                                    .remoteFilePath

                            if (
                                !remotePath
                                    .isNullOrBlank()
                            ) {

                                val bytes =
                                    cloudProvider
                                        .downloadPhotoFile(
                                            remotePath
                                        )
                                        .getOrThrow()

                                files =
                                    photoStorage
                                        .save(
                                            journeyId =
                                                journeyLocalId,

                                            photoId =
                                                localId,

                                            bytes =
                                                bytes
                                        )

                                downloads++
                            }

                            val restored =
                                cloud.toAlbumPhoto(
                                    localId =
                                        localId,

                                    journeyId =
                                        journeyLocalId,

                                    files =
                                        files,

                                    existing =
                                        existing
                                )

                            if (
                                existing == null
                            ) {

                                photoDao
                                    .insertPhoto(
                                        restored
                                    )

                                photosInserted++

                            } else {

                                photoDao
                                    .updatePhoto(
                                        restored
                                    )

                                photosUpdated++
                            }

                            photoIdMap[
                                cloud.id
                            ] = localId
                        }

                        CloudMergeDecision
                            .KEEP_LOCAL -> {

                            existing?.let {

                                photoIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            skipped++
                        }

                        CloudMergeDecision
                            .CONFLICT -> {

                            existing?.let {

                                photoDao
                                    .updatePhoto(
                                        it.copy(
                                            syncStatus =
                                                "CONFLICT"
                                        )
                                    )

                                photoIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            conflicts++
                        }

                        CloudMergeDecision.SKIP -> {

                            existing?.let {

                                photoIdMap[
                                    cloud.id
                                ] = it.id
                            }

                            skipped++
                        }
                    }

                } catch (_: Exception) {

                    failures++
                }
            }

            /*
             * =========================================
             * MEMORY / PHOTO RELATIONSHIPS
             * =========================================
             */

            onProgress(
                RestoreProgress(
                    phase =
                        RestorePhase.RELATIONSHIPS,

                    message =
                        "Restoring Memory albums…"
                )
            )

            links.forEach { link ->

                try {

                    val memoryLocalId =
                        memoryIdMap[
                            link.memoryCloudId
                        ]
                            ?: return@forEach

                    val photoLocalId =
                        photoIdMap[
                            link.photoCloudId
                        ]
                            ?: return@forEach

                    memoryDao
                        .insertMemoryPhotoCrossRef(
                            MemoryPhotoCrossRef(
                                memoryId =
                                    memoryLocalId,

                                albumPhotoId =
                                    photoLocalId,

                                displayOrder =
                                    link.displayOrder,

                                isHeroPhoto =
                                    link.isHeroPhoto
                            )
                        )

                    restoredLinks++

                } catch (_: Exception) {

                    failures++
                }
            }

            onProgress(
                RestoreProgress(
                    phase =
                        RestorePhase.COMPLETE,

                    message =
                        "Restore complete."
                )
            )

            RestoreSummary(
                journeysInserted =
                    journeysInserted,

                journeysUpdated =
                    journeysUpdated,

                memoriesInserted =
                    memoriesInserted,

                memoriesUpdated =
                    memoriesUpdated,

                photosInserted =
                    photosInserted,

                photosUpdated =
                    photosUpdated,

                photoFilesDownloaded =
                    downloads,

                memoryPhotoLinksRestored =
                    restoredLinks,

                conflicts =
                    conflicts,

                skipped =
                    skipped,

                failures =
                    failures
            )
        }
    }
}

/*
 * =====================================================
 * CLOUD -> CURRENT REAL ROOM MODELS
 * =====================================================
 */

private fun CloudJourney.toTrip(
    localId: String,
    existing: Trip? = null
): Trip {

    return Trip(
        id =
            localId,

        destinationName =
            destination,

        country =
            country,

        startDate =
            startDate,

        endDate =
            endDate,

        coverImage =
            existing
                ?.coverImage
                .orEmpty(),

        description =
            description,

        accentGradientIndex =
            existing
                ?.accentGradientIndex
                ?: 0,

        latitude =
            existing
                ?.latitude
                ?: 0.0,

        longitude =
            existing
                ?.longitude
                ?: 0.0,

        title =
            title,

        destination =
            destination,

        coverPhotoId =
            existing
                ?.coverPhotoId
                .orEmpty(),

        accentTheme =
            accentTheme
                ?: existing
                    ?.accentTheme
                ?: "Preset_0",

        createdAt =
            createdAt,

        updatedAt =
            updatedAt,

        favorite =
            existing
                ?.favorite
                ?: false,

        archived =
            existing
                ?.archived
                ?: false,

        statistics =
            existing
                ?.statistics
                .orEmpty(),

        futureCloudId =
            id,

        syncStatus =
            "SYNCED"
    )
}

private fun CloudMemory.toMemory(
    localId: String,
    tripId: String,
    existing: Memory? = null
): Memory {

    val restoredMood =
        runCatching {

            Mood.valueOf(
                mood ?: "HAPPY"
            )

        }.getOrDefault(
            Mood.HAPPY
        )

    return Memory(
        id =
            localId,

        tripId =
            tripId,

        journeyId =
            tripId,

        title =
            title,

        note =
            journalText,

        journalText =
            journalText,

        image =
            existing
                ?.image
                .orEmpty(),

        locationName =
            locationName.orEmpty(),

        latitude =
            latitude,

        longitude =
            longitude,

        date =
            date,

        mood =
            restoredMood,

        tags =
            tags,

        favorite =
            existing
                ?.favorite
                ?: false,

        createdAt =
            createdAt,

        updatedAt =
            updatedAt,

        displayOrder =
            existing
                ?.displayOrder
                ?: 0,

        syncStatus =
            "SYNCED",

        futureCloudId =
            id
    )
}

private fun CloudAlbumPhoto.toAlbumPhoto(
    localId: String,
    journeyId: String,
    files: RestoredPhotoFiles?,
    existing: AlbumPhoto?
): AlbumPhoto {

    val originalPath =
        files
            ?.originalPath
            ?: existing
                ?.localUri
            ?: ""

    val thumbnailPath =
        files
            ?.thumbnailPath
            ?: existing
                ?.thumbnailUri
            ?: originalPath

    return AlbumPhoto(
        id =
            localId,

        journeyId =
            journeyId,

        localUri =
            originalPath,

        thumbnailUri =
            thumbnailPath,

        originalUri =
            originalPath,

        fileName =
            fileName
                ?: existing
                    ?.fileName
                ?: "$localId.jpg",

        mimeType =
            mimeType
                ?: existing
                    ?.mimeType
                ?: "image/jpeg",

        width =
            files
                ?.width
                ?: existing
                    ?.width
                ?: 0,

        height =
            files
                ?.height
                ?: existing
                    ?.height
                ?: 0,

        fileSize =
            files
                ?.fileSize
                ?: existing
                    ?.fileSize
                ?: 0L,

        createdAt =
            createdAt,

        updatedAt =
            updatedAt,

        capturedAt =
            capturedAt,

        gpsLatitude =
            latitude,

        gpsLongitude =
            longitude,

        locationName =
            locationName.orEmpty(),

        favorite =
            existing
                ?.favorite
                ?: false,

        isCoverPhoto =
            isCoverPhoto,

        displayOrder =
            displayOrder,

        syncStatus =
            "SYNCED",

        futureCloudId =
            id
    )
}
