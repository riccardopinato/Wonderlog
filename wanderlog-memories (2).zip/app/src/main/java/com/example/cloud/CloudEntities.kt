package com.example.cloud

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CloudJourney(

    val id: String,

    @SerialName("owner_id")
    val ownerId: String,

    @SerialName("local_reference_id")
    val localReferenceId: String?,

    val title: String,

    val destination: String,

    val country: String,

    val description: String,

    @SerialName("start_date")
    val startDate: String,

    @SerialName("end_date")
    val endDate: String,

    @SerialName("accent_theme")
    val accentTheme: String?,

    @SerialName("cover_photo_cloud_id")
    val coverPhotoCloudId: String?,

    @SerialName("created_at")
    val createdAt: Long,

    @SerialName("updated_at")
    val updatedAt: Long,

    @SerialName("deleted_at")
    val deletedAt: Long? = null,

    @SerialName("schema_version")
    val schemaVersion: Int =
        CloudBackupConfig.CLOUD_SCHEMA_VERSION
)

@Serializable
data class CloudMemory(

    val id: String,

    @SerialName("owner_id")
    val ownerId: String,

    @SerialName("journey_cloud_id")
    val journeyCloudId: String,

    @SerialName("local_reference_id")
    val localReferenceId: String?,

    val title: String,

    @SerialName("journal_text")
    val journalText: String,

    val date: String,

    @SerialName("location_name")
    val locationName: String?,

    val latitude: Double?,

    val longitude: Double?,

    val mood: String?,

    val tags: List<String>,

    @SerialName("created_at")
    val createdAt: Long,

    @SerialName("updated_at")
    val updatedAt: Long,

    @SerialName("deleted_at")
    val deletedAt: Long? = null,

    @SerialName("schema_version")
    val schemaVersion: Int =
        CloudBackupConfig.CLOUD_SCHEMA_VERSION
)

@Serializable
data class CloudAlbumPhoto(

    val id: String,

    @SerialName("owner_id")
    val ownerId: String,

    @SerialName("journey_cloud_id")
    val journeyCloudId: String,

    @SerialName("local_reference_id")
    val localReferenceId: String?,

    @SerialName("remote_file_path")
    val remoteFilePath: String?,

    @SerialName("file_name")
    val fileName: String?,

    @SerialName("mime_type")
    val mimeType: String?,

    @SerialName("captured_at")
    val capturedAt: Long?,

    val latitude: Double?,

    val longitude: Double?,

    @SerialName("location_name")
    val locationName: String?,

    @SerialName("display_order")
    val displayOrder: Int,

    @SerialName("is_cover_photo")
    val isCoverPhoto: Boolean,

    @SerialName("created_at")
    val createdAt: Long,

    @SerialName("updated_at")
    val updatedAt: Long,

    @SerialName("deleted_at")
    val deletedAt: Long? = null,

    @SerialName("schema_version")
    val schemaVersion: Int =
        CloudBackupConfig.CLOUD_SCHEMA_VERSION
)

@Serializable
data class CloudMemoryPhotoLink(

    @SerialName("owner_id")
    val ownerId: String,

    @SerialName("memory_cloud_id")
    val memoryCloudId: String,

    @SerialName("photo_cloud_id")
    val photoCloudId: String,

    @SerialName("display_order")
    val displayOrder: Int,

    @SerialName("is_hero_photo")
    val isHeroPhoto: Boolean
)
