package com.example.cloud

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "cloud_sync_queue",
    indices = [
        Index(
            value = [
                "entityType",
                "localEntityId",
                "operation"
            ],
            unique = true
        )
    ]
)
data class SyncQueueEntity(
    @PrimaryKey
    val id: String,

    val entityType: String,

    val localEntityId: String,

    val operation: String,

    val createdAt: Long,

    val attemptCount: Int,

    val lastError: String?
) {

    fun toDomain():
        SyncQueueItem {

        return SyncQueueItem(
            id = id,

            entityType =
                SyncEntityType.valueOf(
                    entityType
                ),

            localEntityId =
                localEntityId,

            operation =
                SyncOperation.valueOf(
                    operation
                ),

            createdAt =
                createdAt,

            attemptCount =
                attemptCount,

            lastError =
                lastError
        )
    }

    companion object {

        fun fromDomain(
            item: SyncQueueItem
        ): SyncQueueEntity {

            return SyncQueueEntity(
                id = item.id,

                entityType =
                    item.entityType.name,

                localEntityId =
                    item.localEntityId,

                operation =
                    item.operation.name,

                createdAt =
                    item.createdAt,

                attemptCount =
                    item.attemptCount,

                lastError =
                    item.lastError
            )
        }
    }
}
