package com.example.cloud

interface CloudRepository {

    suspend fun enqueueJourney(
        journeyId: String
    )

    suspend fun enqueueMemory(
        memoryId: String
    )

    suspend fun enqueuePhoto(
        photoId: String
    )

    suspend fun enqueueDelete(
        entityType: SyncEntityType,
        localId: String
    )

    suspend fun pendingCount(): Int

    suspend fun syncNow(): Result<SyncSummary>
}
