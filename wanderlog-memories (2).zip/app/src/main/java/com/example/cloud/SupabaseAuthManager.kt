package com.example.cloud

import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email

class SupabaseAuthManager {

    private val client =
        SupabaseClientProvider.client

    fun isAuthenticated(): Boolean {

        return client
            .auth
            .currentSessionOrNull()
            ?.user != null
    }

    fun currentUserId(): String? {

        return client
            .auth
            .currentSessionOrNull()
            ?.user
            ?.id
    }

    fun currentEmail(): String? {

        return client
            .auth
            .currentSessionOrNull()
            ?.user
            ?.email
    }

    suspend fun signUp(
        email: String,
        password: String
    ): Result<Unit> {

        return runCatching {

            require(
                email.isNotBlank()
            ) {
                "Email is required."
            }

            require(
                password.length >= 8
            ) {
                "Password must contain at least 8 characters."
            }

            client
                .auth
                .signUpWith(
                    Email
                ) {

                    this.email =
                        email.trim()

                    this.password =
                        password
                }

            Unit
        }
    }

    suspend fun signIn(
        email: String,
        password: String
    ): Result<Unit> {

        return runCatching {

            client
                .auth
                .signInWith(
                    Email
                ) {

                    this.email =
                        email.trim()

                    this.password =
                        password
                }

            Unit
        }
    }

    suspend fun signOut(context: android.content.Context? = null):
        Result<Unit> {

        return runCatching {

            context?.let { ctx ->
                CloudBackupScheduler(ctx).cancelAllCloudWork()
            }

            client
                .auth
                .signOut()

            Unit
        }
    }
}
