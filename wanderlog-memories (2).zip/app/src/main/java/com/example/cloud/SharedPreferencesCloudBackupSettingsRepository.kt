package com.example.cloud

import android.content.Context
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class SharedPreferencesCloudBackupSettingsRepository(
    context: Context
) : CloudBackupSettingsRepository {

    private val preferences =
        context.applicationContext
            .getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
            )

    override val settings:
        Flow<CloudBackupSettings> =
        callbackFlow {

            fun emitCurrent() {
                trySend(
                    readSettings()
                )
            }

            val listener =
                android.content
                    .SharedPreferences
                    .OnSharedPreferenceChangeListener {
                            _,
                            _
                        ->

                        emitCurrent()
                    }

            preferences
                .registerOnSharedPreferenceChangeListener(
                    listener
                )

            emitCurrent()

            awaitClose {

                preferences
                    .unregisterOnSharedPreferenceChangeListener(
                        listener
                    )
            }
        }

    override suspend fun getSettings():
        CloudBackupSettings {

        return readSettings()
    }

    override suspend fun setAutomaticBackupEnabled(
        enabled: Boolean
    ) {

        preferences
            .edit()
            .putBoolean(
                KEY_AUTO_BACKUP,
                enabled
            )
            .apply()
    }

    override suspend fun setWifiOnly(
        enabled: Boolean
    ) {

        preferences
            .edit()
            .putBoolean(
                KEY_WIFI_ONLY,
                enabled
            )
            .apply()
    }

    override suspend fun setIncludePhotos(
        enabled: Boolean
    ) {

        preferences
            .edit()
            .putBoolean(
                KEY_INCLUDE_PHOTOS,
                enabled
            )
            .apply()
    }

    override suspend fun setBatteryNotLowOnly(
        enabled: Boolean
    ) {

        preferences
            .edit()
            .putBoolean(
                KEY_BATTERY_NOT_LOW,
                enabled
            )
            .apply()
    }

    override suspend fun setPeriodicIntervalHours(
        hours: Long
    ) {

        preferences
            .edit()
            .putLong(
                KEY_PERIOD_HOURS,
                hours.coerceAtLeast(
                    MIN_PERIOD_HOURS
                )
            )
            .apply()
    }

    override suspend fun setLastSuccessfulBackupAt(
        timestamp: Long?
    ) {

        val editor =
            preferences.edit()

        if (timestamp == null) {

            editor.remove(
                KEY_LAST_SUCCESS
            )

        } else {

            editor.putLong(
                KEY_LAST_SUCCESS,
                timestamp
            )
        }

        editor.apply()
    }

    override suspend fun getLastSuccessfulBackupAt():
        Long? {

        if (
            !preferences.contains(
                KEY_LAST_SUCCESS
            )
        ) {
            return null
        }

        return preferences.getLong(
            KEY_LAST_SUCCESS,
            0L
        )
            .takeIf {
                it > 0L
            }
    }

    private fun readSettings():
        CloudBackupSettings {

        return CloudBackupSettings(

            automaticBackupEnabled =
                preferences.getBoolean(
                    KEY_AUTO_BACKUP,
                    CloudBackupConfig
                        .AUTO_SYNC_ENABLED_DEFAULT
                ),

            wifiOnly =
                preferences.getBoolean(
                    KEY_WIFI_ONLY,
                    CloudBackupConfig
                        .AUTO_SYNC_WIFI_ONLY_DEFAULT
                ),

            includePhotos =
                preferences.getBoolean(
                    KEY_INCLUDE_PHOTOS,
                    true
                ),

            batteryNotLowOnly =
                preferences.getBoolean(
                    KEY_BATTERY_NOT_LOW,
                    true
                ),

            periodicIntervalHours =
                preferences.getLong(
                    KEY_PERIOD_HOURS,
                    DEFAULT_PERIOD_HOURS
                )
                    .coerceAtLeast(
                        MIN_PERIOD_HOURS
                    )
        )
    }

    companion object {

        private const val PREFS_NAME =
            "wonderlog_cloud_backup"

        private const val KEY_AUTO_BACKUP =
            "automatic_backup_enabled"

        private const val KEY_WIFI_ONLY =
            "wifi_only"

        private const val KEY_INCLUDE_PHOTOS =
            "include_photos"

        private const val KEY_BATTERY_NOT_LOW =
            "battery_not_low_only"

        private const val KEY_PERIOD_HOURS =
            "periodic_interval_hours"

        private const val KEY_LAST_SUCCESS =
            "last_successful_backup_at"

        private const val DEFAULT_PERIOD_HOURS =
            6L

        private const val MIN_PERIOD_HOURS =
            6L
    }
}
