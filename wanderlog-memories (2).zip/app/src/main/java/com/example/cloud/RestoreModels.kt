package com.example.cloud

data class RestoreSummary(
    val journeysInserted: Int = 0,
    val journeysUpdated: Int = 0,

    val memoriesInserted: Int = 0,
    val memoriesUpdated: Int = 0,

    val photosInserted: Int = 0,
    val photosUpdated: Int = 0,

    val photoFilesDownloaded: Int = 0,

    val memoryPhotoLinksRestored: Int = 0,

    val conflicts: Int = 0,

    val skipped: Int = 0,

    val failures: Int = 0
)

enum class RestorePhase {

    PREPARING,

    JOURNEYS,

    MEMORIES,

    PHOTOS,

    RELATIONSHIPS,

    COMPLETE
}

data class RestoreProgress(
    val phase: RestorePhase,
    val current: Int = 0,
    val total: Int = 0,
    val message: String
)

sealed interface RestoreState {

    data object Idle :
        RestoreState

    data class Running(
        val progress: RestoreProgress
    ) : RestoreState

    data class Success(
        val summary: RestoreSummary
    ) : RestoreState

    data class Error(
        val message: String
    ) : RestoreState
}
