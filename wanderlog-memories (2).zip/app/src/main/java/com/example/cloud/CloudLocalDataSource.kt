package com.example.cloud

data class PhotoCloudDeleteInfo(
    val cloudId: String,
    val remoteFilePath: String?
)

interface CloudLocalDataSource {

    suspend fun getJourneyForCloud(
        localId: String
    ): CloudJourney?

    suspend fun getMemoryForCloud(
        localId: String
    ): CloudMemory?

    suspend fun getPhotoForCloud(
        localId: String
    ): CloudAlbumPhoto?

    suspend fun getPhotoLocalPath(
        localId: String
    ): String?

    suspend fun buildRemotePhotoPath(
        localId: String
    ): String

    suspend fun markJourneySynced(
        localId: String,
        cloudId: String
    )

    suspend fun markMemorySynced(
        localId: String,
        cloudId: String
    )

    suspend fun markPhotoSynced(
        localId: String,
        cloudId: String,
        remotePath: String?
    )

    suspend fun getJourneyCloudId(
        localId: String
    ): String?

    suspend fun getMemoryCloudId(
        localId: String
    ): String?

    suspend fun getPhotoCloudDeleteInfo(
        localId: String
    ): PhotoCloudDeleteInfo?
}
