package com.example.cloud

import java.nio.charset.StandardCharsets
import java.util.UUID

object CloudIdFactory {

    fun journey(
        ownerId: String,
        localId: String
    ): String {

        return stableId(
            "$ownerId|journey|$localId"
        )
    }

    fun memory(
        ownerId: String,
        localId: String
    ): String {

        return stableId(
            "$ownerId|memory|$localId"
        )
    }

    fun photo(
        ownerId: String,
        localId: String
    ): String {

        return stableId(
            "$ownerId|photo|$localId"
        )
    }

    private fun stableId(
        value: String
    ): String {

        return UUID
            .nameUUIDFromBytes(
                value.toByteArray(
                    StandardCharsets.UTF_8
                )
            )
            .toString()
    }
}
