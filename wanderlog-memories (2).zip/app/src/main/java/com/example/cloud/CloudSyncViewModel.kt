package com.example.cloud

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

class CloudSyncViewModel(
    private val repository:
        CloudRepository,

    private val backupCoordinator:
        CloudBackupCoordinator,

    private val settingsRepository:
        CloudBackupSettingsRepository? = null,

    private val scheduler:
        CloudBackupScheduler? = null
) : ViewModel() {

    private val _state =
        MutableStateFlow(
            CloudSyncState()
        )

    val state:
        StateFlow<CloudSyncState> =
        _state.asStateFlow()

    private val _uiState =
        MutableStateFlow(
            CloudBackupUiState()
        )

    val uiState:
        StateFlow<CloudBackupUiState> =
        _uiState.asStateFlow()

    init {
        settingsRepository?.let { repo ->
            repo.settings
                .onEach { newSettings ->
                    _uiState.value =
                        _uiState.value.copy(
                            settings = newSettings
                        )
                }
                .launchIn(viewModelScope)

            viewModelScope.launch {
                val lastSuccess = repo.getLastSuccessfulBackupAt()
                _uiState.value =
                    _uiState.value.copy(
                        lastSuccessfulBackupAt = lastSuccess
                    )
                if (lastSuccess != null && _state.value.lastSuccessfulSyncAt == null) {
                    _state.value =
                        _state.value.copy(
                            lastSuccessfulSyncAt = lastSuccess
                        )
                }
            }
        }
    }

    fun updateSettings(updated: CloudBackupSettings) {
        viewModelScope.launch {
            settingsRepository?.let { repo ->
                repo.setAutomaticBackupEnabled(updated.automaticBackupEnabled)
                repo.setWifiOnly(updated.wifiOnly)
                repo.setIncludePhotos(updated.includePhotos)
                repo.setBatteryNotLowOnly(updated.batteryNotLowOnly)
                repo.setPeriodicIntervalHours(updated.periodicIntervalHours)

                val persisted = repo.getSettings()
                scheduler?.applySettings(persisted)
            }
        }
    }

    fun refreshPendingCount() {

        viewModelScope.launch {

            val pending = repository.pendingCount()
            _state.value =
                _state.value.copy(
                    pendingItems = pending
                )
            _uiState.value =
                _uiState.value.copy(
                    sync = _state.value
                )
        }
    }

    fun backupNow() {

        if (
            _state.value.isSyncing
        ) {
            return
        }

        viewModelScope.launch {

            _state.value =
                _state.value.copy(
                    isSyncing =
                        true,

                    progressLabel =
                        "Backing up your Journeys…",

                    errorMessage =
                        null,

                    summary =
                        null
                )
            _uiState.value =
                _uiState.value.copy(sync = _state.value)

            backupCoordinator
                .backupEverything()
                .onSuccess { summary ->

                    val now = System.currentTimeMillis()
                    settingsRepository?.setLastSuccessfulBackupAt(now)

                    _state.value =
                        _state.value.copy(
                            isSyncing =
                                false,

                            lastSuccessfulSyncAt =
                                now,

                            pendingItems =
                                repository
                                    .pendingCount(),

                            progressLabel =
                                null,

                            summary =
                                summary,

                            errorMessage =
                                null
                        )
                    _uiState.value =
                        _uiState.value.copy(
                            sync = _state.value,
                            lastSuccessfulBackupAt = now
                        )
                }
                .onFailure { error ->

                    _state.value =
                        _state.value.copy(
                            isSyncing =
                                false,

                            progressLabel =
                                null,

                            pendingItems =
                                repository
                                    .pendingCount(),

                            errorMessage =
                                error.message
                                    ?: "Cloud backup failed."
                        )
                    _uiState.value =
                        _uiState.value.copy(sync = _state.value)
                }
        }
    }

    fun clearError() {

        _state.value =
            _state.value.copy(
                errorMessage =
                    null
            )
        _uiState.value =
            _uiState.value.copy(sync = _state.value)
    }
}
