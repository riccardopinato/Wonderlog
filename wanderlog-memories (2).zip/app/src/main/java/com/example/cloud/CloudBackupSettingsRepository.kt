package com.example.cloud

import kotlinx.coroutines.flow.Flow

interface CloudBackupSettingsRepository {

    val settings: Flow<CloudBackupSettings>

    suspend fun getSettings():
        CloudBackupSettings

    suspend fun setAutomaticBackupEnabled(
        enabled: Boolean
    )

    suspend fun setWifiOnly(
        enabled: Boolean
    )

    suspend fun setIncludePhotos(
        enabled: Boolean
    )

    suspend fun setBatteryNotLowOnly(
        enabled: Boolean
    )

    suspend fun setPeriodicIntervalHours(
        hours: Long
    )

    suspend fun setLastSuccessfulBackupAt(
        timestamp: Long?
    )

    suspend fun getLastSuccessfulBackupAt():
        Long?
}
