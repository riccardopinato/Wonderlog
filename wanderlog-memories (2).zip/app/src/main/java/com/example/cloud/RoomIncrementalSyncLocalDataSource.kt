package com.example.cloud

import com.example.data.local.AlbumPhotoDao
import com.example.data.local.MemoryDao
import com.example.data.local.TripDao

class RoomIncrementalSyncLocalDataSource(
    private val tripDao: TripDao,
    private val memoryDao: MemoryDao,
    private val photoDao: AlbumPhotoDao
) : IncrementalSyncLocalDataSource {

    override suspend fun getPendingJourneyIds():
        List<String> {

        return tripDao
            .getPendingCloudSyncIds()
    }

    override suspend fun getPendingMemoryIds():
        List<String> {

        return memoryDao
            .getPendingCloudSyncIds()
    }

    override suspend fun getPendingPhotoIds():
        List<String> {

        return photoDao
            .getPendingCloudSyncIds()
    }
}
