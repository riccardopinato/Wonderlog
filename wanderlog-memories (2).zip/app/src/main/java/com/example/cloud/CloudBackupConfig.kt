package com.example.cloud

object CloudBackupConfig {

    const val MAX_RETRY_COUNT = 5

    const val INITIAL_RETRY_DELAY_MS = 5_000L

    const val AUTO_SYNC_WIFI_ONLY_DEFAULT = true

    const val AUTO_SYNC_ENABLED_DEFAULT = true

    const val SYNC_BATCH_SIZE = 25

    const val PHOTO_UPLOAD_BATCH_SIZE = 5

    const val CLOUD_SCHEMA_VERSION = 1
}
