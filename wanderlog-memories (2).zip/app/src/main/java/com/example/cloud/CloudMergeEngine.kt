package com.example.cloud

enum class CloudMergeDecision {

    INSERT_CLOUD,

    APPLY_CLOUD,

    KEEP_LOCAL,

    CONFLICT,

    SKIP
}

object CloudMergeEngine {

    fun decide(
        localUpdatedAt: Long?,
        localSyncStatus: String?,
        cloudUpdatedAt: Long,
        cloudDeletedAt: Long?
    ): CloudMergeDecision {

        if (
            localUpdatedAt == null ||
            localSyncStatus == null
        ) {

            return if (
                cloudDeletedAt != null
            ) {
                CloudMergeDecision.SKIP
            } else {
                CloudMergeDecision.INSERT_CLOUD
            }
        }

        /*
         * Never overwrite local unsynced edits.
         */
        if (
            localSyncStatus ==
                "LOCAL_ONLY" ||
            localSyncStatus ==
                "PENDING_UPLOAD" ||
            localSyncStatus ==
                "PENDING_DELETE" ||
            localSyncStatus ==
                "CONFLICT"
        ) {

            return if (
                cloudUpdatedAt >
                localUpdatedAt
            ) {
                CloudMergeDecision.CONFLICT
            } else {
                CloudMergeDecision.KEEP_LOCAL
            }
        }

        /*
         * Current Room entities do not yet contain
         * deletedAt. Cloud tombstones therefore must
         * not hard-delete local user data silently.
         */
        if (
            cloudDeletedAt != null
        ) {

            return CloudMergeDecision.SKIP
        }

        return when {

            cloudUpdatedAt >
                localUpdatedAt ->
                CloudMergeDecision.APPLY_CLOUD

            cloudUpdatedAt <
                localUpdatedAt ->
                CloudMergeDecision.KEEP_LOCAL

            else ->
                CloudMergeDecision.SKIP
        }
    }
}
