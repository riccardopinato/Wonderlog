package com.example.cloud

class RoomSyncQueueStore(
    private val dao:
        SyncQueueDao
) : SyncQueueStore {

    override suspend fun insert(
        item: SyncQueueItem
    ) {

        dao.insert(
            SyncQueueEntity
                .fromDomain(
                    item
                )
        )
    }

    override suspend fun remove(
        queueId: String
    ) {

        dao.delete(
            queueId
        )
    }

    override suspend fun update(
        item: SyncQueueItem
    ) {

        dao.insert(
            SyncQueueEntity
                .fromDomain(
                    item
                )
        )
    }

    override suspend fun getPending(
        limit: Int
    ): List<SyncQueueItem> {

        return dao
            .getPending(
                limit
            )
            .map {
                it.toDomain()
            }
    }

    override suspend fun count():
        Int {

        return dao.count()
    }

    override suspend fun clear() {

        dao.clear()
    }
}
