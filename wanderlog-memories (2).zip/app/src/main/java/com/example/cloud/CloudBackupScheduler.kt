package com.example.cloud

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class CloudBackupScheduler(
    context: Context
) {

    private val appContext =
        context.applicationContext

    private val workManager =
        WorkManager.getInstance(
            appContext
        )

    suspend fun applySettings(
        settings:
            CloudBackupSettings
    ) {

        if (
            !settings
                .automaticBackupEnabled
        ) {

            cancelAutomaticBackup()

            return
        }

        val constraints =
            buildConstraints(
                settings
            )

        val request =
            PeriodicWorkRequestBuilder<
                CloudBackupWorker
            >(
                settings
                    .periodicIntervalHours
                    .coerceAtLeast(6L),

                TimeUnit.HOURS,

                calculateFlexHours(
                    settings
                        .periodicIntervalHours
                ),

                TimeUnit.HOURS
            )
                .setConstraints(
                    constraints
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30,
                    TimeUnit.SECONDS
                )
                .addTag(
                    CloudBackupWorker.TAG
                )
                .build()

        workManager
            .enqueueUniquePeriodicWork(
                PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
    }

    fun scheduleOpportunisticBackup(
        settings:
            CloudBackupSettings
    ) {

        if (
            !settings
                .automaticBackupEnabled
        ) {
            return
        }

        val request =
            OneTimeWorkRequestBuilder<
                CloudBackupWorker
            >()
                .setInitialDelay(
                    30,
                    TimeUnit.SECONDS
                )
                .setConstraints(
                    buildConstraints(
                        settings
                    )
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30,
                    TimeUnit.SECONDS
                )
                .addTag(
                    CloudBackupWorker.TAG
                )
                .build()

        workManager
            .enqueueUniqueWork(
                OPPORTUNISTIC_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
    }

    fun scheduleImmediateBackup() {

        val request =
            OneTimeWorkRequestBuilder<
                CloudBackupWorker
            >()
                .setConstraints(
                    Constraints
                        .Builder()
                        .setRequiredNetworkType(
                            NetworkType.CONNECTED
                        )
                        .build()
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30,
                    TimeUnit.SECONDS
                )
                .addTag(
                    CloudBackupWorker.TAG
                )
                .build()

        workManager
            .enqueueUniqueWork(
                MANUAL_WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
    }

    fun cancelAutomaticBackup() {

        workManager
            .cancelUniqueWork(
                PERIODIC_WORK_NAME
            )

        workManager
            .cancelUniqueWork(
                OPPORTUNISTIC_WORK_NAME
            )
    }

    fun cancelAllCloudWork() {

        workManager
            .cancelAllWorkByTag(
                CloudBackupWorker.TAG
            )
    }

    private fun buildConstraints(
        settings:
            CloudBackupSettings
    ): Constraints {

        return Constraints
            .Builder()
            .setRequiredNetworkType(
                if (
                    settings.wifiOnly
                ) {
                    NetworkType.UNMETERED
                } else {
                    NetworkType.CONNECTED
                }
            )
            .setRequiresBatteryNotLow(
                settings
                    .batteryNotLowOnly
            )
            .setRequiresStorageNotLow(
                true
            )
            .build()
    }

    private fun calculateFlexHours(
        intervalHours: Long
    ): Long {

        return when {

            intervalHours >= 12L ->
                2L

            intervalHours >= 6L ->
                1L

            else ->
                1L
        }
    }

    companion object {

        private const val PERIODIC_WORK_NAME =
            "wonderlog_periodic_cloud_backup"

        private const val OPPORTUNISTIC_WORK_NAME =
            "wonderlog_opportunistic_cloud_backup"

        private const val MANUAL_WORK_NAME =
            "wonderlog_manual_cloud_backup"
    }
}
