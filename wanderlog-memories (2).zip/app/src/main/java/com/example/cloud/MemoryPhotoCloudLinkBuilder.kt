package com.example.cloud

import com.example.data.local.AlbumPhotoDao
import com.example.data.local.MemoryDao

class MemoryPhotoCloudLinkBuilder(
    private val memoryDao:
        MemoryDao,

    private val photoDao:
        AlbumPhotoDao,

    private val authManager:
        SupabaseAuthManager
) {

    suspend fun build():
        List<CloudMemoryPhotoLink> {

        val ownerId =
            authManager
                .currentUserId()
                ?: return emptyList()

        return memoryDao
            .getAllMemoryPhotoCrossRefsOnce()
            .mapNotNull { crossRef ->

                val memory =
                    memoryDao
                        .getMemoryById(
                            crossRef.memoryId
                        )
                        ?: return@mapNotNull null

                val photo =
                    photoDao
                        .getPhotoById(
                            crossRef.albumPhotoId
                        )
                        ?: return@mapNotNull null

                val memoryCloudId =
                    memory.futureCloudId
                        ?: CloudIdFactory.memory(
                            ownerId,
                            memory.id
                        )

                val photoCloudId =
                    photo.futureCloudId
                        ?: CloudIdFactory.photo(
                            ownerId,
                            photo.id
                        )

                CloudMemoryPhotoLink(
                    ownerId =
                        ownerId,

                    memoryCloudId =
                        memoryCloudId,

                    photoCloudId =
                        photoCloudId,

                    displayOrder =
                        crossRef.displayOrder,

                    isHeroPhoto =
                        crossRef.isHeroPhoto
                )
            }
    }
}
