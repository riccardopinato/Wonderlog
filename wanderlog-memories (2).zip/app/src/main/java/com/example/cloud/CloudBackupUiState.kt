package com.example.cloud

data class CloudBackupUiState(
    val sync:
        CloudSyncState =
        CloudSyncState(),

    val settings:
        CloudBackupSettings =
        CloudBackupSettings(),

    val lastSuccessfulBackupAt:
        Long? = null
)
