package com.example.cloud

data class CloudBackupSettings(
    val automaticBackupEnabled: Boolean =
        CloudBackupConfig.AUTO_SYNC_ENABLED_DEFAULT,

    val wifiOnly: Boolean =
        CloudBackupConfig.AUTO_SYNC_WIFI_ONLY_DEFAULT,

    val includePhotos: Boolean = true,

    val batteryNotLowOnly: Boolean = true,

    /**
     * Background backup cadence.
     *
     * WorkManager timing is intentionally inexact.
     */
    val periodicIntervalHours: Long = 6L
)
