package com.example.cloud

import android.content.Context
import com.example.data.local.WanderlogDatabase

object CloudRestoreDependencies {

    fun createRepository(
        context: Context
    ): CloudRestoreRepository {

        val database =
            WanderlogDatabase
                .getDatabase(
                    context
                )

        val authManager =
            SupabaseAuthManager()

        return CloudRestoreRepository(
            context =
                context.applicationContext,

            cloudProvider =
                SupabaseCloudProvider(
                    authManager
                ),

            tripDao =
                database.tripDao(),

            memoryDao =
                database.memoryDao(),

            photoDao =
                database.albumPhotoDao()
        )
    }
}
