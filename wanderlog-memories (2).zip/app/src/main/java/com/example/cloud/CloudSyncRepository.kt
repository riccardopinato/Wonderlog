package com.example.cloud

import java.util.UUID

class CloudSyncRepository(
    private val cloudProvider: CloudProvider,
    private val queueStore: SyncQueueStore,
    private val localDataSource: CloudLocalDataSource
) : CloudRepository {

    override suspend fun enqueueJourney(
        journeyId: String
    ) {

        enqueue(
            entityType =
                SyncEntityType.JOURNEY,

            localId =
                journeyId,

            operation =
                SyncOperation.CREATE_OR_UPDATE
        )
    }

    override suspend fun enqueueMemory(
        memoryId: String
    ) {

        enqueue(
            entityType =
                SyncEntityType.MEMORY,

            localId =
                memoryId,

            operation =
                SyncOperation.CREATE_OR_UPDATE
        )
    }

    override suspend fun enqueuePhoto(
        photoId: String
    ) {

        enqueue(
            entityType =
                SyncEntityType.ALBUM_PHOTO,

            localId =
                photoId,

            operation =
                SyncOperation.CREATE_OR_UPDATE
        )
    }

    override suspend fun enqueueDelete(
        entityType: SyncEntityType,
        localId: String
    ) {

        enqueue(
            entityType =
                entityType,

            localId =
                localId,

            operation =
                SyncOperation.DELETE
        )
    }

    override suspend fun pendingCount(): Int {

        return queueStore.count()
    }

    override suspend fun syncNow():
        Result<SyncSummary> {

        return runCatching {

            if (
                !cloudProvider
                    .isAuthenticated()
            ) {
                error(
                    "Cloud backup requires an authenticated account."
                )
            }

            val items =
                queueStore.getPending()

            var uploaded = 0
            var deleted = 0
            var failures = 0

            for (item in items) {

                val result =
                    processItem(
                        item
                    )

                if (result.isSuccess) {

                    when (
                        item.operation
                    ) {

                        SyncOperation.CREATE_OR_UPDATE ->
                            uploaded++

                        SyncOperation.DELETE ->
                            deleted++
                    }

                    queueStore.remove(
                        item.id
                    )

                } else {

                    failures++

                    val updated =
                        item.copy(
                            attemptCount =
                                item.attemptCount + 1,

                            lastError =
                                result
                                    .exceptionOrNull()
                                    ?.message
                        )

                    queueStore.update(
                        updated
                    )
                }
            }

            SyncSummary(
                uploaded =
                    uploaded,

                deleted =
                    deleted,

                failures =
                    failures
            )
        }
    }

    private suspend fun enqueue(
        entityType: SyncEntityType,
        localId: String,
        operation: SyncOperation
    ) {

        queueStore.insert(

            SyncQueueItem(
                id =
                    UUID.randomUUID()
                        .toString(),

                entityType =
                    entityType,

                localEntityId =
                    localId,

                operation =
                    operation,

                createdAt =
                    System.currentTimeMillis()
            )
        )
    }

    private suspend fun processItem(
        item: SyncQueueItem
    ): Result<Unit> {

        return when (
            item.operation
        ) {

            SyncOperation.CREATE_OR_UPDATE ->
                processUpload(
                    item
                )

            SyncOperation.DELETE ->
                processDelete(
                    item
                )
        }
    }

    private suspend fun processUpload(
        item: SyncQueueItem
    ): Result<Unit> {

        return when (
            item.entityType
        ) {

            SyncEntityType.JOURNEY -> {

                val journey =
                    localDataSource
                        .getJourneyForCloud(
                            item.localEntityId
                        )
                        ?: return Result.failure(
                            IllegalStateException(
                                "Journey not found."
                            )
                        )

                cloudProvider
                    .uploadJourney(
                        journey
                    )
                    .map { cloud ->

                        localDataSource
                            .markJourneySynced(
                                localId =
                                    item.localEntityId,

                                cloudId =
                                    cloud.id
                            )
                    }
            }

            SyncEntityType.MEMORY -> {

                val memory =
                    localDataSource
                        .getMemoryForCloud(
                            item.localEntityId
                        )
                        ?: return Result.failure(
                            IllegalStateException(
                                "Memory not found."
                            )
                        )

                cloudProvider
                    .uploadMemory(
                        memory
                    )
                    .map { cloud ->

                        localDataSource
                            .markMemorySynced(
                                localId =
                                    item.localEntityId,

                                cloudId =
                                    cloud.id
                            )
                    }
            }

            SyncEntityType.ALBUM_PHOTO -> {

                val photo =
                    localDataSource
                        .getPhotoForCloud(
                            item.localEntityId
                        )
                        ?: return Result.failure(
                            IllegalStateException(
                                "Photo not found."
                            )
                        )

                val localPath =
                    localDataSource
                        .getPhotoLocalPath(
                            item.localEntityId
                        )

                var uploadedRemotePath =
                    photo.remoteFilePath

                if (
                    uploadedRemotePath == null &&
                    localPath != null
                ) {

                    val remotePath =
                        localDataSource
                            .buildRemotePhotoPath(
                                item.localEntityId
                            )

                    uploadedRemotePath =
                        cloudProvider
                            .uploadPhotoFile(
                                localPath =
                                    localPath,

                                remotePath =
                                    remotePath
                            )
                            .getOrThrow()
                }

                val payload =
                    photo.copy(
                        remoteFilePath =
                            uploadedRemotePath
                    )

                cloudProvider
                    .uploadPhotoMetadata(
                        payload
                    )
                    .map { cloud ->

                        localDataSource
                            .markPhotoSynced(
                                localId =
                                    item.localEntityId,

                                cloudId =
                                    cloud.id,

                                remotePath =
                                    cloud.remoteFilePath
                            )
                    }
            }
        }
    }

    private suspend fun processDelete(
        item: SyncQueueItem
    ): Result<Unit> {

        return when (
            item.entityType
        ) {

            SyncEntityType.JOURNEY -> {

                val cloudId =
                    localDataSource
                        .getJourneyCloudId(
                            item.localEntityId
                        )
                        ?: return Result.success(
                            Unit
                        )

                cloudProvider
                    .deleteJourney(
                        cloudId
                    )
            }

            SyncEntityType.MEMORY -> {

                val cloudId =
                    localDataSource
                        .getMemoryCloudId(
                            item.localEntityId
                        )
                        ?: return Result.success(
                            Unit
                        )

                cloudProvider
                    .deleteMemory(
                        cloudId
                    )
            }

            SyncEntityType.ALBUM_PHOTO -> {

                val cloudInfo =
                    localDataSource
                        .getPhotoCloudDeleteInfo(
                            item.localEntityId
                        )
                        ?: return Result.success(
                            Unit
                        )

                cloudProvider
                    .deletePhoto(
                        cloudId =
                            cloudInfo.cloudId,

                        remoteFilePath =
                            cloudInfo.remoteFilePath
                    )
            }
        }
    }
}
