package com.example.cloud

class IncrementalCloudSyncCoordinator(
    private val repository:
        CloudRepository,

    private val localDataSource:
        IncrementalSyncLocalDataSource,

    private val settingsRepository:
        CloudBackupSettingsRepository
) {

    suspend fun sync():
        Result<SyncSummary> {

        return runCatching {

            val settings =
                settingsRepository
                    .getSettings()

            val journeys =
                localDataSource
                    .getPendingJourneyIds()

            journeys.forEach {

                repository
                    .enqueueJourney(
                        it
                    )
            }

            /*
             * Journeys first because child cloud rows
             * require a valid Journey cloud ID.
             */
            val journeySync =
                repository
                    .syncNow()
                    .getOrThrow()

            val memories =
                localDataSource
                    .getPendingMemoryIds()

            memories.forEach {

                repository
                    .enqueueMemory(
                        it
                    )
            }

            if (
                settings.includePhotos
            ) {

                localDataSource
                    .getPendingPhotoIds()
                    .forEach {

                        repository
                            .enqueuePhoto(
                                it
                            )
                    }
            }

            val contentSync =
                repository
                    .syncNow()
                    .getOrThrow()

            val result =
                SyncSummary(
                    uploaded =
                        journeySync.uploaded +
                            contentSync.uploaded,

                    downloaded =
                        journeySync.downloaded +
                            contentSync.downloaded,

                    deleted =
                        journeySync.deleted +
                            contentSync.deleted,

                    conflicts =
                        journeySync.conflicts +
                            contentSync.conflicts,

                    failures =
                        journeySync.failures +
                            contentSync.failures
                )

            if (
                result.failures == 0
            ) {

                settingsRepository
                    .setLastSuccessfulBackupAt(
                        System.currentTimeMillis()
                    )
            }

            result
        }
    }
}
