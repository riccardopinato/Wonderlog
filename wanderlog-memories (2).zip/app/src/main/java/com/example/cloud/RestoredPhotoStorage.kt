package com.example.cloud

import android.content.Context
import android.graphics.BitmapFactory
import java.io.File

data class RestoredPhotoFiles(
    val originalPath: String,
    val thumbnailPath: String,
    val width: Int,
    val height: Int,
    val fileSize: Long
)

class RestoredPhotoStorage(
    context: Context
) {

    private val filesDir =
        context.applicationContext
            .filesDir

    fun save(
        journeyId: String,
        photoId: String,
        bytes: ByteArray
    ): RestoredPhotoFiles {

        val originals =
            File(
                filesDir,
                "journeys/$journeyId/album/originals"
            ).apply {
                mkdirs()
            }

        val thumbnails =
            File(
                filesDir,
                "journeys/$journeyId/album/thumbnails"
            ).apply {
                mkdirs()
            }

        val original =
            File(
                originals,
                "$photoId.jpg"
            )

        val thumbnail =
            File(
                thumbnails,
                "$photoId.jpg"
            )

        val temp =
            File(
                originals,
                "$photoId.restore.tmp"
            )

        /*
         * Atomic-ish restore:
         * never destroy an existing good file
         * before the download is completely written.
         */
        temp.writeBytes(
            bytes
        )

        if (
            original.exists()
        ) {
            original.delete()
        }

        check(
            temp.renameTo(
                original
            )
        ) {
            "Unable to finalize restored photo."
        }

        /*
         * Current Wonderlog thumbnails can safely fall
         * back to the restored image itself.
         * Photo Engine can regenerate optimized thumbs
         * later during QA/performance.
         */
        original.copyTo(
            target = thumbnail,
            overwrite = true
        )

        val options =
            BitmapFactory.Options().apply {
                inJustDecodeBounds =
                    true
            }

        BitmapFactory.decodeFile(
            original.absolutePath,
            options
        )

        return RestoredPhotoFiles(
            originalPath =
                original.absolutePath,

            thumbnailPath =
                thumbnail.absolutePath,

            width =
                options.outWidth
                    .coerceAtLeast(0),

            height =
                options.outHeight
                    .coerceAtLeast(0),

            fileSize =
                original.length()
        )
    }
}
