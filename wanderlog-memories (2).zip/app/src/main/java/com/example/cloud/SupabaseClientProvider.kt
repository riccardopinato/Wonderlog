package com.example.cloud

import com.example.BuildConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage

object SupabaseClientProvider {

    val client: SupabaseClient by lazy {

        val url =
            BuildConfig.SUPABASE_URL
                .trim()

        val key =
            BuildConfig.SUPABASE_PUBLISHABLE_KEY
                .trim()

        require(url.isNotBlank()) {
            "SUPABASE_URL is not configured."
        }

        require(key.isNotBlank()) {
            "SUPABASE_PUBLISHABLE_KEY is not configured."
        }

        createSupabaseClient(
            supabaseUrl = url,
            supabaseKey = key
        ) {

            install(Auth) {

                /*
                 * Keep sessions persisted locally.
                 *
                 * These are the default behaviours,
                 * explicitly documented here because
                 * cloud restore depends on them.
                 */
                alwaysAutoRefresh = true
                autoLoadFromStorage = true
            }

            install(Postgrest)

            install(Storage)
        }
    }
}
