package com.example.cloud

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SyncQueueDao {

    @Insert(
        onConflict =
            OnConflictStrategy.REPLACE
    )
    suspend fun insert(
        item: SyncQueueEntity
    )

    @Query(
        """
        DELETE FROM cloud_sync_queue
        WHERE id = :id
        """
    )
    suspend fun delete(
        id: String
    )

    @Query(
        """
        SELECT *
        FROM cloud_sync_queue
        ORDER BY createdAt ASC
        LIMIT :limit
        """
    )
    suspend fun getPending(
        limit: Int
    ): List<SyncQueueEntity>

    @Query(
        """
        SELECT COUNT(*)
        FROM cloud_sync_queue
        """
    )
    suspend fun count():
        Int

    @Query(
        """
        DELETE FROM cloud_sync_queue
        """
    )
    suspend fun clear()
}
