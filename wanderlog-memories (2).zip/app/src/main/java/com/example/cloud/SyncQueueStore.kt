package com.example.cloud

interface SyncQueueStore {

    suspend fun insert(
        item: SyncQueueItem
    )

    suspend fun remove(
        queueId: String
    )

    suspend fun update(
        item: SyncQueueItem
    )

    suspend fun getPending(
        limit: Int =
            CloudBackupConfig.SYNC_BATCH_SIZE
    ): List<SyncQueueItem>

    suspend fun count(): Int

    suspend fun clear()
}
