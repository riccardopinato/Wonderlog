package com.example.cloud

object CloudSyncGuard {

    fun canStartBackup(
        authenticated: Boolean,
        premium: Boolean,
        automaticBackupEnabled: Boolean
    ): Boolean {

        return authenticated &&
            premium &&
            automaticBackupEnabled
    }

    fun canRestore(
        authenticated: Boolean,
        premium: Boolean
    ): Boolean {

        return authenticated &&
            premium
    }
}
