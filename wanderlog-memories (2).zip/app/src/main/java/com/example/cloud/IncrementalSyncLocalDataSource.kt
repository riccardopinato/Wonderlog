package com.example.cloud

interface IncrementalSyncLocalDataSource {

    suspend fun getPendingJourneyIds():
        List<String>

    suspend fun getPendingMemoryIds():
        List<String>

    suspend fun getPendingPhotoIds():
        List<String>
}
