package com.example.cloud

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.network.NetworkResultClassifier

class CloudBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(
    appContext,
    workerParams
) {

    override suspend fun doWork():
        Result {

        val settingsRepository =
            CloudWorkerDependencies
                .settingsRepository(
                    applicationContext
                )

        val settings =
            settingsRepository
                .getSettings()

        if (
            !settings
                .automaticBackupEnabled
        ) {

            return Result.success()
        }

        val authManager =
            SupabaseAuthManager()

        if (
            !authManager
                .isAuthenticated()
        ) {

            return Result.success()
        }

        val coordinator =
            CloudWorkerDependencies
                .createIncrementalCoordinator(
                    applicationContext
                )

        val syncResult =
            coordinator.sync()

        return syncResult.fold(

            onSuccess = {
                summary ->

                if (
                    summary.failures == 0
                ) {

                    Result.success(
                        workDataOf(
                            KEY_UPLOADED to
                                summary.uploaded,

                            KEY_DELETED to
                                summary.deleted
                        )
                    )

                } else {

                    retryOrFail()
                }
            },

            onFailure = {
                error ->

                if (
                    NetworkResultClassifier
                        .isRetryable(
                            error
                        )
                ) {

                    retryOrFail()

                } else {

                    Result.failure(
                        workDataOf(
                            KEY_ERROR to
                                (
                                    error.message
                                        ?: "Cloud backup failed."
                                )
                        )
                    )
                }
            }
        )
    }

    private fun retryOrFail():
        Result {

        return if (
            runAttemptCount <
            MAX_WORK_ATTEMPTS
        ) {

            Result.retry()

        } else {

            Result.failure(
                workDataOf(
                    KEY_ERROR to
                        "Maximum cloud backup retries reached."
                )
            )
        }
    }

    companion object {

        const val TAG =
            "wonderlog_cloud_backup"

        const val KEY_UPLOADED =
            "uploaded"

        const val KEY_DELETED =
            "deleted"

        const val KEY_ERROR =
            "error"

        private const val MAX_WORK_ATTEMPTS =
            5
    }
}
