package com.example.cloud

import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.storage.storage
import java.io.File

class SupabaseCloudProvider(
    private val authManager:
        SupabaseAuthManager =
        SupabaseAuthManager()
) : CloudProvider {

    private val client =
        SupabaseClientProvider.client

    override suspend fun isAuthenticated():
        Boolean {

        return authManager
            .isAuthenticated()
    }

    override suspend fun uploadJourney(
        payload: CloudJourney
    ): Result<CloudJourney> {

        return runCatching {

            val userId =
                requireUserId()

            val safePayload =
                payload.copy(
                    ownerId =
                        userId
                )

            client
                .from(
                    JOURNEYS_TABLE
                )
                .upsert(
                    safePayload
                ) {
                    select()
                }
                .decodeSingle<CloudJourney>()
        }
    }

    override suspend fun uploadMemory(
        payload: CloudMemory
    ): Result<CloudMemory> {

        return runCatching {

            val userId =
                requireUserId()

            val safePayload =
                payload.copy(
                    ownerId =
                        userId
                )

            client
                .from(
                    MEMORIES_TABLE
                )
                .upsert(
                    safePayload
                ) {
                    select()
                }
                .decodeSingle<CloudMemory>()
        }
    }

    override suspend fun uploadPhotoMetadata(
        payload: CloudAlbumPhoto
    ): Result<CloudAlbumPhoto> {

        return runCatching {

            val userId =
                requireUserId()

            val safePayload =
                payload.copy(
                    ownerId =
                        userId
                )

            client
                .from(
                    PHOTOS_TABLE
                )
                .upsert(
                    safePayload
                ) {
                    select()
                }
                .decodeSingle<CloudAlbumPhoto>()
        }
    }

    override suspend fun uploadPhotoFile(
        localPath: String,
        remotePath: String
    ): Result<String> {

        return runCatching {

            requireUserId()

            val file =
                File(
                    localPath
                )

            require(
                file.exists()
            ) {
                "Local photo file does not exist."
            }

            client
                .storage
                .from(
                    PHOTOS_BUCKET
                )
                .upload(
                    path =
                        remotePath,

                    data =
                        file.readBytes()
                ) {
                    upsert = true
                }

            remotePath
        }
    }

    override suspend fun deleteJourney(
        cloudId: String
    ): Result<Unit> {

        return runCatching {

            val userId =
                requireUserId()

            client
                .from(
                    JOURNEYS_TABLE
                )
                .delete {

                    filter {

                        eq(
                            "id",
                            cloudId
                        )

                        eq(
                            "owner_id",
                            userId
                        )
                    }
                }

            Unit
        }
    }

    override suspend fun deleteMemory(
        cloudId: String
    ): Result<Unit> {

        return runCatching {

            val userId =
                requireUserId()

            client
                .from(
                    MEMORIES_TABLE
                )
                .delete {

                    filter {

                        eq(
                            "id",
                            cloudId
                        )

                        eq(
                            "owner_id",
                            userId
                        )
                    }
                }

            Unit
        }
    }

    override suspend fun deletePhoto(
        cloudId: String,
        remoteFilePath: String?
    ): Result<Unit> {

        return runCatching {

            val userId =
                requireUserId()

            remoteFilePath
                ?.takeIf {
                    it.isNotBlank()
                }
                ?.let { path ->

                    client
                        .storage
                        .from(
                            PHOTOS_BUCKET
                        )
                        .delete(
                            path
                        )
                }

            client
                .from(
                    PHOTOS_TABLE
                )
                .delete {

                    filter {

                        eq(
                            "id",
                            cloudId
                        )

                        eq(
                            "owner_id",
                            userId
                        )
                    }
                }

            Unit
        }
    }

    override suspend fun fetchJourneys(
        updatedAfter: Long?
    ): Result<List<CloudJourney>> {

        return runCatching {

            val userId =
                requireUserId()

            client
                .from(
                    JOURNEYS_TABLE
                )
                .select {

                    filter {

                        eq(
                            "owner_id",
                            userId
                        )

                        updatedAfter
                            ?.let {

                                gt(
                                    "updated_at",
                                    it
                                )
                            }
                    }
                }
                .decodeList<CloudJourney>()
        }
    }

    override suspend fun fetchMemories(
        updatedAfter: Long?
    ): Result<List<CloudMemory>> {

        return runCatching {

            val userId =
                requireUserId()

            client
                .from(
                    MEMORIES_TABLE
                )
                .select {

                    filter {

                        eq(
                            "owner_id",
                            userId
                        )

                        updatedAfter
                            ?.let {

                                gt(
                                    "updated_at",
                                    it
                                )
                            }
                    }
                }
                .decodeList<CloudMemory>()
        }
    }

    override suspend fun fetchPhotos(
        updatedAfter: Long?
    ): Result<List<CloudAlbumPhoto>> {

        return runCatching {

            val userId =
                requireUserId()

            client
                .from(
                    PHOTOS_TABLE
                )
                .select {

                    filter {

                        eq(
                            "owner_id",
                            userId
                        )

                        updatedAfter
                            ?.let {

                                gt(
                                    "updated_at",
                                    it
                                )
                            }
                    }
                }
                .decodeList<CloudAlbumPhoto>()
        }
    }

    override suspend fun downloadPhotoFile(
        remotePath: String
    ): Result<ByteArray> {

        return runCatching {

            requireUserId()

            client
                .storage
                .from(
                    PHOTOS_BUCKET
                )
                .downloadAuthenticated(
                    remotePath
                )
        }
    }

    override suspend fun uploadMemoryPhotoLinks(
        links: List<CloudMemoryPhotoLink>
    ): Result<Unit> {

        return runCatching {

            val userId =
                requireUserId()

            if (links.isEmpty()) {
                return@runCatching Unit
            }

            val safeLinks =
                links.map {
                    it.copy(
                        ownerId = userId
                    )
                }

            client
                .from(
                    MEMORY_PHOTOS_TABLE
                )
                .upsert(
                    safeLinks
                )

            Unit
        }
    }

    override suspend fun fetchMemoryPhotoLinks():
        Result<List<CloudMemoryPhotoLink>> {

        return runCatching {

            val userId =
                requireUserId()

            client
                .from(
                    MEMORY_PHOTOS_TABLE
                )
                .select {

                    filter {

                        eq(
                            "owner_id",
                            userId
                        )
                    }
                }
                .decodeList<
                    CloudMemoryPhotoLink
                >()
        }
    }

    private fun requireUserId():
        String {

        return client
            .auth
            .currentSessionOrNull()
            ?.user
            ?.id
            ?: error(
                "Supabase user is not authenticated."
            )
    }

    companion object {

        const val PHOTOS_BUCKET =
            "wonderlog-photos"

        private const val JOURNEYS_TABLE =
            "journeys"

        private const val MEMORIES_TABLE =
            "memories"

        private const val PHOTOS_TABLE =
            "album_photos"

        private const val MEMORY_PHOTOS_TABLE =
            "memory_photos"
    }
}
