package com.example.mapmemories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class MapMemoryViewModelFactory(
    private val journeyId:
        String,

    private val repository:
        MapMemoryRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <
        T : ViewModel
    > create(
        modelClass:
            Class<T>
    ): T {

        require(
            modelClass
                .isAssignableFrom(
                    MapMemoryViewModel::class.java
                )
        )

        return MapMemoryViewModel(
            journeyId =
                journeyId,

            repository =
                repository
        ) as T
    }
}
