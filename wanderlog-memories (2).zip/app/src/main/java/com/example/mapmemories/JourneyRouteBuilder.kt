package com.example.mapmemories

import com.example.smartjourney.GeoMath

class JourneyRouteBuilder(
    private val minimumPointDistanceMeters:
        Double =
        50.0
) {

    fun build(
        clusters:
            List<MapMemoryCluster>
    ): List<JourneyRoutePoint> {

        if (
            clusters.isEmpty()
        ) {
            return emptyList()
        }

        val ordered =
            clusters
                .sortedBy {
                    it.firstTimestamp
                        ?: Long.MAX_VALUE
                }

        val result =
            mutableListOf<
                JourneyRoutePoint
            >()

        ordered.forEach {
            cluster ->

            val last =
                result
                    .lastOrNull()

            val shouldAdd =
                if (
                    last == null
                ) {

                    true

                } else {

                    GeoMath
                        .distanceMeters(
                            last.coordinate
                                .latitude,

                            last.coordinate
                                .longitude,

                            cluster.coordinate
                                .latitude,

                            cluster.coordinate
                                .longitude
                        ) >=
                        minimumPointDistanceMeters
                }

            if (
                shouldAdd
            ) {

                result +=
                    JourneyRoutePoint(
                        coordinate =
                            cluster.coordinate,

                        timestamp =
                            cluster
                                .firstTimestamp,

                        clusterId =
                            cluster.id,

                        dayIndex =
                            cluster
                                .dayIndexes
                                .minOrNull()
                    )
            }
        }

        return result
    }
}
