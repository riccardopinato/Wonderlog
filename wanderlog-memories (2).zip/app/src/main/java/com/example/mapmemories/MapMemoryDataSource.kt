package com.example.mapmemories

interface MapMemoryDataSource {

    suspend fun loadJourneyPhotos(
        journeyId: String
    ): List<MapMemoryItem>

    suspend fun loadJourneyMemories(
        journeyId: String
    ): List<MapMemoryItem>
}
