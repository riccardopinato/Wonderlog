package com.example.mapmemories

interface MapMemoryRepository {

    suspend fun loadJourneyMap(
        journeyId: String
    ): Result<MapMemoryMapData>
}

data class MapMemoryMapData(
    val items: List<MapMemoryItem>,
    val availableDays: List<JourneyDayOption>
)
