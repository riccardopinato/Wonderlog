package com.example.mapmemories

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

class MapMemoryRepositoryImpl(
    private val dataSource:
        MapMemoryDataSource
) : MapMemoryRepository {

    override suspend fun loadJourneyMap(
        journeyId: String
    ): Result<MapMemoryMapData> =
        withContext(
            Dispatchers.IO
        ) {

            runCatching {

                coroutineScope {

                    val photosDeferred =
                        async {
                            dataSource
                                .loadJourneyPhotos(
                                    journeyId
                                )
                        }

                    val memoriesDeferred =
                        async {
                            dataSource
                                .loadJourneyMemories(
                                    journeyId
                                )
                        }

                    val items =
                        (
                            photosDeferred.await() +
                            memoriesDeferred.await()
                        )
                            .sortedWith(
                                compareBy<
                                    MapMemoryItem
                                > {
                                    it.timestamp
                                        ?: Long.MAX_VALUE
                                }.thenBy {
                                    it.id
                                }
                            )

                    val days =
                        items
                            .mapNotNull {
                                item ->

                                item.dayIndex
                                    ?.let {
                                        index ->

                                        JourneyDayOption(
                                            dayIndex =
                                                index,

                                            label =
                                                "Day ${
                                                    index + 1
                                                }"
                                        )
                                    }
                            }
                            .distinctBy {
                                it.dayIndex
                            }
                            .sortedBy {
                                it.dayIndex
                            }

                    MapMemoryMapData(
                        items =
                            items,

                        availableDays =
                            days
                    )
                }
            }
        }
}
