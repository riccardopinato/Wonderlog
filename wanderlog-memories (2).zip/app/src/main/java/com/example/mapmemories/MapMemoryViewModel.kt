package com.example.mapmemories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MapMemoryViewModel(
    private val journeyId:
        String,

    private val repository:
        MapMemoryRepository,

    private val clusterEngine:
        MapClusterEngine =
        MapClusterEngine(),

    private val routeBuilder:
        JourneyRouteBuilder =
        JourneyRouteBuilder()
) : ViewModel() {

    private val _state =
        MutableStateFlow(
            MapMemoryUiState(
                journeyId =
                    journeyId
            )
        )

    val state:
        StateFlow<
            MapMemoryUiState
        > =
        _state.asStateFlow()

    init {
        load()
    }

    fun load() {

        viewModelScope.launch {

            _state.value =
                _state.value.copy(
                    loading =
                        true,

                    error =
                        null
                )

            repository
                .loadJourneyMap(
                    journeyId
                )
                .onSuccess {
                    data ->

                    val visible =
                        MapMemoryFilter
                            .apply(
                                data.items,
                                _state
                                    .value
                                    .filter
                            )

                    val clusters =
                        clusterEngine
                            .cluster(
                                visible
                            )

                    _state.value =
                        _state.value.copy(
                            loading =
                                false,

                            allItems =
                                data.items,

                            visibleItems =
                                visible,

                            clusters =
                                clusters,

                            route =
                                routeBuilder
                                    .build(
                                        clusters
                                    ),

                            availableDays =
                                data.availableDays
                        )
                }
                .onFailure {
                    error ->

                    _state.value =
                        _state.value.copy(
                            loading =
                                false,

                            error =
                                error.message
                                    ?: "Unable to load Journey map."
                        )
                }
        }
    }

    fun selectDay(
        dayIndex:
            Int?
    ) {

        updateFilter(
            _state
                .value
                .filter
                .copy(
                    selectedDayIndex =
                        dayIndex
                )
        )
    }

    fun setContentFilter(
        filter:
            MapMemoryContentFilter
    ) {

        updateFilter(
            _state
                .value
                .filter
                .copy(
                    contentFilter =
                        filter
                )
        )
    }

    fun selectCluster(
        clusterId:
            String?
    ) {

        _state.value =
            _state
                .value
                .copy(
                    selectedClusterId =
                        clusterId
                )
    }

    fun clearSelection() {

        selectCluster(
            null
        )
    }

    private fun updateFilter(
        filter:
            MapMemoryFilterState
    ) {

        val visible =
            MapMemoryFilter
                .apply(
                    _state
                        .value
                        .allItems,

                    filter
                )

        val clusters =
            clusterEngine
                .cluster(
                    visible
                )

        _state.value =
            _state
                .value
                .copy(
                    filter =
                        filter,

                    visibleItems =
                        visible,

                    clusters =
                        clusters,

                    route =
                        routeBuilder
                            .build(
                                clusters
                            ),

                    selectedClusterId =
                        null
                )
    }
}
