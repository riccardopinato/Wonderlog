package com.example.mapmemories

import com.example.domain.repository.WanderlogRepository
import kotlinx.coroutines.flow.first
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class WonderlogMapMemoryDataSource(
    private val repository: WanderlogRepository
) : MapMemoryDataSource {

    override suspend fun loadJourneyPhotos(
        journeyId: String
    ): List<MapMemoryItem> {
        val trip = repository.getTripById(journeyId).first()
        val journeyStartDate = parseDate(trip?.startDate)

        val photos = repository.getPhotosForJourney(journeyId).first()

        return photos
            .filter { it.gpsLatitude != null && it.gpsLongitude != null }
            .map { photo ->
                val timestamp = photo.capturedAt ?: photo.createdAt
                val photoDate = runCatching {
                    Instant.ofEpochMilli(timestamp)
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate()
                }.getOrNull()

                val dayIndex = JourneyDayResolver.resolve(journeyStartDate, photoDate)

                MapMemoryItem(
                    id = "photo_${photo.id}",
                    type = MapMemoryItemType.PHOTO,
                    journeyId = journeyId,
                    title = photo.locationName.takeIf { it.isNotBlank() },
                    subtitle = null,
                    coordinate = MapCoordinate(
                        latitude = photo.gpsLatitude!!,
                        longitude = photo.gpsLongitude!!
                    ),
                    timestamp = timestamp,
                    localPhotoUri = photo.localUri.ifBlank { photo.thumbnailUri },
                    memoryId = null,
                    photoId = photo.id,
                    dayIndex = dayIndex,
                    dateLabel = photoDate?.toString()
                )
            }
    }

    override suspend fun loadJourneyMemories(
        journeyId: String
    ): List<MapMemoryItem> {
        val trip = repository.getTripById(journeyId).first()
        val journeyStartDate = parseDate(trip?.startDate)

        val memories = repository.getMemoriesForTrip(journeyId).first()

        return memories
            .filter { it.latitude != null && it.longitude != null }
            .map { memory ->
                val memoryDate = parseDate(memory.date)
                val dayIndex = JourneyDayResolver.resolve(journeyStartDate, memoryDate)

                val memoryDateTimestamp = memoryDate?.atStartOfDay(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
                val timestamp = MemoryTimelineTimestampResolver.resolve(
                    memoryDateTimestamp = memoryDateTimestamp,
                    createdAt = memory.createdAt,
                    updatedAt = memory.updatedAt
                ) ?: System.currentTimeMillis()

                MapMemoryItem(
                    id = "memory_${memory.id}",
                    type = MapMemoryItemType.MEMORY,
                    journeyId = journeyId,
                    title = memory.title,
                    subtitle = memory.locationName.takeIf { it.isNotBlank() },
                    coordinate = MapCoordinate(
                        latitude = memory.latitude!!,
                        longitude = memory.longitude!!
                    ),
                    timestamp = timestamp,
                    localPhotoUri = memory.image.takeIf { it.isNotBlank() },
                    memoryId = memory.id,
                    photoId = null,
                    dayIndex = dayIndex,
                    dateLabel = memory.date
                )
            }
    }

    private fun parseDate(dateStr: String?): LocalDate? {
        if (dateStr.isNullOrBlank()) return null
        return runCatching { LocalDate.parse(dateStr) }.getOrNull()
    }
}
