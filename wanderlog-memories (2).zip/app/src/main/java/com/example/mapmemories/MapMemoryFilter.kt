package com.example.mapmemories

object MapMemoryFilter {

    fun apply(
        items:
            List<MapMemoryItem>,

        filter:
            MapMemoryFilterState
    ): List<MapMemoryItem> {

        return items.filter {
            item ->

            val dayMatches =
                filter
                    .selectedDayIndex ==
                    null ||
                    item.dayIndex ==
                    filter
                        .selectedDayIndex

            val typeMatches =
                when (
                    filter
                        .contentFilter
                ) {

                    MapMemoryContentFilter.ALL ->
                        true

                    MapMemoryContentFilter.PHOTOS ->
                        item.type ==
                            MapMemoryItemType.PHOTO

                    MapMemoryContentFilter.MEMORIES ->
                        item.type ==
                            MapMemoryItemType.MEMORY
                }

            dayMatches &&
                typeMatches
        }
    }
}
