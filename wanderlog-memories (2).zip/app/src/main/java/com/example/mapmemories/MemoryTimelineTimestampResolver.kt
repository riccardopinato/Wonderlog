package com.example.mapmemories

object MemoryTimelineTimestampResolver {

    fun resolve(
        memoryDateTimestamp:
            Long?,
        createdAt:
            Long,
        updatedAt:
            Long
    ): Long? {

        return memoryDateTimestamp
            ?: createdAt
                .takeIf {
                    it > 0L
                }
            ?: updatedAt
                .takeIf {
                    it > 0L
                }
    }
}
