package com.example.mapmemories

import java.time.LocalDate
import java.time.temporal.ChronoUnit

object JourneyDayResolver {

    fun resolve(
        journeyStartDate: LocalDate?,
        itemDate: LocalDate?
    ): Int? {

        if (
            journeyStartDate == null ||
            itemDate == null
        ) {
            return null
        }

        val difference =
            ChronoUnit
                .DAYS
                .between(
                    journeyStartDate,
                    itemDate
                )

        if (
            difference < 0
        ) {
            return null
        }

        return difference
            .toInt()
    }
}
