package com.example.mapmemories

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object MapMemoryTimeFormatter {

    private val timeFormatter =
        DateTimeFormatter
            .ofPattern(
                "HH:mm"
            )

    fun time(
        timestamp:
            Long?
    ): String? {

        if (
            timestamp == null ||
            timestamp <= 0L
        ) {
            return null
        }

        return Instant
            .ofEpochMilli(
                timestamp
            )
            .atZone(
                ZoneId
                    .systemDefault()
            )
            .format(
                timeFormatter
            )
    }
}
