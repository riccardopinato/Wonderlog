package com.example.mapmemories

data class MapCoordinate(
    val latitude: Double,
    val longitude: Double
)

enum class MapMemoryItemType {
    PHOTO,
    MEMORY
}

data class MapMemoryItem(
    val id: String,
    val type: MapMemoryItemType,
    val journeyId: String,
    val title: String?,
    val subtitle: String?,
    val coordinate: MapCoordinate,
    val timestamp: Long?,
    val localPhotoUri: String? = null,
    val memoryId: String? = null,
    val photoId: String? = null,
    val dayIndex: Int? = null,
    val dateLabel: String? = null
)

data class MapMemoryCluster(
    val id: String,
    val coordinate: MapCoordinate,
    val items: List<MapMemoryItem>,
    val dominantTitle: String?,
    val dayIndexes: Set<Int>
) {

    val count: Int
        get() =
            items.size

    val photoCount: Int
        get() =
            items.count {
                it.type ==
                    MapMemoryItemType.PHOTO
            }

    val memoryCount: Int
        get() =
            items.count {
                it.type ==
                    MapMemoryItemType.MEMORY
            }

    val firstTimestamp: Long?
        get() =
            items
                .mapNotNull {
                    it.timestamp
                }
                .minOrNull()

    val lastTimestamp: Long?
        get() =
            items
                .mapNotNull {
                    it.timestamp
                }
                .maxOrNull()
}

data class JourneyRoutePoint(
    val coordinate: MapCoordinate,
    val timestamp: Long?,
    val clusterId: String?,
    val dayIndex: Int?
)

data class JourneyDayOption(
    val dayIndex: Int,
    val label: String
)

enum class MapMemoryContentFilter {
    ALL,
    PHOTOS,
    MEMORIES
}

data class MapMemoryFilterState(
    val selectedDayIndex: Int? = null,
    val contentFilter:
        MapMemoryContentFilter =
        MapMemoryContentFilter.ALL
)

data class MapMemoryUiState(
    val loading: Boolean = true,
    val journeyId: String,
    val allItems: List<MapMemoryItem> = emptyList(),
    val visibleItems: List<MapMemoryItem> = emptyList(),
    val clusters: List<MapMemoryCluster> = emptyList(),
    val route: List<JourneyRoutePoint> = emptyList(),
    val availableDays: List<JourneyDayOption> = emptyList(),
    val filter: MapMemoryFilterState = MapMemoryFilterState(),
    val selectedClusterId: String? = null,
    val error: String? = null
) {

    val selectedCluster: MapMemoryCluster?
        get() =
            clusters
                .firstOrNull {
                    it.id ==
                        selectedClusterId
                }
}
