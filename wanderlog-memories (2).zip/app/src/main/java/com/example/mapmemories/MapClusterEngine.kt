package com.example.mapmemories

import com.example.smartjourney.GeoMath
import java.nio.charset.StandardCharsets
import java.util.UUID

class MapClusterEngine(
    private val clusterRadiusMeters:
        Double =
        900.0
) {

    private fun stableClusterId(
        members:
            List<MapMemoryItem>
    ): String {

        val signature =
            members
                .map {
                    "${it.type}:${it.id}"
                }
                .sorted()
                .joinToString(
                    separator = "|"
                )

        return UUID
            .nameUUIDFromBytes(
                signature
                    .toByteArray(
                        StandardCharsets.UTF_8
                    )
            )
            .toString()
    }

    fun cluster(
        items:
            List<MapMemoryItem>
    ): List<MapMemoryCluster> {

        if (
            items.isEmpty()
        ) {
            return emptyList()
        }

        val remaining =
            items
                .toMutableList()

        val clusters =
            mutableListOf<
                MapMemoryCluster
            >()

        while (
            remaining.isNotEmpty()
        ) {

            val seed =
                remaining
                    .removeAt(
                        0
                    )

            val members =
                mutableListOf(
                    seed
                )

            var expanded =
                true

            while (
                expanded
            ) {

                expanded =
                    false

                val iterator =
                    remaining.iterator()

                while (
                    iterator.hasNext()
                ) {

                    val candidate =
                        iterator.next()

                    val closeToCluster =
                        members.any {
                            member ->

                            GeoMath
                                .distanceMeters(
                                    member
                                        .coordinate
                                        .latitude,

                                    member
                                        .coordinate
                                        .longitude,

                                    candidate
                                        .coordinate
                                        .latitude,

                                    candidate
                                        .coordinate
                                        .longitude
                                ) <=
                                clusterRadiusMeters
                        }

                    if (
                        closeToCluster
                    ) {

                        members +=
                            candidate

                        iterator.remove()

                        expanded =
                            true
                    }
                }
            }

            val centroid =
                GeoMath.centroid(
                    members.map {
                        Pair(
                            it.coordinate
                                .latitude,

                            it.coordinate
                                .longitude
                        )
                    }
                )

            val dominantTitle =
                members
                    .mapNotNull {
                        it.subtitle
                            ?.takeIf {
                                value ->
                                value.isNotBlank()
                            }
                    }
                    .groupingBy {
                        it
                    }
                    .eachCount()
                    .maxByOrNull {
                        it.value
                    }
                    ?.key
                    ?: members
                        .mapNotNull {
                            it.title
                        }
                        .firstOrNull()

            clusters +=
                MapMemoryCluster(
                    id =
                        stableClusterId(
                            members
                        ),

                    coordinate =
                        MapCoordinate(
                            latitude =
                                centroid?.first
                                    ?: seed.coordinate
                                        .latitude,

                            longitude =
                                centroid?.second
                                    ?: seed.coordinate
                                        .longitude
                        ),

                    items =
                        members.sortedBy {
                            it.timestamp
                                ?: Long.MAX_VALUE
                        },

                    dominantTitle =
                        dominantTitle,

                    dayIndexes =
                        members
                            .mapNotNull {
                                it.dayIndex
                            }
                            .toSet()
                )
        }

        return clusters
            .sortedBy {
                it.firstTimestamp
                    ?: Long.MAX_VALUE
            }
    }
}
