package com.example.capture

import android.content.Context
import android.net.Uri
import com.example.data.local.MemoryAttachmentDao
import com.example.data.local.WanderlogDatabase
import com.example.domain.model.Memory
import com.example.domain.model.MemoryPhotoCrossRef
import com.example.domain.model.Mood
import com.example.domain.repository.WanderlogRepository
import com.example.premium.PremiumGate
import com.example.premium.PremiumGateResult
import com.example.premium.PremiumManager
import com.example.storage.AlbumPhotoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class WonderlogCaptureRepository(
    private val context: Context,
    private val wanderlogRepository: WanderlogRepository,
    private val keepsakeRepository: TravelKeepsakeRepository,
    private val premiumGate: PremiumGate = PremiumGate()
) : CaptureRepository {

    override suspend fun getJourneys(): List<CaptureJourneyOption> = withContext(Dispatchers.IO) {
        val trips = wanderlogRepository.getAllTrips().first()
        trips.map { trip ->
            CaptureJourneyOption(
                id = trip.id,
                title = trip.title.ifBlank { trip.destinationName },
                subtitle = "${trip.startDate} • ${trip.destinationName}"
            )
        }
    }

    override suspend fun getMemories(journeyId: String): List<CaptureMemoryOption> = withContext(Dispatchers.IO) {
        val memories = wanderlogRepository.getMemoriesForTrip(journeyId).first()
        memories.map { memory ->
            CaptureMemoryOption(
                id = memory.id,
                title = memory.title,
                dateLabel = memory.date
            )
        }
    }

    override suspend fun save(draft: CaptureDraft): Result<CaptureSaveResult> = withContext(Dispatchers.IO) {
        try {
            val validation = CaptureValidator.validate(draft)
            if (!validation.valid) {
                return@withContext Result.failure(IllegalArgumentException(validation.message ?: "Invalid draft"))
            }

            val journeyId = draft.journeyId
                ?: return@withContext Result.failure(IllegalArgumentException("Journey is required"))

            val isPremium = PremiumManager.isPremium.value

            // 1. Check & Handle Memory destination
            var targetMemoryId: String? = draft.memoryId

            if (draft.createNewMemory) {
                // Check memory quota with PremiumGate
                val existingMemories = wanderlogRepository.getAllMemories().first()
                val memoryCheck = premiumGate.canCreateMemory(existingMemories.size, isPremium)
                if (memoryCheck is PremiumGateResult.LimitReached) {
                    PremiumManager.showUpgrade(
                        title = "Memory limit reached",
                        subtitle = "Upgrade to Wonderlog Premium to add unlimited Memories."
                    )
                    return@withContext Result.failure(
                        IllegalStateException("Memory limit reached for free plan.")
                    )
                }

                val newMemoryId = "mem_${UUID.randomUUID().toString().replace("-", "")}"
                val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

                // Extract text from text/link items if memoryText is empty
                val combinedText = buildString {
                    if (draft.memoryText.isNotBlank()) {
                        append(draft.memoryText)
                    }
                    val textItems = draft.items.filter {
                        it.type == CaptureContentType.TEXT || it.type == CaptureContentType.LINK
                    }
                    if (textItems.isNotEmpty()) {
                        if (isNotEmpty()) append("\n\n")
                        textItems.forEachIndexed { index, item ->
                            val content = item.text ?: item.uri.orEmpty()
                            if (content.isNotBlank()) {
                                if (index > 0) append("\n")
                                append(content)
                            }
                        }
                    }
                }

                val title = when {
                    draft.memoryTitle.isNotBlank() -> draft.memoryTitle
                    draft.items.any { it.title?.isNotBlank() == true } -> {
                        draft.items.first { it.title?.isNotBlank() == true }.title!!
                    }
                    draft.items.any { it.type == CaptureContentType.LINK } -> "Saved Link"
                    draft.items.any { it.type == CaptureContentType.TEXT } -> "Quick Thought"
                    draft.items.any { it.type == CaptureContentType.FILE } -> "Travel Document"
                    else -> "New Memory"
                }

                val location = draft.location
                    ?: draft.items.firstOrNull { it.location != null }?.location

                val memory = Memory(
                    id = newMemoryId,
                    tripId = journeyId,
                    journeyId = journeyId,
                    title = title,
                    note = combinedText,
                    journalText = combinedText,
                    image = "",
                    locationName = location?.label.orEmpty(),
                    latitude = location?.latitude,
                    longitude = location?.longitude,
                    date = todayDate,
                    mood = Mood.HAPPY,
                    tags = listOf("capture"),
                    favorite = false,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )

                wanderlogRepository.insertMemory(memory)
                targetMemoryId = newMemoryId
            } else if (targetMemoryId != null) {
                // If appending text/links to existing memory
                val textItems = draft.items.filter {
                    it.type == CaptureContentType.TEXT || it.type == CaptureContentType.LINK
                }
                if (textItems.isNotEmpty() || draft.memoryText.isNotBlank()) {
                    val existingMemories = wanderlogRepository.getMemoriesForTrip(journeyId).first()
                    val targetMem = existingMemories.firstOrNull { it.id == targetMemoryId }
                    if (targetMem != null) {
                        val appended = buildString {
                            append(targetMem.journalText)
                            if (draft.memoryText.isNotBlank()) {
                                if (isNotEmpty()) append("\n\n")
                                append(draft.memoryText)
                            }
                            textItems.forEach { item ->
                                val content = item.text ?: item.uri.orEmpty()
                                if (content.isNotBlank()) {
                                    if (isNotEmpty()) append("\n")
                                    append(content)
                                }
                            }
                        }
                        wanderlogRepository.insertMemory(
                            targetMem.copy(
                                journalText = appended,
                                note = appended,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }

            // 2. Process IMAGE items
            val imageItems = draft.items.filter { it.type == CaptureContentType.IMAGE }
            var importedPhotoCount = 0

            if (imageItems.isNotEmpty()) {
                val currentPhotos = wanderlogRepository.getPhotosForJourney(journeyId).first()
                val allowance = premiumGate.calculatePhotoImportAllowance(
                    currentPhotoCount = currentPhotos.size,
                    selectedPhotoCount = imageItems.size,
                    isPremium = isPremium
                )

                if (allowance.allowedCount == 0 && imageItems.isNotEmpty()) {
                    PremiumManager.showUpgrade(
                        title = "Album photo limit reached",
                        subtitle = "Upgrade to Wonderlog Premium to add more photos to your Journey."
                    )
                    return@withContext Result.failure(
                        IllegalStateException("Photo limit reached for free plan.")
                    )
                }

                val itemsToImport = imageItems.take(allowance.allowedCount)
                for (item in itemsToImport) {
                    val uriString = item.uri ?: continue
                    val uri = Uri.parse(uriString)

                    val importedPhoto = AlbumPhotoManager.importPhoto(
                        context = context,
                        journeyId = journeyId,
                        uri = uri,
                        displayOrder = currentPhotos.size + importedPhotoCount,
                        existingPhotos = currentPhotos
                    )

                    if (importedPhoto != null) {
                        wanderlogRepository.insertPhoto(importedPhoto)
                        importedPhotoCount++

                        // If memory exists or was created, link with cross ref
                        if (targetMemoryId != null) {
                            wanderlogRepository.insertMemoryPhotoCrossRef(
                                MemoryPhotoCrossRef(
                                    memoryId = targetMemoryId,
                                    albumPhotoId = importedPhoto.id,
                                    displayOrder = importedPhotoCount,
                                    isHeroPhoto = (importedPhotoCount == 1)
                                )
                            )
                        }
                    }
                }
            }

            // 3. Process FILE / PDF items as Keepsakes
            val fileItems = draft.items.filter { it.type == CaptureContentType.FILE }
            var attachmentCount = 0

            if (fileItems.isNotEmpty()) {
                val memId = targetMemoryId
                    ?: return@withContext Result.failure(
                        IllegalStateException("A Memory is required to attach files or keepsakes.")
                    )

                for (fileItem in fileItems) {
                    val uriString = fileItem.uri ?: continue
                    val addResult = keepsakeRepository.addKeepsake(
                        memoryId = memId,
                        sourceUri = uriString,
                        mimeType = fileItem.mimeType,
                        originalName = fileItem.title
                    )
                    if (addResult.isSuccess) {
                        attachmentCount++
                    } else {
                        val error = addResult.exceptionOrNull()
                        if (error is IllegalArgumentException) {
                            return@withContext Result.failure(error)
                        }
                    }
                }
            }

            Result.success(
                CaptureSaveResult(
                    journeyId = journeyId,
                    memoryId = targetMemoryId,
                    importedPhotoCount = importedPhotoCount,
                    attachmentCount = attachmentCount
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
