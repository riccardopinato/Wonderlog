package com.example.capture

import android.content.Intent
import android.net.Uri
import android.os.Build
import java.util.UUID

object WonderlogShareIntentParser {

    fun parse(
        intent: Intent?
    ): List<CaptureIncomingItem> {
        if (intent == null) {
            return emptyList()
        }

        return when (intent.action) {
            Intent.ACTION_SEND -> parseSingle(intent)
            Intent.ACTION_SEND_MULTIPLE -> parseMultiple(intent)
            else -> emptyList()
        }
    }

    private fun parseSingle(
        intent: Intent
    ): List<CaptureIncomingItem> {
        val type = intent.type.orEmpty()

        val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }

        if (uri != null) {
            return listOf(
                itemFromUri(
                    uri = uri,
                    mimeType = type
                )
            )
        }

        val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()

        if (text.isNotBlank()) {
            val subject = intent.getStringExtra(Intent.EXTRA_SUBJECT)
            val looksLikeLink = text.startsWith("http://") || text.startsWith("https://")
            val detectedLocation = SharedLocationParser.parse(text)

            return listOf(
                CaptureIncomingItem(
                    id = UUID.randomUUID().toString(),
                    type = if (looksLikeLink) {
                        CaptureContentType.LINK
                    } else {
                        CaptureContentType.TEXT
                    },
                    text = text,
                    title = subject,
                    mimeType = type,
                    location = detectedLocation
                )
            )
        }

        return emptyList()
    }

    private fun parseMultiple(
        intent: Intent
    ): List<CaptureIncomingItem> {
        val mimeType = intent.type

        val uris: List<Uri> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
        }

        return uris
            .distinct()
            .take(100)
            .map { uri ->
                itemFromUri(
                    uri = uri,
                    mimeType = mimeType
                )
            }
    }

    private fun itemFromUri(
        uri: Uri,
        mimeType: String?
    ): CaptureIncomingItem {
        val effectiveMime = mimeType.orEmpty()

        val contentType = when {
            effectiveMime.startsWith("image/") -> CaptureContentType.IMAGE
            effectiveMime == "application/pdf" -> CaptureContentType.FILE
            else -> CaptureContentType.FILE
        }

        return CaptureIncomingItem(
            id = UUID.randomUUID().toString(),
            type = contentType,
            uri = uri.toString(),
            mimeType = mimeType
        )
    }
}
