package com.example.capture

import com.example.domain.model.MemoryAttachmentEntity

interface TravelKeepsakeRepository {

    suspend fun addKeepsake(
        memoryId: String,
        sourceUri: String,
        mimeType: String?,
        originalName: String?
    ): Result<String>

    suspend fun getKeepsakes(
        memoryId: String
    ): List<MemoryAttachmentEntity>

    suspend fun deleteKeepsake(
        attachmentId: String
    ): Result<Unit>
}
