package com.example.capture

enum class CaptureContentType {
    IMAGE,
    TEXT,
    LINK,
    PLACE,
    FILE
}

data class CaptureLocation(
    val latitude: Double,
    val longitude: Double,
    val label: String? = null
)

data class CaptureIncomingItem(
    val id: String,
    val type: CaptureContentType,
    val uri: String? = null,
    val text: String? = null,
    val title: String? = null,
    val mimeType: String? = null,
    val location: CaptureLocation? = null
)

data class CaptureDraft(
    val items: List<CaptureIncomingItem>,
    val journeyId: String? = null,
    val memoryId: String? = null,
    val createNewMemory: Boolean = false,
    val memoryTitle: String = "",
    val memoryText: String = "",
    val location: CaptureLocation? = null
) {
    val hasImages: Boolean
        get() = items.any { it.type == CaptureContentType.IMAGE }

    val hasFiles: Boolean
        get() = items.any { it.type == CaptureContentType.FILE }

    val hasText: Boolean
        get() = items.any {
            it.type == CaptureContentType.TEXT || it.type == CaptureContentType.LINK
        }
}

sealed interface CaptureUiState {
    data object Idle : CaptureUiState

    data class Ready(
        val draft: CaptureDraft
    ) : CaptureUiState

    data class Saving(
        val draft: CaptureDraft
    ) : CaptureUiState

    data class Success(
        val journeyId: String?,
        val memoryId: String?,
        val importedPhotoCount: Int,
        val attachmentCount: Int
    ) : CaptureUiState

    data class Error(
        val message: String
    ) : CaptureUiState
}
