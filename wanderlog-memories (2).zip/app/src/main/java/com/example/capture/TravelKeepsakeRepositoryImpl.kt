package com.example.capture

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.example.data.local.MemoryAttachmentDao
import com.example.domain.model.MemoryAttachmentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class TravelKeepsakeRepositoryImpl(
    private val context: Context,
    private val attachmentDao: MemoryAttachmentDao
) : TravelKeepsakeRepository {

    companion object {
        const val MAX_KEEPSAKE_BYTES = 25L * 1024L * 1024L // 25 MB
    }

    override suspend fun addKeepsake(
        memoryId: String,
        sourceUri: String,
        mimeType: String?,
        originalName: String?
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(sourceUri)
            val contentResolver = context.contentResolver

            // Determine display name and size
            var resolvedName: String? = originalName
            var reportedSize = 0L

            try {
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIndex != -1 && resolvedName.isNullOrBlank()) {
                            resolvedName = cursor.getString(nameIndex)
                        }
                        if (sizeIndex != -1) {
                            reportedSize = cursor.getLong(sizeIndex)
                        }
                    }
                }
            } catch (_: Exception) {
            }

            if (reportedSize > MAX_KEEPSAKE_BYTES) {
                return@withContext Result.failure(
                    IllegalArgumentException("Keepsake file exceeds maximum allowed size of 25MB.")
                )
            }

            // Determine mime type
            val resolvedMime = mimeType?.ifBlank { null }
                ?: contentResolver.getType(uri)
                ?: "application/octet-stream"

            // Determine category
            val category = resolveAttachmentCategory(resolvedMime, resolvedName)

            // Determine file extension
            val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(resolvedMime)
                ?: resolvedName?.substringAfterLast('.', "")
                ?.takeIf { it.isNotBlank() }
                ?: "bin"

            val attachmentId = "keepsake_${UUID.randomUUID().toString().replace("-", "")}"
            val safeExtension = extension.filter { it.isLetterOrDigit() }.ifBlank { "bin" }

            val memoryDir = File(context.filesDir, "keepsakes/$memoryId")
            if (!memoryDir.exists()) {
                memoryDir.mkdirs()
            }

            val targetFile = File(memoryDir, "$attachmentId.$safeExtension")

            // Copy input stream into private storage safely enforcing MAX_KEEPSAKE_BYTES
            val inputStream = contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("Cannot open input stream for $uri"))

            var bytesCopied = 0L
            inputStream.use { input ->
                FileOutputStream(targetFile).use { output ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        bytesCopied += read
                        if (bytesCopied > MAX_KEEPSAKE_BYTES) {
                            targetFile.delete()
                            return@withContext Result.failure(
                                IllegalArgumentException("Keepsake exceeds 25MB limit.")
                            )
                        }
                        output.write(buffer, 0, read)
                    }
                }
            }

            val entity = MemoryAttachmentEntity(
                id = attachmentId,
                memoryId = memoryId,
                localUri = targetFile.absolutePath,
                originalName = resolvedName ?: "$attachmentId.$safeExtension",
                mimeType = resolvedMime,
                attachmentType = category,
                createdAt = System.currentTimeMillis(),
                syncStatus = "LOCAL_ONLY"
            )

            attachmentDao.insertAttachment(entity)
            Result.success(attachmentId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getKeepsakes(memoryId: String): List<MemoryAttachmentEntity> =
        withContext(Dispatchers.IO) {
            attachmentDao.getAttachmentsForMemory(memoryId)
        }

    override suspend fun deleteKeepsake(attachmentId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val entity = attachmentDao.getAttachmentById(attachmentId)
                if (entity != null) {
                    try {
                        val file = File(entity.localUri)
                        if (file.exists()) {
                            file.delete()
                        }
                    } catch (_: Exception) {}
                    attachmentDao.deleteAttachment(entity)
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun resolveAttachmentCategory(mime: String, name: String?): String {
        val lowerName = name?.lowercase().orEmpty()
        return when {
            lowerName.contains("ticket") || lowerName.contains("biglietto") -> "TICKET"
            lowerName.contains("boarding") || lowerName.contains("pass") || lowerName.contains("carta_imbarco") -> "BOARDING_PASS"
            lowerName.contains("receipt") || lowerName.contains("scontrino") || lowerName.contains("fattura") -> "RECEIPT"
            lowerName.contains("postcard") || lowerName.contains("cartolina") -> "POSTCARD"
            lowerName.contains("screenshot") -> "SCREENSHOT"
            mime == "application/pdf" -> "DOCUMENT"
            else -> "OTHER"
        }
    }
}
