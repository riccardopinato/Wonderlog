package com.example.capture

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CaptureViewModel(
    private val repository: CaptureRepository
) : ViewModel() {

    private val _state = MutableStateFlow<CaptureUiState>(CaptureUiState.Idle)
    val state: StateFlow<CaptureUiState> = _state.asStateFlow()

    private val _journeys = MutableStateFlow<List<CaptureJourneyOption>>(emptyList())
    val journeys: StateFlow<List<CaptureJourneyOption>> = _journeys.asStateFlow()

    private val _memories = MutableStateFlow<List<CaptureMemoryOption>>(emptyList())
    val memories: StateFlow<List<CaptureMemoryOption>> = _memories.asStateFlow()

    fun setIncomingItems(items: List<CaptureIncomingItem>) {
        if (items.isEmpty()) {
            return
        }

        _state.value = CaptureUiState.Ready(
            CaptureDraft(
                items = items
            )
        )

        loadJourneys()
    }

    fun selectJourney(journeyId: String?) {
        updateDraft {
            it.copy(
                journeyId = journeyId,
                memoryId = null
            )
        }

        if (journeyId != null) {
            loadMemories(journeyId)
        } else {
            _memories.value = emptyList()
        }
    }

    fun selectMemory(memoryId: String?) {
        updateDraft {
            it.copy(
                memoryId = memoryId,
                createNewMemory = false
            )
        }
    }

    fun setCreateNewMemory(enabled: Boolean) {
        updateDraft {
            it.copy(
                createNewMemory = enabled,
                memoryId = if (enabled) null else it.memoryId
            )
        }
    }

    fun setMemoryTitle(value: String) {
        updateDraft {
            it.copy(
                memoryTitle = value.take(120)
            )
        }
    }

    fun setMemoryText(value: String) {
        updateDraft {
            it.copy(
                memoryText = value.take(50_000)
            )
        }
    }

    fun save() {
        val current = _state.value
        if (current !is CaptureUiState.Ready) {
            return
        }

        val draft = current.draft

        viewModelScope.launch {
            _state.value = CaptureUiState.Saving(draft)

            repository.save(draft)
                .onSuccess { result ->
                    _state.value = CaptureUiState.Success(
                        journeyId = result.journeyId,
                        memoryId = result.memoryId,
                        importedPhotoCount = result.importedPhotoCount,
                        attachmentCount = result.attachmentCount
                    )
                }
                .onFailure { error ->
                    _state.value = CaptureUiState.Error(
                        error.message ?: "Unable to save this content."
                    )
                }
        }
    }

    fun reset() {
        _state.value = CaptureUiState.Idle
        _journeys.value = emptyList()
        _memories.value = emptyList()
    }

    private fun loadJourneys() {
        viewModelScope.launch {
            _journeys.value = repository.getJourneys()
        }
    }

    private fun loadMemories(journeyId: String) {
        viewModelScope.launch {
            _memories.value = repository.getMemories(journeyId)
        }
    }

    private fun updateDraft(
        transform: (CaptureDraft) -> CaptureDraft
    ) {
        val current = _state.value
        if (current is CaptureUiState.Ready) {
            _state.value = CaptureUiState.Ready(
                transform(current.draft)
            )
        }
    }
}
