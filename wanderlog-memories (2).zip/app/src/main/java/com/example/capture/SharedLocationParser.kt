package com.example.capture

import java.util.regex.Pattern

object SharedLocationParser {

    private val GEO_URI_PATTERN = Pattern.compile("""geo:(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)""")
    private val AT_COORDINATE_PATTERN = Pattern.compile("""@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)""")
    private val Q_COORDINATE_PATTERN = Pattern.compile("""[?&]q=(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)""")

    fun parse(text: String?): CaptureLocation? {
        if (text.isNullOrBlank()) return null

        // 1. geo:LAT,LON
        val geoMatcher = GEO_URI_PATTERN.matcher(text)
        if (geoMatcher.find()) {
            val lat = geoMatcher.group(1)?.toDoubleOrNull()
            val lon = geoMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lon != null && isValid(lat, lon)) {
                return CaptureLocation(latitude = lat, longitude = lon)
            }
        }

        // 2. @LAT,LON
        val atMatcher = AT_COORDINATE_PATTERN.matcher(text)
        if (atMatcher.find()) {
            val lat = atMatcher.group(1)?.toDoubleOrNull()
            val lon = atMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lon != null && isValid(lat, lon)) {
                return CaptureLocation(latitude = lat, longitude = lon)
            }
        }

        // 3. ?q=LAT,LON or &q=LAT,LON
        val qMatcher = Q_COORDINATE_PATTERN.matcher(text)
        if (qMatcher.find()) {
            val lat = qMatcher.group(1)?.toDoubleOrNull()
            val lon = qMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lon != null && isValid(lat, lon)) {
                return CaptureLocation(latitude = lat, longitude = lon)
            }
        }

        return null
    }

    private fun isValid(lat: Double, lon: Double): Boolean {
        return lat in -90.0..90.0 && lon in -180.0..180.0
    }
}
