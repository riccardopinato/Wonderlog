package com.example.capture

interface CaptureRepository {

    suspend fun getJourneys(): List<CaptureJourneyOption>

    suspend fun getMemories(
        journeyId: String
    ): List<CaptureMemoryOption>

    suspend fun save(
        draft: CaptureDraft
    ): Result<CaptureSaveResult>
}

data class CaptureJourneyOption(
    val id: String,
    val title: String,
    val subtitle: String? = null
)

data class CaptureMemoryOption(
    val id: String,
    val title: String,
    val dateLabel: String? = null
)

data class CaptureSaveResult(
    val journeyId: String?,
    val memoryId: String?,
    val importedPhotoCount: Int,
    val attachmentCount: Int
)
