package com.example.capture

object CaptureValidator {

    data class Result(
        val valid: Boolean,
        val message: String? = null
    )

    fun validate(
        draft: CaptureDraft
    ): Result {
        if (draft.journeyId == null) {
            return Result(
                false,
                "Choose a Journey."
            )
        }

        val needsMemory = draft.items.any {
            it.type == CaptureContentType.TEXT ||
            it.type == CaptureContentType.LINK ||
            it.type == CaptureContentType.FILE
        }

        val hasMemoryDestination = draft.memoryId != null || draft.createNewMemory

        if (needsMemory && !hasMemoryDestination) {
            return Result(
                false,
                "Choose a Memory or create a new one."
            )
        }

        if (
            draft.createNewMemory &&
            draft.memoryTitle.isBlank() &&
            draft.memoryText.isBlank() &&
            draft.items.isEmpty()
        ) {
            return Result(
                false,
                "Add something to this Memory."
            )
        }

        return Result(true)
    }
}
