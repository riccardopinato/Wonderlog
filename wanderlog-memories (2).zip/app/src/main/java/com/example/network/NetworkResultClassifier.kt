package com.example.network

import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object NetworkResultClassifier {

    fun isRetryable(
        throwable: Throwable
    ): Boolean {

        return when (
            throwable
        ) {

            is SocketTimeoutException ->
                true

            is UnknownHostException ->
                true

            is IOException ->
                true

            else ->
                false
        }
    }
}
