package com.example.network

object WonderlogNetworkIdentity {

    const val USER_AGENT =
        "Wonderlog/1.0 Android"

    const val ACCEPT_LANGUAGE =
        "en"
}
