package com.example.premium

enum class PremiumPaywallReason {

    JOURNEY_LIMIT,

    PHOTO_LIMIT,

    MEMORY_LIMIT,

    PDF_EXPORT,

    CLOUD_BACKUP,

    OFFLINE_MAPS,

    PREMIUM_THEME,

    ADVANCED_STATISTICS,

    GENERAL
}
