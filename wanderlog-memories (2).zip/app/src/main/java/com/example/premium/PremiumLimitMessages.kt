package com.example.premium

object PremiumLimitMessages {

    fun photoMaximumReached(
        allowance: PhotoImportAllowance
    ): String {

        return if (
            allowance.allowedCount > 0
        ) {

            "This Journey supports up to ${allowance.limit} photos. You can import ${allowance.allowedCount} of the ${allowance.selectedCount} selected photos."

        } else {

            "This Journey has reached its ${allowance.limit}-photo limit."
        }
    }
}
