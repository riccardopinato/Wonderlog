package com.example.premium

import android.app.Activity
import com.revenuecat.purchases.Package

interface RevenueCatRepository {

    fun configure()

    fun refreshCustomerInfo()

    fun loadOfferings()

    fun purchase(
        activity: Activity,
        packageToPurchase: Package
    )

    fun restorePurchases()

    fun clearError()
}
