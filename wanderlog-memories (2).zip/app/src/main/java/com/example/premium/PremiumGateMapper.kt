package com.example.premium

object PremiumGateMapper {

    fun paywallReason(
        result: PremiumGateResult
    ): PremiumPaywallReason? {

        return when (result) {

            PremiumGateResult.Allowed ->
                null

            is PremiumGateResult.LimitReached -> {

                when (result.feature) {

                    PremiumFeature.UNLIMITED_JOURNEYS ->
                        PremiumPaywallReason.JOURNEY_LIMIT

                    PremiumFeature.EXTENDED_ALBUM ->
                        PremiumPaywallReason.PHOTO_LIMIT

                    PremiumFeature.UNLIMITED_MEMORIES ->
                        PremiumPaywallReason.MEMORY_LIMIT

                    PremiumFeature.PDF_EXPORT ->
                        PremiumPaywallReason.PDF_EXPORT

                    PremiumFeature.CLOUD_BACKUP ->
                        PremiumPaywallReason.CLOUD_BACKUP

                    PremiumFeature.OFFLINE_MAPS ->
                        PremiumPaywallReason.OFFLINE_MAPS

                    PremiumFeature.PREMIUM_THEMES ->
                        PremiumPaywallReason.PREMIUM_THEME

                    PremiumFeature.ADVANCED_STATISTICS ->
                        PremiumPaywallReason.ADVANCED_STATISTICS
                }
            }

            is PremiumGateResult.PremiumRequired -> {

                when (result.feature) {

                    PremiumFeature.UNLIMITED_JOURNEYS ->
                        PremiumPaywallReason.JOURNEY_LIMIT

                    PremiumFeature.EXTENDED_ALBUM ->
                        PremiumPaywallReason.PHOTO_LIMIT

                    PremiumFeature.UNLIMITED_MEMORIES ->
                        PremiumPaywallReason.MEMORY_LIMIT

                    PremiumFeature.PDF_EXPORT ->
                        PremiumPaywallReason.PDF_EXPORT

                    PremiumFeature.CLOUD_BACKUP ->
                        PremiumPaywallReason.CLOUD_BACKUP

                    PremiumFeature.OFFLINE_MAPS ->
                        PremiumPaywallReason.OFFLINE_MAPS

                    PremiumFeature.PREMIUM_THEMES ->
                        PremiumPaywallReason.PREMIUM_THEME

                    PremiumFeature.ADVANCED_STATISTICS ->
                        PremiumPaywallReason.ADVANCED_STATISTICS
                }
            }
        }
    }
}
