package com.example.premium

sealed interface PremiumGateResult {

    data object Allowed :
        PremiumGateResult

    data class LimitReached(
        val feature: PremiumFeature,
        val current: Int,
        val limit: Int
    ) : PremiumGateResult

    data class PremiumRequired(
        val feature: PremiumFeature
    ) : PremiumGateResult
}
