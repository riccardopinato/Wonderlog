package com.example.premium

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Single in-process representation of the Premium entitlement.
 *
 * IMPORTANT:
 * Only RevenueCatPremiumManager may update this state.
 *
 * UI, PremiumGate and repositories may observe it,
 * but they must never unlock Premium manually.
 */
object PremiumEntitlementStore {

    private val _isPremium =
        MutableStateFlow(false)

    val isPremium: StateFlow<Boolean> =
        _isPremium.asStateFlow()

    internal fun updateFromRevenueCat(
        isPremium: Boolean
    ) {
        _isPremium.value = isPremium
    }
}
