package com.example.premium

enum class PremiumFeature {

    UNLIMITED_JOURNEYS,

    EXTENDED_ALBUM,

    UNLIMITED_MEMORIES,

    CLOUD_BACKUP,

    PDF_EXPORT,

    OFFLINE_MAPS,

    PREMIUM_THEMES,

    ADVANCED_STATISTICS
}
