package com.example.premium

data class PremiumPlan(
    val id: String,
    val title: String,
    val subtitle: String,
    val priceLabel: String,
    val billingLabel: String,
    val isRecommended: Boolean = false
)
