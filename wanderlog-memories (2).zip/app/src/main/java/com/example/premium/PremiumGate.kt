package com.example.premium

class PremiumGate(
    private val entitlementChecker:
    EntitlementChecker = EntitlementChecker()
) {

    fun canCreateJourney(
        currentJourneyCount: Int,
        isPremium: Boolean
    ): PremiumGateResult {

        val limit =
            entitlementChecker
                .journeyLimit(isPremium)

        return if (
            currentJourneyCount < limit
        ) {

            PremiumGateResult.Allowed

        } else {

            PremiumGateResult.LimitReached(
                feature =
                PremiumFeature.UNLIMITED_JOURNEYS,

                current =
                currentJourneyCount,

                limit =
                limit
            )
        }
    }

    fun canAddAlbumPhotos(
        currentPhotoCount: Int,
        photosToAdd: Int,
        isPremium: Boolean
    ): PremiumGateResult {

        val limit =
            entitlementChecker
                .albumPhotoLimit(isPremium)

        return if (
            currentPhotoCount +
            photosToAdd <= limit
        ) {

            PremiumGateResult.Allowed

        } else {

            PremiumGateResult.LimitReached(
                feature =
                PremiumFeature.EXTENDED_ALBUM,

                current =
                currentPhotoCount,

                limit =
                limit
            )
        }
    }

    fun calculatePhotoImportAllowance(
        currentPhotoCount: Int,
        selectedPhotoCount: Int,
        isPremium: Boolean
    ): PhotoImportAllowance {

        val limit =
            entitlementChecker.albumPhotoLimit(
                isPremium = isPremium
            )

        val safeSelected =
            selectedPhotoCount.coerceAtLeast(0)

        val availableSlots =
            (limit - currentPhotoCount)
                .coerceAtLeast(0)

        val allowed =
            safeSelected
                .coerceAtMost(
                    availableSlots
                )

        val blocked =
            (safeSelected - allowed)
                .coerceAtLeast(0)

        return PhotoImportAllowance(
            selectedCount = safeSelected,
            allowedCount = allowed,
            blockedCount = blocked,
            currentCount = currentPhotoCount,
            limit = limit,
            isFullyAllowed = blocked == 0
        )
    }

    fun canCreateMemory(
        currentMemoryCount: Int,
        isPremium: Boolean
    ): PremiumGateResult {

        val limit =
            entitlementChecker
                .memoryLimit(isPremium)

        return if (
            currentMemoryCount < limit
        ) {

            PremiumGateResult.Allowed

        } else {

            PremiumGateResult.LimitReached(
                feature =
                PremiumFeature.UNLIMITED_MEMORIES,

                current =
                currentMemoryCount,

                limit =
                limit
            )
        }
    }

    fun canUseFeature(
        feature: PremiumFeature,
        isPremium: Boolean
    ): PremiumGateResult {

        return if (
            entitlementChecker
                .hasFeature(
                    feature,
                    isPremium
                )
        ) {

            PremiumGateResult.Allowed

        } else {

            PremiumGateResult
                .PremiumRequired(
                    feature
                )
        }
    }
}
