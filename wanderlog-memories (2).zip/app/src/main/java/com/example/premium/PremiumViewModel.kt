package com.example.premium

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.revenuecat.purchases.Package
import kotlinx.coroutines.flow.StateFlow

class PremiumViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val manager =
        RevenueCatPremiumManager(
            application
        )

    val state: StateFlow<PremiumState> =
        manager.state

    init {
        manager.configure()
    }

    fun refresh() {
        manager.refreshCustomerInfo()
    }

    fun reloadOfferings() {
        manager.loadOfferings()
    }

    fun purchase(
        activity: Activity,
        packageToPurchase: Package
    ) {
        manager.purchase(
            activity = activity,
            packageToPurchase =
                packageToPurchase
        )
    }

    fun restorePurchases() {
        manager.restorePurchases()
    }

    fun clearError() {
        manager.clearError()
    }
}
