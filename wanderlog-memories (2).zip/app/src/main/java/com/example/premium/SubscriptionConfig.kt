package com.example.premium

data class SubscriptionLimits(
    val albumPhotosLimit: Int,
    val memoriesLimit: Int,
    val journeysLimit: Int
)

object SubscriptionConfig {

    const val FREE_JOURNEYS_LIMIT = 3

    const val FREE_ALBUM_PHOTOS_PER_JOURNEY = 5

    const val PREMIUM_ALBUM_PHOTOS_PER_JOURNEY = 100

    const val FREE_MEMORIES_PER_JOURNEY = 5

    const val PREMIUM_JOURNEYS_LIMIT: Int = Int.MAX_VALUE

    const val PREMIUM_MEMORIES_PER_JOURNEY: Int = Int.MAX_VALUE

    const val FREE_CLOUD_BACKUP = false

    const val PREMIUM_CLOUD_BACKUP = true

    const val FREE_PDF_EXPORT = false

    const val PREMIUM_PDF_EXPORT = true

    const val FREE_OFFLINE_MAPS = false

    const val PREMIUM_OFFLINE_MAPS = true

    const val FREE_PREMIUM_THEMES = false

    const val PREMIUM_PREMIUM_THEMES = true

    const val FREE_ADVANCED_STATS = false

    const val PREMIUM_ADVANCED_STATS = true

    /**
     * RevenueCat / Play Billing IDs.
     *
     * Keep these centralized.
     * Replace values with production identifiers before release.
     */
    const val PREMIUM_ENTITLEMENT_ID = "premium"

    const val MONTHLY_PRODUCT_ID = "wonderlog_premium_monthly"

    const val YEARLY_PRODUCT_ID = "wonderlog_premium_yearly"

    const val LIFETIME_PRODUCT_ID = "wonderlog_premium_lifetime"

    // Backward-compatible limits structure
    val freeLimits = SubscriptionLimits(
        albumPhotosLimit = FREE_ALBUM_PHOTOS_PER_JOURNEY,
        memoriesLimit = FREE_MEMORIES_PER_JOURNEY,
        journeysLimit = FREE_JOURNEYS_LIMIT
    )

    val premiumLimits = SubscriptionLimits(
        albumPhotosLimit = PREMIUM_ALBUM_PHOTOS_PER_JOURNEY,
        memoriesLimit = PREMIUM_MEMORIES_PER_JOURNEY,
        journeysLimit = PREMIUM_JOURNEYS_LIMIT
    )

    fun getLimits(isPremium: Boolean): SubscriptionLimits {
        return if (isPremium) premiumLimits else freeLimits
    }
}
