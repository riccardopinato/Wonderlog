package com.example.premium

class EntitlementChecker {

    fun hasFeature(
        feature: PremiumFeature,
        isPremium: Boolean
    ): Boolean {

        if (isPremium) {
            return true
        }

        return when (feature) {

            PremiumFeature.UNLIMITED_JOURNEYS ->
                false

            PremiumFeature.EXTENDED_ALBUM ->
                false

            PremiumFeature.UNLIMITED_MEMORIES ->
                false

            PremiumFeature.CLOUD_BACKUP ->
                SubscriptionConfig.FREE_CLOUD_BACKUP

            PremiumFeature.PDF_EXPORT ->
                SubscriptionConfig.FREE_PDF_EXPORT

            PremiumFeature.OFFLINE_MAPS ->
                SubscriptionConfig.FREE_OFFLINE_MAPS

            PremiumFeature.PREMIUM_THEMES ->
                SubscriptionConfig.FREE_PREMIUM_THEMES

            PremiumFeature.ADVANCED_STATISTICS ->
                SubscriptionConfig.FREE_ADVANCED_STATS
        }
    }

    fun journeyLimit(
        isPremium: Boolean
    ): Int {

        return if (isPremium) {
            SubscriptionConfig.PREMIUM_JOURNEYS_LIMIT
        } else {
            SubscriptionConfig.FREE_JOURNEYS_LIMIT
        }
    }

    fun albumPhotoLimit(
        isPremium: Boolean
    ): Int {

        return if (isPremium) {
            SubscriptionConfig
                .PREMIUM_ALBUM_PHOTOS_PER_JOURNEY
        } else {
            SubscriptionConfig
                .FREE_ALBUM_PHOTOS_PER_JOURNEY
        }
    }

    fun memoryLimit(
        isPremium: Boolean
    ): Int {

        return if (isPremium) {
            SubscriptionConfig
                .PREMIUM_MEMORIES_PER_JOURNEY
        } else {
            SubscriptionConfig
                .FREE_MEMORIES_PER_JOURNEY
        }
    }
}
