package com.example.premium

import com.revenuecat.purchases.Package

data class PremiumState(
    val initialized: Boolean = false,

    val isLoading: Boolean = false,

    val isPremium: Boolean = false,

    val availablePackages: List<Package> = emptyList(),

    val monthlyPackage: Package? = null,

    val yearlyPackage: Package? = null,

    val lifetimePackage: Package? = null,

    val purchasingPackageId: String? = null,

    val errorMessage: String? = null,

    val restoreCompleted: Boolean = false
)
