package com.example.premium

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Compatibility facade for the existing Wonderlog UI.
 *
 * Premium entitlement DOES NOT live here.
 * RevenueCat -> PremiumEntitlementStore is the only
 * source of truth.
 *
 * This object only coordinates upgrade UI.
 */
object PremiumManager {

    val isPremium: StateFlow<Boolean> =
        PremiumEntitlementStore.isPremium

    private val _showUpgradeDialog =
        MutableStateFlow(false)

    val showUpgradeDialog:
        StateFlow<Boolean> =
        _showUpgradeDialog.asStateFlow()

    private val _upgradeTitle =
        MutableStateFlow(
            "Unlock more of your Journey."
        )

    val upgradeTitle:
        StateFlow<String> =
        _upgradeTitle.asStateFlow()

    private val _upgradeSubtitle =
        MutableStateFlow(
            "Wonderlog Premium gives you more space, cloud backup, offline maps and Travel Books."
        )

    val upgradeSubtitle:
        StateFlow<String> =
        _upgradeSubtitle.asStateFlow()

    fun showUpgrade(
        title: String =
            "Unlock more of your Journey.",

        subtitle: String =
            "Wonderlog Premium gives you more space, cloud backup, offline maps and Travel Books."
    ) {

        _upgradeTitle.value =
            title

        _upgradeSubtitle.value =
            subtitle

        _showUpgradeDialog.value =
            true
    }

    fun dismissUpgrade() {

        _showUpgradeDialog.value =
            false
    }
}
