package com.example.premium

data class PhotoImportAllowance(
    val selectedCount: Int,
    val allowedCount: Int,
    val blockedCount: Int,
    val currentCount: Int,
    val limit: Int,
    val isFullyAllowed: Boolean
)
