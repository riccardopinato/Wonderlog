package com.example.premium

data class PremiumPaywallContent(
    val eyebrow: String,
    val title: String,
    val subtitle: String,
    val highlightedValue: String?,
    val benefits: List<String>,
    val primaryAction: String,
    val secondaryAction: String = "Maybe later"
)

object PremiumPaywallContentFactory {

    fun create(
        reason: PremiumPaywallReason
    ): PremiumPaywallContent {

        return when (reason) {

            PremiumPaywallReason.JOURNEY_LIMIT -> {

                PremiumPaywallContent(
                    eyebrow = "WONDERLOG PREMIUM",
                    title = "Ready for another adventure?",
                    subtitle =
                        "The free version includes 3 Journeys. Premium lets you keep every trip in one place.",
                    highlightedValue =
                        "Unlimited Journeys",
                    benefits = listOf(
                        "Unlimited Journeys",
                        "Up to 100 photos per Journey",
                        "Unlimited Memories",
                        "Cloud Backup",
                        "PDF Travel Books"
                    ),
                    primaryAction =
                        "Unlock unlimited Journeys"
                )
            }

            PremiumPaywallReason.PHOTO_LIMIT -> {

                PremiumPaywallContent(
                    eyebrow = "YOUR ALBUM IS FULL",
                    title =
                        "Your Journey deserves more than 5 photos.",
                    subtitle =
                        "Premium expands every Journey into a much larger travel album.",
                    highlightedValue =
                        "5 → 100 photos",
                    benefits = listOf(
                        "Up to 100 photos per Journey",
                        "Full Journey albums",
                        "Unlimited Memories",
                        "Cloud Backup",
                        "PDF Travel Books"
                    ),
                    primaryAction =
                        "Expand my album"
                )
            }

            PremiumPaywallReason.MEMORY_LIMIT -> {

                PremiumPaywallContent(
                    eyebrow = "KEEP THE STORY GOING",
                    title =
                        "Some Journeys need more than 5 Memories.",
                    subtitle =
                        "Premium removes the Memory limit so you can preserve the whole story.",
                    highlightedValue =
                        "Unlimited Memories",
                    benefits = listOf(
                        "Unlimited Memories",
                        "Up to 100 photos per Journey",
                        "Unlimited Journeys",
                        "Cloud Backup",
                        "PDF Travel Books"
                    ),
                    primaryAction =
                        "Keep every Memory"
                )
            }

            PremiumPaywallReason.PDF_EXPORT -> {

                PremiumPaywallContent(
                    eyebrow = "TRAVEL BOOKS",
                    title =
                        "Turn this Journey into something you can keep.",
                    subtitle =
                        "Premium lets you transform your Journey, photos and Memories into a beautiful PDF travel book.",
                    highlightedValue =
                        "PDF Travel Book",
                    benefits = listOf(
                        "Export complete Journeys",
                        "Photos and Memories together",
                        "Save locally",
                        "Share with family and friends",
                        "Premium layouts"
                    ),
                    primaryAction =
                        "Unlock PDF Travel Books"
                )
            }

            PremiumPaywallReason.CLOUD_BACKUP -> {

                PremiumPaywallContent(
                    eyebrow = "PROTECT YOUR JOURNEYS",
                    title =
                        "Your memories should not live on one device only.",
                    subtitle =
                        "Premium Cloud Backup keeps Wonderlog ready for future restore and multi-device synchronization.",
                    highlightedValue =
                        "Cloud Backup",
                    benefits = listOf(
                        "Secure Journey backup",
                        "Photo backup",
                        "Memory backup",
                        "Future device restore",
                        "Future multi-device sync"
                    ),
                    primaryAction =
                        "Unlock Cloud Backup"
                )
            }

            PremiumPaywallReason.OFFLINE_MAPS -> {

                PremiumPaywallContent(
                    eyebrow = "TRAVEL OFFLINE",
                    title =
                        "Take your Journey map with you.",
                    subtitle =
                        "Premium prepares your maps for places where mobile data is slow, expensive or unavailable.",
                    highlightedValue =
                        "Offline Maps",
                    benefits = listOf(
                        "Journey map regions",
                        "Offline map access",
                        "Memory locations",
                        "Photo locations",
                        "Travel without relying on connectivity"
                    ),
                    primaryAction =
                        "Unlock Offline Maps"
                )
            }

            PremiumPaywallReason.PREMIUM_THEME -> {

                PremiumPaywallContent(
                    eyebrow = "MAKE IT YOURS",
                    title =
                        "Give every Journey its own personality.",
                    subtitle =
                        "Premium unlocks additional colors, gradients and visual styles.",
                    highlightedValue =
                        "Premium Themes",
                    benefits = listOf(
                        "Exclusive Journey themes",
                        "Premium gradients",
                        "More visual combinations",
                        "Future seasonal themes"
                    ),
                    primaryAction =
                        "Unlock Premium Themes"
                )
            }

            PremiumPaywallReason.ADVANCED_STATISTICS -> {

                PremiumPaywallContent(
                    eyebrow = "YOUR TRAVEL STORY IN NUMBERS",
                    title =
                        "See more of the Journeys you've created.",
                    subtitle =
                        "Premium unlocks deeper statistics about places, photos and Memories.",
                    highlightedValue =
                        "Advanced Statistics",
                    benefits = listOf(
                        "Journey insights",
                        "Photo statistics",
                        "Memory statistics",
                        "Places visited",
                        "Future yearly travel recap"
                    ),
                    primaryAction =
                        "Unlock Statistics"
                )
            }

            PremiumPaywallReason.GENERAL -> {

                PremiumPaywallContent(
                    eyebrow = "WONDERLOG PREMIUM",
                    title =
                        "Keep the complete story of every Journey.",
                    subtitle =
                        "Unlock the full Wonderlog experience.",
                    highlightedValue =
                        "Wonderlog Premium",
                    benefits = listOf(
                        "Unlimited Journeys",
                        "100 photos per Journey",
                        "Unlimited Memories",
                        "Cloud Backup",
                        "PDF Travel Books",
                        "Offline Maps",
                        "Premium Themes"
                    ),
                    primaryAction =
                        "Unlock Premium"
                )
            }
        }
    }
}
