package com.example.premium

data class PremiumBenefit(
    val title: String,
    val description: String
)

object PremiumBenefits {

    val all =
        listOf(

            PremiumBenefit(
                title =
                "Unlimited Journeys",
                description =
                "Keep every trip, weekend and adventure in one place."
            ),

            PremiumBenefit(
                title =
                "Up to 100 photos per Journey",
                description =
                "Turn each trip into a complete local photo album."
            ),

            PremiumBenefit(
                title =
                "Unlimited Memories",
                description =
                "Write as many personal moments as you want."
            ),

            PremiumBenefit(
                title =
                "Cloud Backup",
                description =
                "Keep your Journeys safe across devices."
            ),

            PremiumBenefit(
                title =
                "PDF Travel Books",
                description =
                "Turn a Journey into a beautiful book you can save or share."
            ),

            PremiumBenefit(
                title =
                "Offline Maps",
                description =
                "Keep important Journey maps available without a connection."
            ),

            PremiumBenefit(
                title =
                "Premium Themes",
                description =
                "Give every Journey its own visual identity."
            ),

            PremiumBenefit(
                title =
                "Advanced Statistics",
                description =
                "See the places, photos and memories that shaped your travels."
            )
        )
}
