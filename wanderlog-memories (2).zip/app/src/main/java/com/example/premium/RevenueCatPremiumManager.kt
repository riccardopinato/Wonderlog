package com.example.premium

import android.app.Activity
import android.app.Application
import android.util.Log
import com.example.BuildConfig
import com.revenuecat.purchases.CustomerInfo
import com.revenuecat.purchases.LogLevel
import com.revenuecat.purchases.Package
import com.revenuecat.purchases.PurchaseParams
import com.revenuecat.purchases.Purchases
import com.revenuecat.purchases.PurchasesConfiguration
import com.revenuecat.purchases.getCustomerInfoWith
import com.revenuecat.purchases.getOfferingsWith
import com.revenuecat.purchases.purchaseWith
import com.revenuecat.purchases.restorePurchasesWith
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RevenueCatPremiumManager(
    private val application: Application
) : RevenueCatRepository {

    private val _state =
        MutableStateFlow(
            PremiumState()
        )

    val state: StateFlow<PremiumState> =
        _state.asStateFlow()

    private var configured = false

    override fun configure() {

        if (configured) {
            return
        }

        val apiKey =
            BuildConfig
                .REVENUECAT_ANDROID_API_KEY
                .trim()

        if (apiKey.isBlank()) {

            _state.value =
                _state.value.copy(
                    initialized = false,
                    errorMessage =
                        "RevenueCat API key is not configured."
                )

            return
        }

        try {

            if (BuildConfig.DEBUG) {
                Purchases.logLevel =
                    LogLevel.DEBUG
            }

            Purchases.configure(
                PurchasesConfiguration
                    .Builder(
                        application,
                        apiKey
                    )
                    .build()
            )

            configured = true

            _state.value =
                _state.value.copy(
                    initialized = true,
                    errorMessage = null
                )

            refreshCustomerInfo()
            loadOfferings()

        } catch (exception: Exception) {

            Log.e(
                TAG,
                "RevenueCat configuration failed.",
                exception
            )

            _state.value =
                _state.value.copy(
                    initialized = false,
                    errorMessage =
                        exception.message
                            ?: "RevenueCat initialization failed."
                )
        }
    }

    override fun refreshCustomerInfo() {

        if (!ensureConfigured()) {
            return
        }

        Purchases.sharedInstance
            .getCustomerInfoWith(

                onError = { error ->

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            errorMessage =
                                error.message
                        )
                },

                onSuccess = { customerInfo ->

                    applyCustomerInfo(
                        customerInfo
                    )
                }
            )
    }

    override fun loadOfferings() {

        if (!ensureConfigured()) {
            return
        }

        _state.value =
            _state.value.copy(
                isLoading = true,
                errorMessage = null
            )

        Purchases.sharedInstance
            .getOfferingsWith(

                onError = { error ->

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            errorMessage =
                                error.message
                        )
                },

                onSuccess = { offerings ->

                    val current =
                        offerings.current

                    val packages =
                        current
                            ?.availablePackages
                            .orEmpty()

                    val monthly =
                        packages.firstOrNull {
                            it.identifier ==
                                "\$rc_monthly"
                        }
                            ?: packages.firstOrNull {
                                it.product.id ==
                                    SubscriptionConfig
                                        .MONTHLY_PRODUCT_ID
                            }

                    val yearly =
                        packages.firstOrNull {
                            it.identifier ==
                                "\$rc_annual"
                        }
                            ?: packages.firstOrNull {
                                it.product.id ==
                                    SubscriptionConfig
                                        .YEARLY_PRODUCT_ID
                            }

                    val lifetime =
                        packages.firstOrNull {
                            it.identifier ==
                                "\$rc_lifetime"
                        }
                            ?: packages.firstOrNull {
                                it.product.id ==
                                    SubscriptionConfig
                                        .LIFETIME_PRODUCT_ID
                            }

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            availablePackages =
                                packages,
                            monthlyPackage =
                                monthly,
                            yearlyPackage =
                                yearly,
                            lifetimePackage =
                                lifetime,
                            errorMessage = null
                        )
                }
            )
    }

    override fun purchase(
        activity: Activity,
        packageToPurchase: Package
    ) {

        if (!ensureConfigured()) {
            return
        }

        _state.value =
            _state.value.copy(
                isLoading = true,
                purchasingPackageId =
                    packageToPurchase.identifier,
                errorMessage = null
            )

        val params =
            PurchaseParams
                .Builder(
                    activity,
                    packageToPurchase
                )
                .build()

        Purchases.sharedInstance
            .purchaseWith(

                purchaseParams = params,

                onError = {
                        error,
                        userCancelled
                    ->

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            purchasingPackageId = null,

                            errorMessage =
                                if (userCancelled) {
                                    null
                                } else {
                                    error.message
                                }
                        )
                },

                onSuccess = {
                        _,
                        customerInfo
                    ->

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            purchasingPackageId = null,
                            errorMessage = null
                        )

                    applyCustomerInfo(
                        customerInfo
                    )
                }
            )
    }

    override fun restorePurchases() {

        if (!ensureConfigured()) {
            return
        }

        _state.value =
            _state.value.copy(
                isLoading = true,
                restoreCompleted = false,
                errorMessage = null
            )

        Purchases.sharedInstance
            .restorePurchasesWith(

                onError = { error ->

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            restoreCompleted = false,
                            errorMessage =
                                error.message
                        )
                },

                onSuccess = { customerInfo ->

                    applyCustomerInfo(
                        customerInfo
                    )

                    _state.value =
                        _state.value.copy(
                            isLoading = false,
                            restoreCompleted = true,
                            errorMessage = null
                        )
                }
            )
    }

    override fun clearError() {

        _state.value =
            _state.value.copy(
                errorMessage = null
            )
    }

    private fun applyCustomerInfo(
        customerInfo: CustomerInfo
    ) {

        val entitlement =
            customerInfo
                .entitlements
                .all[
                    SubscriptionConfig
                        .PREMIUM_ENTITLEMENT_ID
                ]

        val premium =
            entitlement
                ?.isActive == true

        PremiumEntitlementStore
            .updateFromRevenueCat(
                premium
            )

        if (!premium) {
            try {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    val settingsRepo = com.example.cloud.CloudWorkerDependencies.settingsRepository(application)
                    settingsRepo.setAutomaticBackupEnabled(false)
                    com.example.cloud.CloudBackupScheduler(application).cancelAutomaticBackup()
                }
            } catch (_: Exception) {}
        }

        _state.value =
            _state.value.copy(
                initialized = true,
                isLoading = false,
                isPremium = premium,
                errorMessage = null
            )
    }

    private fun ensureConfigured(): Boolean {

        if (!configured) {

            configure()
        }

        return configured
    }

    companion object {

        private const val TAG =
            "RevenueCatPremium"
    }
}
