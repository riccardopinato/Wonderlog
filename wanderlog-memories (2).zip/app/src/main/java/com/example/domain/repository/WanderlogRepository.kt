package com.example.domain.repository

import com.example.domain.model.Memory
import com.example.domain.model.Trip
import com.example.domain.model.AlbumPhoto
import kotlinx.coroutines.flow.Flow

interface WanderlogRepository {
    fun getAllTrips(): Flow<List<Trip>>
    fun getTripById(id: String): Flow<Trip?>
    fun getMemoriesForTrip(tripId: String): Flow<List<Memory>>
    fun getAllMemories(): Flow<List<Memory>>
    fun getMemoriesWithPhotosForTrip(tripId: String): Flow<List<com.example.domain.model.MemoryWithPhotos>>
    fun getAllMemoriesWithPhotos(): Flow<List<com.example.domain.model.MemoryWithPhotos>>
    fun getMemoryWithPhotosById(id: String): Flow<com.example.domain.model.MemoryWithPhotos?>
    suspend fun insertMemoryPhotoCrossRef(crossRef: com.example.domain.model.MemoryPhotoCrossRef)
    suspend fun deleteCrossRefsForMemory(memoryId: String)
    suspend fun insertTrip(trip: Trip)
    suspend fun updateTrip(trip: Trip)
    suspend fun insertMemory(memory: Memory)
    suspend fun deleteTrip(trip: Trip)
    suspend fun deleteMemory(memory: Memory)
    suspend fun populateMockDataIfEmpty()

    // Album Photo operations
    fun getPhotosForJourney(journeyId: String): Flow<List<AlbumPhoto>>
    suspend fun insertPhoto(photo: AlbumPhoto)
    suspend fun insertPhotos(photos: List<AlbumPhoto>)
    suspend fun updatePhoto(photo: AlbumPhoto)
    suspend fun deletePhoto(photo: AlbumPhoto)
    suspend fun deletePhotos(photos: List<AlbumPhoto>)
    suspend fun deletePhotosForJourney(journeyId: String)
    suspend fun getPhotoById(id: String): AlbumPhoto?
}
