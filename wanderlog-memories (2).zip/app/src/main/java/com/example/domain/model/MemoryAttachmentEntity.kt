package com.example.domain.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "memory_attachments",
    foreignKeys = [
        ForeignKey(
            entity = Memory::class,
            parentColumns = ["id"],
            childColumns = ["memoryId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["memoryId"])
    ]
)
data class MemoryAttachmentEntity(
    @PrimaryKey
    val id: String,
    val memoryId: String,
    val localUri: String,
    val originalName: String?,
    val mimeType: String,
    val attachmentType: String,
    val createdAt: Long,
    val syncStatus: String
)
