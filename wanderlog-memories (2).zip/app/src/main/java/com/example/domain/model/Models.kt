package com.example.domain.model

import androidx.room.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

enum class Mood(val emoji: String, val label: String, val colorHex: String, val gradientColors: List<String>) {
    HAPPY("😊", "Happy", "#FFD066", listOf("#FFE599", "#FFD066")),
    CALM("🧘", "Calm", "#52A8FF", listOf("#A1D0FF", "#52A8FF")),
    ADVENTURE("🧗", "Adventure", "#3AD29F", listOf("#86F3D4", "#3AD29F")),
    ROMANTIC("💖", "Romantic", "#FF69B4", listOf("#FFB5D5", "#FF69B4")),
    FOOD("🍕", "Food", "#FFA07A", listOf("#FFD3B6", "#FFA07A")),
    NATURE("🌲", "Nature", "#4CAF50", listOf("#A3E4D7", "#4CAF50")),
    NOSTALGIC("🎞️", "Nostalgic", "#8E44AD", listOf("#D2B4DE", "#8E44AD")),
    ADVENTUROUS("🧗", "Adventurous", "#3AD29F", listOf("#86F3D4", "#3AD29F")), // legacy compat
    SERENE("🧘", "Serene", "#52A8FF", listOf("#A1D0FF", "#52A8FF")), // legacy compat
    ENERGETIC("⚡", "Energetic", "#FF5252", listOf("#FF9E9E", "#FF5252")),
    DREAMY("🌙", "Dreamy", "#9E52FF", listOf("#D9B3FF", "#9E52FF"))
}

data class LocationCoordinate(
    val latitude: Double,
    val longitude: Double
)

@Entity(tableName = "trips")
data class Trip(
    @PrimaryKey val id: String,
    val destinationName: String,
    val country: String,
    val startDate: String, // YYYY-MM-DD
    val endDate: String,   // YYYY-MM-DD
    val coverImage: String, // resource identifier or path
    val description: String,
    val accentGradientIndex: Int = 0, // selects from a list of predefined gradients
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,

    // Journey Engine Expanded Fields
    val title: String = destinationName,
    val destination: String = destinationName,
    val coverPhotoId: String = coverImage,
    val accentTheme: String = "Preset_$accentGradientIndex",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val statistics: String = "",
    val futureCloudId: String? = null,
    val syncStatus: String = "LOCAL_ONLY"
) {
    // Computed property for easier use
    val coordinate: LocationCoordinate
        get() = LocationCoordinate(latitude, longitude)

    val defaultCoordinate: LocationCoordinate
        get() = coordinate
}

@Entity(
    tableName = "memories",
    foreignKeys = [
        ForeignKey(
            entity = Trip::class,
            parentColumns = ["id"],
            childColumns = ["tripId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["tripId"])
    ]
)
data class Memory(
    @PrimaryKey val id: String,
    val tripId: String,
    val journeyId: String = tripId,
    val title: String,
    val note: String, // backwards compatibility
    val journalText: String = note, // scrapbook diary
    val image: String = "", // cover photo
    val locationName: String,
    val latitude: Double?,
    val longitude: Double?,
    val date: String, // YYYY-MM-DD
    val mood: Mood,
    val tags: List<String>,
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val displayOrder: Int = 0,
    val syncStatus: String = "LOCAL_ONLY",
    val futureCloudId: String? = null
) {
    val coordinate: LocationCoordinate?
        get() = if (latitude != null && longitude != null) LocationCoordinate(latitude, longitude) else null
}

@Entity(
    tableName = "memory_photos",
    primaryKeys = ["memoryId", "albumPhotoId"],
    foreignKeys = [
        ForeignKey(
            entity = Memory::class,
            parentColumns = ["id"],
            childColumns = ["memoryId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = AlbumPhoto::class,
            parentColumns = ["id"],
            childColumns = ["albumPhotoId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["memoryId"]),
        Index(value = ["albumPhotoId"])
    ]
)
data class MemoryPhotoCrossRef(
    val memoryId: String,
    val albumPhotoId: String,
    val displayOrder: Int = 0,
    val isHeroPhoto: Boolean = false
)

data class MemoryWithPhotos(
    @Embedded val memory: Memory,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(
            value = MemoryPhotoCrossRef::class,
            parentColumn = "memoryId",
            entityColumn = "albumPhotoId"
        )
    )
    val photos: List<AlbumPhoto>
)

data class MapMarker(
    val id: String,
    val journeyId: String,
    val memoryId: String? = null,
    val albumPhotoId: String? = null,
    val coordinate: LocationCoordinate,
    val title: String,
    val subtitle: String = "",
    val type: String = "Memory", // "Memory", "AlbumPhoto", "Favorite", "CurrentLocation", "FutureRoutePoint"
    val mood: Mood,
    val thumbnailUri: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    
    // For Backwards Compatibility with old code
    val tripId: String = journeyId,
    val note: String = subtitle,
    val image: String = thumbnailUri
)

@Entity(
    tableName = "album_photos",
    foreignKeys = [
        ForeignKey(
            entity = Trip::class,
            parentColumns = ["id"],
            childColumns = ["journeyId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["journeyId"])]
)
data class AlbumPhoto(
    @PrimaryKey val id: String,
    val journeyId: String,
    val localUri: String,
    val thumbnailUri: String,
    val originalUri: String,
    val fileName: String,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fileSize: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val capturedAt: Long? = null,
    val gpsLatitude: Double? = null,
    val gpsLongitude: Double? = null,
    val locationName: String = "",
    val favorite: Boolean = false,
    val isCoverPhoto: Boolean = false,
    val displayOrder: Int = 0,
    val syncStatus: String = "LOCAL_ONLY",
    val futureCloudId: String? = null
) {
    val gpsCoordinate: LocationCoordinate?
        get() = if (gpsLatitude != null && gpsLongitude != null) LocationCoordinate(gpsLatitude, gpsLongitude) else null
}
