package com.example.domain.repository

import com.example.domain.model.LocationPlace
import com.example.domain.model.OfflineMapRegion
import kotlinx.coroutines.flow.Flow

interface MapRepository {
    // Geocoding & Reverse Geocoding
    suspend fun searchPlaces(query: String): List<LocationPlace>
    suspend fun reverseGeocode(latitude: Double, longitude: Double): LocationPlace?
    
    // Offline Regions
    fun getAllOfflineRegions(): Flow<List<OfflineMapRegion>>
    suspend fun saveOfflineRegion(region: OfflineMapRegion)
    suspend fun deleteOfflineRegion(region: OfflineMapRegion)
    suspend fun getOfflineRegionById(id: String): OfflineMapRegion?
    
    // Saved Places / Locations
    fun getAllSavedPlaces(): Flow<List<LocationPlace>>
    suspend fun savePlace(place: LocationPlace)
    suspend fun deletePlace(place: LocationPlace)
}
