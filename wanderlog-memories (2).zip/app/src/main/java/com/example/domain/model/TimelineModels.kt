package com.example.domain.model

data class TimelineItem(
    val memoryId: String,
    val title: String,
    val journalPreview: String,
    val date: String,
    val locationName: String,
    val mood: Mood,
    val heroPhoto: String,
    val photoCount: Int,
    val favorite: Boolean,
    val displayOrder: Int
)

data class TimelineDay(
    val date: String,
    val title: String,
    val subtitle: String,
    val memories: List<TimelineItem>,
    val photoCount: Int,
    val moods: List<Mood>,
    val locations: List<String>
)

data class TimelineSection(
    val sectionId: String,
    val dateRange: String,
    val items: List<TimelineItem>
)

enum class TimelineSort {
    OLDEST_FIRST,
    NEWEST_FIRST,
    FAVORITES_FIRST,
    BY_MOOD,
    BY_LOCATION
}

data class TimelineFilter(
    val showOnlyFavorites: Boolean = false,
    val selectedMood: Mood? = null,
    val selectedTag: String? = null,
    val selectedLocation: String? = null,
    val dateRangeStart: String? = null,
    val dateRangeEnd: String? = null,
    val hasPhotosOnly: Boolean = false,
    val noPhotosOnly: Boolean = false
)
