package com.example.domain.repository

import com.example.domain.model.*

interface TimelineRepository {
    fun generateTimeline(
        trip: Trip,
        memoriesWithPhotos: List<MemoryWithPhotos>,
        sort: TimelineSort,
        filter: TimelineFilter
    ): List<TimelineDay>
    
    fun generateSections(
        memoriesWithPhotos: List<MemoryWithPhotos>,
        sort: TimelineSort,
        filter: TimelineFilter
    ): List<TimelineSection>
}
