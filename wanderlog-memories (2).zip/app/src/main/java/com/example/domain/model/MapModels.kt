package com.example.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location_places")
data class LocationPlace(
    @PrimaryKey val id: String,
    val displayName: String,
    val country: String,
    val city: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val source: String // "NOMINATIM", "MANUAL", "GPS" etc.
) {
    val coordinate: LocationCoordinate
        get() = LocationCoordinate(latitude, longitude)
}

@Entity(tableName = "geocoding_cache")
data class GeocodingCache(
    @PrimaryKey val query: String,
    val displayName: String,
    val country: String,
    val city: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val cachedAt: Long = System.currentTimeMillis()
) {
    val coordinate: LocationCoordinate
        get() = LocationCoordinate(latitude, longitude)
}

@Entity(tableName = "offline_map_regions")
data class OfflineMapRegion(
    @PrimaryKey val id: String,
    val name: String,
    val centerLatitude: Double,
    val centerLongitude: Double,
    val radiusKm: Double,
    val zoomMin: Int,
    val zoomMax: Int,
    val sizeBytes: Long = 0L,
    val isDownloaded: Boolean = false,
    val downloadProgress: Float = 0f,
    val createdAt: Long = System.currentTimeMillis()
) {
    val centerCoordinate: LocationCoordinate
        get() = LocationCoordinate(centerLatitude, centerLongitude)
}

// Map Placeholders required for Offline Map engine
data class TileDownloadQueue(
    val regionId: String,
    val pendingTiles: Int,
    val downloadedTiles: Int,
    val status: String // "IDLE", "DOWNLOADING", "PAUSED", "COMPLETED"
)

enum class TileCachePolicy {
    CACHE_FIRST,
    NETWORK_FIRST,
    OFFLINE_ONLY
}
