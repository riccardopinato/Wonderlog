package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.export.PdfExportOptions
import com.example.export.PdfTravelBookStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfExportOptionsSheet(
    onDismiss: () -> Unit,
    onExport: (
        PdfExportOptions
    ) -> Unit
) {

    val sheetState =
        rememberModalBottomSheetState(
            skipPartiallyExpanded =
                true
        )

    var style by remember {
        mutableStateOf(
            PdfTravelBookStyle
                .EDITORIAL
        )
    }

    var includeDescription by remember {
        mutableStateOf(true)
    }

    var includeAlbum by remember {
        mutableStateOf(true)
    }

    var includeMemories by remember {
        mutableStateOf(true)
    }

    var includeLocations by remember {
        mutableStateOf(true)
    }

    var includeDates by remember {
        mutableStateOf(true)
    }

    ModalBottomSheet(
        onDismissRequest =
            onDismiss,
        sheetState =
            sheetState,
        containerColor =
            Color(0xFF121724)
    ) {

        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal =
                            24.dp
                    )
                    .padding(
                        bottom =
                            32.dp
                    )
        ) {

            Text(
                text =
                    "Travel Book",
                color =
                    Color.White,
                fontSize =
                    25.sp,
                fontWeight =
                    FontWeight.ExtraBold
            )

            Spacer(
                modifier =
                    Modifier.height(
                        6.dp
                    )
            )

            Text(
                text =
                    "Turn this Journey into a book you can keep and share.",
                color =
                    Color.White.copy(
                        alpha =
                            0.58f
                    ),
                fontSize =
                    12.sp
            )

            Spacer(
                modifier =
                    Modifier.height(
                        24.dp
                    )
            )

            Text(
                text = "STYLE",
                color =
                    Color.White.copy(
                        alpha =
                            0.45f
                    ),
                fontSize =
                    10.sp,
                fontWeight =
                    FontWeight.Bold
            )

            Spacer(
                modifier =
                    Modifier.height(
                        10.dp
                    )
            )

            PdfTravelBookStyle.entries
                .forEach {
                        option ->

                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    style =
                                        option
                                }
                                .padding(
                                    vertical =
                                        9.dp
                                )
                    ) {

                        Text(
                            text =
                                when (
                                    option
                                ) {

                                    PdfTravelBookStyle.CLASSIC ->
                                        "Classic"

                                    PdfTravelBookStyle.EDITORIAL ->
                                        "Editorial"

                                    PdfTravelBookStyle.SCRAPBOOK ->
                                        "Scrapbook"
                                },

                            color =
                                if (
                                    style ==
                                    option
                                ) {
                                    Color(
                                        0xFFFF6596
                                    )
                                } else {
                                    Color.White
                                },

                            fontWeight =
                                if (
                                    style ==
                                    option
                                ) {
                                    FontWeight.Bold
                                } else {
                                    FontWeight.Normal
                                }
                        )
                    }
                }

            Spacer(
                modifier =
                    Modifier.height(
                        18.dp
                    )
            )

            Text(
                text =
                    "INCLUDE",
                color =
                    Color.White.copy(
                        alpha =
                            0.45f
                    ),
                fontSize =
                    10.sp,
                fontWeight =
                    FontWeight.Bold
            )

            OptionRow(
                label =
                    "Journey description",
                checked =
                    includeDescription,
                onCheckedChange = {
                    includeDescription =
                        it
                }
            )

            OptionRow(
                label =
                    "Memories",
                checked =
                    includeMemories,
                onCheckedChange = {
                    includeMemories =
                        it
                }
            )

            OptionRow(
                label =
                    "Album photos",
                checked =
                    includeAlbum,
                onCheckedChange = {
                    includeAlbum =
                        it
                }
            )

            OptionRow(
                label =
                    "Locations",
                checked =
                    includeLocations,
                onCheckedChange = {
                    includeLocations =
                        it
                }
            )

            OptionRow(
                label =
                    "Dates",
                checked =
                    includeDates,
                onCheckedChange = {
                    includeDates =
                        it
                }
            )

            Spacer(
                modifier =
                    Modifier.height(
                        22.dp
                    )
            )

            Button(
                onClick = {

                    onExport(
                        PdfExportOptions(
                            style =
                                style,

                            includeCover =
                                true,

                            includeJourneyDescription =
                                includeDescription,

                            includeAlbumPhotos =
                                includeAlbum,

                            includeMemories =
                                includeMemories,

                            includeLocations =
                                includeLocations,

                            includeDates =
                                includeDates
                        )
                    )
                },

                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(
                            52.dp
                        ),

                shape =
                    RoundedCornerShape(
                        18.dp
                    ),

                colors =
                    ButtonDefaults
                        .buttonColors(
                            containerColor =
                                Color(
                                    0xFFFF4D8D
                                )
                        )
            ) {

                Text(
                    text =
                        "Create Travel Book",
                    fontWeight =
                        FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
private fun OptionRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (
        Boolean
    ) -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clickable {
                    onCheckedChange(
                        !checked
                    )
                }
                .padding(
                    vertical =
                        5.dp
                )
    ) {

        Checkbox(
            checked =
                checked,
            onCheckedChange =
                onCheckedChange
        )

        Text(
            text =
                label,
            color =
                Color.White,
            modifier =
                Modifier.padding(
                    top =
                        12.dp
                ),
            fontSize =
                13.sp
        )
    }
}
