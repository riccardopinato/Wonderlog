package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun PremiumUpgradeDialog(
    onDismissRequest: () -> Unit,
    onUnlockClick: () -> Unit,
    modifier: Modifier = Modifier,
    title: String = "You've filled your free travel album.",
    subtitle: String = "Continue collecting every memory with Premium."
) {
    val premiumAccent = Brush.linearGradient(
        colors = listOf(Color(0xFFFF512F), Color(0xFFDD2476))
    )

    Dialog(onDismissRequest = onDismissRequest) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp))
                .border(
                    BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFFFF9A9E), Color(0xFFA18CD1)))),
                    RoundedCornerShape(28.dp)
                )
                .testTag("premium_upgrade_dialog"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Crown / Star Icon Accent
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .shadow(6.dp, CircleShape)
                        .background(premiumAccent, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Premium Badge",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Heading & Subtitle
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF0F172A),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(6.dp))
                
                Text(
                    text = subtitle,
                    fontSize = 13.sp,
                    color = Color(0xFF475569),
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Free vs Premium Side-by-Side Comparison
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Free Column
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Free",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        UpgradeBenefitItem(text = "3 viaggi", checked = true, checkColor = Color(0xFF10B981))
                        UpgradeBenefitItem(text = "5 foto / viaggio", checked = true, checkColor = Color(0xFF10B981))
                        UpgradeBenefitItem(text = "5 memorie / viaggio", checked = true, checkColor = Color(0xFF10B981))
                        UpgradeBenefitItem(text = "Storage locale", checked = true, checkColor = Color(0xFF10B981))
                        UpgradeBenefitItem(text = "Funzioni base", checked = true, checkColor = Color(0xFF10B981))
                    }

                    // Premium Column
                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .background(Color(0xFFFFF1F2), RoundedCornerShape(16.dp))
                            .border(BorderStroke(1.dp, Color(0xFFFECDD3)), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Premium ✨",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFE11D48),
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        UpgradeBenefitItem(text = "Viaggi illimitati", checked = true, checkColor = Color(0xFFE11D48))
                        UpgradeBenefitItem(text = "100 foto / viaggio", checked = true, checkColor = Color(0xFFE11D48))
                        UpgradeBenefitItem(text = "Memorie illimitate", checked = true, checkColor = Color(0xFFE11D48))
                        UpgradeBenefitItem(text = "Backup e Ripristino Cloud", checked = true, checkColor = Color(0xFFE11D48))
                        UpgradeBenefitItem(text = "Mappe offline", checked = true, checkColor = Color(0xFFE11D48))
                        UpgradeBenefitItem(text = "PDF Travel Book", checked = true, checkColor = Color(0xFFE11D48))
                        UpgradeBenefitItem(text = "Temi premium", checked = true, checkColor = Color(0xFFE11D48))
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Unlock Premium Button (Large gradient button)
                Button(
                    onClick = onUnlockClick,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .shadow(4.dp, RoundedCornerShape(20.dp))
                        .background(premiumAccent, RoundedCornerShape(20.dp))
                        .testTag("modal_unlock_premium_button")
                ) {
                    Text(
                        text = "Unlock Premium",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Maybe Later Button (Small secondary button)
                Text(
                    text = "Maybe Later",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    modifier = Modifier
                        .clickable { onDismissRequest() }
                        .padding(8.dp)
                        .testTag("modal_maybe_later_button")
                )
            }
        }
    }
}

@Composable
fun UpgradeBenefitItem(
    text: String,
    checked: Boolean,
    checkColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (checked) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = checkColor,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
        }
        Text(
            text = text,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF1E293B)
        )
    }
}
