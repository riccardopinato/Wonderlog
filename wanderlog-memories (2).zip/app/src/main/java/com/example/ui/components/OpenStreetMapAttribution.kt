package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun OpenStreetMapAttribution(
    modifier:
        Modifier =
        Modifier
) {

    val context =
        LocalContext.current

    Text(
        text =
            "© OpenStreetMap contributors",

        modifier =
            modifier
                .background(
                    color =
                        Color.White.copy(
                            alpha =
                                0.78f
                        ),

                    shape =
                        RoundedCornerShape(
                            8.dp
                        )
                )
                .clickable {

                    runCatching {

                        context
                            .startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(
                                        "https://www.openstreetmap.org/copyright"
                                    )
                                )
                            )
                    }
                }
                .padding(
                    horizontal =
                        7.dp,
                    vertical =
                        4.dp
                ),

        style =
            MaterialTheme
                .typography
                .labelSmall,

        color =
            Color(
                0xFF475569
            )
    )
}
