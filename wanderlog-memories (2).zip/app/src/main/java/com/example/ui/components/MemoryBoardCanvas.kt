package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.model.Memory
import kotlin.math.roundToInt

data class ScrapbookElement(
    val id: String,
    val type: ElementType,
    val text: String = "",
    val image: String = "",
    val moodEmoji: String = "",
    val rotation: Float = 0f,
    val initialOffset: Offset = Offset.Zero
) {
    enum class ElementType {
        PHOTO, STICKER, NOTE, BADGE
    }
}

@Composable
fun MemoryBoardCanvas(
    memories: List<Memory>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Aesthetic scrapbook background grid / warm organic canvas
    val paperBackground = Brush.radialGradient(
        colors = listOf(Color(0xFFFFFDF9), Color(0xFFFAF4E8)),
        center = Offset(400f, 400f),
        radius = 1200f
    )

    // Generate scrapbook elements dynamically based on trip memories
    val elements = remember(memories) {
        val list = mutableListOf<ScrapbookElement>()
        memories.forEachIndexed { index, memory ->
            // Photo Polaroid card
            list.add(
                ScrapbookElement(
                    id = "photo_${memory.id}",
                    type = ScrapbookElement.ElementType.PHOTO,
                    image = memory.image,
                    text = memory.title,
                    rotation = (-8..8).random().toFloat(),
                    initialOffset = Offset((20 + (index * 40) % 150).toFloat(), (50 + (index * 90) % 250).toFloat())
                )
            )

            // Mood Badge sticker
            list.add(
                ScrapbookElement(
                    id = "mood_${memory.id}",
                    type = ScrapbookElement.ElementType.BADGE,
                    text = memory.mood.label,
                    moodEmoji = memory.mood.emoji,
                    rotation = (-15..15).random().toFloat(),
                    initialOffset = Offset((180 + (index * 50) % 140).toFloat(), (200 + (index * 60) % 220).toFloat())
                )
            )

            // Handwritten-style paper note
            list.add(
                ScrapbookElement(
                    id = "note_${memory.id}",
                    type = ScrapbookElement.ElementType.NOTE,
                    text = memory.note,
                    rotation = (-5..5).random().toFloat(),
                    initialOffset = Offset((40 + (index * 70) % 160).toFloat(), (320 + (index * 70) % 230).toFloat())
                )
            )
        }

        // Add some default nostalgic travel stickers to spice it up!
        list.add(
            ScrapbookElement(
                id = "sticker_passport",
                type = ScrapbookElement.ElementType.STICKER,
                text = "PASSPORT ✈️",
                rotation = 12f,
                initialOffset = Offset(240f, 40f)
            )
        )
        list.add(
            ScrapbookElement(
                id = "sticker_wanderlust",
                type = ScrapbookElement.ElementType.STICKER,
                text = "WANDERLUST 🗺️",
                rotation = -14f,
                initialOffset = Offset(30f, 480f)
            )
        )
        list.add(
            ScrapbookElement(
                id = "sticker_adventure",
                type = ScrapbookElement.ElementType.STICKER,
                text = "ADVENTURE 🎒",
                rotation = 8f,
                initialOffset = Offset(220f, 520f)
            )
        )

        list
    }

    if (memories.isEmpty()) {
        Box(modifier = modifier.fillMaxSize().background(paperBackground), contentAlignment = Alignment.Center) {
            EmptyState(
                message = "Memory Board is clear",
                tip = "Add memories to this trip to populate your travel scrapbook canvas with stickers, notes, and interactive polaroids!"
            )
        }
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(paperBackground)
    ) {
        // Aesthetic scrapbook pins and tape graphics
        Text(
            text = "Scrapbook Moodboard 🌸",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Cursive,
            color = Color(0xFFC7B897),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp)
        )

        elements.forEach { element ->
            var offset by remember { mutableStateOf(element.initialOffset) }

            // Draggable scrapbook element container
            Box(
                modifier = Modifier
                    .offset { IntOffset(offset.x.roundToInt(), offset.y.roundToInt()) }
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            offset = Offset(offset.x + dragAmount.x, offset.y + dragAmount.y)
                        }
                    }
                    .rotate(element.rotation)
            ) {
                when (element.type) {
                    ScrapbookElement.ElementType.PHOTO -> {
                        // Polaroid photo item
                        val imgId = remember(element.image) {
                            context.resources.getIdentifier(element.image, "drawable", context.packageName)
                        }

                        Column(
                            modifier = Modifier
                                .width(150.dp)
                                .shadow(8.dp, RoundedCornerShape(8.dp))
                                .background(Color.White)
                                .padding(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .background(Color.LightGray, RoundedCornerShape(4.dp))
                                    .clip(RoundedCornerShape(4.dp))
                            ) {
                                if (imgId != 0) {
                                    AsyncImage(
                                        model = imgId,
                                        contentDescription = element.text,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = element.text,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.SansSerif,
                                color = Color.DarkGray,
                                maxLines = 1
                            )
                        }
                    }

                    ScrapbookElement.ElementType.STICKER -> {
                        // Styled travel stickers with white outline borders
                        Box(
                            modifier = Modifier
                                .shadow(4.dp, RoundedCornerShape(12.dp))
                                .background(
                                    Brush.horizontalGradient(listOf(Color(0xFF3AD29F), Color(0xFF52A8FF))),
                                    RoundedCornerShape(12.dp)
                                )
                                .border(2.dp, Color.White, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = element.text,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    ScrapbookElement.ElementType.NOTE -> {
                        // Handwritten torn notes
                        Box(
                            modifier = Modifier
                                .width(130.dp)
                                .shadow(6.dp, RoundedCornerShape(4.dp))
                                .background(Color(0xFFFEF9C3)) // light yellow torn paper
                                .padding(10.dp)
                        ) {
                            Text(
                                text = element.text,
                                fontSize = 10.sp,
                                color = Color(0xFF451A03),
                                maxLines = 4,
                                fontFamily = FontFamily.SansSerif,
                                lineHeight = 13.sp
                            )
                        }
                    }

                    ScrapbookElement.ElementType.BADGE -> {
                        // Colored mood badges
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .shadow(4.dp, RoundedCornerShape(16.dp))
                                .background(Color.White, RoundedCornerShape(16.dp))
                                .border(1.dp, Color(0xFFF1F1F1), RoundedCornerShape(16.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(element.moodEmoji, fontSize = 12.sp)
                            Text(
                                text = element.text,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}
