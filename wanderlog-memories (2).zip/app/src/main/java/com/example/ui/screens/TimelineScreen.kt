package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.domain.model.*
import com.example.presentation.TimelineEvent
import com.example.presentation.TimelineUiState
import com.example.presentation.WanderlogViewModel
import com.example.premium.PremiumManager

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun TimelineScreen(
    trip: Trip,
    viewModel: WanderlogViewModel,
    onAddMemoryClick: () -> Unit,
    onMemoryClick: (Memory) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.timelineUiState.collectAsState()
    val isPremium by PremiumManager.isPremium.collectAsState()
    val memoriesWithPhotos by viewModel.selectedTripMemoriesWithPhotos.collectAsState()

    var showSortMenu by remember { mutableStateOf(false) }
    var showFilterDialog by remember { mutableStateOf(false) }

    // Dynamically retrieve distinct tags, locations, and dates from the current memories
    val distinctTags = remember(memoriesWithPhotos) {
        memoriesWithPhotos.flatMap { it.memory.tags }.distinct().filter { it.isNotBlank() }
    }
    val distinctLocations = remember(memoriesWithPhotos) {
        memoriesWithPhotos.map { it.memory.locationName }.distinct().filter { it.isNotBlank() }
    }
    val distinctDates = remember(memoriesWithPhotos) {
        memoriesWithPhotos.map { it.memory.date }.distinct().sorted()
    }

    val activeFiltersCount = remember(uiState.filter) {
        var count = 0
        if (uiState.filter.showOnlyFavorites) count++
        if (uiState.filter.selectedMood != null) count++
        if (uiState.filter.selectedTag != null) count++
        if (uiState.filter.selectedLocation != null) count++
        if (uiState.filter.dateRangeStart != null) count++
        if (uiState.filter.hasPhotosOnly) count++
        if (uiState.filter.noPhotosOnly) count++
        count
    }

    val scrapbookBackground = Brush.verticalGradient(
        colors = listOf(
            Color(0xFFFAF7F2), // Elegant warm parchment white
            Color(0xFFF3EAE0)  // Rich soft sand
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("timeline_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize().background(scrapbookBackground)) {
            // Premium cover photo blur header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                // Background cover image with fallbacks
                val coverSource: Any? = remember(trip.coverImage) {
                    when {
                        trip.coverImage.isBlank() -> null
                        trip.coverImage.startsWith("content://") || trip.coverImage.startsWith("file://") || trip.coverImage.startsWith("http") -> trip.coverImage
                        trip.coverImage.startsWith("img_") -> {
                            context.resources.getIdentifier(trip.coverImage, "drawable", context.packageName).let { if (it == 0) trip.coverImage else it }
                        }
                        else -> trip.coverImage.toIntOrNull() ?: trip.coverImage
                    }
                }
                
                if (coverSource != null) {
                    AsyncImage(
                        model = coverSource,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.45f
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                                )
                            )
                    )
                }

                // Smooth luxury dark overlay for contrast
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.5f),
                                    Color.Black.copy(alpha = 0.75f)
                                )
                            )
                        )
                )

                // Header details
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = trip.destinationName,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Travel Timeline Journal",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "📅 ${trip.startDate} to ${trip.endDate}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF3AD29F)
                            )
                        }

                        // Action Buttons: Sort & Filter
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Sort Button
                            IconButton(
                                onClick = { showSortMenu = true },
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                    .size(40.dp)
                                    .testTag("timeline_sort_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sort,
                                    contentDescription = "Sort Timeline",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Filter Button with Badge overlay
                            BadgedBox(
                                badge = {
                                    if (activeFiltersCount > 0) {
                                        Badge(
                                            containerColor = Color(0xFFFF512F),
                                            contentColor = Color.White,
                                            modifier = Modifier.offset(y = (-4).dp, x = (-4).dp)
                                        ) {
                                            Text(activeFiltersCount.toString(), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                IconButton(
                                    onClick = { showFilterDialog = true },
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                        .size(40.dp)
                                        .testTag("timeline_filter_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FilterList,
                                        contentDescription = "Filter Timeline",
                                        tint = if (activeFiltersCount > 0) Color(0xFFFF512F) else Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Bottom Row: Stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val totalMemories = uiState.days.sumOf { it.memories.size }
                        val totalPhotos = uiState.days.sumOf { it.photoCount }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.CollectionsBookmark, contentDescription = null, tint = Color(0xFFFF69B4), modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("$totalMemories memories", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, tint = Color(0xFF52A8FF), modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("$totalPhotos photos", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // Scrollable Active Filter Tags
            if (activeFiltersCount > 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE2E8F0).copy(alpha = 0.5f))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Filtered by:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF475569)
                        )

                        if (uiState.filter.showOnlyFavorites) {
                            ActiveFilterChip(text = "Favorites ❤️") {
                                viewModel.onTimelineEvent(TimelineEvent.ToggleFavoriteFilter(false))
                            }
                        }

                        uiState.filter.selectedMood?.let { mood ->
                            ActiveFilterChip(text = "Mood: ${mood.emoji} ${mood.label}") {
                                viewModel.onTimelineEvent(TimelineEvent.SelectMoodFilter(null))
                            }
                        }

                        uiState.filter.selectedTag?.let { tag ->
                            ActiveFilterChip(text = "#$tag") {
                                viewModel.onTimelineEvent(TimelineEvent.SelectTagFilter(null))
                            }
                        }

                        uiState.filter.selectedLocation?.let { loc ->
                            ActiveFilterChip(text = "At: $loc") {
                                viewModel.onTimelineEvent(TimelineEvent.SelectLocationFilter(null))
                            }
                        }

                        val startDate = uiState.filter.dateRangeStart
                        val endDate = uiState.filter.dateRangeEnd
                        if (startDate != null) {
                            val isSingleDate = startDate == endDate || endDate == null
                            val dateText = if (isSingleDate) {
                                "On: ${formatReadableDate(startDate)}"
                            } else {
                                "${formatReadableDate(startDate)} - ${formatReadableDate(endDate)}"
                            }
                            ActiveFilterChip(text = dateText) {
                                viewModel.onTimelineEvent(TimelineEvent.SetDateRangeFilter(null, null))
                            }
                        }

                        if (uiState.filter.hasPhotosOnly) {
                            ActiveFilterChip(text = "With Photos 📸") {
                                viewModel.onTimelineEvent(TimelineEvent.SetPhotoFilter(hasPhotosOnly = false, noPhotosOnly = false))
                            }
                        }

                        if (uiState.filter.noPhotosOnly) {
                            ActiveFilterChip(text = "Text Diary 📝") {
                                viewModel.onTimelineEvent(TimelineEvent.SetPhotoFilter(hasPhotosOnly = false, noPhotosOnly = false))
                            }
                        }

                        TextButton(
                            onClick = { viewModel.onTimelineEvent(TimelineEvent.ClearFilters) },
                            modifier = Modifier.height(28.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text("Clear All", fontSize = 11.sp, color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Timeline Days content
            if (uiState.days.isEmpty()) {
                // Premium Scrapbook Empty State
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(32.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(Color.White, CircleShape)
                            .shadow(4.dp, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✨",
                            fontSize = 48.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Your story has not started yet.",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF0F172A),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Add your first memory and Wonderlog will build your travel timeline.",
                        fontSize = 13.sp,
                        color = Color(0xFF475569),
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = onAddMemoryClick,
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues(),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(52.dp)
                            .shadow(6.dp, RoundedCornerShape(22.dp))
                            .background(
                                Brush.horizontalGradient(listOf(Color(0xFFFF512F), Color(0xFFDD2476))),
                                shape = RoundedCornerShape(22.dp)
                             )
                            .testTag("add_first_memory_cta")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Add First Memory", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(uiState.days, key = { it.date }) { day ->
                        DaySectionHeader(day = day)

                        Spacer(modifier = Modifier.height(12.dp))

                        day.memories.forEach { item ->
                            val moodColor = try {
                                Color(android.graphics.Color.parseColor(item.mood.colorHex))
                            } catch (e: Exception) {
                                Color(0xFFDD2476)
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min) // Critical for drawing continuous lines!
                            ) {
                                // Left timeline axis track
                                Box(
                                    modifier = Modifier
                                        .width(42.dp)
                                        .fillMaxHeight(),
                                    contentAlignment = Alignment.TopCenter
                                ) {
                                    // Connected track line
                                    Box(
                                        modifier = Modifier
                                            .width(2.5.dp)
                                            .fillMaxHeight()
                                            .background(
                                                Brush.verticalGradient(
                                                    colors = listOf(
                                                        Color(0xFFDD2476).copy(alpha = 0.45f),
                                                        Color(0xFFFF512F).copy(alpha = 0.45f)
                                                    )
                                                )
                                            )
                                    )

                                    // Node dot circle containing mood emoji
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 20.dp)
                                            .size(32.dp)
                                            .background(moodColor.copy(alpha = 0.95f), CircleShape)
                                            .border(2.dp, Color.White, CircleShape)
                                            .shadow(3.dp, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(item.mood.emoji, fontSize = 14.sp)
                                    }
                                }

                                // Card container
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(bottom = 16.dp)
                                ) {
                                    TimelineCard(
                                        item = item,
                                        onFavoriteToggle = {
                                            viewModel.toggleFavoriteMemory(item.memoryId, item.favorite)
                                        },
                                        onClick = {
                                            onMemoryClick(
                                                Memory(
                                                    id = item.memoryId,
                                                    tripId = trip.id,
                                                    title = item.title,
                                                    note = item.journalPreview,
                                                    journalText = item.journalPreview,
                                                    image = item.heroPhoto,
                                                    locationName = item.locationName,
                                                    latitude = null,
                                                    longitude = null,
                                                    date = item.date,
                                                    mood = item.mood,
                                                    tags = emptyList(),
                                                    favorite = item.favorite
                                                )
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sort Selector Dialog
        if (showSortMenu) {
            Dialog(onDismissRequest = { showSortMenu = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Sort Travel Timeline",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Sort options
                        TimelineSort.values().forEach { sortOption ->
                            val isSelected = uiState.sort == sortOption
                            val label = when (sortOption) {
                                TimelineSort.OLDEST_FIRST -> "Chronological (Oldest First) 📅"
                                TimelineSort.NEWEST_FIRST -> "Reverse Chronological (Newest First) ⏰"
                                TimelineSort.FAVORITES_FIRST -> "Favorites First ❤️"
                                TimelineSort.BY_MOOD -> "Grouped by Mood Emoji 🎭"
                                TimelineSort.BY_LOCATION -> "Alphabetical by Location 📍"
                            }

                            Button(
                                onClick = {
                                    viewModel.onTimelineEvent(TimelineEvent.ChangeSort(sortOption))
                                    showSortMenu = false
                                    Toast.makeText(context, "Sorted timeline", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) Color(0xFFFF512F) else Color.White.copy(alpha = 0.08f)
                                )
                            ) {
                                Text(
                                    text = label,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedButton(
                            onClick = { showSortMenu = false },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("Cancel", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Expanded Filter Configuration Dialog (Tag/Location/Date)
        if (showFilterDialog) {
            Dialog(onDismissRequest = { showFilterDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 550.dp)
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Filter Scrapbook Stories",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        // Toggle switches
                        FilterToggleItem(
                            title = "Favorites Only ❤️",
                            description = "Only display precious starred memories",
                            isChecked = uiState.filter.showOnlyFavorites,
                            onCheckedChange = {
                                viewModel.onTimelineEvent(TimelineEvent.ToggleFavoriteFilter(it))
                            }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        FilterToggleItem(
                            title = "Must Contain Photos 📸",
                            description = "Hide memories with empty journals and no images",
                            isChecked = uiState.filter.hasPhotosOnly,
                            onCheckedChange = {
                                viewModel.onTimelineEvent(TimelineEvent.SetPhotoFilter(hasPhotosOnly = it, noPhotosOnly = false))
                            }
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        FilterToggleItem(
                            title = "Text Diary Only 📝",
                            description = "Show journal thoughts without photo attachments",
                            isChecked = uiState.filter.noPhotosOnly,
                            onCheckedChange = {
                                viewModel.onTimelineEvent(TimelineEvent.SetPhotoFilter(hasPhotosOnly = false, noPhotosOnly = it))
                            }
                        )

                        // Moods list
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Filter by Emotional Mood",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.align(Alignment.Start)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Mood.values().take(8).forEach { mood ->
                                val isSelected = uiState.filter.selectedMood == mood
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSelected) Color(0xFFDD2476) else Color.White.copy(alpha = 0.08f)
                                        )
                                        .clickable {
                                            viewModel.onTimelineEvent(
                                                TimelineEvent.SelectMoodFilter(if (isSelected) null else mood)
                                            )
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "${mood.emoji} ${mood.label}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }

                        // Tags list (dynamic!)
                        if (distinctTags.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = "Filter by Tag",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                distinctTags.forEach { tag ->
                                    val isSelected = uiState.filter.selectedTag == tag
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (isSelected) Color(0xFFFF512F) else Color.White.copy(alpha = 0.08f)
                                            )
                                            .clickable {
                                                viewModel.onTimelineEvent(
                                                    TimelineEvent.SelectTagFilter(if (isSelected) null else tag)
                                                )
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "#$tag",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }

                        // Locations list (dynamic!)
                        if (distinctLocations.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = "Filter by Location",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                distinctLocations.forEach { loc ->
                                    val isSelected = uiState.filter.selectedLocation == loc
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (isSelected) Color(0xFFFF512F) else Color.White.copy(alpha = 0.08f)
                                            )
                                            .clickable {
                                                viewModel.onTimelineEvent(
                                                    TimelineEvent.SelectLocationFilter(if (isSelected) null else loc)
                                                )
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = loc,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }

                        // Dates list (dynamic!)
                        if (distinctDates.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = "Filter by Date",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                distinctDates.forEach { date ->
                                    val isSelected = uiState.filter.dateRangeStart == date && uiState.filter.dateRangeEnd == date
                                    val formattedDate = formatReadableDate(date)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (isSelected) Color(0xFFFF512F) else Color.White.copy(alpha = 0.08f)
                                            )
                                            .clickable {
                                                if (isSelected) {
                                                    viewModel.onTimelineEvent(TimelineEvent.SetDateRangeFilter(null, null))
                                                } else {
                                                    viewModel.onTimelineEvent(TimelineEvent.SetDateRangeFilter(date, date))
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = formattedDate,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(28.dp))

                        Button(
                            onClick = { showFilterDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF512F)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Apply Filters", fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = {
                                viewModel.onTimelineEvent(TimelineEvent.ClearFilters)
                                showFilterDialog = false
                            }
                        ) {
                            Text("Reset All Filters", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveFilterChip(
    text: String,
    onRemove: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFDD2476).copy(alpha = 0.15f))
            .border(BorderStroke(1.dp, Color(0xFFDD2476).copy(alpha = 0.3f)), RoundedCornerShape(14.dp))
            .clickable { onRemove() }
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = Color(0xFF9D174D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove filter",
                tint = Color(0xFF9D174D),
                modifier = Modifier.size(12.dp)
            )
        }
    }
}

@Composable
fun FilterToggleItem(
    title: String,
    description: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!isChecked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(description, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFFFF512F)
            )
        )
    }
}

@Composable
fun DaySectionHeader(day: TimelineDay) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Large, premium iOS-style Day tag
        Box(
            modifier = Modifier
                .size(48.dp)
                .shadow(4.dp, RoundedCornerShape(14.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFFFF512F), Color(0xFFDD2476))
                    ),
                    shape = RoundedCornerShape(14.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "DAY",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White.copy(alpha = 0.8f)
                )
                val dayNum = day.title.substringBefore(" ·").replace("Day ", "").trim()
                Text(
                    text = dayNum.ifEmpty { "1" },
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            val titleText = day.title.substringAfter("· ", day.title).trim()
            Text(
                text = titleText,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            
            Spacer(modifier = Modifier.height(2.dp))
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = formatReadableDate(day.date),
                    fontSize = 11.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
                
                Text("•", fontSize = 11.sp, color = Color(0xFF94A3B8))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        tint = Color(0xFF52A8FF),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = if (day.photoCount == 1) "1 photo" else "${day.photoCount} photos",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
                
                if (day.locations.isNotEmpty()) {
                    Text("•", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = null,
                            tint = Color(0xFFFF512F),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = day.locations.first(),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TimelineCard(
    item: TimelineItem,
    onFavoriteToggle: () -> Unit,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val imageSource: Any? = remember(item.heroPhoto) {
        when {
            item.heroPhoto.isBlank() -> null
            item.heroPhoto.startsWith("content://") || item.heroPhoto.startsWith("file://") || item.heroPhoto.startsWith("http") -> item.heroPhoto
            item.heroPhoto.startsWith("img_") -> {
                context.resources.getIdentifier(item.heroPhoto, "drawable", context.packageName).let { if (it == 0) item.heroPhoto else it }
            }
            else -> item.heroPhoto.toIntOrNull() ?: item.heroPhoto
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag("timeline_item_${item.memoryId}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Card Hero Photo
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                if (imageSource != null) {
                    AsyncImage(
                        model = imageSource,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF800080).copy(alpha = 0.08f),
                                        Color(0xFFFF69B4).copy(alpha = 0.08f)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Collections,
                                contentDescription = null,
                                tint = Color.DarkGray.copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Written Entry Only", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        }
                    }
                }

                // Smooth gradient overlay for bottom badge readability
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.4f)),
                                startY = 100f
                            )
                        )
                )

                // Favorite Heart Button (Tactile scale bouncy animation)
                IconButton(
                    onClick = onFavoriteToggle,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.9f), CircleShape)
                        .shadow(2.dp, CircleShape)
                ) {
                    val favoriteScale by animateFloatAsState(
                        targetValue = if (item.favorite) 1.2f else 1.0f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioHighBouncy,
                            stiffness = Spring.StiffnessMedium
                        )
                    )
                    Icon(
                        imageVector = if (item.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (item.favorite) "Unstar" else "Star",
                        tint = if (item.favorite) Color(0xFFEF4444) else Color.Gray,
                        modifier = Modifier
                            .size(18.dp)
                            .scale(favoriteScale)
                    )
                }

                // Mood Emoji Overlay
                val moodColor = try {
                    Color(android.graphics.Color.parseColor(item.mood.colorHex))
                } catch (e: Exception) {
                    Color(0xFFDD2476)
                }

                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .background(moodColor, RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(item.mood.emoji, fontSize = 11.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = item.mood.label,
                        color = Color.Black,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Photo Count Overlay
                if (item.photoCount > 0) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${item.photoCount} photos", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Card details
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = item.title.ifEmpty { "Untitled Memory" },
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (item.locationName.isNotEmpty()) {
                        Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(12.dp))
                        Text(
                            text = item.locationName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF475569),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(11.dp))
                    Text(
                        text = formatReadableDate(item.date),
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = item.journalPreview.ifEmpty { "No diary text written for this memory entry." },
                    fontSize = 12.sp,
                    color = Color(0xFF334155),
                    lineHeight = 17.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// Global self-contained helper to format dates beautifully
private fun formatReadableDate(dateStr: String): String {
    return try {
        val inputFormat = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val outputFormat = java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.US)
        val date = inputFormat.parse(dateStr)
        if (date != null) outputFormat.format(date) else dateStr
    } catch (e: Exception) {
        dateStr
    }
}
