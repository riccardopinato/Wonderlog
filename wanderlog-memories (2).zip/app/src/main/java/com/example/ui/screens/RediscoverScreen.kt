package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rediscover.*
import com.example.ui.components.RediscoverCardItem

enum class RediscoverFilter {
    ALL, JOURNEYS, MEMORIES, PHOTOS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RediscoverScreen(
    viewModel: RediscoverViewModel,
    onBack: () -> Unit,
    onOpenJourney: (String) -> Unit,
    onOpenMemory: (String) -> Unit,
    onOpenPhoto: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsState()
    var selectedFilter by remember { mutableStateOf(RediscoverFilter.ALL) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("rediscover_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Rediscover",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                        Text(
                            text = "Anniversaries & Past Moments",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("rediscover_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.load() },
                        modifier = Modifier.testTag("rediscover_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val currentState = state) {
                is RediscoverUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color(0xFFDD2476))
                    }
                }
                is RediscoverUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = currentState.message,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.load() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDD2476))
                        ) {
                            Text("Retry")
                        }
                    }
                }
                is RediscoverUiState.Ready -> {
                    val allCards = currentState.feed.cards
                    val filteredCards = remember(allCards, selectedFilter) {
                        when (selectedFilter) {
                            RediscoverFilter.ALL -> allCards
                            RediscoverFilter.JOURNEYS -> allCards.filter { it.type == RediscoverType.JOURNEY_ANNIVERSARY }
                            RediscoverFilter.MEMORIES -> allCards.filter { it.type == RediscoverType.MEMORY }
                            RediscoverFilter.PHOTOS -> allCards.filter { it.type == RediscoverType.PHOTO || it.type == RediscoverType.ON_THIS_DAY }
                        }
                    }

                    Column(modifier = Modifier.fillMaxSize()) {
                        // Filter row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            RediscoverFilter.values().forEach { filter ->
                                val selected = selectedFilter == filter
                                FilterChip(
                                    selected = selected,
                                    onClick = { selectedFilter = filter },
                                    label = {
                                        Text(
                                            when (filter) {
                                                RediscoverFilter.ALL -> "All"
                                                RediscoverFilter.JOURNEYS -> "Journeys"
                                                RediscoverFilter.MEMORIES -> "Memories"
                                                RediscoverFilter.PHOTOS -> "Photos"
                                            }
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFDD2476),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        if (filteredCards.isEmpty()) {
                            // Empty State
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Surface(
                                    modifier = Modifier.size(80.dp),
                                    shape = CircleShape,
                                    color = Color(0xFFDD2476).copy(alpha = 0.1f)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            tint = Color(0xFFDD2476),
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(20.dp))
                                Text(
                                    text = "No memories for today yet.",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Your travel moments will appear here when their anniversaries come around.",
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                items(filteredCards, key = { it.id }) { card ->
                                    RediscoverCardItem(
                                        card = card,
                                        onClick = {
                                            when (card.type) {
                                                RediscoverType.JOURNEY_ANNIVERSARY -> {
                                                    card.journeyId?.let(onOpenJourney)
                                                }
                                                RediscoverType.MEMORY -> {
                                                    card.memoryId?.let(onOpenMemory)
                                                        ?: card.journeyId?.let(onOpenJourney)
                                                }
                                                RediscoverType.PHOTO, RediscoverType.ON_THIS_DAY -> {
                                                    card.photoId?.let(onOpenPhoto)
                                                        ?: card.journeyId?.let(onOpenJourney)
                                                }
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(240.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
