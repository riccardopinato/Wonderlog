package com.example.ui.screens

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.premium.PremiumManager
import com.example.premium.PremiumViewModel
import com.example.ui.components.FloatingGlassButton
import com.example.ui.components.GlassCard

@Composable
fun PremiumScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier,
    premiumViewModel: PremiumViewModel = viewModel()
) {
    val context = LocalContext.current
    val isPremium by PremiumManager.isPremium.collectAsState()
    val premiumState by premiumViewModel.state.collectAsState()
    var purchaseMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(premiumState.errorMessage) {
        premiumState.errorMessage?.let {
            purchaseMessage = it
            premiumViewModel.clearError()
        }
    }

    LaunchedEffect(premiumState.restoreCompleted) {
        if (premiumState.restoreCompleted) {
            purchaseMessage = if (isPremium) {
                "Purchases restored successfully! Pro unlocked! ✨"
            } else {
                "No previous purchases found for this account."
            }
        }
    }

    val premiumAccent = Brush.linearGradient(
        colors = listOf(Color(0xFFFF512F), Color(0xFFDD2476)) // Orange-pink premium gradients
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFFF9A9E), // Soft red/pink
                        Color(0xFFFAD0C4), // Peach/rose
                        Color(0xFFA18CD1)  // Soft purple/lavender
                    )
                )
            )
            .testTag("premium_paywall_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            // Back Arrow & Title Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .shadow(4.dp, CircleShape)
                        .background(Color.White.copy(alpha = 0.4f), CircleShape)
                        .border(androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)), CircleShape)
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF0F172A),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "Wanderlog Pro ✨",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Premium Crown Emblem
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .shadow(12.dp, CircleShape)
                    .background(premiumAccent, CircleShape)
                    .clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Unlock Wanderlog Premium",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF0F172A),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Elevate your journal memories with cloud backup, offline maps, and PDF travel books",
                fontSize = 13.sp,
                color = Color(0xFF0F172A).copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // List of premium features! Wrap inside glassmorphic cards!
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PremiumFeatureItem(
                        icon = Icons.Default.AllInclusive,
                        title = "Unlimited Journeys & Memories",
                        subtitle = "Capture every scenic destination without limits"
                    )
                    PremiumFeatureItem(
                        icon = Icons.Default.CloudUpload,
                        title = "Secure Cloud Backup & Restore",
                        subtitle = "Keep your precious travel diaries safely synchronized"
                    )
                    PremiumFeatureItem(
                        icon = Icons.Default.PictureAsPdf,
                        title = "Scrapbook PDF Export",
                        subtitle = "Print or share a highly aesthetic travel book copy"
                    )
                    PremiumFeatureItem(
                        icon = Icons.Default.Map,
                        title = "Offline OpenStreetMap Tiles",
                        subtitle = "Render full interactive maps without cell service"
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Purchase / Unlocked UI
            if (isPremium) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(4.dp, RoundedCornerShape(16.dp))
                        .background(Color(0xFF10B981).copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                        .border(androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Premium Active • All Features Unlocked!",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF10B981)
                        )
                    }
                }
            } else {
                val packageToPurchase = premiumState.lifetimePackage
                    ?: premiumState.yearlyPackage
                    ?: premiumState.monthlyPackage
                    ?: premiumState.availablePackages.firstOrNull()

                val price = packageToPurchase?.product?.price?.formatted
                val isLoading = premiumState.isLoading

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (price != null) {
                        Text(
                            text = price,
                            color = Color(0xFF0F172A),
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp
                        )
                    } else if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = "Unavailable",
                            fontSize = 11.sp,
                            color = Color(0xFF0F172A).copy(
                                alpha = 0.45f
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val buttonLabel = if (premiumState.purchasingPackageId != null) {
                    "Processing..."
                } else if (packageToPurchase != null && price != null) {
                    "Unlock ${packageToPurchase.product.title}"
                } else {
                    "Unlock Wanderlog Premium"
                }

                FloatingGlassButton(
                    text = buttonLabel,
                    onClick = {
                        val activity = context as? Activity
                        if (activity != null && packageToPurchase != null) {
                            premiumViewModel.purchase(activity, packageToPurchase)
                        } else {
                            purchaseMessage = "Unable to start purchase at this time."
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("unlock_premium_button"),
                    gradientColors = listOf(Color(0xFFFF512F), Color(0xFFDD2476))
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Restore Purchases",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A).copy(alpha = 0.6f),
                    modifier = Modifier
                        .clickable {
                            premiumViewModel.restorePurchases()
                        }
                        .padding(8.dp)
                )
            }

            // Congratulations Popup notification message
            purchaseMessage?.let { msg ->
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = msg,
                    fontSize = 13.sp,
                    color = Color(0xFFDD2476),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

@Composable
fun PremiumFeatureItem(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(Color.White.copy(alpha = 0.4f), CircleShape)
                .border(androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFFDD2476),
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color(0xFF0F172A).copy(alpha = 0.6f)
            )
        }
    }
}
