package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.data.local.WanderlogDatabase
import com.example.data.repository.WanderlogRepositoryImpl
import com.example.domain.model.Trip
import com.example.map.MapAction
import com.example.map.MapEvent
import com.example.map.MapViewModel
import com.example.map.MemoryMapView
import com.example.mapmemories.*
import com.example.ui.components.*
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyMapTab(
    trip: Trip,
    viewModel: MapViewModel,
    modifier: Modifier = Modifier,
    mapMemoryViewModel: MapMemoryViewModel? = null,
    onOpenMemory: (String) -> Unit = {},
    onOpenPhoto: (String) -> Unit = {},
    onAddMemoryClick: () -> Unit = {},
    onAlbumClick: () -> Unit = {}
) {
    val context = LocalContext.current

    val uiState by viewModel.uiState.collectAsState()
    var showSearch by remember { mutableStateOf(false) }
    var focusCoordinate by remember { mutableStateOf<MapCoordinate?>(null) }
    var cameraFitRequestKey by remember { mutableIntStateOf(0) }
    var hasInitiallyFitted by remember { mutableStateOf(false) }

    val actualMapMemoryViewModel: MapMemoryViewModel = mapMemoryViewModel ?: androidx.lifecycle.viewmodel.compose.viewModel(
        key = "map_memories_${trip.id}",
        factory = remember(trip.id) {
            val db = WanderlogDatabase.getDatabase(context)
            val repo = WanderlogRepositoryImpl(db.tripDao(), db.memoryDao(), db.albumPhotoDao())
            MapMemoryViewModelFactory(
                journeyId = trip.id,
                repository = MapMemoryRepositoryImpl(WonderlogMapMemoryDataSource(repo))
            )
        }
    )
    val mapMemoryState by actualMapMemoryViewModel.state.collectAsState()

    // Fit camera on initial data load
    LaunchedEffect(mapMemoryState.clusters) {
        if (!hasInitiallyFitted && mapMemoryState.clusters.isNotEmpty()) {
            hasInitiallyFitted = true
            cameraFitRequestKey++
        }
    }

    // Set the active journey ID
    LaunchedEffect(trip.id) {
        viewModel.setJourney(trip.id)
    }

    // Handle single-use Events
    LaunchedEffect(viewModel) {
        viewModel.event.collectLatest { event ->
            when (event) {
                is MapEvent.ShowMessage -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
                is MapEvent.ZoomTo -> {
                    // Handled internally by map view
                }
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Real OpenStreetMap View
        MemoryMapView(
            modifier = Modifier.fillMaxSize(),
            clusters = mapMemoryState.clusters,
            route = mapMemoryState.route,
            selectedClusterId = mapMemoryState.selectedClusterId,
            cameraFitRequestKey = cameraFitRequestKey,
            focusCoordinate = focusCoordinate,
            onClusterClick = { clusterId ->
                actualMapMemoryViewModel.selectCluster(clusterId)
            }
        )

        // 2. Journey Map Controls Top Overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Compact Map Toolbar
            JourneyMapToolbar(
                journeyTitle = trip.title.ifBlank { trip.destinationName },
                onSearch = {
                    showSearch = !showSearch
                },
                onFitJourney = {
                    cameraFitRequestKey++
                }
            )

            // Day Selector
            if (mapMemoryState.availableDays.isNotEmpty()) {
                MapMemoryDaySelector(
                    days = mapMemoryState.availableDays,
                    selectedDay = mapMemoryState.filter.selectedDayIndex,
                    onSelected = { dayIndex ->
                        actualMapMemoryViewModel.selectDay(dayIndex)
                        cameraFitRequestKey++
                    }
                )
            }

            Spacer(Modifier.height(2.dp))

            // Content Filter Row (All, Photos, Memories)
            MapMemoryContentFilterRow(
                selected = mapMemoryState.filter.contentFilter,
                onSelected = { filter ->
                    actualMapMemoryViewModel.setContentFilter(filter)
                }
            )
        }

        // 3. Search Overlay (Shown only when triggered)
        AnimatedVisibility(
            visible = showSearch,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 64.dp)
                .zIndex(10f),
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            JourneyMapSearchOverlay(
                searchQuery = uiState.searchQuery,
                searchResults = uiState.searchResults,
                onQueryChange = { viewModel.onAction(MapAction.UpdateSearchQuery(it)) },
                onSearchTriggered = { viewModel.onAction(MapAction.TriggerSearch) },
                onPlaceSelected = { place ->
                    viewModel.onAction(MapAction.SelectPlaceResult(place))
                    focusCoordinate = MapCoordinate(place.latitude, place.longitude)
                    showSearch = false
                },
                onClose = {
                    showSearch = false
                }
            )
        }

        // 4. Loading Overlay
        if (mapMemoryState.loading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = Color(0xFFE85D75))
            }
        }

        // 5. Empty State
        if (!mapMemoryState.loading && mapMemoryState.allItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = null,
                            tint = Color(0xFFE85D75),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = "No places yet",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Add a location to a Memory or import photos with location data to see this Journey on the map.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onAlbumClick,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Open Album")
                            }
                            Button(
                                onClick = onAddMemoryClick,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE85D75))
                            ) {
                                Text("Add Memory")
                            }
                        }
                    }
                }
            }
        }

        // 6. OpenStreetMap Attribution
        OpenStreetMapAttribution(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 10.dp, bottom = 10.dp)
        )

        // 7. Cluster Bottom Sheet
        mapMemoryState.selectedCluster?.let { cluster ->
            MapMemoryBottomSheet(
                cluster = cluster,
                onDismiss = {
                    actualMapMemoryViewModel.clearSelection()
                },
                onOpenMemory = onOpenMemory,
                onOpenPhoto = onOpenPhoto
            )
        }
    }
}
