package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.mapmemories.*

@Composable
fun MapMemoryDaySelector(
    days:
        List<JourneyDayOption>,

    selectedDay:
        Int?,

    onSelected:
        (Int?) -> Unit
) {

    LazyRow(
        contentPadding =
            PaddingValues(
                horizontal =
                    16.dp
            ),

        horizontalArrangement =
            Arrangement.spacedBy(
                8.dp
            )
    ) {

        item {

            FilterChip(
                selected =
                    selectedDay ==
                        null,

                onClick = {

                    onSelected(
                        null
                    )
                },

                label = {

                    Text(
                        "All"
                    )
                }
            )
        }

        items(
            items =
                days,

            key = {
                it.dayIndex
            }
        ) {
            day ->

            FilterChip(
                selected =
                    selectedDay ==
                        day.dayIndex,

                onClick = {

                    onSelected(
                        day.dayIndex
                    )
                },

                label = {

                    Text(
                        day.label
                    )
                }
            )
        }
    }
}

@Composable
fun MapMemoryContentFilterRow(
    selected:
        MapMemoryContentFilter,

    onSelected:
        (
            MapMemoryContentFilter
        ) -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal =
                        16.dp
                ),

        horizontalArrangement =
            Arrangement.spacedBy(
                8.dp
            )
    ) {

        MapFilterChip(
            label =
                "All",

            selected =
                selected ==
                    MapMemoryContentFilter.ALL,

            onClick = {

                onSelected(
                    MapMemoryContentFilter.ALL
                )
            }
        )

        MapFilterChip(
            label =
                "Photos",

            selected =
                selected ==
                    MapMemoryContentFilter.PHOTOS,

            onClick = {

                onSelected(
                    MapMemoryContentFilter.PHOTOS
                )
            }
        )

        MapFilterChip(
            label =
                "Memories",

            selected =
                selected ==
                    MapMemoryContentFilter.MEMORIES,

            onClick = {

                onSelected(
                    MapMemoryContentFilter.MEMORIES
                )
            }
        )
    }
}

@Composable
private fun RowScope.MapFilterChip(
    label:
        String,

    selected:
        Boolean,

    onClick:
        () -> Unit
) {

    FilterChip(
        selected =
            selected,

        onClick =
            onClick,

        label = {

            Text(
                label
            )
        },

        modifier =
            Modifier.weight(
                1f
            )
    )
}

@Composable
fun MapMemoryClusterBadge(
    cluster:
        MapMemoryCluster,

    onClick:
        () -> Unit
) {

    Surface(
        modifier =
            Modifier
                .clickable(
                    onClick =
                        onClick
                ),

        shape =
            RoundedCornerShape(
                18.dp
            ),

        color =
            Color.White,

        shadowElevation =
            6.dp
    ) {

        Row(
            modifier =
                Modifier.padding(
                    horizontal =
                        10.dp,
                    vertical =
                        7.dp
                ),

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Icon(
                imageVector =
                    Icons.Default
                        .Place,

                contentDescription =
                    null,

                tint =
                    Color(
                        0xFFE85D75
                    ),

                modifier =
                    Modifier.size(
                        18.dp
                    )
            )

            Spacer(
                Modifier.width(
                    4.dp
                )
            )

            Text(
                text =
                    cluster
                        .count
                        .toString(),

                fontWeight =
                    FontWeight.Bold
            )
        }
    }
}
