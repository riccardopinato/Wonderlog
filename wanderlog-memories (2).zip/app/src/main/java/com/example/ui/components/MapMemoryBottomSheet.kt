package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.mapmemories.*
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapMemoryBottomSheet(
    cluster:
        MapMemoryCluster,

    onDismiss:
        () -> Unit,

    onOpenMemory:
        (String) -> Unit,

    onOpenPhoto:
        (String) -> Unit
) {

    ModalBottomSheet(
        onDismissRequest =
            onDismiss
    ) {

        LazyColumn(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        bottom =
                            28.dp
                    )
        ) {

            item {

                Column(
                    modifier =
                        Modifier.padding(
                            horizontal =
                                20.dp
                        )
                ) {

                    Text(
                        text =
                            cluster
                                .dominantTitle
                                ?: "Journey stop",

                        style =
                            MaterialTheme
                                .typography
                                .headlineSmall,

                        fontWeight =
                            FontWeight.Black
                    )

                    Spacer(
                        Modifier.height(
                            4.dp
                        )
                    )

                    Text(
                        text =
                            "${cluster.photoCount} photos • ${cluster.memoryCount} Memories",

                        style =
                            MaterialTheme
                                .typography
                                .bodyMedium
                    )
                }

                Spacer(
                    Modifier.height(
                        16.dp
                    )
                )
            }

            val photos =
                cluster.items
                    .filter {
                        it.type ==
                            MapMemoryItemType.PHOTO
                    }

            if (
                photos.isNotEmpty()
            ) {

                item {

                    LazyRow(
                        contentPadding =
                            PaddingValues(
                                horizontal =
                                    20.dp
                            ),

                        horizontalArrangement =
                            Arrangement.spacedBy(
                                10.dp
                            )
                    ) {

                        items(
                            items =
                                photos,

                            key = {
                                it.id
                            }
                        ) {
                            photo ->

                            Surface(
                                modifier =
                                    Modifier
                                        .size(
                                            110.dp
                                        ),

                                shape =
                                    RoundedCornerShape(
                                        16.dp
                                    ),

                                onClick = {

                                    photo.photoId
                                        ?.let(
                                            onOpenPhoto
                                        )
                                }
                            ) {

                                AsyncImage(
                                    model =
                                        photo.localPhotoUri,

                                    contentDescription =
                                        null,

                                    contentScale =
                                        ContentScale.Crop,

                                    modifier =
                                        Modifier
                                            .fillMaxSize()
                                            .clip(
                                                RoundedCornerShape(
                                                    16.dp
                                                )
                                            )
                                )
                            }
                        }
                    }

                    Spacer(
                        Modifier.height(
                            18.dp
                        )
                    )
                }
            }

            val timeline =
                cluster.items
                    .sortedBy {
                        it.timestamp
                            ?: Long.MAX_VALUE
                    }

            items(
                items =
                    timeline,

                key = {
                    it.id
                }
            ) {
                item ->

                MapMemoryTimelineRow(
                    item =
                        item,

                    onOpenMemory =
                        onOpenMemory,

                    onOpenPhoto =
                        onOpenPhoto
                )
            }
        }
    }
}

@Composable
private fun MapMemoryTimelineRow(
    item:
        MapMemoryItem,

    onOpenMemory:
        (String) -> Unit,

    onOpenPhoto:
        (String) -> Unit
) {

    val click: () -> Unit = {
        when (item.type) {
            MapMemoryItemType.MEMORY ->
                item.memoryId?.let(onOpenMemory)
            MapMemoryItemType.PHOTO ->
                item.photoId?.let(onOpenPhoto)
        }
    }

    Surface(
        modifier =
            Modifier
                .fillMaxWidth(),

        onClick =
            click
    ) {

        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal =
                            20.dp,
                        vertical =
                            12.dp
                    ),

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Icon(
                imageVector =
                    when (
                        item.type
                    ) {

                        MapMemoryItemType.PHOTO ->
                            Icons.Default.Photo

                        MapMemoryItemType.MEMORY ->
                            Icons.Default.Place
                    },

                contentDescription =
                    null
            )

            Spacer(
                Modifier.width(
                    12.dp
                )
            )

            Column(
                modifier =
                    Modifier.weight(
                        1f
                    )
            ) {

                Text(
                    text =
                        item.title
                            ?: when (
                                item.type
                            ) {

                                MapMemoryItemType.PHOTO ->
                                    "Photo"

                                MapMemoryItemType.MEMORY ->
                                    "Memory"
                            },

                    fontWeight =
                        FontWeight.SemiBold
                )

                item.subtitle
                    ?.takeIf {
                        it.isNotBlank()
                    }
                    ?.let {

                        Text(
                            text =
                                it,

                            style =
                                MaterialTheme
                                    .typography
                                    .bodySmall
                        )
                    }
            }

            val formattedTime = if (item.type == MapMemoryItemType.PHOTO) {
                MapMemoryTimeFormatter.time(item.timestamp)
            } else {
                if (item.dateLabel?.contains(":") == true) {
                    MapMemoryTimeFormatter.time(item.timestamp)
                } else null
            }

            if (formattedTime != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = formattedTime,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
