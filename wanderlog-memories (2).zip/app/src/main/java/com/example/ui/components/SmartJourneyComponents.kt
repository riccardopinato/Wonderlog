package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.smartjourney.SmartJourneyCreationAllowance
import com.example.smartjourney.SmartJourneyPhoto
import com.example.smartjourney.SmartJourneyStopDraft

@Composable
fun SmartJourneyLimitBanner(
    allowance:
        SmartJourneyCreationAllowance,

    onUpgrade:
        () -> Unit
) {

    val background =
        when {

            allowance
                .journeyLimitReached ->
                Color(
                    0xFFFFE4E6
                )

            allowance
                .hasBlockedPhotos ->
                Color(
                    0xFFFFF4D6
                )

            else ->
                Color(
                    0xFFE7F8EE
                )
        }

    val accent =
        when {

            allowance
                .journeyLimitReached ->
                Color(
                    0xFFBE123C
                )

            allowance
                .hasBlockedPhotos ->
                Color(
                    0xFFB45309
                )

            else ->
                Color(
                    0xFF047857
                )
        }

    Surface(
        modifier =
            Modifier.fillMaxWidth(),

        shape =
            RoundedCornerShape(
                18.dp
            ),

        color =
            background
    ) {

        Row(
            modifier =
                Modifier.padding(
                    16.dp
                ),

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Icon(
                imageVector =
                    if (
                        allowance
                            .requiresUpgrade
                    ) {
                        Icons.Default.Lock
                    } else {
                        Icons.Default.PhotoLibrary
                    },

                contentDescription =
                    null,

                tint =
                    accent
            )

            Spacer(
                Modifier.width(
                    12.dp
                )
            )

            Column(
                modifier =
                    Modifier.weight(
                        1f
                    )
            ) {

                Text(
                    text =
                        when {

                            allowance
                                .journeyLimitReached ->

                                "Journey limit reached"

                            allowance
                                .hasBlockedPhotos &&
                                !allowance
                                    .isPremium ->

                                "${allowance.allowedPhotoCount} of ${allowance.selectedPhotoCount} photos will be imported on Free"

                            allowance
                                .hasBlockedPhotos ->

                                "${allowance.allowedPhotoCount} of ${allowance.selectedPhotoCount} photos can be imported in this Journey"

                            else ->

                                "${allowance.allowedPhotoCount} photos ready to import"
                        },

                    fontWeight =
                        FontWeight.Bold,

                    color =
                        accent
                )

                Spacer(
                    Modifier.height(
                        3.dp
                    )
                )

                Text(
                    text =
                        when {

                            allowance
                                .journeyLimitReached ->

                                "Upgrade Wonderlog Premium to create another Journey."

                            allowance
                                .hasBlockedPhotos &&
                                !allowance
                                    .isPremium ->

                                "Upgrade to Premium for up to 100 photos per Journey."

                            allowance
                                .hasBlockedPhotos ->

                                "The remaining photos will stay outside this Journey."

                            else ->

                                "Everything selected can be added."
                        },

                    style =
                        MaterialTheme
                            .typography
                            .bodySmall,

                    color =
                        accent.copy(
                            alpha =
                                0.76f
                        )
                )
            }

            if (
                allowance
                    .requiresUpgrade
            ) {

                TextButton(
                    onClick =
                        onUpgrade
                ) {

                    Text(
                        "Upgrade"
                    )
                }
            }
        }
    }
}

@Composable
fun SmartJourneyStopCard(
    stop:
        SmartJourneyStopDraft,

    photos:
        List<
            SmartJourneyPhoto
        >,

    onRename:
        () -> Unit,

    onToggleMemory:
        (Boolean) -> Unit,

    onTogglePhoto:
        (String) -> Unit,

    onMovePhotoPrevious:
        (String) -> Unit,

    onMovePhotoNext:
        (String) -> Unit,

    canMovePrevious:
        Boolean,

    canMoveNext:
        Boolean,

    onMergePrevious:
        (() -> Unit)? =
        null,

    onMergeNext:
        (() -> Unit)? =
        null
) {

    val includedPhotoCount =
        photos.count {
            it.included
        }

    Surface(
        modifier =
            Modifier.fillMaxWidth(),

        shape =
            RoundedCornerShape(
                22.dp
            ),

        color =
            Color.White.copy(
                alpha =
                    0.82f
            ),

        tonalElevation =
            1.dp
    ) {

        Column(
            modifier =
                Modifier.padding(
                    vertical =
                        18.dp
                )
        ) {

            Row(
                modifier =
                    Modifier.padding(
                        horizontal =
                            18.dp
                    ),

                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                Box(
                    modifier =
                        Modifier
                            .size(
                                40.dp
                            )
                            .background(
                                color =
                                    Color(
                                        0xFFFFE5E5
                                    ),

                                shape =
                                    RoundedCornerShape(
                                        12.dp
                                    )
                            ),

                    contentAlignment =
                        Alignment.Center
                ) {

                    Icon(
                        imageVector =
                            Icons.Default
                                .LocationOn,

                        contentDescription =
                            null,

                        tint =
                            Color(
                                0xFFE85D75
                            )
                    )
                }

                Spacer(
                    Modifier.width(
                        12.dp
                    )
                )

                Column(
                    modifier =
                        Modifier.weight(
                            1f
                        )
                ) {

                    Text(
                        text =
                            stop.title,

                        fontWeight =
                            FontWeight.Bold
                    )

                    Text(
                        text =
                            "$includedPhotoCount of ${photos.size} photos included",

                        style =
                            MaterialTheme
                                .typography
                                .bodySmall,

                        color =
                            Color.Gray
                    )
                }

                IconButton(
                    onClick =
                        onRename
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.Edit,

                        contentDescription =
                            "Rename stop"
                    )
                }
            }

            if (
                photos.isNotEmpty()
            ) {

                Spacer(
                    Modifier.height(
                        14.dp
                    )
                )

                LazyRow(
                    contentPadding =
                        PaddingValues(
                            horizontal =
                                18.dp
                        ),

                    horizontalArrangement =
                        Arrangement.spacedBy(
                            10.dp
                        )
                ) {

                    items(
                        items =
                            photos,

                        key = {
                            photo ->
                            photo.id
                        }
                    ) {
                        photo ->

                        SmartJourneyPhotoTile(
                            photo =
                                photo,

                            onToggle = {

                                onTogglePhoto(
                                    photo.id
                                )
                            },

                            onMovePrevious =
                                if (
                                    canMovePrevious
                                ) {

                                    {

                                        onMovePhotoPrevious(
                                            photo.id
                                        )
                                    }

                                } else {

                                    null
                                },

                            onMoveNext =
                                if (
                                    canMoveNext
                                ) {

                                    {

                                        onMovePhotoNext(
                                            photo.id
                                        )
                                    }

                                } else {

                                    null
                                }
                        )
                    }
                }
            }

            Spacer(
                Modifier.height(
                    16.dp
                )
            )

            HorizontalDivider(
                modifier =
                    Modifier.padding(
                        horizontal =
                            18.dp
                    ),

                color =
                    Color.Black.copy(
                        alpha =
                            0.06f
                    )
            )

            Spacer(
                Modifier.height(
                    10.dp
                )
            )

            Row(
                modifier =
                    Modifier.padding(
                        horizontal =
                            18.dp
                    ),

                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                Switch(
                    checked =
                        stop
                            .createMemory,

                    onCheckedChange =
                        onToggleMemory
                )

                Spacer(
                    Modifier.width(
                        10.dp
                    )
                )

                Column(
                    modifier =
                        Modifier.weight(
                            1f
                        )
                ) {

                    Text(
                        text =
                            "Create Memory draft",

                        style =
                            MaterialTheme
                                .typography
                                .bodyMedium,

                        fontWeight =
                            FontWeight.SemiBold
                    )

                    Text(
                        text =
                            "Journal text stays empty.",

                        style =
                            MaterialTheme
                                .typography
                                .bodySmall,

                        color =
                            Color.Gray
                    )
                }
            }

            if (
                onMergePrevious != null ||
                onMergeNext != null
            ) {

                Spacer(
                    Modifier.height(
                        8.dp
                    )
                )

                Row(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(
                                horizontal =
                                    12.dp
                            ),

                    horizontalArrangement =
                        Arrangement.End
                ) {

                    onMergePrevious
                        ?.let {
                            mergeAction ->

                            TextButton(
                                onClick =
                                    mergeAction
                            ) {

                                Icon(
                                    imageVector =
                                        Icons.Default
                                            .ArrowUpward,

                                    contentDescription =
                                        null,

                                    modifier =
                                        Modifier.size(
                                            16.dp
                                        )
                                )

                                Spacer(
                                    Modifier.width(
                                        4.dp
                                    )
                                )

                                Text(
                                    "Merge previous"
                                )
                            }
                        }

                    onMergeNext
                        ?.let {
                            mergeAction ->

                            TextButton(
                                onClick =
                                    mergeAction
                            ) {

                                Icon(
                                    imageVector =
                                        Icons.Default
                                            .ArrowDownward,

                                    contentDescription =
                                        null,

                                    modifier =
                                        Modifier.size(
                                            16.dp
                                        )
                                )

                                Spacer(
                                    Modifier.width(
                                        4.dp
                                    )
                                )

                                Text(
                                    "Merge next"
                                )
                            }
                        }
                }
            }
        }
    }
}

@Composable
private fun SmartJourneyPhotoTile(
    photo:
        SmartJourneyPhoto,

    onToggle:
        () -> Unit,

    onMovePrevious:
        (() -> Unit)?,

    onMoveNext:
        (() -> Unit)?
) {

    var menuExpanded by
        remember {
            mutableStateOf(
                false
            )
        }

    Box(
        modifier =
            Modifier
                .size(
                    112.dp
                )
                .clip(
                    RoundedCornerShape(
                        16.dp
                    )
                )
                .background(
                    Color(
                        0xFFE5E7EB
                    )
                )
    ) {

        AsyncImage(
            model =
                photo
                    .source
                    .sourceUri,

            contentDescription =
                null,

            contentScale =
                ContentScale.Crop,

            modifier =
                Modifier
                    .fillMaxSize()
                    .alpha(
                        if (
                            photo.included
                        ) {
                            1f
                        } else {
                            0.38f
                        }
                    )
        )

        Box(
            modifier =
                Modifier
                    .align(
                        Alignment.TopStart
                    )
                    .padding(
                        6.dp
                    )
                    .size(
                        30.dp
                    )
                    .background(
                        Color.Black.copy(
                            alpha =
                                0.44f
                        ),
                        CircleShape
                    )
                    .clickable(
                        onClick =
                            onToggle
                    ),

            contentAlignment =
                Alignment.Center
        ) {

            Icon(
                imageVector =
                    if (
                        photo.included
                    ) {

                        Icons.Default
                            .CheckCircle

                    } else {

                        Icons.Outlined
                            .Circle
                    },

                contentDescription =
                    if (
                        photo.included
                    ) {
                        "Exclude photo"
                    } else {
                        "Include photo"
                    },

                tint =
                    Color.White,

                modifier =
                    Modifier.size(
                        22.dp
                    )
            )
        }

        if (
            onMovePrevious != null ||
            onMoveNext != null
        ) {

            Box(
                modifier =
                    Modifier
                        .align(
                            Alignment.TopEnd
                        )
            ) {

                IconButton(
                    onClick = {

                        menuExpanded =
                            true
                    },

                    modifier =
                        Modifier
                            .padding(
                                3.dp
                            )
                            .size(
                                32.dp
                            )
                            .background(
                                Color.Black.copy(
                                    alpha =
                                        0.44f
                                ),
                                CircleShape
                            )
                ) {

                    Icon(
                        imageVector =
                            Icons.Default
                                .MoreVert,

                        contentDescription =
                            "Photo options",

                        tint =
                            Color.White,

                        modifier =
                            Modifier.size(
                                19.dp
                            )
                    )
                }

                DropdownMenu(
                    expanded =
                        menuExpanded,

                    onDismissRequest = {

                        menuExpanded =
                            false
                    }
                ) {

                    onMovePrevious
                        ?.let {
                            action ->

                            DropdownMenuItem(
                                text = {

                                    Text(
                                        "Move to previous stop"
                                    )
                                },

                                leadingIcon = {

                                    Icon(
                                        Icons.Default
                                            .ArrowUpward,

                                        contentDescription =
                                            null
                                    )
                                },

                                onClick = {

                                    menuExpanded =
                                        false

                                    action()
                                }
                            )
                        }

                    onMoveNext
                        ?.let {
                            action ->

                            DropdownMenuItem(
                                text = {

                                    Text(
                                        "Move to next stop"
                                    )
                                },

                                leadingIcon = {

                                    Icon(
                                        Icons.Default
                                            .ArrowDownward,

                                        contentDescription =
                                            null
                                    )
                                },

                                onClick = {

                                    menuExpanded =
                                        false

                                    action()
                                }
                            )
                        }
                }
            }
        }

        if (
            !photo.included
        ) {

            Surface(
                modifier =
                    Modifier
                        .align(
                            Alignment.BottomCenter
                        )
                        .padding(
                            6.dp
                        ),

                shape =
                    RoundedCornerShape(
                        20.dp
                    ),

                color =
                    Color.Black.copy(
                        alpha =
                            0.64f
                    )
            ) {

                Text(
                    text =
                        "Excluded",

                    modifier =
                        Modifier.padding(
                            horizontal =
                                8.dp,
                            vertical =
                                3.dp
                        ),

                    style =
                        MaterialTheme
                            .typography
                            .labelSmall,

                    color =
                        Color.White,

                    textAlign =
                        TextAlign.Center
                )
            }
        }
    }
}
