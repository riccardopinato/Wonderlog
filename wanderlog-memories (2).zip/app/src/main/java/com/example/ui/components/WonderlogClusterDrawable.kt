package com.example.ui.components

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable

fun createWonderlogClusterDrawable(
    context: Context,
    count: Int,
    selected: Boolean
): Drawable {
    val diameter = when {
        count >= 100 -> 96
        count >= 10 -> 84
        else -> 76
    }

    return object : Drawable() {

        private val backgroundPaint =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {

                color =
                    if (
                        selected
                    ) {
                        android.graphics.Color
                            .rgb(
                                219,
                                39,
                                119
                            )
                    } else {
                        android.graphics.Color
                            .WHITE
                    }

                style =
                    Paint.Style.FILL
            }

        private val borderPaint =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {

                color =
                    android.graphics.Color
                        .rgb(
                            232,
                            93,
                            117
                        )

                style =
                    Paint.Style.STROKE

                strokeWidth =
                    if (
                        selected
                    ) {
                        6f
                    } else {
                        4f
                    }
            }

        private val textPaint =
            Paint(
                Paint.ANTI_ALIAS_FLAG
            ).apply {

                color =
                    if (
                        selected
                    ) {
                        android.graphics.Color
                            .WHITE
                    } else {
                        android.graphics.Color
                            .rgb(
                                30,
                                41,
                                59
                            )
                    }

                textAlign =
                    Paint.Align.CENTER

                typeface =
                    Typeface.DEFAULT_BOLD

                textSize =
                    32f
            }

        override fun draw(
            canvas: Canvas
        ) {

            val cx =
                bounds.exactCenterX()

            val cy =
                bounds.exactCenterY()

            val radius =
                minOf(
                    bounds.width(),
                    bounds.height()
                ) /
                    2f -
                    4f

            canvas.drawCircle(
                cx,
                cy,
                radius,
                backgroundPaint
            )

            canvas.drawCircle(
                cx,
                cy,
                radius,
                borderPaint
            )

            val metrics =
                textPaint
                    .fontMetrics

            val baseline =
                cy -
                    (
                        metrics.ascent +
                            metrics.descent
                    ) /
                    2f

            canvas.drawText(
                count
                    .toString(),

                cx,
                baseline,
                textPaint
            )
        }

        override fun setAlpha(
            alpha: Int
        ) {

            backgroundPaint.alpha =
                alpha

            borderPaint.alpha =
                alpha

            textPaint.alpha =
                alpha
        }

        override fun setColorFilter(
            colorFilter:
                android.graphics.ColorFilter?
        ) {

            backgroundPaint
                .colorFilter =
                colorFilter

            borderPaint
                .colorFilter =
                colorFilter

            textPaint
                .colorFilter =
                colorFilter
        }

        @Deprecated(
            "Deprecated in Android"
        )
        override fun getOpacity():
            Int {

            return android.graphics
                .PixelFormat
                .TRANSLUCENT
        }

        override fun getIntrinsicWidth():
            Int =
            diameter

        override fun getIntrinsicHeight():
            Int =
            diameter
    }.apply {

        setBounds(
            0,
            0,
            diameter,
            diameter
        )
    }
}
