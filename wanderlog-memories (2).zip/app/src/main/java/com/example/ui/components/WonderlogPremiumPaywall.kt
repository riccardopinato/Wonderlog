package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.premium.PremiumPaywallContentFactory
import com.example.premium.PremiumPaywallReason

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WonderlogPremiumPaywall(
    reason: PremiumPaywallReason,
    onDismiss: () -> Unit,
    onUnlockPremium: () -> Unit,
    modifier: Modifier = Modifier
) {

    val content =
        PremiumPaywallContentFactory.create(
            reason
        )

    val sheetState =
        rememberModalBottomSheetState(
            skipPartiallyExpanded = true
        )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF111522),
        dragHandle = null,
        modifier = modifier
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(
                    horizontal = 24.dp
                )
                .padding(
                    top = 12.dp,
                    bottom = 28.dp
                )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                Row(
                    modifier = Modifier
                        .background(
                            brush =
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFFF6B6B),
                                        Color(0xFFFF4D9D),
                                        Color(0xFF8B5CF6)
                                    )
                                ),
                            shape =
                                RoundedCornerShape(
                                    50.dp
                                )
                        )
                        .padding(
                            horizontal = 11.dp,
                            vertical = 6.dp
                        ),
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.Star,
                        contentDescription =
                            null,
                        tint =
                            Color.White,
                        modifier =
                            Modifier.size(
                                13.dp
                            )
                    )

                    Spacer(
                        modifier =
                            Modifier.size(
                                5.dp
                            )
                    )

                    Text(
                        text =
                            content.eyebrow,
                        color =
                            Color.White,
                        fontSize =
                            9.sp,
                        fontWeight =
                            FontWeight.ExtraBold
                    )
                }

                Spacer(
                    modifier =
                        Modifier.weight(1f)
                )

                IconButton(
                    onClick =
                        onDismiss
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.Close,
                        contentDescription =
                            "Close",
                        tint =
                            Color.White.copy(
                                alpha = 0.7f
                            )
                    )
                }
            }

            Spacer(
                modifier =
                    Modifier.height(
                        22.dp
                    )
            )

            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(
                        brush =
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(
                                        0xFFFF6B6B
                                    ),
                                    Color(
                                        0xFFFF4D9D
                                    ),
                                    Color(
                                        0xFF8B5CF6
                                    )
                                )
                            ),
                        shape =
                            CircleShape
                    ),
                contentAlignment =
                    Alignment.Center
            ) {

                Icon(
                    imageVector =
                        Icons.Default.Star,
                    contentDescription =
                        null,
                    tint =
                        Color.White,
                    modifier =
                        Modifier.size(
                            31.dp
                        )
                )
            }

            Spacer(
                modifier =
                    Modifier.height(
                        18.dp
                    )
            )

            Text(
                text =
                    content.title,
                color =
                    Color.White,
                fontSize =
                    27.sp,
                lineHeight =
                    31.sp,
                fontWeight =
                    FontWeight.ExtraBold
            )

            Spacer(
                modifier =
                    Modifier.height(
                        10.dp
                    )
            )

            Text(
                text =
                    content.subtitle,
                color =
                    Color.White.copy(
                        alpha = 0.62f
                    ),
                fontSize =
                    13.sp,
                lineHeight =
                    19.sp
            )

            content.highlightedValue
                ?.let { value ->

                    Spacer(
                        modifier =
                            Modifier.height(
                                20.dp
                            )
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush =
                                    Brush.horizontalGradient(
                                        colors =
                                            listOf(
                                                Color(
                                                    0xFFFF4D9D
                                                ).copy(
                                                    alpha =
                                                        0.16f
                                                ),
                                                Color(
                                                    0xFF8B5CF6
                                                ).copy(
                                                    alpha =
                                                        0.16f
                                                )
                                            )
                                    ),
                                shape =
                                    RoundedCornerShape(
                                        20.dp
                                    )
                            )
                            .padding(
                                18.dp
                            ),
                        contentAlignment =
                            Alignment.Center
                    ) {

                        Text(
                            text = value,
                            color =
                                Color.White,
                            fontSize =
                                22.sp,
                            fontWeight =
                                FontWeight.ExtraBold,
                            textAlign =
                                TextAlign.Center
                        )
                    }
                }

            Spacer(
                modifier =
                    Modifier.height(
                        22.dp
                    )
            )

            Column(
                verticalArrangement =
                    Arrangement.spacedBy(
                        12.dp
                    )
            ) {

                content.benefits
                    .forEach { benefit ->

                        Row(
                            verticalAlignment =
                                Alignment.CenterVertically
                        ) {

                            Box(
                                modifier =
                                    Modifier
                                        .size(
                                            26.dp
                                        )
                                        .background(
                                            color =
                                                Color(
                                                    0xFF45D69A
                                                ).copy(
                                                    alpha =
                                                        0.16f
                                                ),
                                            shape =
                                                CircleShape
                                        ),
                                contentAlignment =
                                    Alignment.Center
                            ) {

                                Icon(
                                    imageVector =
                                        Icons.Default.Check,
                                    contentDescription =
                                        null,
                                    tint =
                                        Color(
                                            0xFF64E5AE
                                        ),
                                    modifier =
                                        Modifier.size(
                                            15.dp
                                        )
                                )
                            }

                            Spacer(
                                modifier =
                                    Modifier.size(
                                        11.dp
                                    )
                            )

                            Text(
                                text =
                                    benefit,
                                color =
                                    Color.White.copy(
                                        alpha =
                                            0.88f
                                    ),
                                fontSize =
                                    13.sp,
                                fontWeight =
                                    FontWeight.SemiBold
                            )
                        }
                    }
            }

            Spacer(
                modifier =
                    Modifier.height(
                        28.dp
                    )
            )

            Button(
                onClick =
                    onUnlockPremium,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(
                            54.dp
                        ),
                shape =
                    RoundedCornerShape(
                        20.dp
                    ),
                colors =
                    ButtonDefaults.buttonColors(
                        containerColor =
                            Color.Transparent
                    ),
                contentPadding =
                    androidx.compose.foundation.layout.PaddingValues(
                        0.dp
                    )
            ) {

                Box(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(
                                54.dp
                            )
                            .background(
                                brush =
                                    Brush.horizontalGradient(
                                        colors =
                                            listOf(
                                                Color(
                                                    0xFFFF6B6B
                                                ),
                                                Color(
                                                    0xFFFF4D9D
                                                ),
                                                Color(
                                                    0xFF8B5CF6
                                                )
                                            )
                                    ),
                                shape =
                                    RoundedCornerShape(
                                        20.dp
                                    )
                            ),
                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        text =
                            content.primaryAction,
                        color =
                            Color.White,
                        fontSize =
                            14.sp,
                        fontWeight =
                            FontWeight.ExtraBold
                    )
                }
            }

            Spacer(
                modifier =
                    Modifier.height(
                        7.dp
                    )
            )

            Button(
                onClick =
                    onDismiss,
                modifier =
                    Modifier.fillMaxWidth(),
                colors =
                    ButtonDefaults.buttonColors(
                        containerColor =
                            Color.Transparent
                    )
            ) {

                Text(
                    text =
                        content.secondaryAction,
                    color =
                        Color.White.copy(
                            alpha = 0.48f
                        ),
                    fontSize =
                        12.sp
                )
            }
        }
    }
}
