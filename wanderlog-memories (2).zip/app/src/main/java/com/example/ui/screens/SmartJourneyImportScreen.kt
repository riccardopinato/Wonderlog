package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.smartjourney.SmartJourneyAnalysisPhase
import com.example.smartjourney.SmartJourneyUiState
import com.example.smartjourney.SmartJourneyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartJourneyImportScreen(
    viewModel: SmartJourneyViewModel,
    onBackClick: () -> Unit,
    onDraftReady: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.state.collectAsState()

    val picker =
        rememberLauncherForActivityResult(
            contract =
                ActivityResultContracts
                    .PickMultipleVisualMedia()
        ) { uris ->
            val selected =
                uris
                    .distinct()
                    .take(300)

            if (selected.isNotEmpty()) {
                viewModel.analyse(
                    selected.map { it.toString() }
                )
            }
        }

    LaunchedEffect(uiState) {
        if (uiState is SmartJourneyUiState.DraftReady) {
            onDraftReady()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Smart Journey") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            when (val state = uiState) {
                is SmartJourneyUiState.Idle,
                is SmartJourneyUiState.Selecting -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            Color(0xFFFF5E62),
                                            Color(0xFFFF4A5A)
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(48.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(28.dp))

                        Text(
                            text = "Build a Journey from your photos",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Choose your travel photos. Wonderlog will automatically cluster them by day and location to draft your Journey.",
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(36.dp))

                        Button(
                            onClick = {
                                picker.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            },
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Choose photos",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }

                is SmartJourneyUiState.Analysing -> {
                    val progress = state.progress
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(
                            progress = { progress.fraction },
                            modifier = Modifier.size(64.dp),
                            strokeWidth = 6.dp
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        val phaseText = when (progress.phase) {
                            SmartJourneyAnalysisPhase.READING_METADATA ->
                                "Reading photo metadata (${progress.processed}/${progress.total})..."
                            SmartJourneyAnalysisPhase.GROUPING_DAYS ->
                                "Grouping photos by day..."
                            SmartJourneyAnalysisPhase.CLUSTERING_LOCATIONS ->
                                "Detecting places and stops..."
                            SmartJourneyAnalysisPhase.RESOLVING_PLACES ->
                                "Naming locations..."
                            SmartJourneyAnalysisPhase.BUILDING_DRAFT ->
                                "Assembling Journey draft..."
                            SmartJourneyAnalysisPhase.COMPLETE ->
                                "Almost ready..."
                        }

                        Text(
                            text = phaseText,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "${(progress.fraction * 100).toInt()}% complete",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                is SmartJourneyUiState.Error -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Something went wrong",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = state.message,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { viewModel.reset() },
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Try again")
                        }
                    }
                }

                else -> Unit
            }
        }
    }
}
