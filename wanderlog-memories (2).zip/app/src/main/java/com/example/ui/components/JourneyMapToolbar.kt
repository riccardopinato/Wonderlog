package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun JourneyMapToolbar(
    journeyTitle:
        String,

    onSearch:
        () -> Unit,

    onFitJourney:
        () -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal =
                        14.dp,
                    vertical =
                        8.dp
                )
                .background(
                    color =
                        Color.White.copy(
                            alpha =
                                0.92f
                        ),

                    shape =
                        RoundedCornerShape(
                            18.dp
                        )
                )
                .padding(
                    horizontal =
                        14.dp,
                    vertical =
                        6.dp
                ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        Text(
            text =
                journeyTitle,

            modifier =
                Modifier.weight(
                    1f
                ),

            style =
                MaterialTheme
                    .typography
                    .titleMedium,

            fontWeight =
                FontWeight.Bold,

            maxLines =
                1
        )

        IconButton(
            onClick =
                onSearch
        ) {

            Icon(
                imageVector =
                    Icons.Default
                        .Search,

                contentDescription =
                    "Search places"
            )
        }

        IconButton(
            onClick =
                onFitJourney
        ) {

            Icon(
                imageVector =
                    Icons.Default
                        .MyLocation,

                contentDescription =
                    "Fit Journey"
            )
        }
    }
}
