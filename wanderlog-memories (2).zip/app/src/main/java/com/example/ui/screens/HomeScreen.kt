package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.LocalPostOffice
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.domain.model.Trip
import com.example.domain.model.Memory
import com.example.ui.components.DestinationCard
import com.example.ui.components.EmptyState
import com.example.premium.PremiumManager
import com.example.storage.PhotoStorageManager
import kotlinx.coroutines.launch

enum class FilterType {
    ACTIVE, FAVORITES, ARCHIVED, ALL
}

enum class SortType {
    NEWEST, OLDEST, ALPHABETICAL, RECENTLY_UPDATED, TRAVEL_DATE
}

@Composable
fun HomeScreen(
    trips: List<Trip>,
    allMemories: List<Memory> = emptyList(),
    onTripClick: (String) -> Unit,
    onCreateTripClick: () -> Unit,
    onPremiumClick: () -> Unit,
    onFavoriteToggle: (Trip) -> Unit = {},
    onArchiveToggle: (Trip) -> Unit = {},
    onDuplicate: (Trip) -> Unit = {},
    onRename: (Trip, String) -> Unit = { _, _ -> },
    onThemeChange: (Trip, Int) -> Unit = { _, _ -> },
    onCoverChange: (Trip, String) -> Unit = { _, _ -> },
    onDeleteTrip: (Trip) -> Unit = {},
    onBuildFromPhotosClick: () -> Unit = {},
    rediscoverCards: List<com.example.rediscover.RediscoverCard> = emptyList(),
    onRediscoverJourneyClick: (String) -> Unit = {},
    onRediscoverMemoryClick: (String) -> Unit = {},
    onRediscoverPhotoClick: (String) -> Unit = {},
    onRediscoverSeeAllClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(FilterType.ACTIVE) }
    var selectedSort by remember { mutableStateOf(SortType.NEWEST) }
    var showPostcardDialog by remember { mutableStateOf(false) }

    // Dialog state controllers
    var showRenameDialogForTrip by remember { mutableStateOf<Trip?>(null) }
    var renameInput by remember { mutableStateOf("") }
    var showThemeDialogForTrip by remember { mutableStateOf<Trip?>(null) }
    var selectedTripForCoverChange by remember { mutableStateOf<Trip?>(null) }

    // Image Picker for Cover Photo Update
    val homePhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val trip = selectedTripForCoverChange
        if (uri != null && trip != null) {
            coroutineScope.launch {
                val savedPath = PhotoStorageManager.saveUriToPrivateStorage(context, uri)
                if (savedPath != null) {
                    onCoverChange(trip, savedPath)
                }
            }
        }
    }

    // Advanced search, sorting and filtering
    val filteredTrips = remember(trips, searchQuery, selectedFilter, selectedSort, allMemories) {
        var list = trips

        // Search: Title, Country, Destination, Description, and Memory tags
        if (searchQuery.isNotBlank()) {
            list = list.filter { trip ->
                val matchesTrip = trip.destinationName.contains(searchQuery, ignoreCase = true) ||
                        trip.country.contains(searchQuery, ignoreCase = true) ||
                        trip.description.contains(searchQuery, ignoreCase = true) ||
                        trip.title.contains(searchQuery, ignoreCase = true)

                val tripMemories = allMemories.filter { it.tripId == trip.id }
                val matchesTags = tripMemories.any { memory ->
                    memory.tags.any { tag -> tag.contains(searchQuery, ignoreCase = true) }
                }

                matchesTrip || matchesTags
            }
        }

        // Filtering
        list = when (selectedFilter) {
            FilterType.ACTIVE -> list.filter { !it.archived }
            FilterType.FAVORITES -> list.filter { it.favorite && !it.archived }
            FilterType.ARCHIVED -> list.filter { it.archived }
            FilterType.ALL -> list
        }

        // Sorting
        list = when (selectedSort) {
            SortType.NEWEST -> list.sortedByDescending { it.createdAt }
            SortType.OLDEST -> list.sortedBy { it.createdAt }
            SortType.ALPHABETICAL -> list.sortedBy { it.destinationName.lowercase() }
            SortType.RECENTLY_UPDATED -> list.sortedByDescending { it.updatedAt }
            SortType.TRAVEL_DATE -> list.sortedByDescending { it.startDate }
        }

        list
    }

    val tripsCount = trips.size
    val memoriesCount = allMemories.size
    val countriesCount = remember(trips) {
        trips.map { it.country }.distinct().filter { it.isNotBlank() }.size
    }
    val citiesCount = remember(trips, allMemories) {
        (trips.map { it.destinationName } + allMemories.map { it.locationName })
            .filter { it.isNotBlank() }.distinct().size
    }

    val greeting = remember {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        when (hour) {
            in 5..11 -> "Good Morning"
            in 12..17 -> "Good Afternoon"
            else -> "Good Evening"
        }
    }

    // Vintage Postcard Dialog Popup
    if (showPostcardDialog) {
        Dialog(onDismissRequest = { showPostcardDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .shadow(24.dp, RoundedCornerShape(20.dp))
                    .background(Color(0xFFFAF6EE), RoundedCornerShape(20.dp)) // Aged postcard paper tone
                    .border(androidx.compose.foundation.BorderStroke(3.dp, Color(0xFFE2D6C5)), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                // Postcard back central divider line
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                        .background(Color(0xFFE2D6C5).copy(alpha = 0.8f))
                        .align(Alignment.Center)
                )

                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Side: Personal handwritten travel note
                    Column(
                        modifier = Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                            .padding(end = 6.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Dear Riccardo,",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                color = Color(0xFF334155)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Every scenic route you take and every photo you snap creates a permanent landmark in the map of your life. Keep writing your travel story!",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                color = Color(0xFF475569),
                                lineHeight = 14.sp
                            )
                        }
                        Text(
                            text = "With ❤️, Wanderlog",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontStyle = FontStyle.Italic,
                            color = Color(0xFFDD2476)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Right Side: Vintage Postcard Stamp & Address stats
                    Column(
                        modifier = Modifier
                            .weight(0.9f)
                            .fillMaxHeight()
                            .padding(start = 6.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Stamp layout on top-right
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .border(
                                        androidx.compose.foundation.BorderStroke(
                                            1.5.dp,
                                            Color(0xFFDD2476).copy(alpha = 0.4f)
                                        ),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .background(Color.White)
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("✈️", fontSize = 12.sp)
                                    Text("ITALIA", fontSize = 7.sp, fontWeight = FontWeight.Black, color = Color(0xFFDD2476))
                                }
                            }
                        }

                        // Address lines mimicking destination stamp
                        Column(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "To: Riccardo the Explorer",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(Color(0xFFE2D6C5))
                            )
                            Text(
                                text = "📖 $memoriesCount memories",
                                fontSize = 10.sp,
                                color = Color(0xFF475569),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "🌍 $countriesCount countries",
                                fontSize = 10.sp,
                                color = Color(0xFF475569),
                                fontWeight = FontWeight.SemiBold
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(Color(0xFFE2D6C5))
                            )
                        }
                    }
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFFF9A9E), // Soft red/pink
                        Color(0xFFFAD0C4), // Peach/rose
                        Color(0xFFA18CD1)  // Soft purple/lavender
                    )
                )
            )
            .testTag("home_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 70.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Title Header, Greetings & Personalized Metrics
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Wanderlog",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "YOUR JOURNEYS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A).copy(alpha = 0.6f),
                                letterSpacing = 2.sp
                            )
                        }

                        // Premium status badge click
                        IconButton(
                            onClick = onPremiumClick,
                            modifier = Modifier
                                .shadow(6.dp, CircleShape)
                                .background(Color.White.copy(alpha = 0.4f), CircleShape)
                                .border(androidx.compose.foundation.BorderStroke(2.dp, Color.White.copy(alpha = 0.5f)), CircleShape)
                                .size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = "Premium Paywall",
                                tint = Color(0xFFFFD066)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic personalized greetings
                    Text(
                        text = "$greeting, Riccardo 👋",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF0F172A).copy(alpha = 0.7f),
                        letterSpacing = 0.3.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "✈️ Live Your Story",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F172A),
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "Let every road trip and flight fuel your personal scrapbooks.",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF0F172A).copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Redesigned Stats Pill widgets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatBadge(
                            value = "$tripsCount",
                            label = "Journeys",
                            icon = Icons.Default.Place,
                            modifier = Modifier.weight(1.1f)
                        )
                        StatBadge(
                            value = "$memoriesCount",
                            label = "Memories",
                            icon = Icons.Default.PhotoLibrary,
                            modifier = Modifier.weight(1.1f)
                        )
                        StatBadge(
                            value = "$citiesCount",
                            label = "Cities",
                            icon = Icons.Default.LocationCity,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Postcard dialog trigger row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPostcardDialog = true }
                            .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .border(androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalPostOffice,
                            contentDescription = null,
                            tint = Color(0xFFDD2476),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "View Travel Postcard Stats 📬",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A).copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // REDISCOVER SECTION (Daily Highlights & Anniversaries)
            if (rediscoverCards.isNotEmpty()) {
                item {
                    com.example.ui.components.RediscoverHomeSection(
                        cards = rediscoverCards,
                        onOpenJourney = onRediscoverJourneyClick,
                        onOpenMemory = onRediscoverMemoryClick,
                        onOpenPhoto = onRediscoverPhotoClick,
                        onSeeAll = onRediscoverSeeAllClick,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
            }

            // Search Bar (Translucent Apple design!)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                        .border(
                            androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_search_bar"),
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "🔍 Search name, country, description, tags...",
                                    color = Color(0xFF0F172A).copy(alpha = 0.5f),
                                    fontSize = 13.sp
                                )
                            }
                            innerTextField()
                        }
                    )
                }
            }

            // FILTER TABS SELECTOR (Active, Favorites, Archived, All)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .border(androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)), RoundedCornerShape(16.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterType.values().forEach { filter ->
                        val isSelected = selectedFilter == filter
                        val label = when (filter) {
                            FilterType.ACTIVE -> "🧭 Active"
                            FilterType.FAVORITES -> "⭐ Favs"
                            FilterType.ARCHIVED -> "📦 Archive"
                            FilterType.ALL -> "🌍 All"
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color.White.copy(alpha = 0.9f) else Color.Transparent)
                                .clickable { selectedFilter = filter }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }

            // SORTING SELECTION (Scrollable Chips)
            item {
                Column {
                    Text(
                        text = "SORT BY",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A).copy(alpha = 0.5f),
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SortType.values().forEach { sort ->
                            val isSelected = selectedSort == sort
                            val label = when (sort) {
                                SortType.NEWEST -> "📅 Newest Created"
                                SortType.OLDEST -> "⏳ Oldest Created"
                                SortType.ALPHABETICAL -> "🔤 Alphabetical"
                                SortType.RECENTLY_UPDATED -> "⏱️ Recently Updated"
                                SortType.TRAVEL_DATE -> "✈️ Travel Date"
                            }
                            AssistChip(
                                onClick = { selectedSort = sort },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = if (isSelected) Color.White else Color.White.copy(alpha = 0.3f),
                                    labelColor = if (isSelected) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.7f)
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = 1.dp,
                                    color = if (isSelected) Color(0xFFDD2476).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.4f)
                                )
                            )
                        }
                    }
                }
            }

            // Empty State transition
            if (trips.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 36.dp)
                            .testTag("premium_empty_state"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("✨🗺️✨", fontSize = 72.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Your next adventure starts here.",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Create a scrapbook to log your travel routes, memorable moments, and personal notes. Every adventure belongs here.",
                            fontSize = 14.sp,
                            color = Color(0xFF0F172A).copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = onCreateTripClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDD2476)),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.height(50.dp)
                            ) {
                                Text("Create Journey", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                            OutlinedButton(
                                onClick = onBuildFromPhotosClick,
                                shape = RoundedCornerShape(20.dp),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFDD2476)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDD2476)),
                                modifier = Modifier.height(50.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = Color(0xFFDD2476),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Build from photos", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            } else if (filteredTrips.isEmpty()) {
                item {
                    EmptyState(
                        message = "No journeys found",
                        tip = "Try searching for another destination, tag, or adjust your active filters."
                    )
                }
            } else {
                items(filteredTrips, key = { it.id }) { trip ->
                    var isVisible by remember { mutableStateOf(false) }
                    LaunchedEffect(Unit) { isVisible = true }

                    AnimatedVisibility(
                        visible = isVisible,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        val tripMemories = remember(allMemories) { allMemories.filter { it.tripId == trip.id } }
                        val tripPhotosCount = remember(tripMemories) { tripMemories.filter { it.image.isNotBlank() }.size }

                        DestinationCard(
                            trip = trip,
                            memoriesCount = tripMemories.size,
                            albumPhotosCount = tripPhotosCount,
                            onClick = { onTripClick(trip.id) },
                            onFavoriteToggle = { onFavoriteToggle(trip) },
                            onArchiveToggle = { onArchiveToggle(trip) },
                            onDuplicate = { onDuplicate(trip) },
                            onRename = { showRenameDialogForTrip = trip; renameInput = trip.destinationName },
                            onChangeTheme = { showThemeDialogForTrip = trip },
                            onChangeCover = {
                                selectedTripForCoverChange = trip
                                homePhotoPickerLauncher.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            },
                            onDelete = { onDeleteTrip(trip) }
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }

        // Floating Enormous Coral-Red Floating FAB (Sleek Apple style, sits higher and separated)
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 110.dp, end = 24.dp)
                .shadow(
                    elevation = 18.dp,
                    shape = CircleShape,
                    ambientColor = Color(0xFFFF4A5A).copy(alpha = 0.5f),
                    spotColor = Color(0xFFFF4A5A).copy(alpha = 0.6f)
                )
                .background(
                    brush = Brush.linearGradient(listOf(Color(0xFFFF5E62), Color(0xFFFF4A5A))),
                    shape = CircleShape
                )
                .border(androidx.compose.foundation.BorderStroke(3.dp, Color.White), CircleShape)
                .clickable(onClick = onCreateTripClick)
                .size(68.dp)
                .testTag("create_trip_fab"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Create Trip",
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )
        }
    }

    // ✏️ Rename Journey Dialog
    if (showRenameDialogForTrip != null) {
        Dialog(onDismissRequest = { showRenameDialogForTrip = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Rename Journey",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = renameInput,
                        onValueChange = { renameInput = it },
                        placeholder = { Text("Enter new journey name...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showRenameDialogForTrip = null },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel", color = Color.Gray)
                        }

                        Button(
                            onClick = {
                                val trip = showRenameDialogForTrip
                                if (renameInput.isNotBlank() && trip != null) {
                                    onRename(trip, renameInput)
                                    showRenameDialogForTrip = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDD2476)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Rename", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // 🎨 Theme Preset Selection Dialog
    if (showThemeDialogForTrip != null) {
        val presetThemes = listOf(
            Triple("Sunset", Color(0xFFFF5E62), Color(0xFFFF9966)),
            Triple("Ocean", Color(0xFF2193b0), Color(0xFF6dd5ed)),
            Triple("Lavender", Color(0xFF8E2DE2), Color(0xFF4A00E0)),
            Triple("Forest", Color(0xFF11998e), Color(0xFF38ef7d)),
            Triple("Cherry Blossom", Color(0xFFff758c), Color(0xFFff7eb3)),
            Triple("Golden Hour", Color(0xFFf12711), Color(0xFFf5af19))
        )

        Dialog(onDismissRequest = { showThemeDialogForTrip = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Select Accent Theme",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        presetThemes.chunked(2).forEach { rowThemes ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                rowThemes.forEach { themeTriple ->
                                    val index = presetThemes.indexOf(themeTriple)
                                    val isPremiumUser by PremiumManager.isPremium.collectAsState()
                                    val isLocked = index >= 2 && !isPremiumUser

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(50.dp)
                                            .shadow(4.dp, RoundedCornerShape(12.dp))
                                            .background(
                                                Brush.linearGradient(listOf(themeTriple.second, themeTriple.third)),
                                                RoundedCornerShape(12.dp)
                                            )
                                            .clickable {
                                                if (isLocked) {
                                                    PremiumManager.showUpgrade()
                                                } else {
                                                    showThemeDialogForTrip?.let { trip ->
                                                        onThemeChange(trip, index)
                                                    }
                                                    showThemeDialogForTrip = null
                                                }
                                            }
                                            .padding(8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            if (isLocked) {
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = "Locked",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                            }
                                            Text(
                                                text = themeTriple.first,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    TextButton(
                        onClick = { showThemeDialogForTrip = null },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Close", color = Color.Gray)
                    }
                }
            }
        }
    }
}

// Custom Stat badge widget for the travelers panel
@Composable
fun StatBadge(
    value: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .background(Color.White.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .border(androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(Color.White.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFFDD2476),
                modifier = Modifier.size(14.dp)
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = label.uppercase(),
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A).copy(alpha = 0.6f),
                letterSpacing = 0.5.sp
            )
        }
    }
}

// Minimal placeholder so basic text field is usable
@Composable
fun BasicTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    decorationBox: @Composable (@Composable () -> Unit) -> Unit
) {
    androidx.compose.foundation.text.BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        textStyle = LocalTextStyle.current.copy(color = Color.DarkGray, fontSize = 14.sp),
        decorationBox = decorationBox
    )
}
