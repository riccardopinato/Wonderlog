package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.model.AlbumPhoto
import com.example.domain.model.LocationCoordinate
import com.example.domain.model.MapMarker
import com.example.domain.model.Memory
import com.example.domain.model.MemoryWithPhotos
import com.example.domain.model.Mood
import com.example.domain.model.Trip
import com.example.map.MemoryMapView
import com.example.location.LocationSearchResult
import com.example.location.LocationSearchService
import com.example.premium.PremiumManager
import com.example.premium.SubscriptionConfig
import com.example.presentation.WanderlogViewModel
import com.example.storage.PhotoStorageManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditMemoryScreen(
    trip: Trip,
    memoryWithPhotos: MemoryWithPhotos,
    viewModel: WanderlogViewModel,
    onSaveMemory: (Memory, List<AlbumPhoto>) -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by PremiumManager.isPremium.collectAsState()

    // Collect album photos from ViewModel
    val albumPhotos by viewModel.selectedTripPhotos.collectAsState()

    // Form fields prefilled with existing memory data
    var title by remember { mutableStateOf(memoryWithPhotos.memory.title) }
    var locationName by remember { mutableStateOf(memoryWithPhotos.memory.locationName) }
    var date by remember { mutableStateOf(memoryWithPhotos.memory.date) }
    var journalText by remember { mutableStateOf(memoryWithPhotos.memory.journalText) }
    var selectedMood by remember { mutableStateOf(memoryWithPhotos.memory.mood) }

    // Selected photos prefilled with cross-referenced photos
    var selectedAlbumPhotos by remember { mutableStateOf<List<AlbumPhoto>>(memoryWithPhotos.photos) }

    // Coordinates (kept internal, never displayed)
    var latitude by remember { mutableStateOf<Double?>(memoryWithPhotos.memory.latitude) }
    var longitude by remember { mutableStateOf<Double?>(memoryWithPhotos.memory.longitude) }

    // Location search UI state
    var searchQuery by remember { mutableStateOf(memoryWithPhotos.memory.locationName) }
    var suggestions by remember { mutableStateOf<List<LocationSearchResult>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }
    var showSuggestions by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var isLocatingCurrent by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                Toast.makeText(context, "Adding to Journey Album...", Toast.LENGTH_SHORT).show()
                val limits = SubscriptionConfig.getLimits(isPremium)
                val currentCount = albumPhotos.size
                val allowedToImportCount = if (isPremium) uris.size else (limits.albumPhotosLimit - currentCount).coerceAtLeast(0)

                if (allowedToImportCount == 0 && !isPremium) {
                    PremiumManager.showUpgrade(
                        title = "Journey Album limit reached.",
                        subtitle = "Upgrade to Premium to import up to 100 photos, customize cover arts, and write unlimited memories."
                    )
                    return@launch
                }

                val targetUris = uris.take(allowedToImportCount)
                val newPhotos = mutableListOf<AlbumPhoto>()
                for ((idx, uri) in targetUris.withIndex()) {
                    try {
                        val photo = com.example.storage.AlbumPhotoManager.importPhoto(
                            context = context,
                            journeyId = trip.id,
                            uri = uri,
                            displayOrder = currentCount + idx,
                            existingPhotos = albumPhotos
                        )
                        if (photo != null) {
                            newPhotos.add(photo)
                        }
                    } catch (pie: com.example.storage.PhotoImportException) {
                        val msg = when (pie.reason) {
                            com.example.storage.PhotoImportException.ImportReason.DUPLICATE -> "Skipped duplicate photo."
                            com.example.storage.PhotoImportException.ImportReason.UNSUPPORTED_FORMAT -> "Unsupported image format."
                            com.example.storage.PhotoImportException.ImportReason.STORAGE_FULL -> "Cannot import: Storage is full."
                            com.example.storage.PhotoImportException.ImportReason.FILE_COPY_FAILED -> "Failed to copy photo to private storage."
                            com.example.storage.PhotoImportException.ImportReason.CORRUPTED -> "Skipped corrupted photo."
                            com.example.storage.PhotoImportException.ImportReason.UNKNOWN -> "Failed to import photo."
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                
                if (newPhotos.isNotEmpty()) {
                    viewModel.insertPhotos(newPhotos)
                    Toast.makeText(context, "Saved ${newPhotos.size} photo(s) to Album!", Toast.LENGTH_SHORT).show()
                    // Auto-select newly added photos
                    selectedAlbumPhotos = selectedAlbumPhotos + newPhotos
                }

                if (uris.size > allowedToImportCount) {
                    PremiumManager.showUpgrade(
                        title = "Journey Album limit reached.",
                        subtitle = "Upgrade to Premium to import up to 100 photos, customize cover arts, and write unlimited memories."
                    )
                }
            }
        }
    }

    // Validation
    val isFormValid = title.isNotBlank() && 
            locationName.isNotBlank() && 
            (journalText.isNotBlank() || selectedAlbumPhotos.isNotEmpty())

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A), // Slate 900
                        Color(0xFF1E293B)  // Slate 800
                    )
                )
            )
            .testTag("edit_memory_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .statusBarsPadding()
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.12f), CircleShape)
                        .testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Text(
                    text = "Edit Scrapbook Memory",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                // Silent spacer to balance layout
                Spacer(modifier = Modifier.width(48.dp))
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // 1. Photo Selection Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "1. Scrapbook Photos",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8)
                    )

                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDD2476),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("import_new_photos_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Import New", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Journey Album Carousel selection
                if (albumPhotos.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(20.dp))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)), RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Your Journey Album is empty. Tap to import photos.",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                        }
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(albumPhotos) { photo ->
                            val isSelected = selectedAlbumPhotos.any { it.id == photo.id }
                            val selectionIndex = selectedAlbumPhotos.indexOfFirst { it.id == photo.id }

                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.White.copy(alpha = 0.05f))
                                    .border(
                                        BorderStroke(
                                            width = if (isSelected) 3.dp else 1.dp,
                                            color = if (isSelected) Color(0xFFFF512F) else Color.White.copy(alpha = 0.15f)
                                        ),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .clickable {
                                        selectedAlbumPhotos = if (isSelected) {
                                            selectedAlbumPhotos.filter { it.id != photo.id }
                                        } else {
                                            selectedAlbumPhotos + photo
                                        }
                                    }
                            ) {
                                AsyncImage(
                                    model = photo.localUri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .size(20.dp)
                                            .background(Color(0xFFFF512F), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (selectionIndex + 1).toString(),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 2. Details
                Text(
                    text = "2. Scrapbook Details",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title of Memory", color = Color.White.copy(alpha = 0.6f)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFDD2476),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("memory_title_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Location search
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = locationName,
                        onValueChange = { query ->
                            locationName = query
                            searchQuery = query
                            showSuggestions = true
                            searchJob?.cancel()
                            searchJob = coroutineScope.launch {
                                delay(400)
                                isSearching = true
                                suggestions = LocationSearchService.searchLocation(query)
                                isSearching = false
                            }
                        },
                        label = { Text("Spot / Location", color = Color.White.copy(alpha = 0.6f)) },
                        trailingIcon = {
                            if (isLocatingCurrent) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                            } else {
                                IconButton(onClick = {
                                    isLocatingCurrent = true
                                    coroutineScope.launch {
                                        delay(1000)
                                        val locs = listOf(
                                            Triple("Panoramic Viewpoint", 40.7128, -74.0060),
                                            Triple("Central Plaza Café", 35.6580, 139.7016),
                                            Triple("Old Town Bridge", 48.8566, 2.3522)
                                        ).random()
                                        locationName = locs.first
                                        latitude = locs.second
                                        longitude = locs.third
                                        isLocatingCurrent = false
                                        Toast.makeText(context, "📍 Located: ${locs.first}", Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Current Location", tint = Color.White.copy(alpha = 0.7f))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFDD2476),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                            focusedContainerColor = Color.White.copy(alpha = 0.05f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("memory_location_input")
                    )

                    if (showSuggestions && suggestions.isNotEmpty()) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 70.dp)
                                .shadow(8.dp)
                                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)), RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column {
                                suggestions.forEach { result ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                locationName = result.cityOrName
                                                searchQuery = result.cityOrName
                                                latitude = result.latitude
                                                longitude = result.longitude
                                                showSuggestions = false
                                            }
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = Color(0xFFDD2476), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(result.cityOrName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            if (result.country.isNotEmpty()) {
                                                Text(result.country, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                                            }
                                        }
                                    }
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                                }
                            }
                        }
                    }
                }

                // Miniature Map Preview card
                val currentLat = latitude
                val currentLon = longitude
                if (currentLat != null && currentLon != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .shadow(4.dp, RoundedCornerShape(16.dp))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)), RoundedCornerShape(16.dp)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            val coord = LocationCoordinate(currentLat, currentLon)
                            MemoryMapView(
                                markers = listOf(
                                    MapMarker(
                                        id = "preview",
                                        journeyId = "",
                                        coordinate = coord,
                                        title = locationName,
                                        subtitle = "Selected Spot",
                                        mood = selectedMood
                                    )
                                ),
                                centerCoordinate = coord,
                                onMarkerClick = {},
                                modifier = Modifier.fillMaxSize()
                            )
                            
                            // Small floating tag
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("Map Preview", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)", color = Color.White.copy(alpha = 0.6f)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFDD2476),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("memory_date_input")
                )

                Spacer(modifier = Modifier.height(24.dp))

                // 3. Mood selector
                Text(
                    text = "3. Memory Mood",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(Mood.values().filter { !it.name.contains("legacy") && it.name != "ADVENTUROUS" && it.name != "SERENE" }) { mood ->
                        val isMoodSelected = selectedMood == mood
                        val glowGradient = Brush.horizontalGradient(
                            colors = mood.gradientColors.map { Color(android.graphics.Color.parseColor(it)) }
                        )

                        Box(
                            modifier = Modifier
                                .shadow(if (isMoodSelected) 6.dp else 0.dp, RoundedCornerShape(20.dp))
                                .background(
                                    if (isMoodSelected) glowGradient else Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.07f), Color.White.copy(alpha = 0.07f))),
                                    RoundedCornerShape(20.dp)
                                )
                                .border(
                                    BorderStroke(1.dp, if (isMoodSelected) Color.White else Color.White.copy(alpha = 0.15f)),
                                    RoundedCornerShape(20.dp)
                                )
                                .clickable { selectedMood = mood }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(mood.emoji, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = mood.label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMoodSelected) Color.Black else Color.White
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 4. Diary Text (Journal)
                Text(
                    text = "4. Diary Text",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = journalText,
                    onValueChange = { journalText = it },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFDD2476),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                        focusedContainerColor = Color.White.copy(alpha = 0.06f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                    ),
                    shape = RoundedCornerShape(20.dp),
                    minLines = 4,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("memory_journal_input")
                )

                Spacer(modifier = Modifier.height(32.dp))

                // 5. Update Memory Button
                Button(
                    onClick = {
                        val updatedMemory = memoryWithPhotos.memory.copy(
                            title = title,
                            note = journalText,
                            journalText = journalText,
                            image = selectedAlbumPhotos.firstOrNull()?.localUri ?: "",
                            locationName = locationName,
                            latitude = latitude,
                            longitude = longitude,
                            date = date,
                            mood = selectedMood
                        )
                        onSaveMemory(updatedMemory, selectedAlbumPhotos)
                        Toast.makeText(context, "Memory updated successfully!", Toast.LENGTH_SHORT).show()
                    },
                    enabled = isFormValid,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        disabledContainerColor = Color.White.copy(alpha = 0.08f)
                    ),
                    contentPadding = PaddingValues(),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .shadow(6.dp, RoundedCornerShape(22.dp))
                        .background(
                            if (isFormValid) Brush.linearGradient(colors = listOf(Color(0xFFFF512F), Color(0xFFDD2476)))
                            else Brush.linearGradient(colors = listOf(Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.05f))),
                            RoundedCornerShape(22.dp)
                        )
                        .testTag("save_memory_button")
                ) {
                    Text(
                        text = "Save Memory Changes",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = if (isFormValid) Color.White else Color.White.copy(alpha = 0.4f)
                    )
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
