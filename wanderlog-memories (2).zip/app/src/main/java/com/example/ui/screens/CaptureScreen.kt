package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.capture.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CaptureScreen(
    viewModel: CaptureViewModel,
    onBack: () -> Unit,
    onNavigateToJourney: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.state.collectAsState()
    val journeys by viewModel.journeys.collectAsState()
    val memories by viewModel.memories.collectAsState()

    var journeyDropdownExpanded by remember { mutableStateOf(false) }
    var memoryDropdownExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Save to Wonderlog",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color(0xFF0F172A)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF8FAFC),
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val currentState = state) {
                is CaptureUiState.Idle -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No items to capture",
                            color = Color.Gray,
                            fontSize = 15.sp
                        )
                    }
                }

                is CaptureUiState.Ready, is CaptureUiState.Saving -> {
                    val draft = if (currentState is CaptureUiState.Ready) {
                        currentState.draft
                    } else {
                        (currentState as CaptureUiState.Saving).draft
                    }
                    val isSaving = currentState is CaptureUiState.Saving
                    val validationResult = remember(draft) { CaptureValidator.validate(draft) }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // 1. Content Preview
                        CaptureContentPreviewCard(draft = draft)

                        // 2. Choose Journey
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Destination Journey",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF334155)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Box {
                                    OutlinedButton(
                                        onClick = { journeyDropdownExpanded = true },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("capture_journey_dropdown"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        val selectedJourney = journeys.firstOrNull { it.id == draft.journeyId }
                                        Text(
                                            text = selectedJourney?.title ?: "Select Journey ▼",
                                            color = if (selectedJourney != null) Color(0xFF0F172A) else Color.Gray,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }

                                    DropdownMenu(
                                        expanded = journeyDropdownExpanded,
                                        onDismissRequest = { journeyDropdownExpanded = false }
                                    ) {
                                        if (journeys.isEmpty()) {
                                            DropdownMenuItem(
                                                text = { Text("No journeys available") },
                                                onClick = { journeyDropdownExpanded = false }
                                            )
                                        } else {
                                            journeys.forEach { journey ->
                                                DropdownMenuItem(
                                                    text = {
                                                        Column {
                                                            Text(journey.title, fontWeight = FontWeight.Medium)
                                                            if (journey.subtitle != null) {
                                                                Text(
                                                                    journey.subtitle,
                                                                    fontSize = 11.sp,
                                                                    color = Color.Gray
                                                                )
                                                            }
                                                        }
                                                    },
                                                    onClick = {
                                                        viewModel.selectJourney(journey.id)
                                                        journeyDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // 3. Destination Mode (Add to Album, Add to existing Memory, Create new Memory)
                        if (draft.journeyId != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "Destination",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF334155)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Mode 1: Journey Album (Only allowed if images only and no text/files)
                                    val canSaveToAlbumOnly = !draft.hasFiles && !draft.hasText
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable(enabled = canSaveToAlbumOnly) {
                                                viewModel.setCreateNewMemory(false)
                                                viewModel.selectMemory(null)
                                            }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = !draft.createNewMemory && draft.memoryId == null,
                                            onClick = {
                                                viewModel.setCreateNewMemory(false)
                                                viewModel.selectMemory(null)
                                            },
                                            enabled = canSaveToAlbumOnly
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                "Add to Journey Album",
                                                fontWeight = FontWeight.Medium,
                                                color = if (canSaveToAlbumOnly) Color(0xFF0F172A) else Color.LightGray
                                            )
                                            Text(
                                                "Saves imported photos directly into the trip album",
                                                fontSize = 11.sp,
                                                color = if (canSaveToAlbumOnly) Color.Gray else Color.LightGray
                                            )
                                        }
                                    }

                                    // Mode 2: Existing Memory
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.setCreateNewMemory(false)
                                            }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = !draft.createNewMemory && draft.memoryId != null,
                                            onClick = { viewModel.setCreateNewMemory(false) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text("Add to existing Memory", fontWeight = FontWeight.Medium)
                                            Text("Attach to an existing memory inside this Journey", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }

                                    if (!draft.createNewMemory && draft.memoryId != null || (!draft.createNewMemory && !canSaveToAlbumOnly)) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Box(modifier = Modifier.padding(start = 36.dp)) {
                                            OutlinedButton(
                                                onClick = { memoryDropdownExpanded = true },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("capture_memory_dropdown"),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                val selectedMem = memories.firstOrNull { it.id == draft.memoryId }
                                                Text(
                                                    selectedMem?.title ?: "Select Memory ▼",
                                                    color = if (selectedMem != null) Color(0xFF0F172A) else Color.Gray,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }

                                            DropdownMenu(
                                                expanded = memoryDropdownExpanded,
                                                onDismissRequest = { memoryDropdownExpanded = false }
                                            ) {
                                                if (memories.isEmpty()) {
                                                    DropdownMenuItem(
                                                        text = { Text("No memories yet. Create one below.") },
                                                        onClick = {
                                                            viewModel.setCreateNewMemory(true)
                                                            memoryDropdownExpanded = false
                                                        }
                                                    )
                                                } else {
                                                    memories.forEach { mem ->
                                                        DropdownMenuItem(
                                                            text = {
                                                                Column {
                                                                    Text(mem.title, fontWeight = FontWeight.Medium)
                                                                    if (mem.dateLabel != null) {
                                                                        Text(mem.dateLabel, fontSize = 11.sp, color = Color.Gray)
                                                                    }
                                                                }
                                                            },
                                                            onClick = {
                                                                viewModel.selectMemory(mem.id)
                                                                memoryDropdownExpanded = false
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Mode 3: Create new Memory
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.setCreateNewMemory(true)
                                            }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = draft.createNewMemory,
                                            onClick = { viewModel.setCreateNewMemory(true) }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text("Create new Memory", fontWeight = FontWeight.Medium)
                                            Text("Creates a brand new travel scrapbook entry", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }

                                    if (draft.createNewMemory) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Column(
                                            modifier = Modifier.padding(start = 36.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = draft.memoryTitle,
                                                onValueChange = { viewModel.setMemoryTitle(it) },
                                                label = { Text("Memory title") },
                                                placeholder = { Text("e.g. Afternoon at Piazza Navona") },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("capture_memory_title_input"),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )

                                            OutlinedTextField(
                                                value = draft.memoryText,
                                                onValueChange = { viewModel.setMemoryText(it) },
                                                label = { Text("Memory thoughts or notes") },
                                                placeholder = { Text("Add notes, highlights or reflections...") },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(min = 90.dp)
                                                    .testTag("capture_memory_text_input"),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Validation error message if invalid
                        if (!validationResult.valid && validationResult.message != null) {
                            Text(
                                text = validationResult.message,
                                color = Color(0xFFE11D48),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }

                        // Save Button
                        Button(
                            onClick = { viewModel.save() },
                            enabled = validationResult.valid && !isSaving,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("capture_save_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFE85D75)
                            )
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Saving to Wonderlog...")
                            } else {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Save", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    }
                }

                is CaptureUiState.Success -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Saved to Wonderlog!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val summary = buildString {
                            if (currentState.importedPhotoCount > 0) {
                                append("${currentState.importedPhotoCount} photos imported. ")
                            }
                            if (currentState.attachmentCount > 0) {
                                append("${currentState.attachmentCount} keepsakes attached.")
                            }
                            if (isEmpty()) {
                                append("Memory updated successfully.")
                            }
                        }
                        Text(
                            text = summary,
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onBack,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Close")
                            }
                            if (currentState.journeyId != null) {
                                Button(
                                    onClick = {
                                        onNavigateToJourney(currentState.journeyId)
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFE85D75)
                                    )
                                ) {
                                    Text("Open Journey")
                                }
                            }
                        }
                    }
                }

                is CaptureUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Could not save",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentState.message,
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.reset() },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE85D75))
                        ) {
                            Text("Try Again")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CaptureContentPreviewCard(draft: CaptureDraft) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Captured Content",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(10.dp))

            // 1. Image previews
            val imageItems = draft.items.filter { it.type == CaptureContentType.IMAGE }
            if (imageItems.isNotEmpty()) {
                val previewItems = imageItems.take(20)
                val remaining = imageItems.size - previewItems.size

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(previewItems) { item ->
                        AsyncImage(
                            model = item.uri,
                            contentDescription = "Preview thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFE2E8F0))
                        )
                    }
                    if (remaining > 0) {
                        item {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFCBD5E1)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "+$remaining",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF334155),
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // 2. Text / Link preview
            val textItems = draft.items.filter {
                it.type == CaptureContentType.TEXT || it.type == CaptureContentType.LINK
            }
            for (textItem in textItems) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF1F5F9)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (textItem.type == CaptureContentType.LINK) Icons.Default.Link else Icons.Default.Notes,
                            contentDescription = null,
                            tint = Color(0xFFE85D75),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            if (textItem.title != null) {
                                Text(
                                    text = textItem.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                            }
                            Text(
                                text = textItem.text.orEmpty(),
                                fontSize = 12.sp,
                                color = Color(0xFF334155),
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // 3. File / Document preview
            val fileItems = draft.items.filter { it.type == CaptureContentType.FILE }
            for (fileItem in fileItems) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF1F5F9)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("📄", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = fileItem.title ?: "Document attachment",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF0F172A),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = fileItem.mimeType ?: "File",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // 4. Detected Location preview if present
            val location = draft.items.firstOrNull { it.location != null }?.location
            if (location != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = null,
                        tint = Color(0xFFE85D75),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Detected location: ${String.format("%.4f, %.4f", location.latitude, location.longitude)}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}
