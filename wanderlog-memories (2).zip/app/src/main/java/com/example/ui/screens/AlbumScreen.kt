package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.domain.model.AlbumPhoto
import com.example.domain.model.Trip
import com.example.presentation.WanderlogViewModel
import com.example.premium.PremiumManager
import com.example.premium.SubscriptionConfig
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AlbumScreen(
    trip: Trip,
    viewModel: WanderlogViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Observe album state from viewmodel
    val photos by viewModel.selectedTripPhotos.collectAsState()
    val isImporting by viewModel.isImporting.collectAsState()
    val importProgress by viewModel.importProgress.collectAsState()
    val isPremium by PremiumManager.isPremium.collectAsState()

    // UI state variables
    var selectedPhotoForViewer by remember { mutableStateOf<AlbumPhoto?>(null) }
    var isSelectionMode by remember { mutableStateOf(false) }
    val selectedPhotoIds = remember { mutableStateListOf<String>() }
    var sortBy by remember { mutableStateOf(0) } // 0: Display Order, 1: Date Taken, 2: Favorites
    var showLocalUpgradeModal by remember { mutableStateOf(false) }

    // Sort the photos
    val sortedPhotos = remember(photos, sortBy) {
        when (sortBy) {
            1 -> photos.sortedByDescending { it.capturedAt ?: it.createdAt }
            2 -> photos.sortedByDescending { it.favorite }
            else -> photos.sortedBy { it.displayOrder }
        }
    }

    // Launchers for picking photos
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(),
        onResult = { uris ->
            if (uris.isNotEmpty()) {
                val currentCount = photos.size
                val limits = SubscriptionConfig.getLimits(isPremium)
                if (!isPremium && currentCount + uris.size > limits.albumPhotosLimit) {
                    showLocalUpgradeModal = true
                } else {
                    viewModel.importPhotos(context, trip.id, uris)
                }
            }
        }
    )

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview(),
        onResult = { bitmap ->
            if (bitmap != null) {
                coroutineScope.launch {
                    val currentCount = photos.size
                    val limits = SubscriptionConfig.getLimits(isPremium)
                    if (!isPremium && currentCount >= limits.albumPhotosLimit) {
                        showLocalUpgradeModal = true
                    } else {
                        val path = com.example.storage.PhotoStorageManager.saveBitmapToPrivateStorage(context, bitmap)
                        if (path != null) {
                            val fileUri = Uri.fromFile(File(path))
                            viewModel.importPhotos(context, trip.id, listOf(fileUri))
                        }
                    }
                }
            }
        }
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A), // Slate 900
                        Color(0xFF1E293B)  // Slate 800
                    )
                )
            )
            .testTag("album_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (isSelectionMode) {
                            isSelectionMode = false
                            selectedPhotoIds.clear()
                        } else {
                            onBackClick()
                        }
                    },
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                        .size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isSelectionMode) "${selectedPhotoIds.size} Selected" else "Journey Album",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = trip.destinationName,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Header Action Buttons
                if (!isSelectionMode && sortedPhotos.isNotEmpty()) {
                    // Sort Menu trigger
                    var showSortMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(
                            onClick = { showSortMenu = true },
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.1f), CircleShape)
                                .size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sort,
                                contentDescription = "Sort Options",
                                tint = Color.White
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                            modifier = Modifier.background(Color(0xFF1E293B))
                        ) {
                            DropdownMenuItem(
                                text = { Text("Custom Order 📍", color = Color.White) },
                                onClick = { sortBy = 0; showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Date Captured 📅", color = Color.White) },
                                onClick = { sortBy = 1; showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Favorites First ⭐", color = Color.White) },
                                onClick = { sortBy = 2; showSortMenu = false }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Selection mode toggle
                    IconButton(
                        onClick = { isSelectionMode = true },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.1f), CircleShape)
                            .size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Checklist,
                            contentDescription = "Select Mode",
                            tint = Color.White
                        )
                    }
                }
            }

            // Limit Indicator Bar
            val limit = SubscriptionConfig.getLimits(isPremium).albumPhotosLimit
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isPremium) Icons.Default.WorkspacePremium else Icons.Default.Photo,
                    contentDescription = null,
                    tint = if (isPremium) Color(0xFFFBBF24) else Color(0xFF38BDF8),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Storage: ${photos.size} of $limit photos used",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.weight(1f)
                )
                if (!isPremium) {
                    Text(
                        text = "Upgrade ⚡",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDD2476),
                        modifier = Modifier.clickable { showLocalUpgradeModal = true }
                    )
                }
            }

            // Loading/Importing progress bar
            AnimatedVisibility(
                visible = isImporting,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Optimizing and importing photos...",
                            fontSize = 12.sp,
                            color = Color(0xFF38BDF8)
                        )
                        Text(
                            text = "${(importProgress * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { importProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = Color(0xFFDD2476),
                        trackColor = Color.White.copy(alpha = 0.1f)
                    )
                }
            }

            // Main Area
            if (sortedPhotos.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .shadow(8.dp, RoundedCornerShape(24.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFFDD2476), Color(0xFFFF512F))
                                    ),
                                    RoundedCornerShape(24.dp)
                                )
                                .size(90.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Start filling this Journey with your favorite photos.",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            lineHeight = 26.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Create a stunning offline travel memory book. Copy your photos safely, view them offline, extract Exif coordinates, and design beautiful stories.",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp),
                            lineHeight = 20.sp
                        )
                        Spacer(modifier = Modifier.height(28.dp))
                        
                        // Import Floating Action Button/Trigger
                        Row {
                            Button(
                                onClick = { photoPickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFDD2476)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Gallery", fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = { cameraLauncher.launch() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF10B981)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Camera", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                // Photo Grid
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(sortedPhotos, key = { it.id }) { photo ->
                            val isSelected = selectedPhotoIds.contains(photo.id)
                            
                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        border = BorderStroke(
                                            width = if (isSelected) 3.dp else 0.dp,
                                            color = if (isSelected) Color(0xFFDD2476) else Color.Transparent
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .combinedClickable(
                                        onClick = {
                                            if (isSelectionMode) {
                                                if (isSelected) {
                                                    selectedPhotoIds.remove(photo.id)
                                                } else {
                                                    selectedPhotoIds.add(photo.id)
                                                }
                                            } else {
                                                selectedPhotoForViewer = photo
                                            }
                                        },
                                        onLongClick = {
                                            if (!isSelectionMode) {
                                                isSelectionMode = true
                                                selectedPhotoIds.add(photo.id)
                                            }
                                        }
                                    )
                                    .testTag("photo_tile_${photo.id}")
                            ) {
                                AsyncImage(
                                    model = photo.thumbnailUri,
                                    contentDescription = "Photo taken in ${photo.locationName}",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )

                                // Gradients overlay
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f)),
                                                startY = 100f
                                            )
                                        )
                                )

                                // Checkbox overlay for selection mode
                                if (isSelectionMode) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .background(
                                                if (isSelected) Color(0xFFDD2476) else Color.Black.copy(alpha = 0.6f),
                                                CircleShape
                                            )
                                            .size(22.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }

                                // Badges
                                Row(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (photo.isCoverPhoto) {
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFDD2476), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "COVER",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }

                                    if (photo.favorite) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "Favorite",
                                            tint = Color(0xFFFBBF24),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }

                                // Location overlay preview if exists
                                if (photo.locationName.isNotEmpty() && !isSelectionMode) {
                                    Text(
                                        text = photo.locationName.substringBefore(","),
                                        fontSize = 9.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Floating Import Action Panel (Bottom Center)
                    if (!isSelectionMode) {
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(20.dp)
                                .shadow(8.dp, RoundedCornerShape(20.dp))
                                .background(Color(0xFF1E293B).copy(alpha = 0.95f), RoundedCornerShape(20.dp))
                                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)), RoundedCornerShape(20.dp))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Add Photos:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            IconButton(
                                onClick = { photoPickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.1f), CircleShape)
                                    .size(40.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = "Import Gallery", tint = Color(0xFF38BDF8))
                            }

                            IconButton(
                                onClick = { cameraLauncher.launch() },
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.1f), CircleShape)
                                    .size(40.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Capture Photo", tint = Color(0xFF10B981))
                            }
                        }
                    }
                }
            }
        }

        // Floating action sheet for selection mode
        AnimatedVisibility(
            visible = isSelectionMode && selectedPhotoIds.isNotEmpty(),
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .shadow(12.dp, RoundedCornerShape(16.dp))
                    .background(Color(0xFFEF4444), RoundedCornerShape(16.dp))
                    .clickable {
                        val photosToDelete = photos.filter { it.id in selectedPhotoIds }
                        viewModel.deletePhotos(photosToDelete)
                        isSelectionMode = false
                        selectedPhotoIds.clear()
                        Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show()
                    }
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Delete Selected (${selectedPhotoIds.size})",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        // Premium Upgrade Modal Popup
        if (showLocalUpgradeModal) {
            Dialog(
                onDismissRequest = { showLocalUpgradeModal = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.75f))
                        .clickable { showLocalUpgradeModal = false },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 340.dp)
                            .padding(24.dp)
                            .shadow(16.dp, RoundedCornerShape(28.dp))
                            .background(Color(0xFF1E293B), RoundedCornerShape(28.dp))
                            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)), RoundedCornerShape(28.dp))
                            .clickable(enabled = false) {}
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFFDD2476), Color(0xFFFF512F))
                                    ),
                                    CircleShape
                                )
                                .size(64.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "You've filled your free travel album.",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Upgrade to Premium to save up to 100 photos per Journey, unlock unlimited memories, cloud backup, offline maps and PDF travel books.",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = {
                                showLocalUpgradeModal = false
                                PremiumManager.showUpgrade(
                                    title = "You've filled your free travel album.",
                                    subtitle = "Upgrade to Premium to save up to 100 photos per Journey, unlock unlimited memories, cloud backup, offline maps and PDF travel books."
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDD2476)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Unlock Premium", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = { showLocalUpgradeModal = false }
                        ) {
                            Text("Maybe Later", color = Color.White.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }

        // Fullscreen Photo Viewer Dialog Overlay
        selectedPhotoForViewer?.let { activePhoto ->
            FullscreenPhotoViewer(
                photos = sortedPhotos,
                initialPhoto = activePhoto,
                viewModel = viewModel,
                onDismiss = { selectedPhotoForViewer = null }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FullscreenPhotoViewer(
    photos: List<AlbumPhoto>,
    initialPhoto: AlbumPhoto,
    viewModel: WanderlogViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    // Find initial index
    val initialIndex = remember(photos, initialPhoto) {
        val index = photos.indexOfFirst { it.id == initialPhoto.id }
        if (index != -1) index else 0
    }

    val pagerState = rememberPagerState(initialPage = initialIndex, pageCount = { photos.size })

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .testTag("fullscreen_viewer")
        ) {
            // Horizontal Pager
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val photo = photos.getOrNull(page)
                if (photo != null) {
                    var scale by remember { mutableStateOf(1f) }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = photo.originalUri,
                            contentDescription = "Fullscreen photo",
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale
                                ),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }

            // Top bar controls
            val currentPage = pagerState.currentPage
            val currentPhoto = photos.getOrNull(currentPage)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }

                if (currentPhoto != null) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Reorder Left
                        IconButton(
                            onClick = { viewModel.movePhotoOrder(currentPhoto, up = true) },
                            enabled = currentPage > 0,
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                .size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = "Move Left",
                                tint = if (currentPage > 0) Color.White else Color.White.copy(alpha = 0.3f)
                            )
                        }

                        // Reorder Right
                        IconButton(
                            onClick = { viewModel.movePhotoOrder(currentPhoto, up = false) },
                            enabled = currentPage < photos.size - 1,
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                .size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Move Right",
                                tint = if (currentPage < photos.size - 1) Color.White else Color.White.copy(alpha = 0.3f)
                            )
                        }

                        // Favorite
                        IconButton(
                            onClick = { viewModel.toggleFavoritePhoto(currentPhoto) },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                .size(40.dp)
                        ) {
                            Icon(
                                imageVector = if (currentPhoto.favorite) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "Favorite",
                                tint = if (currentPhoto.favorite) Color(0xFFFBBF24) else Color.White
                            )
                        }

                        // Cover photo toggle
                        IconButton(
                            onClick = {
                                viewModel.setAsJourneyCover(currentPhoto)
                                Toast.makeText(context, "Set as cover photo", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .background(
                                    if (currentPhoto.isCoverPhoto) Color(0xFFDD2476) else Color.Black.copy(alpha = 0.5f),
                                    CircleShape
                                )
                                .size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Wallpaper,
                                contentDescription = "Set as Cover",
                                tint = Color.White
                            )
                        }

                        // Delete
                        IconButton(
                            onClick = {
                                viewModel.deletePhoto(currentPhoto)
                                Toast.makeText(context, "Photo removed", Toast.LENGTH_SHORT).show()
                                if (photos.size <= 1) {
                                    onDismiss()
                                }
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                .size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = Color(0xFFEF4444)
                            )
                        }
                    }
                }
            }

            // Bottom metadata overlay info
            if (currentPhoto != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                        .align(Alignment.BottomCenter)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentPhoto.locationName.isNotEmpty()) "📍 ${currentPhoto.locationName}" else "📍 Location Unknown",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        Text(
                            text = "${currentPage + 1} / ${photos.size}",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    val dateFormatted = remember(currentPhoto.capturedAt) {
                        try {
                            val sdf = SimpleDateFormat("MMM dd, yyyy  •  HH:mm", Locale.getDefault())
                            sdf.format(Date(currentPhoto.capturedAt ?: currentPhoto.createdAt))
                        } catch (e: Exception) {
                            "Unknown Date"
                        }
                    }

                    Text(
                        text = "Captured: $dateFormatted",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Extra tech details
                    val sizeFormatted = remember(currentPhoto.fileSize) {
                        val kb = currentPhoto.fileSize / 1024
                        if (kb > 1024) {
                            String.format(Locale.US, "%.1f MB", kb / 1024.0)
                        } else {
                            "$kb KB"
                        }
                    }

                    Text(
                        text = "Dimensions: ${currentPhoto.width} × ${currentPhoto.height}  •  File Size: $sizeFormatted",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}
