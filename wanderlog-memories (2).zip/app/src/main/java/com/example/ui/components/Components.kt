package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.model.Memory
import com.example.domain.model.Mood
import com.example.domain.model.Trip

// Predefined gradient palettes for destinations to avoid flat grey surfaces!
val GRADIENTS = listOf(
    listOf(Color(0xFFFF9E9E), Color(0xFFFFD066)), // Japan Peach
    listOf(Color(0xFF86F3D4), Color(0xFF52A8FF)), // Paris Mint
    listOf(Color(0xFFD9B3FF), Color(0xFF9E52FF)), // Iceland Lavender
    listOf(Color(0xFFFFB5D5), Color(0xFFFF69B4)), // Rome Rose
    listOf(Color(0xFFA1D0FF), Color(0xFF52A8FF)), // NY Cyan
    listOf(Color(0xFFFFE599), Color(0xFFFFC04D))  // Warm Amber
)

@Composable
fun getGradient(index: Int): Brush {
    val colors = GRADIENTS.getOrElse(index) { GRADIENTS.last() }
    return Brush.linearGradient(colors)
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color.White.copy(alpha = 0.35f),
    borderColor: Color = Color.White.copy(alpha = 0.45f),
    borderRadius: Dp = 24.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(borderRadius),
                ambientColor = Color.Black.copy(alpha = 0.05f),
                spotColor = Color.Black.copy(alpha = 0.1f)
            )
            .background(
                color = backgroundColor,
                shape = RoundedCornerShape(borderRadius)
            )
            .border(
                border = BorderStroke(1.dp, borderColor),
                shape = RoundedCornerShape(borderRadius)
            )
            .clip(RoundedCornerShape(borderRadius))
            .padding(16.dp),
        content = content
    )
}

@Composable
fun DestinationCard(
    trip: Trip,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    memoriesCount: Int = 0,
    albumPhotosCount: Int = 0,
    onFavoriteToggle: (() -> Unit)? = null,
    onArchiveToggle: (() -> Unit)? = null,
    onDuplicate: (() -> Unit)? = null,
    onRename: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    onChangeTheme: (() -> Unit)? = null,
    onChangeCover: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val imageId = remember(trip.coverImage) {
        context.resources.getIdentifier(trip.coverImage, "drawable", context.packageName)
    }
    var showMenu by remember { mutableStateOf(false) }

    val formattedUpdated = remember(trip.updatedAt) {
        try {
            val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
            sdf.format(java.util.Date(trip.updatedAt))
        } catch (e: Exception) {
            "Recent"
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(28.dp),
                ambientColor = Color.Black.copy(alpha = 0.08f),
                spotColor = Color.Black.copy(alpha = 0.15f)
            )
            .border(BorderStroke(1.5.dp, Color.White.copy(alpha = 0.6f)), RoundedCornerShape(28.dp))
            .clickable(onClick = onClick)
            .testTag("destination_card_${trip.id}"),
        shape = RoundedCornerShape(28.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background cover photo
            if (imageId != 0) {
                AsyncImage(
                    model = imageId,
                    contentDescription = trip.destinationName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else if (trip.coverImage.isNotEmpty() && !trip.coverImage.startsWith("img_dest_")) {
                AsyncImage(
                    model = trip.coverImage,
                    contentDescription = trip.destinationName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(getGradient(trip.accentGradientIndex))
                )
            }

            // Dark subtle overlay for contrast
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.4f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.75f)
                            ),
                            startY = 0f
                        )
                    )
            )

            // TOP BAR OVERLAYS (Archived / Country Badges & Quick Action Heart / Menu)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
                    .align(Alignment.TopStart),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Country Accent Badge
                    Box(
                        modifier = Modifier
                            .shadow(4.dp, CircleShape)
                            .background(getGradient(trip.accentGradientIndex), CircleShape)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = trip.country,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Archived Indicator
                    if (trip.archived) {
                        Box(
                            modifier = Modifier
                                .shadow(4.dp, CircleShape)
                                .background(Color(0xFF475569), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star, // fallback simple, let's use location for simplicity or standard
                                    contentDescription = "Archived",
                                    tint = Color.White,
                                    modifier = Modifier.size(10.dp)
                                )
                                Text(
                                    text = "ARCHIVED",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }

                // Options/More Menu and Quick Favorite Button
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quick Favorite heart button
                    if (onFavoriteToggle != null) {
                        IconButton(
                            onClick = {
                                onFavoriteToggle()
                            },
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color.White.copy(alpha = 0.35f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Favorite",
                                tint = if (trip.favorite) Color(0xFFFFD066) else Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Context Menu
                    Box {
                        IconButton(
                            onClick = { showMenu = !showMenu },
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color.White.copy(alpha = 0.35f), CircleShape)
                        ) {
                            Text(
                                text = "⋮",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(Color.White)
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (trip.favorite) "⭐ Unfavorite" else "⭐ Favorite") },
                                onClick = {
                                    showMenu = false
                                    onFavoriteToggle?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (trip.archived) "📦 Restore" else "📦 Archive") },
                                onClick = {
                                    showMenu = false
                                    onArchiveToggle?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("👯 Duplicate") },
                                onClick = {
                                    showMenu = false
                                    onDuplicate?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("✏️ Rename") },
                                onClick = {
                                    showMenu = false
                                    onRename?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🎨 Change Theme") },
                                onClick = {
                                    showMenu = false
                                    onChangeTheme?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("📸 Change Cover") },
                                onClick = {
                                    showMenu = false
                                    onChangeCover?.invoke()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🗑️ Delete") },
                                onClick = {
                                    showMenu = false
                                    onDelete?.invoke()
                                }
                            )
                        }
                    }
                }
            }

            // BOTTOM DETAILS - Elegant Frosted Glass Plate
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(12.dp)
                    .shadow(10.dp, RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .border(BorderStroke(0.5.dp, Color.White.copy(alpha = 0.25f)), RoundedCornerShape(20.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = trip.destinationName,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.SansSerif,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📅 ${trip.startDate.take(10)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (trip.description.isNotEmpty()) {
                        Text(
                            text = trip.description,
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // Metrics line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("📝", fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "$memoriesCount memories",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🖼️", fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "$albumPhotosCount photos",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                        }

                        Text(
                            text = "Updated: $formattedUpdated",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryCard(
    memory: Memory,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val imageId = remember(memory.image) {
        context.resources.getIdentifier(memory.image, "drawable", context.packageName)
    }

    // Polaroid-style layout with frosted white borders!
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.85f))
            .border(BorderStroke(1.5.dp, Color.White.copy(alpha = 0.5f)), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(8.dp)
            .testTag("memory_card_${memory.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp))
        ) {
            if (imageId != 0) {
                AsyncImage(
                    model = imageId,
                    contentDescription = memory.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else if (memory.image.isNotEmpty()) {
                val firstImgPath = memory.image.split(",").firstOrNull { it.isNotEmpty() } ?: memory.image
                AsyncImage(
                    model = firstImgPath,
                    contentDescription = memory.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(getGradient(0))
                )
            }

            // Delete action button
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(32.dp)
                    .background(Color.White.copy(alpha = 0.7f), CircleShape)
            ) {
                Text("✕", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Red)
            }

            // Mood tag overlaid on top-left of image
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                MoodBadge(mood = memory.mood)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Polaroid handwritten caption
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
            Text(
                text = memory.title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1C1E),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = memory.note,
                fontSize = 12.sp,
                color = Color.DarkGray,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color.Red,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = memory.locationName,
                        fontSize = 10.sp,
                        color = Color.Gray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = memory.date,
                    fontSize = 10.sp,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun MoodBadge(mood: Mood) {
    val gradientColor = remember(mood) {
        val startColor = Color(android.graphics.Color.parseColor(mood.gradientColors[0]))
        val endColor = Color(android.graphics.Color.parseColor(mood.gradientColors[1]))
        Brush.horizontalGradient(listOf(startColor, endColor))
    }

    Box(
        modifier = Modifier
            .shadow(2.dp, RoundedCornerShape(12.dp))
            .background(gradientColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = mood.emoji, fontSize = 12.sp)
            Text(
                text = mood.label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun FloatingGlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable (() -> Unit)? = null,
    gradientColors: List<Color> = listOf(Color(0xFF52A8FF), Color(0xFF9E52FF))
) {
    val brush = Brush.linearGradient(gradientColors)
    Box(
        modifier = modifier
            .shadow(6.dp, RoundedCornerShape(30.dp))
            .background(brush, RoundedCornerShape(30.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }
    }
}

@Composable
fun GlassBottomNavigation(
    tabs: List<String>,
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    icons: List<@Composable (Boolean) -> Unit>
) {
    Box(
        modifier = modifier
            .padding(horizontal = 32.dp, vertical = 12.dp)
            .shadow(16.dp, RoundedCornerShape(24.dp), ambientColor = Color.Black.copy(alpha = 0.05f), spotColor = Color.Black.copy(alpha = 0.15f))
            .background(Color.White, RoundedCornerShape(24.dp))
            .border(BorderStroke(0.5.dp, Color(0xFF0F172A).copy(alpha = 0.08f)), RoundedCornerShape(24.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, title ->
                val isSelected = selectedTab == index
                val scale by animateFloatAsState(
                    targetValue = if (isSelected) 1.18f else 1.0f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                )
                val tintColor = if (isSelected) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.5f)

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .scale(scale)
                        .clickable { onTabSelected(index) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(modifier = Modifier.rotate(if (isSelected) -4f else 0f)) {
                        icons.getOrNull(index)?.invoke(isSelected)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = title,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = tintColor,
                        letterSpacing = 0.3.sp
                    )
                }
            }
        }
    }
}

@Composable
fun TravelSticker(
    emoji: String,
    text: String,
    rotation: Float,
    gradientIndex: Int,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .rotate(rotation)
            .shadow(4.dp, RoundedCornerShape(16.dp))
            .background(getGradient(gradientIndex), RoundedCornerShape(16.dp))
            .border(BorderStroke(2.dp, Color.White), RoundedCornerShape(16.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(emoji, fontSize = 14.sp)
            Text(
                text.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun EmptyState(
    message: String,
    tip: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🗺️", fontSize = 64.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = message,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.DarkGray
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = tip,
            fontSize = 12.sp,
            color = Color.Gray,
            lineHeight = 18.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
