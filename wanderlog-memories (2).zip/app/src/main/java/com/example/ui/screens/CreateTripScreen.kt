package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.domain.model.Trip
import com.example.location.LocationSearchResult
import com.example.location.LocationSearchService
import com.example.storage.PhotoStorageManager
import com.example.ui.components.getGradient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

import com.example.premium.PremiumManager
import com.example.premium.SubscriptionConfig

val PRESET_THEMES = listOf(
    Triple("Sunset", Color(0xFFFF5E62), Color(0xFFFF9966)),
    Triple("Ocean", Color(0xFF2193b0), Color(0xFF6dd5ed)),
    Triple("Lavender", Color(0xFF8E2DE2), Color(0xFF4A00E0)),
    Triple("Forest", Color(0xFF11998e), Color(0xFF38ef7d)),
    Triple("Cherry Blossom", Color(0xFFff758c), Color(0xFFff7eb3)),
    Triple("Golden Hour", Color(0xFFf12711), Color(0xFFf5af19))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTripScreen(
    onSaveTrip: (Trip) -> Unit,
    onBackClick: () -> Unit,
    existingTripsCount: Int = 0,
    onBuildFromPhotosClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by PremiumManager.isPremium.collectAsState()

    var destinationName by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf("2026-07-03") }
    var endDate by remember { mutableStateOf("2026-07-10") }
    var description by remember { mutableStateOf("") }
    
    // Internal coordinate states (never displayed to user)
    var latitude by remember { mutableStateOf(35.6762) }
    var longitude by remember { mutableStateOf(139.6503) }
    
    var selectedGradientIndex by remember { mutableStateOf(0) }
    var coverImagePath by remember { mutableStateOf<String?>(null) }
    
    // Suggestion and search states
    var searchQuery by remember { mutableStateOf("") }
    var suggestions by remember { mutableStateOf<List<LocationSearchResult>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var showSuggestions by remember { mutableStateOf(false) }
    var isLocatingCurrent by remember { mutableStateOf(false) }
    
    // Dialog state for cover photo source
    var showPhotoSourceDialog by remember { mutableStateOf(false) }

    val isFormValid = destinationName.isNotBlank() && country.isNotBlank()

    // Activity Result Launchers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val savedPath = PhotoStorageManager.saveUriToPrivateStorage(context, uri)
                if (savedPath != null) {
                    coverImagePath = savedPath
                }
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            coroutineScope.launch {
                val savedPath = PhotoStorageManager.saveBitmapToPrivateStorage(context, bitmap)
                if (savedPath != null) {
                    coverImagePath = savedPath
                }
            }
        }
    }

    // Helper: Trigger Nominatim suggestions with debounce
    fun triggerLocationSearch(query: String) {
        searchQuery = query
        destinationName = query
        searchJob?.cancel()
        if (query.length < 3) {
            suggestions = emptyList()
            showSuggestions = false
            return
        }
        
        searchJob = coroutineScope.launch {
            delay(400) // Debounce
            isSearching = true
            showSuggestions = true
            val results = LocationSearchService.searchLocation(query)
            suggestions = results
            isSearching = false
        }
    }

    // Helper: Use current location with graceful offline fallbacks
    fun locateCurrentAndReverseGeocode() {
        isLocatingCurrent = true
        coroutineScope.launch {
            try {
                val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var lastKnownLocation: Location? = null
                
                try {
                    lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                } catch (se: SecurityException) {
                    Log.w("CreateTrip", "Location permission missing or denied", se)
                }

                if (lastKnownLocation != null) {
                    val lat = lastKnownLocation.latitude
                    val lon = lastKnownLocation.longitude
                    latitude = lat
                    longitude = lon
                    
                    // Fetch location details using reverse geocoding on OSM
                    val reverseResults = LocationSearchService.searchLocation("$lat, $lon")
                    if (reverseResults.isNotEmpty()) {
                        val first = reverseResults.first()
                        destinationName = first.cityOrName.ifEmpty { "Current Location" }
                        country = first.country
                        searchQuery = destinationName
                        Toast.makeText(context, "📍 Located: $destinationName, $country", Toast.LENGTH_SHORT).show()
                    } else {
                        destinationName = "My Location"
                        country = "Earth"
                        searchQuery = destinationName
                    }
                } else {
                    // Graceful simulation fallback with informational toast
                    delay(1200)
                    val sampleFallbacks = listOf(
                        LocationSearchResult("Rome, Italy", "Rome", "Italy", 41.9028, 12.4964),
                        LocationSearchResult("Kyoto, Japan", "Kyoto", "Japan", 35.0116, 135.7681),
                        LocationSearchResult("Paris, France", "Paris", "France", 48.8566, 2.3522),
                        LocationSearchResult("New York, USA", "New York", "United States", 40.7128, -74.0060)
                    )
                    val fallback = sampleFallbacks.random()
                    latitude = fallback.latitude
                    longitude = fallback.longitude
                    destinationName = fallback.cityOrName
                    country = fallback.country
                    searchQuery = destinationName
                    Toast.makeText(context, "📍 Simulated: $destinationName, $country", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("CreateTrip", "Error in locateCurrent", e)
                Toast.makeText(context, "Failed to fetch GPS coordinates", Toast.LENGTH_SHORT).show()
            } finally {
                isLocatingCurrent = false
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFFF9A9E), // Soft red/pink
                        Color(0xFFFAD0C4), // Peach/rose
                        Color(0xFFA18CD1)  // Soft purple/lavender
                    )
                )
            )
            .testTag("create_trip_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            // Premium iOS Style Back Button and Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .shadow(2.dp, CircleShape)
                        .background(Color.White, CircleShape)
                        .size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF0F172A),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "Start a Journey",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    letterSpacing = (-0.5).sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 📸 Trip Cover Image Hero Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .shadow(8.dp, RoundedCornerShape(24.dp))
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        if (coverImagePath == null) {
                            val preset = PRESET_THEMES.getOrNull(selectedGradientIndex) ?: PRESET_THEMES[0]
                            Brush.linearGradient(listOf(preset.second, preset.third))
                        } else {
                            Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                        }
                    )
                    .clickable { showPhotoSourceDialog = true },
                contentAlignment = Alignment.Center
            ) {
                if (coverImagePath != null) {
                    AsyncImage(
                        model = coverImagePath,
                        contentDescription = "Cover Image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Semi-transparent overlay to keep actions visible
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.25f))
                    )
                }

                // Call to action overlay
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = if (coverImagePath == null) Icons.Default.AddPhotoAlternate else Icons.Default.Edit,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (coverImagePath == null) "Add Cover Photo" else "Change Cover Photo",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 📍 Destination Search with OpenStreetMap Suggestions
            Text(
                text = "Where will your next memory begin?",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF475569),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Box(modifier = Modifier.fillMaxWidth()) {
                Column {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { triggerLocationSearch(it) },
                        placeholder = { Text("🔍 Search destination...") },
                        trailingIcon = {
                            if (isLocatingCurrent) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                IconButton(onClick = { locateCurrentAndReverseGeocode() }) {
                                    Icon(
                                        imageVector = Icons.Default.MyLocation,
                                        contentDescription = "Current Location",
                                        tint = Color(0xFFDD2476)
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("trip_destination_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFDD2476),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.8f),
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A)
                        ),
                        shape = RoundedCornerShape(18.dp)
                    )

                    // Suggestions Dropdown List
                    AnimatedVisibility(
                        visible = showSuggestions && (isSearching || suggestions.isNotEmpty()),
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                                .heightIn(max = 180.dp)
                                .shadow(8.dp, RoundedCornerShape(16.dp)),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            if (isSearching) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                               ) {
                                    CircularProgressIndicator(color = Color(0xFFDD2476), strokeWidth = 2.dp)
                               }
                            } else {
                                LazyColumn(modifier = Modifier.padding(8.dp)) {
                                    items(suggestions) { place ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    destinationName = place.cityOrName
                                                    country = place.country
                                                    latitude = place.latitude
                                                    longitude = place.longitude
                                                    searchQuery = place.displayName
                                                    showSuggestions = false
                                                }
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = Color.Red,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = place.displayName,
                                                fontSize = 12.sp,
                                                color = Color(0xFF334155),
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Country Input Field
            OutlinedTextField(
                value = country,
                onValueChange = { country = it },
                label = { Text("Country") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trip_country_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFDD2476),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.8f),
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color(0xFF0F172A),
                    unfocusedTextColor = Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Travel Dates Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = startDate,
                    onValueChange = { startDate = it },
                    label = { Text("Start Date") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFDD2476),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.8f),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Color(0xFF0F172A),
                        unfocusedTextColor = Color(0xFF0F172A)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                OutlinedTextField(
                    value = endDate,
                    onValueChange = { endDate = it },
                    label = { Text("End Date") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFDD2476),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.8f),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Color(0xFF0F172A),
                        unfocusedTextColor = Color(0xFF0F172A)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Short Description Input Field
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Journey Inspiration (Optional)") },
                placeholder = { Text("A cozy diary outline of this trip's wanderlust goal...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFDD2476),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.8f),
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color(0xFF0F172A),
                    unfocusedTextColor = Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Theme Preset Selector with gorgeous gradient views
            Text(
                text = "Select Visual Accent Theme",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF475569)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PRESET_THEMES.forEachIndexed { i, theme ->
                    val isSelected = selectedGradientIndex == i
                    val isLockedTheme = i >= 2 && !isPremium
                    val scale by animateFloatAsState(if (isSelected) 1.15f else 1.0f)
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .shadow(if (isSelected) 6.dp else 2.dp, CircleShape)
                            .background(Brush.linearGradient(listOf(theme.second, theme.third)), CircleShape)
                            .border(
                                BorderStroke(if (isSelected) 2.dp else 1.dp, Color.White),
                                CircleShape
                            )
                            .clickable {
                                if (isLockedTheme) {
                                    PremiumManager.showUpgrade()
                                } else {
                                    selectedGradientIndex = i
                                }
                            }
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLockedTheme) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Premium Locked Theme",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(16.dp)
                            )
                        } else if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Start This Journey Button with Premium Gradient
            Button(
                onClick = {
                    if (isFormValid) {
                        val limit = SubscriptionConfig.getLimits(isPremium).journeysLimit
                        if (existingTripsCount >= limit) {
                            PremiumManager.showUpgrade()
                        } else {
                            val newTrip = Trip(
                                id = "trip_${UUID.randomUUID()}",
                                destinationName = destinationName,
                                country = country,
                                startDate = startDate,
                                endDate = endDate,
                                coverImage = coverImagePath ?: "img_dest_japan_1783080879621",
                                description = description,
                                accentGradientIndex = selectedGradientIndex,
                                latitude = latitude,
                                longitude = longitude
                            )
                            onSaveTrip(newTrip)
                        }
                    }
                },
                enabled = isFormValid,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    disabledContainerColor = Color.LightGray.copy(alpha = 0.4f)
                ),
                contentPadding = PaddingValues(),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(
                        if (isFormValid) Brush.linearGradient(listOf(Color(0xFFFF512F), Color(0xFFDD2476)))
                        else Brush.linearGradient(listOf(Color.LightGray, Color.LightGray)),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .testTag("save_trip_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(imageVector = Icons.Default.Explore, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Start This Journey",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Secondary Action: Build Journey from photos
            OutlinedButton(
                onClick = onBuildFromPhotosClick,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.5.dp, Color(0xFFDD2476)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFDD2476)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("build_from_photos_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color(0xFFDD2476)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Build from photos",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFFDD2476)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Choose your travel photos and Wonderlog will organise them by day and place.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF0F172A).copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(48.dp))
        }
    }

    // Modal Photo Source Dialog (Camera / Gallery)
    if (showPhotoSourceDialog) {
        Dialog(onDismissRequest = { showPhotoSourceDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Choose Cover Photo Source",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    Button(
                        onClick = {
                            showPhotoSourceDialog = false
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Gallery", fontWeight = FontWeight.Bold)
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Button(
                        onClick = {
                            showPhotoSourceDialog = false
                            cameraLauncher.launch(null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDD2476)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Camera Capture", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
