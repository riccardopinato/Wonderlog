package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.smartjourney.*
import com.example.ui.components.SmartJourneyLimitBanner
import com.example.ui.components.SmartJourneyStopCard
import java.time.format.DateTimeFormatter

@Composable
fun SmartJourneyDraftScreen(
    viewModel:
        SmartJourneyViewModel,

    onBack:
        () -> Unit,

    onUpgradeRequested:
        () -> Unit,

    onJourneyCreated:
        (String) -> Unit
) {

    val state by
        viewModel
            .state
            .collectAsState()

    val current =
        state

    if (
        current is
        SmartJourneyUiState
            .Success
    ) {

        LaunchedEffect(
            current
        ) {

            onJourneyCreated(
                current
                    .result
                    .journeyId
            )
        }

        return
    }

    val draft =
        when (
            current
        ) {

            is SmartJourneyUiState
                .DraftReady ->
                current.draft

            is SmartJourneyUiState
                .Saving ->
                current.draft

            else ->
                return
        }

    val allowance =
        when (
            current
        ) {

            is SmartJourneyUiState
                .DraftReady ->
                current.allowance

            is SmartJourneyUiState
                .Saving ->
                current.allowance

            else ->
                null
        }

    val saving =
        current is
            SmartJourneyUiState
                .Saving

    var stopBeingRenamed by
        remember {
            mutableStateOf<
                SmartJourneyStopDraft?
            >(
                null
            )
        }

    var stopRenameText by
        remember {
            mutableStateOf(
                ""
            )
        }

    var pendingMerge by
        remember {
            mutableStateOf<
                Triple<
                    Int,
                    String,
                    String
                >?
            >(
                null
            )
        }

    var showPhotoLimitConfirmation by
        remember {
            mutableStateOf(
                false
            )
        }

    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(
                                0xFFFFF7F3
                            ),
                            Color(
                                0xFFF7F5FF
                            ),
                            Color.White
                        )
                    )
                )
    ) {

        Column(
            modifier =
                Modifier.fillMaxSize()
        ) {

            Row(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal =
                                16.dp,
                            vertical =
                                12.dp
                        ),

                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                IconButton(
                    onClick =
                        onBack,

                    enabled =
                        !saving
                ) {

                    Icon(
                        imageVector =
                            Icons.Default
                                .ArrowBack,

                        contentDescription =
                            "Back"
                    )
                }

                Column {

                    Text(
                        text =
                            "Review Journey",

                        fontWeight =
                            FontWeight.Bold,

                        fontSize =
                            20.sp
                    )

                    Text(
                        text =
                            "Wonderlog organises your photos. You write the story.",

                        style =
                            MaterialTheme
                                .typography
                                .bodySmall,

                        color =
                            Color.Black.copy(
                                alpha =
                                    0.48f
                            )
                    )
                }
            }

            LazyColumn(
                modifier =
                    Modifier.weight(
                        1f
                    ),

                contentPadding =
                    PaddingValues(
                        start =
                            20.dp,
                        end =
                            20.dp,
                        bottom =
                            140.dp
                    ),

                verticalArrangement =
                    Arrangement.spacedBy(
                        14.dp
                    )
            ) {

                item {

                    OutlinedTextField(
                        value =
                            draft.title,

                        onValueChange =
                            viewModel::
                                renameJourney,

                        label = {

                            Text(
                                "Journey name"
                            )
                        },

                        modifier =
                            Modifier.fillMaxWidth(),

                        singleLine =
                            true,

                        shape =
                            RoundedCornerShape(
                                16.dp
                            )
                    )

                    Spacer(
                        Modifier.height(
                            10.dp
                        )
                    )

                    OutlinedTextField(
                        value =
                            draft.destination,

                        onValueChange =
                            viewModel::
                                changeDestination,

                        label = {

                            Text(
                                "Destination"
                            )
                        },

                        modifier =
                            Modifier.fillMaxWidth(),

                        singleLine =
                            true,

                        shape =
                            RoundedCornerShape(
                                16.dp
                            )
                    )

                    Spacer(
                        Modifier.height(
                            14.dp
                        )
                    )

                    Text(
                        text =
                            "${draft.includedPhotos.size} included • ${draft.excludedPhotoCount} excluded • ${draft.days.size} days • ${draft.stopCount} stops",

                        style =
                            MaterialTheme
                                .typography
                                .bodySmall,

                        color =
                            Color.Black.copy(
                                alpha =
                                    0.58f
                            )
                    )

                    allowance
                        ?.let {

                            Spacer(
                                Modifier.height(
                                    14.dp
                                )
                            )

                            SmartJourneyLimitBanner(
                                allowance =
                                    it,

                                onUpgrade =
                                    onUpgradeRequested
                            )
                        }

                    Spacer(
                        Modifier.height(
                            16.dp
                        )
                    )

                    Row(
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Switch(
                            checked =
                                draft
                                    .createMemoryDrafts,

                            onCheckedChange =
                                viewModel::
                                    setAllMemoryDrafts
                        )

                        Spacer(
                            Modifier.width(
                                10.dp
                            )
                        )

                        Column {

                            Text(
                                text =
                                    "Create Memory drafts",

                                fontWeight =
                                    FontWeight.SemiBold
                            )

                            Text(
                                text =
                                    "Each stop becomes an empty Memory you can write later.",

                                style =
                                    MaterialTheme
                                        .typography
                                        .bodySmall,

                                color =
                                    Color.Gray
                            )
                        }
                    }
                }

                draft.days
                    .forEach {
                        day ->

                        item(
                            key =
                                "day-${day.index}"
                        ) {

                            Spacer(
                                Modifier.height(
                                    10.dp
                                )
                            )

                            Text(
                                text =
                                    "${day.title.uppercase()} — ${
                                        day.date.format(
                                            DateTimeFormatter.ofPattern(
                                                "dd MMM"
                                            )
                                        )
                                    }",

                                fontWeight =
                                    FontWeight.Black,

                                fontSize =
                                    15.sp,

                                color =
                                    Color(
                                        0xFF334155
                                    )
                            )
                        }

                        itemsIndexed(
                            items =
                                day.stops,

                            key = {
                                _,
                                stop ->

                                stop.id
                            }
                        ) {
                                stopIndex,
                                stop
                            ->

                            val previousStop =
                                day.stops
                                    .getOrNull(
                                        stopIndex - 1
                                    )

                            val nextStop =
                                day.stops
                                    .getOrNull(
                                        stopIndex + 1
                                    )

                            val stopPhotos =
                                stop.photoIds
                                    .mapNotNull {
                                        id ->

                                        draft.photos
                                            .firstOrNull {
                                                photo ->
                                                photo.id ==
                                                    id
                                            }
                                    }

                            SmartJourneyStopCard(
                                stop =
                                    stop,

                                photos =
                                    stopPhotos,

                                onRename = {

                                    stopBeingRenamed =
                                        stop

                                    stopRenameText =
                                        stop.title
                                },

                                onToggleMemory = {
                                    enabled ->

                                    viewModel
                                        .setMemoryDraftEnabled(
                                            stopId =
                                                stop.id,

                                            enabled =
                                                enabled
                                        )
                                },

                                onTogglePhoto = {
                                    photoId ->

                                    viewModel
                                        .togglePhotoIncluded(
                                            photoId
                                        )
                                },

                                onMovePhotoPrevious = {
                                    photoId ->

                                    previousStop
                                        ?.let {
                                            destination ->

                                            viewModel
                                                .movePhoto(
                                                    photoId =
                                                        photoId,

                                                    destinationStopId =
                                                        destination.id
                                                )
                                        }
                                },

                                onMovePhotoNext = {
                                    photoId ->

                                    nextStop
                                        ?.let {
                                            destination ->

                                            viewModel
                                                .movePhoto(
                                                    photoId =
                                                        photoId,

                                                    destinationStopId =
                                                        destination.id
                                                )
                                        }
                                },

                                canMovePrevious =
                                    previousStop !=
                                        null,

                                canMoveNext =
                                    nextStop !=
                                        null,

                                onMergePrevious =
                                    previousStop
                                        ?.let {
                                            previous ->

                                            {

                                                pendingMerge =
                                                    Triple(
                                                        day.index,
                                                        previous.id,
                                                        stop.id
                                                    )
                                            }
                                        },

                                onMergeNext =
                                    nextStop
                                        ?.let {
                                            next ->

                                            {

                                                pendingMerge =
                                                    Triple(
                                                        day.index,
                                                        stop.id,
                                                        next.id
                                                    )
                                            }
                                        }
                            )
                        }
                    }
            }
        }

        Surface(
            modifier =
                Modifier
                    .align(
                        Alignment.BottomCenter
                    )
                    .fillMaxWidth(),

            color =
                Color.White.copy(
                    alpha =
                        0.96f
                ),

            shadowElevation =
                12.dp
        ) {

            Column(
                modifier =
                    Modifier.padding(
                        horizontal =
                            20.dp,
                        vertical =
                            14.dp
                    )
            ) {

                allowance
                    ?.let {

                        if (
                            it.hasBlockedPhotos &&
                            !it.journeyLimitReached
                        ) {

                            Text(
                                text =
                                    "${it.allowedPhotoCount} photos will be imported.",

                                modifier =
                                    Modifier.fillMaxWidth(),

                                style =
                                    MaterialTheme
                                        .typography
                                        .labelMedium,

                                color =
                                    Color(
                                        0xFF92400E
                                    ),

                                textAlign =
                                    androidx.compose.ui.text.style
                                        .TextAlign
                                        .Center
                            )

                            Spacer(
                                Modifier.height(
                                    6.dp
                                )
                            )
                        }
                    }

                Button(
                    onClick = {

                        when {

                            allowance
                                ?.journeyLimitReached ==
                                true ->

                                onUpgradeRequested()

                            allowance
                                ?.hasBlockedPhotos ==
                                true ->

                                showPhotoLimitConfirmation =
                                    true

                            else ->

                                viewModel
                                    .createJourney()
                        }
                    },

                    enabled =
                        !saving &&
                            draft
                                .includedPhotos
                                .isNotEmpty(),

                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(
                                56.dp
                            ),

                    shape =
                        RoundedCornerShape(
                            18.dp
                        )
                ) {

                    if (
                        saving
                    ) {

                        CircularProgressIndicator(
                            modifier =
                                Modifier.size(
                                    20.dp
                                ),

                            strokeWidth =
                                2.dp
                        )

                    } else {

                        Icon(
                            imageVector =
                                Icons.Default
                                    .Check,

                            contentDescription =
                                null
                        )

                        Spacer(
                            Modifier.width(
                                8.dp
                            )
                        )

                        Text(
                            text =
                                if (
                                    allowance
                                        ?.journeyLimitReached ==
                                    true
                                ) {

                                    "Unlock Premium"

                                } else {

                                    "Create Journey"
                                },

                            fontWeight =
                                FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    stopBeingRenamed
        ?.let {
            stop ->

            AlertDialog(
                onDismissRequest = {

                    stopBeingRenamed =
                        null
                },

                title = {

                    Text(
                        "Rename stop"
                    )
                },

                text = {

                    OutlinedTextField(
                        value =
                            stopRenameText,

                        onValueChange = {

                            stopRenameText =
                                it
                        },

                        singleLine =
                            true
                    )
                },

                confirmButton = {

                    TextButton(
                        onClick = {

                            viewModel
                                .renameStop(
                                    stopId =
                                        stop.id,

                                    title =
                                        stopRenameText
                                )

                            stopBeingRenamed =
                                null
                        }
                    ) {

                        Text(
                            "Save"
                        )
                    }
                },

                dismissButton = {

                    TextButton(
                        onClick = {

                            stopBeingRenamed =
                                null
                        }
                    ) {

                        Text(
                            "Cancel"
                        )
                    }
                }
            )
        }

    pendingMerge
        ?.let {
            merge ->

            AlertDialog(
                onDismissRequest = {

                    pendingMerge =
                        null
                },

                title = {

                    Text(
                        "Merge these stops?"
                    )
                },

                text = {

                    Text(
                        "Their photos will be grouped into one stop. You can still move or exclude individual photos afterwards."
                    )
                },

                confirmButton = {

                    TextButton(
                        onClick = {

                            viewModel
                                .mergeStops(
                                    dayIndex =
                                        merge.first,

                                    firstStopId =
                                        merge.second,

                                    secondStopId =
                                        merge.third
                                )

                            pendingMerge =
                                null
                        }
                    ) {

                        Text(
                            "Merge"
                        )
                    }
                },

                dismissButton = {

                    TextButton(
                        onClick = {

                            pendingMerge =
                                null
                        }
                    ) {

                        Text(
                            "Cancel"
                        )
                    }
                }
            )
        }

    if (
        showPhotoLimitConfirmation
    ) {

        val currentAllowance =
            allowance

        if (
            currentAllowance != null
        ) {

            AlertDialog(
                onDismissRequest = {

                    showPhotoLimitConfirmation =
                        false
                },

                title = {

                    Text(
                        if (
                            currentAllowance
                                .requiresUpgrade
                        ) {

                            "Some photos require Premium"

                        } else {

                            "Photo limit"
                        }
                    )
                },

                text = {

                    Text(
                        "${currentAllowance.allowedPhotoCount} of ${currentAllowance.selectedPhotoCount} included photos will be imported into this Journey. ${
                            if (
                                currentAllowance
                                    .requiresUpgrade
                            ) {
                                "Upgrade to Wonderlog Premium to increase the Journey photo limit."
                            } else {
                                "The remaining photos will not be copied."
                            }
                        }"
                    )
                },

                confirmButton = {

                    TextButton(
                        onClick = {

                            showPhotoLimitConfirmation =
                                false

                            viewModel
                                .createJourney()
                        }
                    ) {

                        Text(
                            "Continue"
                        )
                    }
                },

                dismissButton = {

                    Row {

                        if (
                            currentAllowance
                                .requiresUpgrade
                        ) {

                            TextButton(
                                onClick = {

                                    showPhotoLimitConfirmation =
                                        false

                                    onUpgradeRequested()
                                }
                            ) {

                                Text(
                                    "Upgrade"
                                )
                            }
                        }

                        TextButton(
                            onClick = {

                                showPhotoLimitConfirmation =
                                    false
                            }
                        ) {

                            Text(
                                "Cancel"
                            )
                        }
                    }
                }
            )
        }
    }
}
