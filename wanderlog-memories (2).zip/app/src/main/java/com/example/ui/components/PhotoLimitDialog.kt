package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.premium.PhotoImportAllowance

@Composable
fun PhotoLimitDialog(
    allowance: PhotoImportAllowance,
    onImportAllowed: () -> Unit,
    onUnlockPremium: () -> Unit,
    onDismiss: () -> Unit
) {

    AlertDialog(
        onDismissRequest = onDismiss,

        containerColor = Color(0xFF141927),

        shape = RoundedCornerShape(26.dp),

        title = {

            Text(
                text = "Your free album is almost full.",
                color = Color.White,
                fontWeight = FontWeight.ExtraBold
            )
        },

        text = {

            Column {

                Text(
                    text =
                        "You selected ${allowance.selectedCount} photos, but this Journey has room for only ${allowance.allowedCount} more in the free version.",
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(
                    modifier = Modifier.height(16.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush =
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFFF4D9D)
                                            .copy(alpha = 0.14f),
                                        Color(0xFF8B5CF6)
                                            .copy(alpha = 0.14f)
                                    )
                                ),
                            shape =
                                RoundedCornerShape(18.dp)
                        )
                        .padding(16.dp)
                ) {

                    Text(
                        text =
                            "${allowance.currentCount} / ${allowance.limit} photos used",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(
                        modifier = Modifier.height(5.dp)
                    )

                    Text(
                        text =
                            "Premium expands every Journey to 100 photos.",
                        color =
                            Color.White.copy(alpha = 0.62f),
                        fontSize = 12.sp
                    )
                }
            }
        },

        confirmButton = {

            Column(
                modifier = Modifier.fillMaxWidth()
            ) {

                Button(
                    onClick = onUnlockPremium,
                    modifier =
                        Modifier.fillMaxWidth(),
                    shape =
                        RoundedCornerShape(16.dp),
                    colors =
                        ButtonDefaults.buttonColors(
                            containerColor =
                                Color(0xFFFF4D9D)
                        )
                ) {

                    Text(
                        text = "Unlock 100 photos",
                        fontWeight = FontWeight.Bold
                    )
                }

                if (allowance.allowedCount > 0) {

                    Spacer(
                        modifier =
                            Modifier.height(6.dp)
                    )

                    Button(
                        onClick = onImportAllowed,
                        modifier =
                            Modifier.fillMaxWidth(),
                        shape =
                            RoundedCornerShape(16.dp),
                        colors =
                            ButtonDefaults.buttonColors(
                                containerColor =
                                    Color.White.copy(
                                        alpha = 0.10f
                                    )
                            )
                    ) {

                        Text(
                            text =
                                "Import ${allowance.allowedCount} photos",
                            color = Color.White,
                            fontWeight =
                                FontWeight.Bold
                        )
                    }
                }
            }
        },

        dismissButton = {

            TextButton(
                onClick = onDismiss
            ) {

                Text(
                    text = "Cancel",
                    color =
                        Color.White.copy(
                            alpha = 0.55f
                        )
                )
            }
        }
    )
}
