package com.example.smartjourney

import android.content.Context
import android.net.Uri
import com.example.storage.PhotoMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext

class SmartJourneyIntegrationRepository(
    private val context:
        Context,
    private val integration:
        SmartJourneyPersistenceAdapter,
    private val creationPolicy:
        SmartJourneyCreationPolicy =
        SmartJourneyCreationPolicy()
) : SmartJourneyRepository {

    @Volatile
    private var currentDraft:
        SmartJourneyDraft? = null

    fun buildDraftFromPhotos(
        uris: List<Uri>,
        options: SmartJourneyBuildOptions =
            SmartJourneyBuildOptions()
    ): Flow<SmartJourneyAnalysisProgress> =
        flow {

            emit(
                SmartJourneyAnalysisProgress(
                    processed = 0,
                    total = uris.size,
                    phase =
                        SmartJourneyAnalysisPhase
                            .READING_METADATA
                )
            )

            val sourcePhotos =
                mutableListOf<
                    SmartJourneySourcePhoto
                >()

            uris.forEachIndexed {
                    index,
                    uri
                ->

                val sourceMetadata =
                    PhotoMetadataReader
                        .read(
                            context =
                                context,
                            uri =
                                uri
                        )

                val modifiedAt =
                    integration
                        .readModifiedTimestamp(
                            uri
                        )

                sourcePhotos +=
                    SmartJourneySourcePhoto(
                        sourceUri =
                            uri.toString(),
                        originalIndex =
                            index,
                        capturedAt =
                            sourceMetadata
                                .capturedAt,
                        modifiedAt =
                            modifiedAt,
                        latitude =
                            sourceMetadata
                                .latitude,
                        longitude =
                            sourceMetadata
                                .longitude,
                        placeLabel =
                            null,
                        included =
                            true
                    )

                emit(
                    SmartJourneyAnalysisProgress(
                        processed =
                            index + 1,
                        total =
                            uris.size,
                        phase =
                            SmartJourneyAnalysisPhase
                                .READING_METADATA
                    )
                )
            }

            emit(
                SmartJourneyAnalysisProgress(
                    processed =
                        uris.size,
                    total =
                        uris.size,
                    phase =
                        SmartJourneyAnalysisPhase
                            .GROUPING_DAYS
                )
            )

            emit(
                SmartJourneyAnalysisProgress(
                    processed =
                        uris.size,
                    total =
                        uris.size,
                    phase =
                        SmartJourneyAnalysisPhase
                            .CLUSTERING_LOCATIONS
                )
            )

            emit(
                SmartJourneyAnalysisProgress(
                    processed =
                        uris.size,
                    total =
                        uris.size,
                    phase =
                        SmartJourneyAnalysisPhase
                            .RESOLVING_PLACES
                )
            )

            val engine =
                SmartJourneyReconstructionEngine(
                    options
                )

            val draft =
                engine.reconstruct(
                    photos =
                        sourcePhotos,

                    resolvePlace = {
                            latitude,
                            longitude
                        ->

                        integration
                            .reverseGeocode(
                                latitude,
                                longitude
                            )
                    }
                )

            emit(
                SmartJourneyAnalysisProgress(
                    processed =
                        uris.size,
                    total =
                        uris.size,
                    phase =
                        SmartJourneyAnalysisPhase
                            .BUILDING_DRAFT
                )
            )

            currentDraft =
                draft

            emit(
                SmartJourneyAnalysisProgress(
                    processed =
                        uris.size,
                    total =
                        uris.size,
                    phase =
                        SmartJourneyAnalysisPhase
                            .COMPLETE
                )
            )
        }

    fun getCurrentDraft():
        SmartJourneyDraft? =
        currentDraft

    fun updateDraft(
        draft: SmartJourneyDraft
    ) {
        currentDraft =
            draft
    }

    fun clearDraft() {
        currentDraft =
            null
    }

    override suspend fun analyseSelectedPhotos(
        uriStrings: List<String>,
        onProgress:
            suspend (
                SmartJourneyAnalysisProgress
            ) -> Unit
    ): Result<SmartJourneyDraft> =
        withContext(Dispatchers.IO) {
            runCatching {
                val uris = uriStrings.map { Uri.parse(it) }
                val options = SmartJourneyBuildOptions()
                buildDraftFromPhotos(uris, options).collect { progress ->
                    onProgress(progress)
                }
                currentDraft ?: throw IllegalStateException("Unable to build draft from photos.")
            }
        }

    override suspend fun evaluateCreationAllowance(
        draft:
            SmartJourneyDraft
    ): Result<
        SmartJourneyCreationAllowance
    > =
        withContext(
            Dispatchers.IO
        ) {

            runCatching {

                val currentJourneyCount =
                    integration
                        .getCurrentJourneyCount()

                val premium =
                    com.example.premium
                        .PremiumEntitlementStore
                        .isPremium
                        .value

                creationPolicy
                    .evaluate(
                        currentJourneyCount =
                            currentJourneyCount,

                        selectedPhotoCount =
                            draft
                                .includedPhotos
                                .size,

                        isPremium =
                            premium
                    )
            }
        }

    override suspend fun createJourneyFromDraft(
        draft:
            SmartJourneyDraft
    ): Result<
        SmartJourneyCreationResult
    > =
        withContext(
            Dispatchers.IO
        ) {

            runCatching {

                val includedPhotos =
                    draft.photos
                        .filter {
                            it.included
                        }
                        .sortedWith(
                            compareBy<
                                SmartJourneyPhoto
                            > {

                                it.source
                                    .effectiveTimestamp
                                    ?: Long.MAX_VALUE

                            }.thenBy {

                                it.source
                                    .originalIndex
                            }
                        )

                require(
                    includedPhotos
                        .isNotEmpty()
                ) {
                    "The Journey must contain at least one photo."
                }

                val allowance =
                    evaluateCreationAllowance(
                        draft
                    )
                        .getOrThrow()

                if (
                    !allowance
                        .journeyCreationAllowed
                ) {

                    throw SmartJourneyLimitException(
                        "Your current plan has reached the Journey limit."
                    )
                }

                if (
                    allowance
                        .allowedPhotoCount <=
                    0
                ) {

                    throw SmartJourneyLimitException(
                        "No additional photos can be added to this Journey."
                    )
                }

                /*
                 * Smart Journey may analyse more photos than the
                 * current subscription allows.
                 *
                 * ONLY allowed photos are copied into Wonderlog
                 * when the user confirms creation.
                 */

                val importablePhotos =
                    includedPhotos
                        .take(
                            allowance
                                .allowedPhotoCount
                        )

                val importableDraftPhotoIds =
                    importablePhotos
                        .map {
                            it.id
                        }
                        .toSet()

                /*
                 * 1. CREATE JOURNEY
                 *
                 * Reuse current Journey/Trip entity creation.
                 */

                val journeyId =
                    integration
                        .createJourney(
                            title =
                                draft.title,
                            destination =
                                draft.destination,
                            startDate =
                                draft.startDate,
                            endDate =
                                draft.endDate
                        )

                /*
                 * 2. IMPORT ALBUM PHOTOS
                 *
                 * Iterate ONLY importablePhotos.
                 */

                val realPhotoIdByDraftId =
                    mutableMapOf<
                        String,
                        String
                    >()

                importablePhotos
                    .forEach {
                        draftPhoto ->

                        val realPhotoId =
                            integration
                                .importAlbumPhoto(
                                    journeyId =
                                        journeyId,

                                    uri =
                                        Uri.parse(
                                            draftPhoto
                                                .source
                                                .sourceUri
                                        )
                                )

                        realPhotoIdByDraftId[
                            draftPhoto.id
                        ] =
                            realPhotoId
                    }

                /*
                 * 3. CREATE EMPTY MEMORY DRAFTS
                 *
                 * Reuse current Memory entity and MemoryPhotoCrossRef.
                 * DO NOT create a Memory if none of that stop's photos were actually imported.
                 */

                var memoryCount =
                    0

                draft.days.forEach {
                    day ->

                    day.stops
                        .filter {
                            it.createMemory
                        }
                        .forEach {
                            stop ->

                            val stopPhotoIds =
                                stop.photoIds
                                    .filter {
                                        importableDraftPhotoIds.contains(it)
                                    }
                                    .mapNotNull {
                                        realPhotoIdByDraftId[
                                            it
                                        ]
                                    }

                            if (stopPhotoIds.isNotEmpty()) {
                                integration
                                    .createEmptyMemoryDraft(
                                        journeyId =
                                            journeyId,
                                        title =
                                            stop.title,
                                        date =
                                            day.date,
                                        locationName =
                                            stop.placeLabel
                                                .orEmpty(),
                                        latitude =
                                            stop.latitude,
                                        longitude =
                                            stop.longitude,
                                        albumPhotoIds =
                                            stopPhotoIds
                                    )

                                memoryCount++
                            }
                        }
                }

                clearDraft()

                SmartJourneyCreationResult(
                    journeyId =
                        journeyId,
                    photoCount =
                        realPhotoIdByDraftId
                            .size,
                    memoryDraftCount =
                        memoryCount
                )
            }
        }
}
