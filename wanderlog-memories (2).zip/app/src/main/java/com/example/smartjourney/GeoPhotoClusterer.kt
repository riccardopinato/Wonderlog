package com.example.smartjourney

import kotlin.math.abs

class GeoPhotoClusterer(
    private val options:
        SmartJourneyBuildOptions
) {

    data class StopCluster(
        val photos:
            List<SmartJourneySourcePhoto>,

        val latitude:
            Double?,

        val longitude:
            Double?
    )

    fun cluster(
        photos:
            List<SmartJourneySourcePhoto>
    ): List<StopCluster> {

        if (
            photos.isEmpty()
        ) {
            return emptyList()
        }

        val sorted =
            photos.sortedWith(
                compareBy<
                    SmartJourneySourcePhoto
                > {
                    it.effectiveTimestamp
                        ?: Long.MAX_VALUE
                }.thenBy {
                    it.originalIndex
                }
            )

        val clusters =
            mutableListOf<
                MutableList<
                    SmartJourneySourcePhoto
                >
            >()

        sorted.forEach {
            photo ->

            val current =
                clusters
                    .lastOrNull()

            if (
                current == null
            ) {

                clusters +=
                    mutableListOf(
                        photo
                    )

                return@forEach
            }

            if (
                shouldJoin(
                    current,
                    photo
                )
            ) {

                current +=
                    photo

            } else {

                clusters +=
                    mutableListOf(
                        photo
                    )
            }
        }

        mergeOrphanClusters(
            clusters
        )

        return clusters
            .filter {
                it.isNotEmpty()
            }
            .map {
                cluster ->

                val coordinates =
                    cluster
                        .mapNotNull {
                            photo ->

                            val lat =
                                photo.latitude

                            val lon =
                                photo.longitude

                            if (
                                GeoMath
                                    .isValidCoordinate(
                                        lat,
                                        lon
                                    )
                            ) {

                                Pair(
                                    lat!!,
                                    lon!!
                                )

                            } else {

                                null
                            }
                        }

                val centroid =
                    GeoMath.centroid(
                        coordinates
                    )

                StopCluster(
                    photos =
                        cluster.toList(),

                    latitude =
                        centroid?.first,

                    longitude =
                        centroid?.second
                )
            }
    }

    private fun shouldJoin(
        current:
            List<
                SmartJourneySourcePhoto
            >,

        candidate:
            SmartJourneySourcePhoto
    ): Boolean {

        val previous =
            current.last()

        val timeClose =
            isTimeClose(
                previous,
                candidate
            )

        val previousHasGps =
            GeoMath
                .isValidCoordinate(
                    previous.latitude,
                    previous.longitude
                )

        val candidateHasGps =
            GeoMath
                .isValidCoordinate(
                    candidate.latitude,
                    candidate.longitude
                )

        if (
            previousHasGps &&
            candidateHasGps
        ) {

            val distance =
                GeoMath
                    .distanceMeters(
                        previous.latitude!!,
                        previous.longitude!!,
                        candidate.latitude!!,
                        candidate.longitude!!
                    )

            return timeClose &&
                distance <=
                options
                    .geoClusterRadiusMeters
        }

        /*
         * Missing GPS does not automatically create
         * a new stop.
         *
         * Temporal proximity is the fallback.
         */

        return timeClose
    }

    private fun isTimeClose(
        first:
            SmartJourneySourcePhoto,

        second:
            SmartJourneySourcePhoto
    ): Boolean {

        val firstTimestamp =
            first
                .effectiveTimestamp

        val secondTimestamp =
            second
                .effectiveTimestamp

        if (
            firstTimestamp == null ||
            secondTimestamp == null
        ) {

            return true
        }

        val difference =
            abs(
                secondTimestamp -
                    firstTimestamp
            )

        return difference <=
            options
                .maxStopTimeGapMinutes *
            60_000L
    }

    private fun mergeOrphanClusters(
        clusters:
            MutableList<
                MutableList<
                    SmartJourneySourcePhoto
                >
            >
    ) {

        if (
            clusters.size <= 1
        ) {
            return
        }

        var index =
            0

        while (
            index <
            clusters.size
        ) {

            val cluster =
                clusters[
                    index
                ]

            val hasGps =
                cluster.any {
                    GeoMath
                        .isValidCoordinate(
                            it.latitude,
                            it.longitude
                        )
                }

            val tooSmall =
                cluster.size <
                    options
                        .minimumPhotosPerStop

            if (
                !hasGps ||
                tooSmall
            ) {

                val previous =
                    clusters
                        .getOrNull(
                            index - 1
                        )

                val next =
                    clusters
                        .getOrNull(
                            index + 1
                        )

                val destination =
                    when {

                        previous != null &&
                        next != null -> {

                            if (
                                temporalDistance(
                                    cluster,
                                    previous
                                ) <=
                                temporalDistance(
                                    cluster,
                                    next
                                )
                            ) {
                                previous
                            } else {
                                next
                            }
                        }

                        previous != null ->
                            previous

                        next != null ->
                            next

                        else ->
                            null
                    }

                if (
                    destination != null &&
                    isWithinOrphanWindow(
                        cluster,
                        destination
                    )
                ) {

                    destination +=
                        cluster

                    destination
                        .sortBy {
                            it.effectiveTimestamp
                                ?: Long.MAX_VALUE
                        }

                    clusters
                        .removeAt(
                            index
                        )

                    continue
                }
            }

            index++
        }
    }

    private fun temporalDistance(
        first:
            List<
                SmartJourneySourcePhoto
            >,

        second:
            List<
                SmartJourneySourcePhoto
            >
    ): Long {

        val firstTimestamp =
            first
                .mapNotNull {
                    it.effectiveTimestamp
                }
                .minOrNull()
                ?: return Long.MAX_VALUE

        val secondTimestamp =
            second
                .mapNotNull {
                    it.effectiveTimestamp
                }
                .minOrNull()
                ?: return Long.MAX_VALUE

        return kotlin.math.abs(
            firstTimestamp -
                secondTimestamp
        )
    }

    private fun isWithinOrphanWindow(
        first:
            List<
                SmartJourneySourcePhoto
            >,

        second:
            List<
                SmartJourneySourcePhoto
            >
    ): Boolean {

        val distance =
            temporalDistance(
                first,
                second
            )

        return distance <=
            options
                .orphanAssignmentTimeWindowMinutes *
            60_000L
    }
}
