package com.example.smartjourney

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SmartJourneyViewModel(
    private val repository:
        SmartJourneyRepository
) : ViewModel() {

    private val _state =
        MutableStateFlow<
            SmartJourneyUiState
        >(
            SmartJourneyUiState.Idle
        )

    val state:
        StateFlow<
            SmartJourneyUiState
        > =
        _state.asStateFlow()

    fun analyse(
        uriStrings:
            List<String>
    ) {

        if (
            uriStrings
                .isEmpty()
        ) {
            return
        }

        val uniqueUris =
            uriStrings
                .distinct()

        viewModelScope.launch {

            repository
                .analyseSelectedPhotos(
                    uriStrings =
                        uniqueUris,

                    onProgress = {
                        progress ->

                        _state.value =
                            SmartJourneyUiState
                                .Analysing(
                                    progress
                                )
                    }
                )
                .onSuccess {
                    draft ->

                    publishDraftWithAllowance(
                        draft
                    )
                }
                .onFailure {
                    error ->

                    _state.value =
                        SmartJourneyUiState
                            .Error(
                                error.message
                                    ?: "Unable to analyse these photos."
                            )
                }
        }
    }

    fun renameJourney(
        title:
            String
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .renameJourney(
                    draft,
                    title
                )
        }
    }

    fun changeDestination(
        destination:
            String
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .changeDestination(
                    draft,
                    destination
                )
        }
    }

    fun renameStop(
        stopId:
            String,

        title:
            String
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .renameStop(
                    draft,
                    stopId,
                    title
                )
        }
    }

    fun setPhotoIncluded(
        photoId:
            String,

        included:
            Boolean
    ) {

        updateDraft(
            refreshAllowance =
                true
        ) {
            draft ->

            SmartJourneyDraftEditor
                .setPhotoIncluded(
                    draft,
                    photoId,
                    included
                )
        }
    }

    fun togglePhotoIncluded(
        photoId:
            String
    ) {

        val current =
            currentDraft()
                ?: return

        val photo =
            current
                .photos
                .firstOrNull {
                    it.id ==
                        photoId
                }
                ?: return

        setPhotoIncluded(
            photoId =
                photoId,

            included =
                !photo.included
        )
    }

    fun setMemoryDraftEnabled(
        stopId:
            String,

        enabled:
            Boolean
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .setMemoryDraftEnabled(
                    draft,
                    stopId,
                    enabled
                )
        }
    }

    fun setAllMemoryDrafts(
        enabled:
            Boolean
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .setAllMemoryDrafts(
                    draft,
                    enabled
                )
        }
    }

    fun mergeStops(
        dayIndex:
            Int,

        firstStopId:
            String,

        secondStopId:
            String
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .mergeAdjacentStops(
                    draft =
                        draft,

                    dayIndex =
                        dayIndex,

                    firstStopId =
                        firstStopId,

                    secondStopId =
                        secondStopId
                )
        }
    }

    fun movePhoto(
        photoId:
            String,

        destinationStopId:
            String
    ) {

        updateDraft(
            refreshAllowance =
                false
        ) {
            draft ->

            SmartJourneyDraftEditor
                .movePhoto(
                    draft =
                        draft,

                    photoId =
                        photoId,

                    destinationStopId =
                        destinationStopId
                )
        }
    }

    fun refreshAllowance() {

        val draft =
            currentDraft()
                ?: return

        viewModelScope.launch {

            publishDraftWithAllowance(
                draft
            )
        }
    }

    fun createJourney() {

        val current =
            _state.value

        if (
            current !is
            SmartJourneyUiState
                .DraftReady
        ) {
            return
        }

        val draft =
            current.draft

        viewModelScope.launch {

            /*
             * Re-evaluate entitlement immediately before
             * persistence because subscription state may
             * have changed while the draft was open.
             */

            val allowance =
                repository
                    .evaluateCreationAllowance(
                        draft
                    )
                    .getOrElse {
                        error ->

                        _state.value =
                            SmartJourneyUiState
                                .Error(
                                    error.message
                                        ?: "Unable to check Journey limits."
                                )

                        return@launch
                    }

            if (
                !allowance
                    .journeyCreationAllowed
            ) {

                _state.value =
                    SmartJourneyUiState
                        .DraftReady(
                            draft =
                                draft,

                            allowance =
                                allowance
                        )

                return@launch
            }

            _state.value =
                SmartJourneyUiState
                    .Saving(
                        draft =
                            draft,

                        allowance =
                            allowance
                    )

            repository
                .createJourneyFromDraft(
                    draft
                )
                .onSuccess {
                    result ->

                    _state.value =
                        SmartJourneyUiState
                            .Success(
                                result
                            )
                }
                .onFailure {
                    error ->

                    _state.value =
                        SmartJourneyUiState
                            .Error(
                                error.message
                                    ?: "Unable to create Journey."
                            )
                }
        }
    }

    fun reset() {

        _state.value =
            SmartJourneyUiState.Idle
    }

    private fun currentDraft():
        SmartJourneyDraft? {

        return when (
            val current =
                _state.value
        ) {

            is SmartJourneyUiState
                .DraftReady ->
                current.draft

            is SmartJourneyUiState
                .Saving ->
                current.draft

            else ->
                null
        }
    }

    private fun updateDraft(
        refreshAllowance:
            Boolean,

        transform:
            (
                SmartJourneyDraft
            ) ->
            SmartJourneyDraft
    ) {

        val current =
            _state.value

        if (
            current !is
            SmartJourneyUiState
                .DraftReady
        ) {
            return
        }

        val updated =
            transform(
                current.draft
            )

        _state.value =
            SmartJourneyUiState
                .DraftReady(
                    draft =
                        updated,

                    allowance =
                        current.allowance
                )

        if (
            refreshAllowance
        ) {

            viewModelScope.launch {

                publishDraftWithAllowance(
                    updated
                )
            }
        }
    }

    private suspend fun publishDraftWithAllowance(
        draft:
            SmartJourneyDraft
    ) {

        val allowance =
            repository
                .evaluateCreationAllowance(
                    draft
                )
                .getOrNull()

        _state.value =
            SmartJourneyUiState
                .DraftReady(
                    draft =
                        draft,

                    allowance =
                        allowance
                )
    }
}
