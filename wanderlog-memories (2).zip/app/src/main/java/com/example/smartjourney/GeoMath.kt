package com.example.smartjourney

import kotlin.math.*

object GeoMath {

    private const val EARTH_RADIUS_METERS =
        6_371_000.0

    fun distanceMeters(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {

        val latitudeDelta =
            Math.toRadians(
                lat2 - lat1
            )

        val longitudeDelta =
            Math.toRadians(
                lon2 - lon1
            )

        val firstLatitude =
            Math.toRadians(
                lat1
            )

        val secondLatitude =
            Math.toRadians(
                lat2
            )

        val a =
            sin(
                latitudeDelta / 2
            ).pow(
                2
            ) +
                cos(
                    firstLatitude
                ) *
                cos(
                    secondLatitude
                ) *
                sin(
                    longitudeDelta / 2
                ).pow(
                    2
                )

        val c =
            2 *
                atan2(
                    sqrt(
                        a
                    ),
                    sqrt(
                        1 - a
                    )
                )

        return EARTH_RADIUS_METERS *
            c
    }

    fun centroid(
        coordinates:
            List<Pair<Double, Double>>
    ): Pair<Double, Double>? {

        if (
            coordinates.isEmpty()
        ) {
            return null
        }

        return Pair(
            coordinates
                .map {
                    it.first
                }
                .average(),

            coordinates
                .map {
                    it.second
                }
                .average()
        )
    }

    fun isValidCoordinate(
        latitude: Double?,
        longitude: Double?
    ): Boolean {

        if (
            latitude == null ||
            longitude == null
        ) {
            return false
        }

        return latitude in -90.0..90.0 &&
            longitude in -180.0..180.0
    }
}
