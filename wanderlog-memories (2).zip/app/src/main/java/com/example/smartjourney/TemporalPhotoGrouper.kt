package com.example.smartjourney

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class TemporalPhotoGrouper(
    private val zoneId:
        ZoneId =
        ZoneId.systemDefault()
) {

    data class DayGroup(
        val date:
            LocalDate,

        val photos:
            List<SmartJourneySourcePhoto>
    )

    fun group(
        photos:
            List<SmartJourneySourcePhoto>
    ): List<DayGroup> {

        if (
            photos.isEmpty()
        ) {
            return emptyList()
        }

        val sorted =
            photos
                .filter {
                    it.included
                }
                .sortedWith(
                    compareBy<
                        SmartJourneySourcePhoto
                    > {
                        it.effectiveTimestamp
                            ?: Long.MAX_VALUE
                    }.thenBy {
                        it.originalIndex
                    }
                )

        val timestamped =
            sorted.filter {
                it.effectiveTimestamp != null
            }

        val withoutTimestamp =
            sorted.filter {
                it.effectiveTimestamp == null
            }

        val groups =
            linkedMapOf<
                LocalDate,
                MutableList<
                    SmartJourneySourcePhoto
                >
            >()

        timestamped.forEach {
            photo ->

            val date =
                Instant
                    .ofEpochMilli(
                        photo
                            .effectiveTimestamp!!
                    )
                    .atZone(
                        zoneId
                    )
                    .toLocalDate()

            groups
                .getOrPut(
                    date
                ) {
                    mutableListOf()
                }
                .add(
                    photo
                )
        }

        if (
            withoutTimestamp
                .isNotEmpty()
        ) {

            /*
             * We do not invent dates.
             *
             * Photos with no usable timestamp are attached
             * to the nearest available day only to keep them
             * inside the draft.
             *
             * If there are no dated photos at all, use today's
             * local date only as a UI grouping placeholder.
             * The integration layer must not pretend this is
             * EXIF-derived truth.
             */

            val fallbackDate =
                groups.keys
                    .lastOrNull()
                    ?: LocalDate.now(
                        zoneId
                    )

            groups
                .getOrPut(
                    fallbackDate
                ) {
                    mutableListOf()
                }
                .addAll(
                    withoutTimestamp
                )
        }

        return groups
            .map {
                entry ->

                DayGroup(
                    date =
                        entry.key,

                    photos =
                        entry.value
                            .sortedBy {
                                it.originalIndex
                            }
                )
            }
            .sortedBy {
                it.date
            }
    }
}
