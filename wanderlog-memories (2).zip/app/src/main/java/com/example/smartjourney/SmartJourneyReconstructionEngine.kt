package com.example.smartjourney

import java.time.format.DateTimeFormatter
import java.util.UUID

class SmartJourneyReconstructionEngine(
    private val options:
        SmartJourneyBuildOptions =
        SmartJourneyBuildOptions()
) {

    suspend fun reconstruct(
        photos:
            List<
                SmartJourneySourcePhoto
            >,

        resolvePlace:
            suspend (
                Double,
                Double
            ) -> String?
    ): SmartJourneyDraft {

        require(
            photos.isNotEmpty()
        ) {
            "At least one photo is required."
        }

        val dayGroups =
            TemporalPhotoGrouper()
                .group(
                    photos
                )

        val geoClusterer =
            GeoPhotoClusterer(
                options
            )

        val allDraftPhotos =
            mutableListOf<
                SmartJourneyPhoto
            >()

        val days =
            mutableListOf<
                SmartJourneyDayDraft
            >()

        dayGroups
            .forEachIndexed {
                    dayIndex,
                    dayGroup
                ->

                val clusters =
                    geoClusterer
                        .cluster(
                            dayGroup.photos
                        )

                val stops =
                    mutableListOf<
                        SmartJourneyStopDraft
                    >()

                clusters
                    .forEachIndexed {
                            stopIndex,
                            cluster
                        ->

                        val stopId =
                            UUID
                                .randomUUID()
                                .toString()

                        val resolvedPlace =
                            if (
                                cluster.latitude != null &&
                                cluster.longitude != null
                            ) {

                                runCatching {

                                    resolvePlace(
                                        cluster.latitude,
                                        cluster.longitude
                                    )

                                }.getOrNull()

                            } else {

                                null
                            }

                        val metadataPlace =
                            cluster.photos
                                .mapNotNull {
                                    it.placeLabel
                                        ?.trim()
                                        ?.takeIf {
                                            value ->
                                            value.isNotBlank()
                                        }
                                }
                                .groupingBy {
                                    it
                                }
                                .eachCount()
                                .maxByOrNull {
                                    it.value
                                }
                                ?.key

                        val placeLabel =
                            resolvedPlace
                                ?: metadataPlace

                        val title =
                            placeLabel
                                ?: "Stop ${
                                    stopIndex + 1
                                }"

                        val photoIds =
                            cluster.photos
                                .map {
                                    source ->

                                    val id =
                                        UUID
                                            .randomUUID()
                                            .toString()

                                    allDraftPhotos +=
                                        SmartJourneyPhoto(
                                            id =
                                                id,

                                            source =
                                                source,

                                            dayIndex =
                                                dayIndex,

                                            stopId =
                                                stopId
                                        )

                                    id
                                }

                        stops +=
                            SmartJourneyStopDraft(
                                id =
                                    stopId,

                                dayIndex =
                                    dayIndex,

                                title =
                                    title,

                                latitude =
                                    cluster.latitude,

                                longitude =
                                    cluster.longitude,

                                placeLabel =
                                    placeLabel,

                                photoIds =
                                    photoIds,

                                createMemory =
                                    options
                                        .createMemoryDrafts
                            )
                    }

                days +=
                    SmartJourneyDayDraft(
                        index =
                            dayIndex,

                        date =
                            dayGroup.date,

                        title =
                            "Day ${
                                dayIndex + 1
                            }",

                        stops =
                            stops
                    )
            }

        val placeFrequency =
            days
                .flatMap {
                    it.stops
                }
                .mapNotNull {
                    it.placeLabel
                }
                .groupingBy {
                    it
                }
                .eachCount()

        val destination =
            placeFrequency
                .maxByOrNull {
                    it.value
                }
                ?.key
                .orEmpty()

        val startDate =
            days
                .minOfOrNull {
                    it.date
                }

        val endDate =
            days
                .maxOfOrNull {
                    it.date
                }

        val formatter =
            DateTimeFormatter
                .ofPattern(
                    "MMM yyyy"
                )

        val suggestedTitle =
            when {

                destination
                    .isNotBlank() &&
                    startDate != null ->

                    "$destination ${
                        startDate.format(
                            formatter
                        )
                    }"

                destination
                    .isNotBlank() ->

                    destination

                startDate != null ->

                    "Journey ${
                        startDate.format(
                            formatter
                        )
                    }"

                else ->
                    "New Journey"
            }

        return SmartJourneyDraft(
            id =
                UUID
                    .randomUUID()
                    .toString(),

            suggestedTitle =
                suggestedTitle,

            title =
                suggestedTitle,

            destination =
                destination,

            startDate =
                startDate,

            endDate =
                endDate,

            days =
                days,

            photos =
                allDraftPhotos,

            createMemoryDrafts =
                options
                    .createMemoryDrafts,

            analysedPhotoCount =
                photos.size,

            excludedPhotoCount =
                0
        )
    }
}
