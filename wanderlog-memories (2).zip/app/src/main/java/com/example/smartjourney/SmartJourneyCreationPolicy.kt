package com.example.smartjourney

import com.example.premium.PremiumGate
import com.example.premium.PremiumGateResult

class SmartJourneyCreationPolicy(
    private val premiumGate:
        PremiumGate =
        PremiumGate()
) {

    fun evaluate(
        currentJourneyCount: Int,
        selectedPhotoCount: Int,
        isPremium: Boolean
    ): SmartJourneyCreationAllowance {

        val journeyGate =
            premiumGate
                .canCreateJourney(
                    currentJourneyCount =
                        currentJourneyCount,

                    isPremium =
                        isPremium
                )

        val photoAllowance =
            premiumGate
                .calculatePhotoImportAllowance(
                    currentPhotoCount =
                        0,

                    selectedPhotoCount =
                        selectedPhotoCount,

                    isPremium =
                        isPremium
                )

        return SmartJourneyCreationAllowance(

            isPremium =
                isPremium,

            journeyCreationAllowed =
                journeyGate is
                    PremiumGateResult.Allowed,

            selectedPhotoCount =
                selectedPhotoCount,

            allowedPhotoCount =
                photoAllowance
                    .allowedCount,

            blockedPhotoCount =
                photoAllowance
                    .blockedCount
        )
    }
}

class SmartJourneyLimitException(
    message: String
) : IllegalStateException(
    message
)
