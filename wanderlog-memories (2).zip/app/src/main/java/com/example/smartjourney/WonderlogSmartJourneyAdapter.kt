package com.example.smartjourney

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.example.domain.model.Memory
import com.example.domain.model.MemoryPhotoCrossRef
import com.example.domain.model.Mood
import com.example.domain.model.Trip
import com.example.domain.repository.MapRepository
import com.example.domain.repository.WanderlogRepository
import com.example.storage.AlbumPhotoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.util.UUID

class WonderlogSmartJourneyAdapter(
    private val context: Context,
    private val wanderlogRepository: WanderlogRepository,
    private val mapRepository: MapRepository
) : SmartJourneyPersistenceAdapter {

    override suspend fun getCurrentJourneyCount(): Int = withContext(Dispatchers.IO) {
        wanderlogRepository.getAllTrips().first().size
    }

    override suspend fun readModifiedTimestamp(uri: Uri): Long? = withContext(Dispatchers.IO) {
        runCatching {
            if (uri.scheme == "file") {
                val file = File(uri.path ?: return@runCatching null)
                if (file.exists() && file.lastModified() > 0) return@runCatching file.lastModified()
            }
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val dateModCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
                if (dateModCol != -1 && cursor.moveToFirst()) {
                    val sec = cursor.getLong(dateModCol)
                    if (sec > 0) return@runCatching sec * 1000L
                }
            }
            null
        }.getOrNull()
    }

    override suspend fun reverseGeocode(latitude: Double, longitude: Double): String? = withContext(Dispatchers.IO) {
        runCatching {
            val place = mapRepository.reverseGeocode(latitude, longitude)
            if (place != null) {
                if (place.city.isNotBlank()) place.city
                else place.displayName.split(",").firstOrNull()?.trim()
            } else {
                null
            }
        }.getOrNull()
    }

    override suspend fun createJourney(
        title: String,
        destination: String,
        startDate: LocalDate?,
        endDate: LocalDate?
    ): String = withContext(Dispatchers.IO) {
        val journeyId = "trip_${UUID.randomUUID()}"
        val startStr = startDate?.toString() ?: LocalDate.now().toString()
        val endStr = endDate?.toString() ?: startStr
        val trip = Trip(
            id = journeyId,
            destinationName = destination.ifBlank { title },
            country = "",
            startDate = startStr,
            endDate = endStr,
            coverImage = "",
            description = "",
            accentGradientIndex = 0,
            latitude = 0.0,
            longitude = 0.0,
            title = title,
            destination = destination.ifBlank { title },
            coverPhotoId = "",
            accentTheme = "Preset_0",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            favorite = false,
            archived = false,
            syncStatus = "LOCAL_ONLY"
        )
        wanderlogRepository.insertTrip(trip)
        journeyId
    }

    override suspend fun importAlbumPhoto(journeyId: String, uri: Uri): String = withContext(Dispatchers.IO) {
        val existingPhotos = wanderlogRepository.getPhotosForJourney(journeyId).first()
        val nextOrder = existingPhotos.size
        val photo = AlbumPhotoManager.importPhoto(
            context = context,
            journeyId = journeyId,
            uri = uri,
            displayOrder = nextOrder,
            existingPhotos = existingPhotos
        ) ?: error("Failed to import photo $uri")

        wanderlogRepository.insertPhoto(photo)

        // Set as journey cover if journey currently has empty or placeholder cover
        val trip = wanderlogRepository.getTripById(journeyId).first()
        if (trip != null && (trip.coverImage.isBlank() || trip.coverImage.startsWith("img_") || trip.coverPhotoId.isBlank() || trip.coverPhotoId.startsWith("img_"))) {
            wanderlogRepository.updateTrip(trip.copy(
                coverImage = photo.localUri,
                coverPhotoId = photo.id,
                updatedAt = System.currentTimeMillis()
            ))
            wanderlogRepository.updatePhoto(photo.copy(isCoverPhoto = true))
        }

        photo.id
    }

    override suspend fun createEmptyMemoryDraft(
        journeyId: String,
        title: String,
        date: LocalDate,
        locationName: String,
        latitude: Double?,
        longitude: Double?,
        albumPhotoIds: List<String>
    ): String = withContext(Dispatchers.IO) {
        val memoryId = "mem_${UUID.randomUUID()}"
        val memory = Memory(
            id = memoryId,
            tripId = journeyId,
            journeyId = journeyId,
            title = title,
            note = "",
            journalText = "",
            image = "",
            locationName = locationName,
            latitude = latitude,
            longitude = longitude,
            date = date.toString(),
            mood = Mood.CALM,
            tags = emptyList(),
            favorite = false,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            displayOrder = 0,
            syncStatus = "LOCAL_ONLY"
        )
        wanderlogRepository.insertMemory(memory)
        wanderlogRepository.deleteCrossRefsForMemory(memoryId)
        albumPhotoIds.forEachIndexed { index, photoId ->
            wanderlogRepository.insertMemoryPhotoCrossRef(
                MemoryPhotoCrossRef(
                    memoryId = memoryId,
                    albumPhotoId = photoId,
                    displayOrder = index,
                    isHeroPhoto = index == 0
                )
            )
        }
        memoryId
    }
}
