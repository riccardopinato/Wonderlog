package com.example.smartjourney

object SmartJourneyDraftEditor {

    fun renameJourney(
        draft:
            SmartJourneyDraft,

        title:
            String
    ): SmartJourneyDraft {

        return draft.copy(
            title =
                title
                    .take(
                        120
                    )
        )
    }

    fun changeDestination(
        draft:
            SmartJourneyDraft,

        destination:
            String
    ): SmartJourneyDraft {

        return draft.copy(
            destination =
                destination
                    .take(
                        120
                    )
        )
    }

    fun renameStop(
        draft:
            SmartJourneyDraft,

        stopId:
            String,

        title:
            String
    ): SmartJourneyDraft {

        return draft.copy(
            days =
                draft.days.map {
                    day ->

                    day.copy(
                        stops =
                            day.stops.map {
                                stop ->

                                if (
                                    stop.id ==
                                    stopId
                                ) {

                                    stop.copy(
                                        title =
                                            title.take(
                                                120
                                            ),
                                        manuallyEdited =
                                            true
                                    )

                                } else {

                                    stop
                                }
                            }
                    )
                }
        )
    }

    fun setPhotoIncluded(
        draft:
            SmartJourneyDraft,

        photoId:
            String,

        included:
            Boolean
    ): SmartJourneyDraft {

        val photos =
            draft.photos.map {
                photo ->

                if (
                    photo.id ==
                    photoId
                ) {
                    photo.copy(
                        included =
                            included
                    )
                } else {
                    photo
                }
            }

        return draft.copy(
            photos =
                photos,

            excludedPhotoCount =
                photos.count {
                    !it.included
                }
        )
    }

    fun setMemoryDraftEnabled(
        draft:
            SmartJourneyDraft,

        stopId:
            String,

        enabled:
            Boolean
    ): SmartJourneyDraft {

        return draft.copy(
            days =
                draft.days.map {
                    day ->

                    day.copy(
                        stops =
                            day.stops.map {
                                stop ->

                                if (
                                    stop.id ==
                                    stopId
                                ) {
                                    stop.copy(
                                        createMemory =
                                            enabled
                                    )
                                } else {
                                    stop
                                }
                            }
                    )
                }
        )
    }

    fun setAllMemoryDrafts(
        draft:
            SmartJourneyDraft,

        enabled:
            Boolean
    ): SmartJourneyDraft {

        return draft.copy(
            createMemoryDrafts =
                enabled,

            days =
                draft.days.map {
                    day ->

                    day.copy(
                        stops =
                            day.stops.map {
                                it.copy(
                                    createMemory =
                                        enabled
                                )
                            }
                    )
                }
        )
    }

    fun mergeAdjacentStops(
        draft:
            SmartJourneyDraft,

        dayIndex:
            Int,

        firstStopId:
            String,

        secondStopId:
            String
    ): SmartJourneyDraft {

        val targetDay =
            draft.days
                .firstOrNull {
                    it.index ==
                    dayIndex
                }
                ?: return draft

        val firstIndex =
            targetDay.stops
                .indexOfFirst {
                    it.id ==
                    firstStopId
                }

        val secondIndex =
            targetDay.stops
                .indexOfFirst {
                    it.id ==
                    secondStopId
                }

        if (
            firstIndex < 0 ||
            secondIndex < 0 ||
            kotlin.math.abs(
                firstIndex -
                secondIndex
            ) != 1
        ) {
            return draft
        }

        val lowerIndex =
            minOf(
                firstIndex,
                secondIndex
            )

        val upperIndex =
            maxOf(
                firstIndex,
                secondIndex
            )

        val first =
            targetDay.stops[
                lowerIndex
            ]

        val second =
            targetDay.stops[
                upperIndex
            ]

        val coordinates =
            listOfNotNull(
                first.latitude
                    ?.let {
                        lat ->

                        first.longitude
                            ?.let {
                                lon ->

                                Pair(
                                    lat,
                                    lon
                                )
                            }
                    },

                second.latitude
                    ?.let {
                        lat ->

                        second.longitude
                            ?.let {
                                lon ->

                                Pair(
                                    lat,
                                    lon
                                )
                            }
                    }
            )

        val centroid =
            GeoMath.centroid(
                coordinates
            )

        val merged =
            first.copy(
                title =
                    if (
                        first.manuallyEdited
                    ) {
                        first.title
                    } else {
                        first.placeLabel
                            ?: second.placeLabel
                            ?: first.title
                    },

                latitude =
                    centroid?.first,

                longitude =
                    centroid?.second,

                photoIds =
                    first.photoIds +
                        second.photoIds,

                createMemory =
                    first.createMemory ||
                        second.createMemory
            )

        val updatedStops =
            targetDay.stops
                .toMutableList()
                .apply {

                    removeAt(
                        upperIndex
                    )

                    this[
                        lowerIndex
                    ] =
                        merged
                }

        val movedPhotoIds =
            second
                .photoIds
                .toSet()

        return draft.copy(
            days =
                draft.days.map {
                    day ->

                    if (
                        day.index ==
                        dayIndex
                    ) {

                        day.copy(
                            stops =
                                updatedStops
                        )

                    } else {

                        day
                    }
                },

            photos =
                draft.photos.map {
                    photo ->

                    if (
                        photo.id in
                        movedPhotoIds
                    ) {

                        photo.copy(
                            stopId =
                                merged.id
                        )

                    } else {

                        photo
                    }
                }
        )
    }

    fun movePhoto(
        draft:
            SmartJourneyDraft,

        photoId:
            String,

        destinationStopId:
            String
    ): SmartJourneyDraft {

        val destinationStop =
            draft.days
                .flatMap {
                    it.stops
                }
                .firstOrNull {
                    it.id ==
                    destinationStopId
                }
                ?: return draft

        val photo =
            draft.photos
                .firstOrNull {
                    it.id ==
                    photoId
                }
                ?: return draft

        val oldStopId =
            photo.stopId

        val updatedDays =
            draft.days.map {
                day ->

                day.copy(
                    stops =
                        day.stops
                            .map {
                                stop ->

                                when (
                                    stop.id
                                ) {

                                    oldStopId ->
                                        stop.copy(
                                            photoIds =
                                                stop
                                                    .photoIds
                                                    .filterNot {
                                                        it ==
                                                        photoId
                                                    }
                                        )

                                    destinationStopId ->
                                        stop.copy(
                                            photoIds =
                                                (
                                                    stop.photoIds +
                                                    photoId
                                                )
                                                    .distinct()
                                        )

                                    else ->
                                        stop
                                }
                            }
                            .filter {
                                it.photoIds
                                    .isNotEmpty()
                            }
                )
            }

        return draft.copy(
            days =
                updatedDays,

            photos =
                draft.photos.map {
                    current ->

                    if (
                        current.id ==
                        photoId
                    ) {

                        current.copy(
                            dayIndex =
                                destinationStop
                                    .dayIndex,

                            stopId =
                                destinationStopId
                        )

                    } else {

                        current
                    }
                }
        )
    }
}
