package com.example.smartjourney

interface SmartJourneyRepository {

    suspend fun analyseSelectedPhotos(
        uriStrings: List<String>,
        onProgress:
            suspend (
                SmartJourneyAnalysisProgress
            ) -> Unit
    ): Result<SmartJourneyDraft>

    suspend fun evaluateCreationAllowance(
        draft:
            SmartJourneyDraft
    ): Result<
        SmartJourneyCreationAllowance
    >

    suspend fun createJourneyFromDraft(
        draft:
            SmartJourneyDraft
    ): Result<
        SmartJourneyCreationResult
    >
}
