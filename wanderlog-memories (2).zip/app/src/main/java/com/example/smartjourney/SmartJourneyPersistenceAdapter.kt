package com.example.smartjourney

import android.net.Uri
import java.time.LocalDate

interface SmartJourneyPersistenceAdapter {

    suspend fun getCurrentJourneyCount():
        Int

    suspend fun readModifiedTimestamp(
        uri: Uri
    ): Long?

    suspend fun reverseGeocode(
        latitude: Double,
        longitude: Double
    ): String?

    suspend fun createJourney(
        title: String,
        destination: String,
        startDate: LocalDate?,
        endDate: LocalDate?
    ): String

    suspend fun importAlbumPhoto(
        journeyId: String,
        uri: Uri
    ): String

    suspend fun createEmptyMemoryDraft(
        journeyId: String,
        title: String,
        date: LocalDate,
        locationName: String,
        latitude: Double?,
        longitude: Double?,
        albumPhotoIds: List<String>
    ): String
}
