package com.example.smartjourney

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class SmartJourneyViewModelFactory(
    private val repository:
        SmartJourneyRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(
        modelClass: Class<T>
    ): T {

        if (
            modelClass.isAssignableFrom(
                SmartJourneyViewModel::class.java
            )
        ) {
            return SmartJourneyViewModel(
                repository
            ) as T
        }

        throw IllegalArgumentException(
            "Unknown ViewModel class: ${modelClass.name}"
        )
    }
}
