package com.example.smartjourney

import java.time.LocalDate

data class SmartJourneySourcePhoto(
    val sourceUri: String,
    val originalIndex: Int,
    val capturedAt: Long?,
    val modifiedAt: Long?,
    val latitude: Double?,
    val longitude: Double?,
    val placeLabel: String? = null,
    val included: Boolean = true
) {

    val effectiveTimestamp: Long?
        get() =
            capturedAt
                ?: modifiedAt
}

data class SmartJourneyPhoto(
    val id: String,
    val source: SmartJourneySourcePhoto,
    val dayIndex: Int,
    val stopId: String?,
    val included: Boolean = true
)

data class SmartJourneyStopDraft(
    val id: String,
    val dayIndex: Int,
    val title: String,
    val latitude: Double?,
    val longitude: Double?,
    val placeLabel: String?,
    val photoIds: List<String>,
    val createMemory: Boolean = true,
    val manuallyEdited: Boolean = false
)

data class SmartJourneyDayDraft(
    val index: Int,
    val date: LocalDate,
    val title: String,
    val stops: List<SmartJourneyStopDraft>
)

data class SmartJourneyDraft(
    val id: String,
    val suggestedTitle: String,
    val title: String,
    val destination: String,
    val startDate: LocalDate?,
    val endDate: LocalDate?,
    val days: List<SmartJourneyDayDraft>,
    val photos: List<SmartJourneyPhoto>,
    val createMemoryDrafts: Boolean = true,
    val analysedPhotoCount: Int = 0,
    val excludedPhotoCount: Int = 0
) {

    val includedPhotos: List<SmartJourneyPhoto>
        get() =
            photos.filter {
                it.included
            }

    val stopCount: Int
        get() =
            days.sumOf {
                it.stops.size
            }
}

data class SmartJourneyAnalysisProgress(
    val processed: Int,
    val total: Int,
    val phase: SmartJourneyAnalysisPhase
) {

    val fraction: Float
        get() =
            if (total <= 0) {
                0f
            } else {
                processed
                    .toFloat()
                    .div(
                        total
                    )
                    .coerceIn(
                        0f,
                        1f
                    )
            }
}

enum class SmartJourneyAnalysisPhase {

    READING_METADATA,

    GROUPING_DAYS,

    CLUSTERING_LOCATIONS,

    RESOLVING_PLACES,

    BUILDING_DRAFT,

    COMPLETE
}

data class SmartJourneyBuildOptions(
    val geoClusterRadiusMeters: Double = 2_500.0,
    val maxStopTimeGapMinutes: Long = 240L,
    val orphanAssignmentTimeWindowMinutes: Long = 360L,
    val minimumPhotosPerStop: Int = 1,
    val createMemoryDrafts: Boolean = true
)

data class SmartJourneyCreationResult(
    val journeyId: String,
    val photoCount: Int,
    val memoryDraftCount: Int
)

data class SmartJourneyCreationAllowance(
    val isPremium: Boolean,
    val journeyCreationAllowed: Boolean,
    val selectedPhotoCount: Int,
    val allowedPhotoCount: Int,
    val blockedPhotoCount: Int
) {

    val journeyLimitReached: Boolean
        get() =
            !journeyCreationAllowed

    val hasBlockedPhotos: Boolean
        get() =
            blockedPhotoCount > 0

    val requiresUpgrade: Boolean
        get() =
            !isPremium &&
                (
                    journeyLimitReached ||
                    hasBlockedPhotos
                )

    val allPhotosAllowed: Boolean
        get() =
            blockedPhotoCount == 0
}

sealed interface SmartJourneyUiState {

    data object Idle :
        SmartJourneyUiState

    data class Selecting(
        val selectedCount: Int
    ) : SmartJourneyUiState

    data class Analysing(
        val progress:
            SmartJourneyAnalysisProgress
    ) : SmartJourneyUiState

    data class DraftReady(
        val draft:
            SmartJourneyDraft,

        val allowance:
            SmartJourneyCreationAllowance? =
            null
    ) : SmartJourneyUiState

    data class Saving(
        val draft:
            SmartJourneyDraft,

        val allowance:
            SmartJourneyCreationAllowance? =
            null
    ) : SmartJourneyUiState

    data class Success(
        val result:
            SmartJourneyCreationResult
    ) : SmartJourneyUiState

    data class Error(
        val message: String
    ) : SmartJourneyUiState
}
