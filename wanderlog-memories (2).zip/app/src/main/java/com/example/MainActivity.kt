package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardTravel
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.capture.WonderlogShareIntentParser
import com.example.domain.model.LocationCoordinate
import com.example.domain.model.MapMarker
import com.example.domain.model.Mood
import com.example.presentation.Screen
import com.example.presentation.WanderlogViewModel
import com.example.ui.components.GlassBottomNavigation
import com.example.ui.components.PremiumUpgradeDialog
import com.example.premium.PremiumManager
import com.example.rediscover.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private var pendingShareIntent: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingShareIntent = intent

        setContent {
            MyApplicationTheme {
                val viewModel: WanderlogViewModel = viewModel()

                LaunchedEffect(Unit) {
                    val intentToProcess = pendingShareIntent
                    if (intentToProcess != null) {
                        if (intentToProcess.action == Intent.ACTION_SEND || intentToProcess.action == Intent.ACTION_SEND_MULTIPLE) {
                            val items = WonderlogShareIntentParser.parse(intentToProcess)
                            if (items.isNotEmpty()) {
                                viewModel.captureViewModel.setIncomingItems(items)
                                viewModel.navigateTo(Screen.Capture)
                            }
                        } else if (intentToProcess.getStringExtra("EXTRA_NAVIGATE_TO") == "REDISCOVER") {
                            val journeyId = intentToProcess.getStringExtra("EXTRA_JOURNEY_ID")
                            val memoryId = intentToProcess.getStringExtra("EXTRA_MEMORY_ID")
                            if (!journeyId.isNullOrBlank()) {
                                viewModel.selectTrip(journeyId)
                                viewModel.navigateTo(Screen.DestinationDetail(journeyId))
                            } else if (!memoryId.isNullOrBlank()) {
                                viewModel.selectMemory(memoryId)
                                viewModel.navigateTo(Screen.MemoryDetail(memoryId))
                            } else {
                                viewModel.navigateTo(Screen.Rediscover)
                            }
                        }
                        pendingShareIntent = null
                    }
                }
                
                val currentScreen by viewModel.currentScreen.collectAsState()
                val trips by viewModel.trips.collectAsState()
                val selectedTrip by viewModel.selectedTrip.collectAsState()
                val selectedTripMemories by viewModel.selectedTripMemories.collectAsState()
                val allMemories by viewModel.allMemories.collectAsState()
                val rediscoverCards by viewModel.rediscoverCards.collectAsState()
                val showUpgradeDialog by PremiumManager.showUpgradeDialog.collectAsState()
                val upgradeTitle by PremiumManager.upgradeTitle.collectAsState()
                val upgradeSubtitle by PremiumManager.upgradeSubtitle.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.navigationBars
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = if (currentScreen is Screen.Home || currentScreen is Screen.Premium) 0.dp else innerPadding.calculateBottomPadding())
                    ) {
                        // Main screen routing with elegant crossfade animations
                        Crossfade(
                            targetState = currentScreen,
                            animationSpec = tween(durationMillis = 350)
                        ) { screen ->
                            when (screen) {
                                is Screen.Onboarding -> {
                                    OnboardingScreen(
                                        onStartClick = { viewModel.navigateTo(Screen.Home) }
                                    )
                                }

                                is Screen.Home -> {
                                    HomeScreen(
                                        trips = trips,
                                        allMemories = allMemories,
                                        rediscoverCards = rediscoverCards,
                                        onRediscoverJourneyClick = { journeyId ->
                                            viewModel.selectTrip(journeyId)
                                            viewModel.navigateTo(Screen.DestinationDetail(journeyId))
                                        },
                                        onRediscoverMemoryClick = { memoryId ->
                                            viewModel.selectMemory(memoryId)
                                            viewModel.navigateTo(Screen.MemoryDetail(memoryId))
                                        },
                                        onRediscoverPhotoClick = { _ ->
                                            viewModel.navigateTo(Screen.Rediscover)
                                        },
                                        onRediscoverSeeAllClick = {
                                            viewModel.navigateTo(Screen.Rediscover)
                                        },
                                        onTripClick = { id ->
                                            viewModel.selectTrip(id)
                                            viewModel.navigateTo(Screen.DestinationDetail(id))
                                        },
                                        onCreateTripClick = { viewModel.navigateTo(Screen.CreateTrip) },
                                        onPremiumClick = { viewModel.navigateTo(Screen.Premium) },
                                        onBuildFromPhotosClick = {
                                            viewModel.resetSmartJourney()
                                            viewModel.navigateTo(Screen.SmartJourneyImport)
                                        },
                                        onFavoriteToggle = { trip -> viewModel.favoriteTrip(trip, !trip.favorite) },
                                        onArchiveToggle = { trip -> viewModel.archiveTrip(trip, !trip.archived) },
                                        onDuplicate = { trip -> viewModel.duplicateTrip(trip) },
                                        onRename = { trip, newName -> viewModel.renameTrip(trip, newName) },
                                        onThemeChange = { trip, themeIndex -> viewModel.changeTripTheme(trip, themeIndex) },
                                        onCoverChange = { trip, path -> viewModel.changeTripCover(trip, path) },
                                        onDeleteTrip = { trip -> viewModel.deleteTrip(trip) }
                                    )
                                }

                                is Screen.DestinationDetail -> {
                                    selectedTrip?.let { trip ->
                                        DestinationDetailScreen(
                                            trip = trip,
                                            memories = selectedTripMemories,
                                            viewModel = viewModel,
                                            onAddMemoryClick = { viewModel.navigateTo(Screen.AddMemory(trip.id)) },
                                            onBackClick = { viewModel.navigateTo(Screen.Home) },
                                            onDeleteTripClick = {
                                                viewModel.deleteTrip(trip)
                                                viewModel.navigateTo(Screen.Home)
                                            },
                                            onDeleteMemoryClick = { memory ->
                                                viewModel.deleteMemory(memory)
                                            },
                                            onAlbumClick = { viewModel.navigateTo(Screen.Album(trip.id)) },
                                            onMemoryClick = { memory ->
                                                viewModel.selectMemory(memory.id)
                                                viewModel.navigateTo(Screen.MemoryDetail(memory.id))
                                            },
                                            onReplayClick = {
                                                viewModel.navigateTo(Screen.JourneyReplay(trip.id))
                                            }
                                        )
                                    }
                                }

                                is Screen.Album -> {
                                    selectedTrip?.let { trip ->
                                        AlbumScreen(
                                            trip = trip,
                                            viewModel = viewModel,
                                            onBackClick = { viewModel.navigateTo(Screen.DestinationDetail(trip.id)) }
                                        )
                                    }
                                }

                                is Screen.CreateTrip -> {
                                    CreateTripScreen(
                                        onSaveTrip = { trip ->
                                            viewModel.addTrip(trip)
                                            viewModel.selectTrip(trip.id)
                                            viewModel.navigateTo(Screen.DestinationDetail(trip.id))
                                        },
                                        onBackClick = { viewModel.navigateTo(Screen.Home) },
                                        existingTripsCount = trips.size,
                                        onBuildFromPhotosClick = {
                                            viewModel.resetSmartJourney()
                                            viewModel.navigateTo(Screen.SmartJourneyImport)
                                        }
                                    )
                                }

                                is Screen.AddMemory -> {
                                    selectedTrip?.let { trip ->
                                        AddMemoryScreen(
                                            trip = trip,
                                            viewModel = viewModel,
                                            onSaveMemory = { memory, photos ->
                                                viewModel.saveMemoryWithPhotos(memory, photos)
                                                viewModel.navigateTo(Screen.DestinationDetail(trip.id))
                                            },
                                            onBackClick = { viewModel.navigateTo(Screen.DestinationDetail(trip.id)) }
                                        )
                                    }
                                }

                                is Screen.EditMemory -> {
                                    selectedTrip?.let { trip ->
                                        val selectedMemoryWithPhotos by viewModel.selectedMemoryWithPhotos.collectAsState()
                                        selectedMemoryWithPhotos?.let { memoryWithPhotos ->
                                            EditMemoryScreen(
                                                trip = trip,
                                                memoryWithPhotos = memoryWithPhotos,
                                                viewModel = viewModel,
                                                onSaveMemory = { memory, photos ->
                                                    viewModel.updateMemoryWithPhotos(memory, photos)
                                                    viewModel.navigateTo(Screen.MemoryDetail(memory.id))
                                                },
                                                onBackClick = { viewModel.navigateTo(Screen.MemoryDetail(memoryWithPhotos.memory.id)) }
                                            )
                                        }
                                    }
                                }

                                is Screen.MemoryDetail -> {
                                    val selectedMemoryWithPhotos by viewModel.selectedMemoryWithPhotos.collectAsState()
                                    selectedMemoryWithPhotos?.let { memoryWithPhotos ->
                                        MemoryDetailScreen(
                                            memoryWithPhotos = memoryWithPhotos,
                                            viewModel = viewModel,
                                            onBackClick = { viewModel.navigateTo(Screen.DestinationDetail(memoryWithPhotos.memory.tripId)) },
                                            onEditClick = {
                                                viewModel.selectMemory(memoryWithPhotos.memory.id)
                                                viewModel.navigateTo(Screen.EditMemory(memoryWithPhotos.memory.id))
                                            },
                                            onDeleteClick = {
                                                viewModel.deleteMemory(memoryWithPhotos.memory)
                                                viewModel.navigateTo(Screen.DestinationDetail(memoryWithPhotos.memory.tripId))
                                            }
                                        )
                                    }
                                }

                                is Screen.Premium -> {
                                    PremiumScreen(
                                        onBackClick = { viewModel.navigateTo(Screen.Home) }
                                    )
                                }

                                is Screen.SmartJourneyImport -> {
                                    SmartJourneyImportScreen(
                                        viewModel = viewModel.smartJourneyViewModel,
                                        onBackClick = { viewModel.navigateTo(Screen.Home) },
                                        onDraftReady = { viewModel.navigateTo(Screen.SmartJourneyDraft) }
                                    )
                                }

                                is Screen.SmartJourneyDraft -> {
                                    SmartJourneyDraftScreen(
                                        viewModel = viewModel.smartJourneyViewModel,
                                        onBack = { viewModel.navigateTo(Screen.SmartJourneyImport) },
                                        onUpgradeRequested = { viewModel.navigateTo(Screen.Premium) },
                                        onJourneyCreated = { journeyId ->
                                            viewModel.selectTrip(journeyId)
                                            viewModel.navigateTo(Screen.DestinationDetail(journeyId))
                                        }
                                    )
                                }

                                is Screen.Capture -> {
                                    CaptureScreen(
                                        viewModel = viewModel.captureViewModel,
                                        onBack = { viewModel.navigateTo(Screen.Home) },
                                        onNavigateToJourney = { journeyId ->
                                            viewModel.selectTrip(journeyId)
                                            viewModel.navigateTo(Screen.DestinationDetail(journeyId))
                                        }
                                    )
                                }

                                is Screen.Rediscover -> {
                                    val rediscoverViewModel: RediscoverViewModel = viewModel(
                                        factory = RediscoverViewModelFactory(viewModel.rediscoverRepository)
                                    )
                                    RediscoverScreen(
                                        viewModel = rediscoverViewModel,
                                        onBack = { viewModel.navigateTo(Screen.Home) },
                                        onOpenJourney = { journeyId ->
                                            viewModel.selectTrip(journeyId)
                                            viewModel.navigateTo(Screen.DestinationDetail(journeyId))
                                        },
                                        onOpenMemory = { memoryId ->
                                            viewModel.selectMemory(memoryId)
                                            viewModel.navigateTo(Screen.MemoryDetail(memoryId))
                                        },
                                        onOpenPhoto = { _ ->
                                            viewModel.navigateTo(Screen.Home)
                                        }
                                    )
                                }

                                is Screen.JourneyReplay -> {
                                    val replayViewModel: JourneyReplayViewModel = viewModel(
                                        key = "replay_${screen.journeyId}",
                                        factory = JourneyReplayViewModelFactory(
                                            journeyId = screen.journeyId,
                                            repository = viewModel.rediscoverRepository
                                        )
                                    )
                                    JourneyReplayScreen(
                                        viewModel = replayViewModel,
                                        onBack = {
                                            viewModel.selectTrip(screen.journeyId)
                                            viewModel.navigateTo(Screen.DestinationDetail(screen.journeyId))
                                        }
                                    )
                                }
                            }
                        }

                        // Premium Upgrade Dialog Overlay
                        if (showUpgradeDialog) {
                            PremiumUpgradeDialog(
                                onDismissRequest = {
                                    PremiumManager.dismissUpgrade()
                                },
                                onUnlockClick = {
                                    PremiumManager.dismissUpgrade()
                                    viewModel.navigateTo(Screen.Premium)
                                },
                                title = upgradeTitle,
                                subtitle = upgradeSubtitle
                            )
                        }

                        // Floating Glass Bottom Navigation on core tabs (Home, Premium)
                        if (currentScreen is Screen.Home || currentScreen is Screen.Premium) {
                            val selectedTabIndex = when (currentScreen) {
                                is Screen.Home -> 0
                                is Screen.Premium -> 2
                                else -> 0
                            }

                            GlassBottomNavigation(
                                tabs = listOf("Destinations", "Global Map", "Premium"),
                                selectedTab = selectedTabIndex,
                                onTabSelected = { index ->
                                    when (index) {
                                        0 -> viewModel.navigateTo(Screen.Home)
                                        1 -> {
                                            // Handle global map toggle or view directly. For seamless prototype,
                                            // we will trigger detail screen view of active trip, or show home search.
                                            viewModel.navigateTo(Screen.Home)
                                        }
                                        2 -> viewModel.navigateTo(Screen.Premium)
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .testTag("global_bottom_navigation"),
                                  icons = listOf(
                                    { selected ->
                                        Icon(
                                            imageVector = Icons.Default.CardTravel,
                                            contentDescription = null,
                                            tint = if (selected) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.6f),
                                            modifier = Modifier.size(26.dp)
                                        )
                                    },
                                    { selected ->
                                        Icon(
                                            imageVector = Icons.Default.Map,
                                            contentDescription = null,
                                            tint = if (selected) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.6f),
                                            modifier = Modifier.size(26.dp)
                                        )
                                    },
                                    { selected ->
                                        Icon(
                                            imageVector = Icons.Default.WorkspacePremium,
                                            contentDescription = null,
                                            tint = if (selected) Color(0xFFDD2476) else Color(0xFF0F172A).copy(alpha = 0.6f),
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val viewModel = androidx.lifecycle.ViewModelProvider(this)[WanderlogViewModel::class.java]
        val items = WonderlogShareIntentParser.parse(intent)
        if (items.isNotEmpty()) {
            viewModel.captureViewModel.setIncomingItems(items)
            viewModel.navigateTo(Screen.Capture)
        } else if (intent.getStringExtra("EXTRA_NAVIGATE_TO") == "REDISCOVER") {
            val journeyId = intent.getStringExtra("EXTRA_JOURNEY_ID")
            val memoryId = intent.getStringExtra("EXTRA_MEMORY_ID")
            if (!journeyId.isNullOrBlank()) {
                viewModel.selectTrip(journeyId)
                viewModel.navigateTo(Screen.DestinationDetail(journeyId))
            } else if (!memoryId.isNullOrBlank()) {
                viewModel.selectMemory(memoryId)
                viewModel.navigateTo(Screen.MemoryDetail(memoryId))
            } else {
                viewModel.navigateTo(Screen.Rediscover)
            }
        }
    }
}
