package com.example.rediscover

import com.example.data.local.AlbumPhotoDao
import com.example.data.local.MemoryDao
import com.example.data.local.TripDao
import com.example.data.local.WanderlogDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class RediscoverRepositoryImpl(
    private val tripDao: TripDao,
    private val memoryDao: MemoryDao,
    private val albumPhotoDao: AlbumPhotoDao
) : RediscoverRepository {

    constructor(db: WanderlogDatabase) : this(
        tripDao = db.tripDao(),
        memoryDao = db.memoryDao(),
        albumPhotoDao = db.albumPhotoDao()
    )

    override suspend fun getJourneys(): List<RediscoverJourney> = withContext(Dispatchers.IO) {
        val trips = tripDao.getAllTripsOnce()
        val allPhotos = albumPhotoDao.getAllPhotosOnce()
        val allMemories = memoryDao.getAllMemoriesOnce()

        val photosByTrip = allPhotos.groupBy { it.journeyId }
        val memoriesByTrip = allMemories.groupBy { it.tripId }

        trips.map { trip ->
            val tripPhotos = photosByTrip[trip.id].orEmpty()
            val tripMemories = memoriesByTrip[trip.id].orEmpty()

            val startTs = RediscoverDateUtils.dateStringToTimestamp(trip.startDate) ?: trip.createdAt
            val endTs = RediscoverDateUtils.dateStringToTimestamp(trip.endDate) ?: trip.updatedAt

            val cover = trip.coverPhotoId.takeIf { it.isNotBlank() }
                ?: trip.coverImage.takeIf { it.isNotBlank() }
                ?: tripPhotos.firstOrNull { it.isCoverPhoto }?.localUri
                ?: tripPhotos.firstOrNull()?.localUri

            RediscoverJourney(
                id = trip.id,
                title = trip.title.ifBlank { trip.destinationName },
                destination = trip.destination.ifBlank { trip.destinationName },
                startTimestamp = startTs,
                endTimestamp = endTs,
                coverPhotoUri = cover,
                photoCount = tripPhotos.size,
                memoryCount = tripMemories.size
            )
        }
    }

    override suspend fun getMemories(): List<RediscoverMemory> = withContext(Dispatchers.IO) {
        val memoriesWithPhotos = memoryDao.getAllMemoriesWithPhotos().first()
        memoriesWithPhotos.map { mwp ->
            val memory = mwp.memory
            val timestamp = RediscoverDateUtils.dateStringToTimestamp(memory.date) ?: memory.createdAt
            val photos = mwp.photos.map { it.localUri.ifBlank { it.thumbnailUri.ifBlank { it.originalUri } } }
                .filter { it.isNotBlank() }
                .ifEmpty {
                    if (memory.image.isNotBlank()) listOf(memory.image) else emptyList()
                }

            RediscoverMemory(
                id = memory.id,
                journeyId = memory.tripId,
                title = memory.title,
                journalText = memory.journalText.ifBlank { memory.note },
                timestamp = timestamp,
                locationName = memory.locationName.takeIf { it.isNotBlank() },
                photoUris = photos
            )
        }
    }

    override suspend fun getPhotos(): List<RediscoverPhoto> = withContext(Dispatchers.IO) {
        val allPhotos = albumPhotoDao.getAllPhotosOnce()
        allPhotos.map { photo ->
            val timestamp = photo.capturedAt ?: photo.createdAt
            val uri = photo.localUri.ifBlank { photo.thumbnailUri.ifBlank { photo.originalUri } }
            RediscoverPhoto(
                id = photo.id,
                journeyId = photo.journeyId,
                localUri = uri,
                timestamp = timestamp,
                locationName = photo.locationName.takeIf { it.isNotBlank() }
            )
        }
    }
}
