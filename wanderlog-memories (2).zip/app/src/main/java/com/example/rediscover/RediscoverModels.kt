package com.example.rediscover

enum class RediscoverType {
    ON_THIS_DAY,
    JOURNEY_ANNIVERSARY,
    MEMORY,
    PHOTO
}

data class RediscoverPhoto(
    val id: String,
    val journeyId: String,
    val localUri: String,
    val timestamp: Long?,
    val locationName: String? = null
)

data class RediscoverMemory(
    val id: String,
    val journeyId: String,
    val title: String,
    val journalText: String?,
    val timestamp: Long?,
    val locationName: String?,
    val photoUris: List<String>
)

data class RediscoverJourney(
    val id: String,
    val title: String,
    val destination: String?,
    val startTimestamp: Long?,
    val endTimestamp: Long?,
    val coverPhotoUri: String?,
    val photoCount: Int,
    val memoryCount: Int
)

data class RediscoverCard(
    val id: String,
    val type: RediscoverType,
    val title: String,
    val subtitle: String?,
    val journeyId: String?,
    val memoryId: String?,
    val photoId: String?,
    val imageUri: String?,
    val timestamp: Long?,
    val yearsAgo: Int? = null
)

data class RediscoverFeed(
    val cards: List<RediscoverCard>,
    val generatedForDayKey: String
)

sealed interface RediscoverUiState {
    data object Loading : RediscoverUiState
    data class Ready(val feed: RediscoverFeed) : RediscoverUiState
    data class Error(val message: String) : RediscoverUiState
}
