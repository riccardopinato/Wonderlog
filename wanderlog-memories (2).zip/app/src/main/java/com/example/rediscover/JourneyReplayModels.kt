package com.example.rediscover

enum class JourneyReplaySlideType {
    COVER,
    PHOTO,
    MEMORY,
    PLACE,
    END
}

data class JourneyReplaySlide(
    val id: String,
    val type: JourneyReplaySlideType,
    val title: String?,
    val subtitle: String?,
    val imageUri: String?,
    val timestamp: Long?,
    val memoryId: String? = null,
    val photoId: String? = null
)

data class JourneyReplay(
    val journeyId: String,
    val journeyTitle: String,
    val slides: List<JourneyReplaySlide>
)
