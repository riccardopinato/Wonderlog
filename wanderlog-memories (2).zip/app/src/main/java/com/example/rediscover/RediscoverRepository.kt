package com.example.rediscover

interface RediscoverRepository {

    suspend fun getJourneys(): List<RediscoverJourney>

    suspend fun getMemories(): List<RediscoverMemory>

    suspend fun getPhotos(): List<RediscoverPhoto>

    suspend fun getJourney(journeyId: String): RediscoverJourney? {
        return getJourneys().firstOrNull { it.id == journeyId }
    }
}
