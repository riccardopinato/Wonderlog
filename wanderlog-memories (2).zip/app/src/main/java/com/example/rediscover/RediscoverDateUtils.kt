package com.example.rediscover

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object RediscoverDateUtils {

    fun toLocalDate(
        timestamp: Long?,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): LocalDate? {
        if (timestamp == null || timestamp <= 0L) {
            return null
        }
        return Instant
            .ofEpochMilli(timestamp)
            .atZone(zoneId)
            .toLocalDate()
    }

    fun isSameMonthDay(
        candidate: LocalDate?,
        today: LocalDate
    ): Boolean {
        if (candidate == null) {
            return false
        }
        return candidate.monthValue == today.monthValue &&
                candidate.dayOfMonth == today.dayOfMonth
    }

    fun yearsBetween(
        past: LocalDate,
        today: LocalDate
    ): Int {
        if (past.isAfter(today)) {
            return 0
        }
        return today.year - past.year
    }

    fun daysDifference(
        first: LocalDate,
        second: LocalDate
    ): Long {
        return kotlin.math.abs(
            ChronoUnit.DAYS.between(first, second)
        )
    }

    fun dayKey(
        date: LocalDate
    ): String {
        return "%04d-%02d-%02d"
            .format(
                date.year,
                date.monthValue,
                date.dayOfMonth
            )
    }

    fun parseIsoDate(dateString: String?): LocalDate? {
        if (dateString.isNullOrBlank()) return null
        return runCatching { LocalDate.parse(dateString.trim()) }.getOrNull()
    }

    fun dateStringToTimestamp(
        dateString: String?,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Long? {
        val localDate = parseIsoDate(dateString) ?: return null
        return runCatching {
            localDate.atStartOfDay(zoneId).toInstant().toEpochMilli()
        }.getOrNull()
    }
}
