package com.example.rediscover

class JourneyReplayBuilder {

    fun build(
        journey: RediscoverJourney,
        photos: List<RediscoverPhoto>,
        memories: List<RediscoverMemory>
    ): JourneyReplay {

        val journeyPhotos = photos.filter {
            it.journeyId == journey.id
        }

        val journeyMemories = memories.filter {
            it.journeyId == journey.id
        }

        val slides = mutableListOf<JourneyReplaySlide>()

        slides += JourneyReplaySlide(
            id = "cover-${journey.id}",
            type = JourneyReplaySlideType.COVER,
            title = journey.title,
            subtitle = journey.destination,
            imageUri = journey.coverPhotoUri,
            timestamp = journey.startTimestamp
        )

        val events = mutableListOf<JourneyReplaySlide>()

        journeyPhotos.forEach { photo ->
            events += JourneyReplaySlide(
                id = "photo-${photo.id}",
                type = JourneyReplaySlideType.PHOTO,
                title = photo.locationName,
                subtitle = null,
                imageUri = photo.localUri,
                timestamp = photo.timestamp,
                photoId = photo.id
            )
        }

        journeyMemories.forEach { memory ->
            events += JourneyReplaySlide(
                id = "memory-${memory.id}",
                type = JourneyReplaySlideType.MEMORY,
                title = memory.title,
                subtitle = memory.journalText
                    ?.trim()
                    ?.take(220)
                    ?.takeIf { it.isNotBlank() },
                imageUri = memory.photoUris.firstOrNull(),
                timestamp = memory.timestamp,
                memoryId = memory.id
            )
        }

        slides += events.sortedWith(
            compareBy<JourneyReplaySlide> {
                it.timestamp ?: Long.MAX_VALUE
            }.thenBy {
                it.id
            }
        )

        slides += JourneyReplaySlide(
            id = "end-${journey.id}",
            type = JourneyReplaySlideType.END,
            title = journey.title,
            subtitle = "${journey.photoCount} photos • ${journey.memoryCount} Memories",
            imageUri = journey.coverPhotoUri,
            timestamp = journey.endTimestamp
        )

        return JourneyReplay(
            journeyId = journey.id,
            journeyTitle = journey.title,
            slides = slides
        )
    }
}
