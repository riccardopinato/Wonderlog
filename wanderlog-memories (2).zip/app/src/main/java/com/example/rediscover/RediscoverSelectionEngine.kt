package com.example.rediscover

import kotlin.math.abs

object RediscoverSelectionEngine {

    private fun priorityScore(card: RediscoverCard): Int {
        return when (card.type) {
            RediscoverType.JOURNEY_ANNIVERSARY -> 1
            RediscoverType.MEMORY -> if (!card.imageUri.isNullOrBlank()) 2 else 3
            RediscoverType.PHOTO -> 4
            else -> 5
        }
    }

    fun selectForHome(
        feed: RediscoverFeed,
        maxCards: Int = 5
    ): List<RediscoverCard> {
        if (feed.cards.isEmpty()) return emptyList()

        val seed = feed.generatedForDayKey.hashCode()

        val sorted = feed.cards.sortedWith(
            compareBy<RediscoverCard> { priorityScore(it) }
                .thenBy { abs((it.id + seed).hashCode()) }
        )

        val selected = mutableListOf<RediscoverCard>()
        val journeyCounts = mutableMapOf<String, Int>()

        for (card in sorted) {
            val jId = card.journeyId
            if (jId != null) {
                val count = journeyCounts.getOrDefault(jId, 0)
                if (count >= 2) {
                    continue
                }
                journeyCounts[jId] = count + 1
            }
            selected.add(card)
            if (selected.size >= maxCards) {
                break
            }
        }

        return selected
    }

    fun selectWidgetCard(
        feed: RediscoverFeed
    ): RediscoverCard? {
        return selectForHome(
            feed = feed,
            maxCards = 1
        ).firstOrNull()
    }
}
