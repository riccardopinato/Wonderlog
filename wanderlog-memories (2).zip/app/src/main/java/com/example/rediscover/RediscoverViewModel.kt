package com.example.rediscover

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

class RediscoverViewModel(
    private val repository: RediscoverRepository,
    private val engine: RediscoverEngine = RediscoverEngine()
) : ViewModel() {

    private val _state = MutableStateFlow<RediscoverUiState>(RediscoverUiState.Loading)
    val state: StateFlow<RediscoverUiState> = _state.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.value = RediscoverUiState.Loading
            runCatching {
                coroutineScope {
                    val journeys = async { repository.getJourneys() }
                    val memories = async { repository.getMemories() }
                    val photos = async { repository.getPhotos() }

                    engine.buildFeed(
                        today = LocalDate.now(),
                        journeys = journeys.await(),
                        memories = memories.await(),
                        photos = photos.await()
                    )
                }
            }.onSuccess { feed ->
                _state.value = RediscoverUiState.Ready(feed)
            }.onFailure { error ->
                _state.value = RediscoverUiState.Error(
                    error.message ?: "Unable to load memories."
                )
            }
        }
    }
}

class RediscoverViewModelFactory(
    private val repository: RediscoverRepository,
    private val engine: RediscoverEngine = RediscoverEngine()
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return RediscoverViewModel(repository, engine) as T
    }
}
