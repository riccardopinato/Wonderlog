package com.example.rediscover

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class JourneyReplayUiState(
    val loading: Boolean = true,
    val replay: JourneyReplay? = null,
    val currentIndex: Int = 0,
    val playing: Boolean = true,
    val error: String? = null
)

class JourneyReplayViewModel(
    private val journeyId: String,
    private val repository: RediscoverRepository,
    private val builder: JourneyReplayBuilder = JourneyReplayBuilder()
) : ViewModel() {

    private val _state = MutableStateFlow(JourneyReplayUiState())
    val state: StateFlow<JourneyReplayUiState> = _state.asStateFlow()

    private var autoPlayJob: Job? = null

    init {
        loadReplay()
    }

    fun loadReplay() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching {
                val journey = repository.getJourney(journeyId)
                    ?: error("Journey not found")
                val photos = repository.getPhotos()
                val memories = repository.getMemories()

                builder.build(journey, photos, memories)
            }.onSuccess { replay ->
                _state.value = _state.value.copy(
                    loading = false,
                    replay = replay,
                    currentIndex = 0,
                    playing = true
                )
                startAutoPlay()
            }.onFailure { err ->
                _state.value = _state.value.copy(
                    loading = false,
                    error = err.message ?: "Failed to build replay"
                )
            }
        }
    }

    private fun startAutoPlay() {
        autoPlayJob?.cancel()
        autoPlayJob = viewModelScope.launch {
            while (_state.value.playing) {
                val currentReplay = _state.value.replay ?: break
                val currentIdx = _state.value.currentIndex
                if (currentIdx >= currentReplay.slides.lastIndex) {
                    _state.value = _state.value.copy(playing = false)
                    break
                }

                val currentSlide = currentReplay.slides.getOrNull(currentIdx)
                val delayTime = if (currentSlide?.type == JourneyReplaySlideType.MEMORY &&
                    !currentSlide.subtitle.isNullOrBlank()
                ) {
                    6500L
                } else {
                    4500L
                }

                delay(delayTime)

                // Advance if still playing
                if (_state.value.playing) {
                    val nextIdx = _state.value.currentIndex + 1
                    if (nextIdx < currentReplay.slides.size) {
                        _state.value = _state.value.copy(currentIndex = nextIdx)
                        if (nextIdx == currentReplay.slides.lastIndex) {
                            _state.value = _state.value.copy(playing = false)
                            break
                        }
                    } else {
                        _state.value = _state.value.copy(playing = false)
                        break
                    }
                }
            }
        }
    }

    fun next() {
        val replay = _state.value.replay ?: return
        if (_state.value.currentIndex < replay.slides.lastIndex) {
            _state.value = _state.value.copy(currentIndex = _state.value.currentIndex + 1)
            restartTimerIfPlaying()
        }
    }

    fun previous() {
        if (_state.value.currentIndex > 0) {
            _state.value = _state.value.copy(currentIndex = _state.value.currentIndex - 1)
            restartTimerIfPlaying()
        }
    }

    fun togglePlay() {
        val newPlaying = !_state.value.playing
        _state.value = _state.value.copy(playing = newPlaying)
        if (newPlaying) {
            val replay = _state.value.replay
            if (replay != null && _state.value.currentIndex >= replay.slides.lastIndex) {
                _state.value = _state.value.copy(currentIndex = 0)
            }
            startAutoPlay()
        } else {
            autoPlayJob?.cancel()
        }
    }

    fun pause() {
        _state.value = _state.value.copy(playing = false)
        autoPlayJob?.cancel()
    }

    fun resume() {
        if (!_state.value.playing) {
            _state.value = _state.value.copy(playing = true)
            startAutoPlay()
        }
    }

    fun goToSlide(index: Int) {
        val replay = _state.value.replay ?: return
        if (index in replay.slides.indices) {
            _state.value = _state.value.copy(currentIndex = index)
            restartTimerIfPlaying()
        }
    }

    private fun restartTimerIfPlaying() {
        if (_state.value.playing) {
            startAutoPlay()
        }
    }

    override fun onCleared() {
        super.onCleared()
        autoPlayJob?.cancel()
    }
}

class JourneyReplayViewModelFactory(
    private val journeyId: String,
    private val repository: RediscoverRepository,
    private val builder: JourneyReplayBuilder = JourneyReplayBuilder()
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return JourneyReplayViewModel(journeyId, repository, builder) as T
    }
}
