package com.example.rediscover

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.abs

class RediscoverEngine(
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {

    fun buildFeed(
        today: LocalDate,
        journeys: List<RediscoverJourney>,
        memories: List<RediscoverMemory>,
        photos: List<RediscoverPhoto>
    ): RediscoverFeed {
        val exactCards = mutableListOf<RediscoverCard>()

        exactCards += buildJourneyAnniversaries(today, journeys)
        exactCards += buildMemoryAnniversaries(today, memories)
        exactCards += buildPhotoAnniversaries(today, photos)

        val deduplicated = exactCards.distinctBy {
            "${it.type}:${it.journeyId}:${it.memoryId}:${it.photoId}"
        }

        if (deduplicated.isNotEmpty()) {
            return RediscoverFeed(
                cards = deduplicated,
                generatedForDayKey = RediscoverDateUtils.dayKey(today)
            )
        }

        // Fallback 1: Nearby Journey anniversaries (within +/- 3 days of today's month & day)
        val nearbyCards = buildNearbyJourneyAnniversaries(today, journeys)
        if (nearbyCards.isNotEmpty()) {
            return RediscoverFeed(
                cards = nearbyCards.distinctBy { "${it.type}:${it.journeyId}" },
                generatedForDayKey = RediscoverDateUtils.dayKey(today)
            )
        }

        // Fallback 2: Deterministic old Memory fallback (at least 30 days old)
        val fallbackMemoryCard = buildFallbackMemory(today, memories, journeys)
        val fallbackList = if (fallbackMemoryCard != null) listOf(fallbackMemoryCard) else emptyList()

        return RediscoverFeed(
            cards = fallbackList,
            generatedForDayKey = RediscoverDateUtils.dayKey(today)
        )
    }

    private fun buildJourneyAnniversaries(
        today: LocalDate,
        journeys: List<RediscoverJourney>
    ): List<RediscoverCard> {
        return journeys.mapNotNull { journey ->
            val date = RediscoverDateUtils.toLocalDate(journey.startTimestamp, zoneId)
                ?: return@mapNotNull null

            if (!RediscoverDateUtils.isSameMonthDay(date, today)) {
                return@mapNotNull null
            }

            val years = RediscoverDateUtils.yearsBetween(date, today)
            if (years <= 0) {
                return@mapNotNull null
            }

            RediscoverCard(
                id = "journey-anniversary-${journey.id}-${today.year}",
                type = RediscoverType.JOURNEY_ANNIVERSARY,
                title = journey.title,
                subtitle = "$years ${if (years == 1) "year" else "years"} ago",
                journeyId = journey.id,
                memoryId = null,
                photoId = null,
                imageUri = journey.coverPhotoUri,
                timestamp = journey.startTimestamp,
                yearsAgo = years
            )
        }
    }

    private fun buildNearbyJourneyAnniversaries(
        today: LocalDate,
        journeys: List<RediscoverJourney>
    ): List<RediscoverCard> {
        return journeys.mapNotNull { journey ->
            val date = RediscoverDateUtils.toLocalDate(journey.startTimestamp, zoneId)
                ?: return@mapNotNull null

            val years = today.year - date.year
            if (years <= 0) {
                return@mapNotNull null
            }

            val anniversaryThisYear = runCatching {
                date.withYear(today.year)
            }.getOrElse {
                date.plusDays(1).withYear(today.year)
            }

            val diffDays = RediscoverDateUtils.daysDifference(anniversaryThisYear, today)
            if (diffDays in 1..3) {
                RediscoverCard(
                    id = "journey-nearby-${journey.id}-${today.year}",
                    type = RediscoverType.JOURNEY_ANNIVERSARY,
                    title = journey.title,
                    subtitle = "Around this time $years ${if (years == 1) "year" else "years"} ago",
                    journeyId = journey.id,
                    memoryId = null,
                    photoId = null,
                    imageUri = journey.coverPhotoUri,
                    timestamp = journey.startTimestamp,
                    yearsAgo = years
                )
            } else {
                null
            }
        }
    }

    private fun buildMemoryAnniversaries(
        today: LocalDate,
        memories: List<RediscoverMemory>
    ): List<RediscoverCard> {
        return memories.mapNotNull { memory ->
            val date = RediscoverDateUtils.toLocalDate(memory.timestamp, zoneId)
                ?: return@mapNotNull null

            if (!RediscoverDateUtils.isSameMonthDay(date, today)) {
                return@mapNotNull null
            }

            val years = RediscoverDateUtils.yearsBetween(date, today)
            if (years <= 0) {
                return@mapNotNull null
            }

            val subtitle = buildString {
                append("$years ${if (years == 1) "year" else "years"} ago")
                memory.locationName?.takeIf { it.isNotBlank() }?.let {
                    append(" • ")
                    append(it)
                }
            }

            RediscoverCard(
                id = "memory-anniversary-${memory.id}-${today.year}",
                type = RediscoverType.MEMORY,
                title = memory.title,
                subtitle = subtitle,
                journeyId = memory.journeyId,
                memoryId = memory.id,
                photoId = null,
                imageUri = memory.photoUris.firstOrNull(),
                timestamp = memory.timestamp,
                yearsAgo = years
            )
        }
    }

    private fun buildPhotoAnniversaries(
        today: LocalDate,
        photos: List<RediscoverPhoto>
    ): List<RediscoverCard> {
        return photos.mapNotNull { photo ->
            val date = RediscoverDateUtils.toLocalDate(photo.timestamp, zoneId)
                ?: return@mapNotNull null

            if (!RediscoverDateUtils.isSameMonthDay(date, today)) {
                return@mapNotNull null
            }

            val years = RediscoverDateUtils.yearsBetween(date, today)
            if (years <= 0) {
                return@mapNotNull null
            }

            val subtitle = buildString {
                append("$years ${if (years == 1) "year" else "years"} ago")
                photo.locationName?.takeIf { it.isNotBlank() }?.let {
                    append(" • ")
                    append(it)
                }
            }

            RediscoverCard(
                id = "photo-anniversary-${photo.id}-${today.year}",
                type = RediscoverType.PHOTO,
                title = "On this day",
                subtitle = subtitle,
                journeyId = photo.journeyId,
                memoryId = null,
                photoId = photo.id,
                imageUri = photo.localUri,
                timestamp = photo.timestamp,
                yearsAgo = years
            )
        }
    }

    private fun buildFallbackMemory(
        today: LocalDate,
        memories: List<RediscoverMemory>,
        journeys: List<RediscoverJourney>
    ): RediscoverCard? {
        val eligible = memories.filter { memory ->
            val date = RediscoverDateUtils.toLocalDate(memory.timestamp, zoneId)
                ?: return@filter false
            val daysAgo = ChronoUnit.DAYS.between(date, today)
            if (daysAgo < 30) {
                return@filter false
            }
            memory.title.isNotBlank() || !memory.journalText.isNullOrBlank() || memory.photoUris.isNotEmpty()
        }

        if (eligible.isEmpty()) {
            return null
        }

        val dayKey = RediscoverDateUtils.dayKey(today)
        val seed = dayKey.hashCode()
        val selected = eligible.minByOrNull { abs((it.id + seed).hashCode()) } ?: return null

        val journeyTitle = journeys.firstOrNull { it.id == selected.journeyId }?.title
        val subtitle = if (!journeyTitle.isNullOrBlank()) {
            "From $journeyTitle"
        } else {
            selected.locationName?.takeIf { it.isNotBlank() } ?: "Resurfaced Memory"
        }

        val memDate = RediscoverDateUtils.toLocalDate(selected.timestamp, zoneId) ?: today
        val yearsAgo = RediscoverDateUtils.yearsBetween(memDate, today).takeIf { it > 0 }

        return RediscoverCard(
            id = "memory-fallback-${selected.id}-$dayKey",
            type = RediscoverType.MEMORY,
            title = selected.title,
            subtitle = subtitle,
            journeyId = selected.journeyId,
            memoryId = selected.id,
            photoId = null,
            imageUri = selected.photoUris.firstOrNull(),
            timestamp = selected.timestamp,
            yearsAgo = yearsAgo
        )
    }
}
