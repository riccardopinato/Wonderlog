package com.example.rediscover

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.WanderlogDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream

class RediscoverWidgetProvider : AppWidgetProvider() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val goAsync = goAsync()
        scope.launch {
            try {
                val db = WanderlogDatabase.getDatabase(context)
                val repo = RediscoverRepositoryImpl(db)
                val journeys = repo.getJourneys()
                val memories = repo.getMemories()
                val photos = repo.getPhotos()

                val engine = RediscoverEngine()
                val feed = engine.buildFeed(
                    today = java.time.LocalDate.now(),
                    journeys = journeys,
                    memories = memories,
                    photos = photos
                )
                val bestCard = RediscoverSelectionEngine.selectWidgetCard(feed)

                for (appWidgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_memory_of_the_day)

                    if (bestCard != null) {
                        views.setViewVisibility(R.id.widget_empty_text, View.GONE)
                        views.setViewVisibility(R.id.widget_title, View.VISIBLE)
                        views.setViewVisibility(R.id.widget_subtitle, View.VISIBLE)
                        views.setViewVisibility(R.id.widget_badge, View.VISIBLE)

                        views.setTextViewText(R.id.widget_title, bestCard.title)
                        
                        val subtitle = if (!bestCard.subtitle.isNullOrBlank()) {
                            bestCard.subtitle
                        } else if (bestCard.yearsAgo != null && bestCard.yearsAgo > 0) {
                            "${bestCard.yearsAgo} year${if (bestCard.yearsAgo > 1) "s" else ""} ago today"
                        } else {
                            "Rediscover your journeys"
                        }
                        views.setTextViewText(R.id.widget_subtitle, subtitle)

                        val badgeText = when (bestCard.type) {
                            RediscoverType.ON_THIS_DAY -> "✨ ON THIS DAY"
                            RediscoverType.JOURNEY_ANNIVERSARY -> "✈️ JOURNEY ANNIVERSARY"
                            RediscoverType.MEMORY -> "📖 MEMORY"
                            RediscoverType.PHOTO -> "📸 MOMENT"
                        }
                        views.setTextViewText(R.id.widget_badge, badgeText)

                        // Load photo if available
                        val photoUri = bestCard.imageUri
                        var bitmap: Bitmap? = null
                        if (!photoUri.isNullOrBlank()) {
                            bitmap = loadSampledBitmap(context, photoUri)
                        }

                        if (bitmap != null) {
                            views.setImageViewBitmap(R.id.widget_image, bitmap)
                            views.setViewVisibility(R.id.widget_image, View.VISIBLE)
                        } else {
                            views.setViewVisibility(R.id.widget_image, View.GONE)
                        }

                        // Tap Intent to open the trip or app
                        val intent = Intent(context, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            bestCard.journeyId?.let { putExtra("EXTRA_JOURNEY_ID", it) }
                            bestCard.memoryId?.let { putExtra("EXTRA_MEMORY_ID", it) }
                            putExtra("EXTRA_NAVIGATE_TO", "REDISCOVER")
                        }
                        val pendingIntent = PendingIntent.getActivity(
                            context,
                            appWidgetId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                    } else {
                        // Empty state
                        views.setViewVisibility(R.id.widget_image, View.GONE)
                        views.setViewVisibility(R.id.widget_title, View.GONE)
                        views.setViewVisibility(R.id.widget_subtitle, View.GONE)
                        views.setViewVisibility(R.id.widget_badge, View.GONE)
                        views.setViewVisibility(R.id.widget_empty_text, View.VISIBLE)

                        val intent = Intent(context, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        val pendingIntent = PendingIntent.getActivity(
                            context,
                            appWidgetId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                    }

                    appWidgetManager.updateAppWidget(appWidgetId, views)
                }
            } catch (e: Exception) {
                // Graceful fallback
            } finally {
                goAsync.finish()
            }
        }
    }

    private fun loadSampledBitmap(context: Context, pathOrUri: String): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }

            openStream(context, pathOrUri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }

            val targetWidth = 600
            val targetHeight = 400
            var inSampleSize = 1
            if (options.outHeight > targetHeight || options.outWidth > targetWidth) {
                val halfHeight = options.outHeight / 2
                val halfWidth = options.outWidth / 2
                while ((halfHeight / inSampleSize) >= targetHeight && (halfWidth / inSampleSize) >= targetWidth) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
            }

            openStream(context, pathOrUri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun openStream(context: Context, pathOrUri: String): InputStream? {
        return if (pathOrUri.startsWith("content://") || pathOrUri.startsWith("file://")) {
            context.contentResolver.openInputStream(Uri.parse(pathOrUri))
        } else {
            val file = File(pathOrUri)
            if (file.exists()) file.inputStream() else null
        }
    }

    companion object {
        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, RediscoverWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
            if (appWidgetIds.isNotEmpty()) {
                val intent = Intent(context, RediscoverWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}
