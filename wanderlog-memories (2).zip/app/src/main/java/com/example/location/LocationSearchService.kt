package com.example.location

import android.util.Log
import com.example.network.WonderlogNetworkIdentity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class LocationSearchResult(
    val displayName: String,
    val cityOrName: String,
    val country: String,
    val latitude: Double,
    val longitude: Double
)

object LocationSearchService {
    private const val TAG = "LocationSearchService"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun searchLocation(query: String): List<LocationSearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        
        // OSM Nominatim API requires a custom User-Agent to prevent 403 Forbidden
        val url = "https://nominatim.openstreetmap.org/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&format=json&limit=5&addressdetails=1"
        
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", WonderlogNetworkIdentity.USER_AGENT)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "OSM Nominatim API request failed: ${response.code}")
                    return@withContext emptyList()
                }
                
                val bodyString = response.body?.string() ?: ""
                val jsonArray = JSONArray(bodyString)
                val results = mutableListOf<LocationSearchResult>()
                
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val lat = obj.optDouble("lat", 0.0)
                    val lon = obj.optDouble("lon", 0.0)
                    val displayName = obj.optString("display_name", "")
                    
                    val address = obj.optJSONObject("address")
                    val country = address?.optString("country", "") ?: ""
                    
                    // Try to extract a clean city or tourist spot name
                    val cityOrName = address?.optString("city")
                        ?: address?.optString("town")
                        ?: address?.optString("village")
                        ?: address?.optString("municipality")
                        ?: address?.optString("attraction")
                        ?: address?.optString("tourism")
                        ?: displayName.split(",").firstOrNull()?.trim()
                        ?: ""

                    results.add(
                        LocationSearchResult(
                            displayName = displayName,
                            cityOrName = cityOrName,
                            country = country,
                            latitude = lat,
                            longitude = lon
                        )
                    )
                }
                return@withContext results
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error searching location on OSM", e)
            return@withContext emptyList()
        }
    }
}
