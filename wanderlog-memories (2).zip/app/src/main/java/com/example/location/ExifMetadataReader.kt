package com.example.location

import android.content.Context
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import com.example.network.WonderlogNetworkIdentity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class PhotoMetadata(
    val dateString: String?, // YYYY-MM-DD
    val latitude: Double?,
    val longitude: Double?,
    val resolvedPlaceName: String?,
    val resolvedCountry: String?
)

object ExifMetadataReader {
    private const val TAG = "ExifMetadataReader"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    /**
     * Extracts Exif details from an image URI and optionally reverse-geocodes GPS coordinates on OSM.
     */
    suspend fun extractMetadata(context: Context, uri: Uri): PhotoMetadata = withContext(Dispatchers.IO) {
        var dateString: String? = null
        var latitude: Double? = null
        var longitude: Double? = null
        
        try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            if (inputStream != null) {
                val exifInterface = ExifInterface(inputStream)
                
                // 1. Extract date
                val rawDate = exifInterface.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                    ?: exifInterface.getAttribute(ExifInterface.TAG_DATETIME)
                if (rawDate != null) {
                    try {
                        // Standard EXIF format is "yyyy:MM:dd HH:mm:ss"
                        val parser = SimpleDateFormat("yyyy:MM:dd", Locale.getDefault())
                        val parsedDate: Date? = parser.parse(rawDate.substring(0, 10))
                        if (parsedDate != null) {
                            val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                            dateString = formatter.format(parsedDate)
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to parse raw date: $rawDate", e)
                    }
                }
                
                // 2. Extract GPS coordinates
                val latLong = FloatArray(2)
                if (exifInterface.getLatLong(latLong)) {
                    latitude = latLong[0].toDouble()
                    longitude = latLong[1].toDouble()
                    Log.d(TAG, "Extracted EXIF GPS: Lat=$latitude, Lon=$longitude")
                }
                
                inputStream.close()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting EXIF metadata: ${e.message}", e)
        }
        
        // 3. Reverse geocode if coordinates exist
        var resolvedPlaceName: String? = null
        var resolvedCountry: String? = null
        
        if (latitude != null && longitude != null) {
            val resolved = reverseGeocode(latitude, longitude)
            if (resolved != null) {
                resolvedPlaceName = resolved.first
                resolvedCountry = resolved.second
            }
        }
        
        PhotoMetadata(
            dateString = dateString,
            latitude = latitude,
            longitude = longitude,
            resolvedPlaceName = resolvedPlaceName,
            resolvedCountry = resolvedCountry
        )
    }

    /**
     * Calls OSM Nominatim Reverse Geocoding to translate coordinates to a placename.
     */
    private suspend fun reverseGeocode(lat: Double, lon: Double): Pair<String, String>? = withContext(Dispatchers.IO) {
        val url = "https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lon&format=json&accept-language=en"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", WonderlogNetworkIdentity.USER_AGENT)
            .build()
            
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val bodyString = response.body?.string() ?: ""
                val json = JSONObject(bodyString)
                val displayName = json.optString("display_name", "")
                
                val address = json.optJSONObject("address")
                val country = address?.optString("country", "") ?: ""
                
                val placeName = address?.optString("suburb")
                    ?: address?.optString("city")
                    ?: address?.optString("town")
                    ?: address?.optString("village")
                    ?: address?.optString("tourism")
                    ?: address?.optString("attraction")
                    ?: displayName.split(",").firstOrNull()?.trim()
                    ?: ""
                
                return@withContext Pair(placeName, country)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Nominatim Reverse Geocoding error: ${e.message}")
            return@withContext null
        }
    }
}
