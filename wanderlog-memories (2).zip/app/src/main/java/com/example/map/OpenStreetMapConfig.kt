package com.example.map

object OpenStreetMapConfig {

    const val TILE_SOURCE_NAME =
        "Mapnik"

    const val USER_AGENT =
        "Wonderlog/1.0"

    const val MIN_ZOOM =
        3.0

    const val MAX_ZOOM =
        20.0

    const val DEFAULT_ZOOM =
        13.5

    const val SINGLE_CLUSTER_ZOOM =
        15.5
}
