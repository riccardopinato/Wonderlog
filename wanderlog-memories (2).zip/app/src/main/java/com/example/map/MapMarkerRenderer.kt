package com.example.map

import android.graphics.Bitmap
import com.example.domain.model.MapMarker

class MapMarkerRenderer {
    fun renderMarkerIcon(marker: MapMarker): Bitmap? {
        // Generates custom circular image pin with colored borders based on trip mood
        return null
    }
}
