package com.example.map

import android.util.Log
import com.example.data.local.LocationPlaceDao
import com.example.data.local.GeocodingCacheDao
import com.example.data.local.OfflineMapRegionDao
import com.example.domain.model.*
import com.example.domain.repository.MapRepository
import com.example.network.WonderlogNetworkIdentity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit

class OpenStreetMapRepository(
    private val locationPlaceDao: LocationPlaceDao,
    private val geocodingCacheDao: GeocodingCacheDao,
    private val offlineMapRegionDao: OfflineMapRegionDao
) : MapRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val userAgent = WonderlogNetworkIdentity.USER_AGENT

    override suspend fun searchPlaces(query: String): List<LocationPlace> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        
        // 1. Check local Geocoding Cache first
        val cached = geocodingCacheDao.getCache(query)
        if (cached != null) {
            Log.d("OSMRepo", "Cache hit for query: $query")
            return@withContext listOf(
                LocationPlace(
                    id = UUID.randomUUID().toString(),
                    displayName = cached.displayName,
                    country = cached.country,
                    city = cached.city,
                    region = cached.region,
                    latitude = cached.latitude,
                    longitude = cached.longitude,
                    source = "CACHED"
                )
            )
        }

        // 2. Network call to Nominatim
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&limit=5&addressdetails=1&accept-language=en"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e("OSMRepo", "Nominatim search failed with code ${response.code}")
                    return@withContext emptyList()
                }

                val body = response.body?.string() ?: ""
                val array = JSONArray(body)
                val results = mutableListOf<LocationPlace>()

                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val lat = obj.optDouble("lat", 0.0)
                    val lon = obj.optDouble("lon", 0.0)
                    val displayName = obj.optString("display_name", "")

                    val addressObj = obj.optJSONObject("address")
                    val country = addressObj?.optString("country") ?: ""
                    val city = addressObj?.optString("city")
                        ?: addressObj?.optString("town")
                        ?: addressObj?.optString("village")
                        ?: addressObj?.optString("municipality")
                        ?: ""
                    val region = addressObj?.optString("state")
                        ?: addressObj?.optString("county")
                        ?: addressObj?.optString("region")
                        ?: ""

                    val place = LocationPlace(
                        id = UUID.randomUUID().toString(),
                        displayName = displayName,
                        country = country,
                        city = city,
                        region = region,
                        latitude = lat,
                        longitude = lon,
                        source = "NOMINATIM"
                    )
                    results.add(place)

                    // Cache the first exact result
                    if (i == 0) {
                        geocodingCacheDao.insertCache(
                            GeocodingCache(
                                query = query,
                                displayName = displayName,
                                country = country,
                                city = city,
                                region = region,
                                latitude = lat,
                                longitude = lon
                            )
                        )
                    }
                }
                return@withContext results
            }
        } catch (e: Exception) {
            Log.e("OSMRepo", "Error calling search Nominatim API", e)
            return@withContext emptyList()
        }
    }

    override suspend fun reverseGeocode(latitude: Double, longitude: Double): LocationPlace? = withContext(Dispatchers.IO) {
        // Query as query representation
        val queryKey = "lat=${latitude}&lon=${longitude}"
        val cached = geocodingCacheDao.getCache(queryKey)
        if (cached != null) {
            return@withContext LocationPlace(
                id = UUID.randomUUID().toString(),
                displayName = cached.displayName,
                country = cached.country,
                city = cached.city,
                region = cached.region,
                latitude = cached.latitude,
                longitude = cached.longitude,
                source = "CACHED"
            )
        }

        val url = "https://nominatim.openstreetmap.org/reverse?lat=$latitude&lon=$longitude&format=json&accept-language=en"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: ""
                val json = JSONObject(body)
                val displayName = json.optString("display_name", "")

                val addressObj = json.optJSONObject("address")
                val country = addressObj?.optString("country") ?: ""
                val city = addressObj?.optString("city")
                    ?: addressObj?.optString("town")
                    ?: addressObj?.optString("village")
                    ?: addressObj?.optString("municipality")
                    ?: ""
                val region = addressObj?.optString("state")
                    ?: addressObj?.optString("county")
                    ?: ""

                val place = LocationPlace(
                    id = UUID.randomUUID().toString(),
                    displayName = displayName,
                    country = country,
                    city = city,
                    region = region,
                    latitude = latitude,
                    longitude = longitude,
                    source = "NOMINATIM"
                )

                // Cache it
                geocodingCacheDao.insertCache(
                    GeocodingCache(
                        query = queryKey,
                        displayName = displayName,
                        country = country,
                        city = city,
                        region = region,
                        latitude = latitude,
                        longitude = longitude
                    )
                )

                return@withContext place
            }
        } catch (e: Exception) {
            Log.e("OSMRepo", "Error calling reverse Nominatim API", e)
            return@withContext null
        }
    }

    override fun getAllOfflineRegions(): Flow<List<OfflineMapRegion>> = offlineMapRegionDao.getAllRegions()

    override suspend fun saveOfflineRegion(region: OfflineMapRegion) {
        offlineMapRegionDao.insertRegion(region)
    }

    override suspend fun deleteOfflineRegion(region: OfflineMapRegion) {
        offlineMapRegionDao.deleteRegion(region)
    }

    override suspend fun getOfflineRegionById(id: String): OfflineMapRegion? {
        return offlineMapRegionDao.getRegionById(id)
    }

    override fun getAllSavedPlaces(): Flow<List<LocationPlace>> = locationPlaceDao.getAllPlaces()

    override suspend fun savePlace(place: LocationPlace) {
        locationPlaceDao.insertPlace(place)
    }

    override suspend fun deletePlace(place: LocationPlace) {
        locationPlaceDao.deletePlace(place)
    }
}
