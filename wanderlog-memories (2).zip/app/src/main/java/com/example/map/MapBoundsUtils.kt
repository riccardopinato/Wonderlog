package com.example.map

import com.example.mapmemories.MapMemoryCluster
import org.osmdroid.util.BoundingBox

object MapBoundsUtils {

    fun fromClusters(
        clusters:
            List<MapMemoryCluster>
    ): BoundingBox? {

        if (
            clusters.isEmpty()
        ) {
            return null
        }

        val north =
            clusters.maxOf {
                it.coordinate
                    .latitude
            }

        val south =
            clusters.minOf {
                it.coordinate
                    .latitude
            }

        val east =
            clusters.maxOf {
                it.coordinate
                    .longitude
            }

        val west =
            clusters.minOf {
                it.coordinate
                    .longitude
            }

        return BoundingBox(
            north,
            east,
            south,
            west
        )
    }
}
