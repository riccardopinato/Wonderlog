package com.example.map

import com.example.domain.model.LocationCoordinate
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

class UserLocationService {
    fun observeCurrentLocation(): Flow<LocationCoordinate> {
        // Simulates observing GPS location stream
        return flowOf(LocationCoordinate(35.6762, 139.6503))
    }
}
