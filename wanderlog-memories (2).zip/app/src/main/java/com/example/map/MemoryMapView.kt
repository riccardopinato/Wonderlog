package com.example.map

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.domain.model.LocationCoordinate
import com.example.domain.model.MapMarker
import com.example.mapmemories.JourneyRoutePoint
import com.example.mapmemories.MapCoordinate
import com.example.mapmemories.MapMemoryCluster
import com.example.ui.components.createWonderlogClusterDrawable
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

@Composable
fun MemoryMapView(
    modifier: Modifier = Modifier,
    clusters: List<MapMemoryCluster> = emptyList(),
    route: List<JourneyRoutePoint> = emptyList(),
    selectedClusterId: String? = null,
    cameraFitRequestKey: Int = 0,
    focusCoordinate: MapCoordinate? = null,
    onClusterClick: (String) -> Unit = {},
    onMapUserInteraction: () -> Unit = {},
    markers: List<MapMarker> = emptyList(),
    centerCoordinate: LocationCoordinate? = null,
    onMarkerClick: (MapMarker) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val latestClusterClick by rememberUpdatedState(onClusterClick)
    val latestMarkerClick by rememberUpdatedState(onMarkerClick)
    val latestUserInteraction by rememberUpdatedState(onMapUserInteraction)
    val latestClusters by rememberUpdatedState(clusters)

    var mapViewRef by remember {
        mutableStateOf<MapView?>(null)
    }

    var lastHandledFitRequest by remember {
        mutableIntStateOf(Int.MIN_VALUE)
    }

    LaunchedEffect(Unit) {
        OsmMapLifecycle.ensureConfigured(context)
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { androidContext ->
            OsmMapLifecycle.ensureConfigured(androidContext)

            MapView(androidContext).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                setMultiTouchControls(true)
                minZoomLevel = OpenStreetMapConfig.MIN_ZOOM
                maxZoomLevel = OpenStreetMapConfig.MAX_ZOOM

                controller.setZoom(OpenStreetMapConfig.DEFAULT_ZOOM)
                if (centerCoordinate != null) {
                    controller.setCenter(GeoPoint(centerCoordinate.latitude, centerCoordinate.longitude))
                }

                isTilesScaledToDpi = true
                setBuiltInZoomControls(false)

                val receiver = object : MapEventsReceiver {
                    override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean = false
                    override fun longPressHelper(p: GeoPoint?): Boolean = false
                }

                overlays.add(MapEventsOverlay(receiver))

                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        android.view.MotionEvent.ACTION_MOVE,
                        android.view.MotionEvent.ACTION_UP -> {
                            latestUserInteraction()
                        }
                    }
                    false
                }

                mapViewRef = this
            }
        },
        update = { map ->
            val removable = map.overlays.filter { overlay ->
                overlay is Marker || overlay is Polyline
            }
            removable.forEach { map.overlays.remove(it) }

            if (route.size >= 2) {
                val polyline = Polyline(map).apply {
                    setPoints(
                        route.map { point ->
                            GeoPoint(
                                point.coordinate.latitude,
                                point.coordinate.longitude
                            )
                        }
                    )
                    outlinePaint.color = AndroidColor.argb(150, 112, 90, 220)
                    outlinePaint.strokeWidth = 7f
                    isGeodesic = true
                }
                map.overlays.add(polyline)
            }

            clusters.forEach { cluster ->
                val marker = Marker(map).apply {
                    position = GeoPoint(
                        cluster.coordinate.latitude,
                        cluster.coordinate.longitude
                    )
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    title = cluster.dominantTitle ?: "Journey stop"
                    snippet = "${cluster.photoCount} photos • ${cluster.memoryCount} Memories"
                    relatedObject = cluster.id
                    icon = createWonderlogClusterDrawable(
                        context = map.context,
                        count = cluster.count,
                        selected = cluster.id == selectedClusterId
                    )
                    setOnMarkerClickListener { clicked, _ ->
                        val id = clicked.relatedObject as? String
                        if (id != null) {
                            latestClusterClick(id)
                        }
                        true
                    }
                }
                map.overlays.add(marker)
            }

            if (clusters.isEmpty() && markers.isNotEmpty()) {
                markers.forEach { mapMarker ->
                    val marker = Marker(map).apply {
                        position = GeoPoint(
                            mapMarker.coordinate.latitude,
                            mapMarker.coordinate.longitude
                        )
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        title = mapMarker.title
                        snippet = mapMarker.subtitle
                        setOnMarkerClickListener { _, _ ->
                            latestMarkerClick(mapMarker)
                            true
                        }
                    }
                    map.overlays.add(marker)
                }
            }

            map.invalidate()
        }
    )

    fun fitVisibleClusters() {
        val map = mapViewRef ?: return
        val currentClusters = latestClusters

        if (currentClusters.isEmpty()) {
            if (centerCoordinate != null) {
                map.controller.setZoom(OpenStreetMapConfig.DEFAULT_ZOOM)
                map.controller.animateTo(
                    GeoPoint(
                        centerCoordinate.latitude,
                        centerCoordinate.longitude
                    )
                )
            }
            return
        }

        if (currentClusters.size == 1) {
            val only = currentClusters.first()
            map.controller.setZoom(OpenStreetMapConfig.SINGLE_CLUSTER_ZOOM)
            map.controller.animateTo(
                GeoPoint(
                    only.coordinate.latitude,
                    only.coordinate.longitude
                )
            )
        } else {
            val bounds = MapBoundsUtils.fromClusters(currentClusters) ?: return
            map.zoomToBoundingBox(bounds, true, 96)
        }
    }

    LaunchedEffect(cameraFitRequestKey) {
        if (cameraFitRequestKey == lastHandledFitRequest) {
            return@LaunchedEffect
        }
        lastHandledFitRequest = cameraFitRequestKey
        fitVisibleClusters()
    }

    LaunchedEffect(focusCoordinate) {
        focusCoordinate?.let { coordinate ->
            mapViewRef?.controller?.apply {
                setZoom(16.0)
                animateTo(
                    GeoPoint(
                        coordinate.latitude,
                        coordinate.longitude
                    )
                )
            }
        }
    }

    DisposableEffect(lifecycleOwner, mapViewRef) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapViewRef?.onResume()
                Lifecycle.Event.ON_PAUSE -> mapViewRef?.onPause()
                else -> Unit
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapViewRef?.onPause()
            mapViewRef?.onDetach()
            mapViewRef = null
        }
    }
}
