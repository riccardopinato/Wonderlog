package com.example.map

object MapProvider {

    const val NAME =
        "OpenStreetMap"

    const val ENGINE =
        "osmdroid"

    const val SUPPORTS_REAL_TILES =
        true

    const val SUPPORTS_PAN =
        true

    const val SUPPORTS_ZOOM =
        true

    const val SUPPORTS_POLYLINES =
        true

    const val SUPPORTS_MARKERS =
        true
}
