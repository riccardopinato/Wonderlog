package com.example.map

import com.example.domain.model.LocationCoordinate
import com.example.domain.model.TileCachePolicy
import com.example.domain.model.TileDownloadQueue
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

class OfflineTileCacheManager {
    fun getDownloadQueue(): Flow<List<TileDownloadQueue>> {
        return flowOf(
            listOf(
                TileDownloadQueue("region_1", 0, 150, "COMPLETED"),
                TileDownloadQueue("region_2", 80, 20, "DOWNLOADING")
            )
        )
    }

    suspend fun cacheTiles(center: LocationCoordinate, radiusKm: Double, zoomRange: IntRange) {
        // Downloads and saves OSM tiles in local storage for offline use
    }

    fun isTileCached(zoom: Int, x: Int, y: Int): Boolean {
        return true
    }

    fun cleanCache(limitMb: Int) {
        // Purges tile cache to respect limit constraints
    }

    fun getCachePolicy(): TileCachePolicy {
        return TileCachePolicy.CACHE_FIRST
    }
}
