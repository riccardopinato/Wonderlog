package com.example.map

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.*
import com.example.domain.repository.MapRepository
import com.example.data.local.WanderlogDatabase
import com.example.premium.PremiumManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface MapEvent {
    data class ShowMessage(val message: String) : MapEvent
    data class ZoomTo(val coordinate: LocationCoordinate) : MapEvent
}

sealed interface MapAction {
    data class SelectMarker(val marker: MapMarker?) : MapAction
    data class UpdateSearchQuery(val query: String) : MapAction
    object TriggerSearch : MapAction
    data class SelectPlaceResult(val place: LocationPlace) : MapAction
    data class ToggleMoodFilter(val mood: Mood?) : MapAction
    data class ToggleTypeFilter(val type: String?) : MapAction // "All", "Memory", "AlbumPhoto"
    data class SetCenter(val coordinate: LocationCoordinate) : MapAction
    object RequestCurrentLocation : MapAction
    data class CreateOfflineRegion(val name: String, val radiusKm: Double) : MapAction
    data class DeleteOfflineRegion(val region: OfflineMapRegion) : MapAction
}

class MapViewModel(
    application: Application,
    private val mapRepository: MapRepository,
    private val db: WanderlogDatabase
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MapUiState())
    val uiState: StateFlow<MapUiState> = _uiState.asStateFlow()

    private val _event = MutableSharedFlow<MapEvent>()
    val event: SharedFlow<MapEvent> = _event.asSharedFlow()

    private var journeyId: String? = null

    init {
        // Collect saved places
        viewModelScope.launch {
            mapRepository.getAllSavedPlaces().collect { places ->
                _uiState.update { it.copy(savedPlaces = places) }
            }
        }

        // Collect offline regions
        viewModelScope.launch {
            mapRepository.getAllOfflineRegions().collect { regions ->
                _uiState.update { it.copy(offlineRegions = regions) }
            }
        }

        // Collect premium status
        viewModelScope.launch {
            PremiumManager.isPremium.collect { isPremium ->
                _uiState.update { it.copy(isPremium = isPremium) }
            }
        }
    }

    fun setJourney(tripId: String) {
        this.journeyId = tripId
        
        // Observe memories and album photos for this journey to build markers dynamically
        viewModelScope.launch {
            val memoriesFlow = db.memoryDao().getMemoriesForTrip(tripId)
            val photosFlow = db.albumPhotoDao().getPhotosForJourney(tripId)
            val tripFlow = flow { emit(db.tripDao().getTripById(tripId)) }

            combine(memoriesFlow, photosFlow, tripFlow) { memories, photos, trip ->
                val markersList = mutableListOf<MapMarker>()

                // 1. Map Memories to Markers
                memories.forEach { memory ->
                    val coord = memory.coordinate
                    if (coord != null) {
                        markersList.add(
                            MapMarker(
                                id = "memory_${memory.id}",
                                journeyId = tripId,
                                memoryId = memory.id,
                                coordinate = coord,
                                title = memory.title,
                                subtitle = memory.locationName,
                                type = "Memory",
                                mood = memory.mood,
                                thumbnailUri = memory.image,
                                createdAt = memory.createdAt
                            )
                        )
                    }
                }

                // 2. Map Album Photos with EXIF coordinate to Markers
                photos.forEach { photo ->
                    val coord = photo.gpsCoordinate
                    if (coord != null) {
                        markersList.add(
                            MapMarker(
                                id = "photo_${photo.id}",
                                journeyId = tripId,
                                albumPhotoId = photo.id,
                                coordinate = coord,
                                title = photo.locationName.ifBlank { "Photo Detail" },
                                subtitle = "Captured Photo",
                                type = "AlbumPhoto",
                                mood = Mood.CALM, // photos default to Calm mood for markers
                                thumbnailUri = photo.localUri,
                                createdAt = photo.createdAt
                            )
                        )
                    }
                }

                // 3. Set map center to Trip default location if we have no center set yet
                if (trip != null && _uiState.value.centerCoordinate.latitude == 35.6762 && _uiState.value.centerCoordinate.longitude == 139.6503) {
                    val tripCoord = LocationCoordinate(trip.latitude, trip.longitude)
                    _uiState.update { it.copy(centerCoordinate = tripCoord) }
                }

                markersList
            }.collect { markers ->
                _uiState.update { 
                    it.copy(markers = markers)
                }
                applyFilters()
            }
        }
    }

    fun onAction(action: MapAction) {
        when (action) {
            is MapAction.SelectMarker -> {
                _uiState.update { it.copy(selectedMarker = action.marker) }
            }
            is MapAction.UpdateSearchQuery -> {
                _uiState.update { it.copy(searchQuery = action.query) }
                if (action.query.isBlank()) {
                    _uiState.update { it.copy(searchResults = emptyList(), isSearching = false) }
                }
            }
            is MapAction.TriggerSearch -> {
                val query = _uiState.value.searchQuery
                if (query.isNotBlank()) {
                    _uiState.update { it.copy(isSearching = true, error = null) }
                    viewModelScope.launch {
                        try {
                            val results = mapRepository.searchPlaces(query)
                            _uiState.update { it.copy(searchResults = results, isSearching = false) }
                            if (results.isEmpty()) {
                                _event.emit(MapEvent.ShowMessage("No spots found on OSM for: $query"))
                            }
                        } catch (e: Exception) {
                            _uiState.update { it.copy(error = e.localizedMessage, isSearching = false) }
                            _event.emit(MapEvent.ShowMessage("Search failed: ${e.message}"))
                        }
                    }
                }
            }
            is MapAction.SelectPlaceResult -> {
                val place = action.place
                val coord = place.coordinate
                _uiState.update { 
                    it.copy(
                        centerCoordinate = coord,
                        searchQuery = place.city.ifBlank { place.displayName.split(",").firstOrNull() ?: "" },
                        searchResults = emptyList()
                    )
                }
                viewModelScope.launch {
                    _event.emit(MapEvent.ZoomTo(coord))
                }
            }
            is MapAction.ToggleMoodFilter -> {
                val current = _uiState.value.selectedMoodFilter
                val next = if (current == action.mood) null else action.mood
                _uiState.update { it.copy(selectedMoodFilter = next) }
                applyFilters()
            }
            is MapAction.ToggleTypeFilter -> {
                val current = _uiState.value.selectedTypeFilter
                val next = if (current == action.type) null else action.type
                _uiState.update { it.copy(selectedTypeFilter = next) }
                applyFilters()
            }
            is MapAction.SetCenter -> {
                _uiState.update { it.copy(centerCoordinate = action.coordinate) }
            }
            is MapAction.RequestCurrentLocation -> {
                // Emulates user current location acquisition on OSM
                viewModelScope.launch {
                    val gpsLocation = LocationCoordinate(35.6895, 139.6917) // Tokyo Metropolitan GPS mockup
                    _uiState.update { it.copy(centerCoordinate = gpsLocation) }
                    _event.emit(MapEvent.ZoomTo(gpsLocation))
                    _event.emit(MapEvent.ShowMessage("📍 Centered on your GPS Location"))
                }
            }
            is MapAction.CreateOfflineRegion -> {
                val isPremium = _uiState.value.isPremium
                if (!isPremium) {
                    viewModelScope.launch {
                        _event.emit(MapEvent.ShowMessage("🔒 Offline Maps is a Premium Feature!"))
                    }
                    return
                }

                viewModelScope.launch {
                    val newRegion = OfflineMapRegion(
                        id = UUID.randomUUID().toString(),
                        name = action.name,
                        centerLatitude = _uiState.value.centerCoordinate.latitude,
                        centerLongitude = _uiState.value.centerCoordinate.longitude,
                        radiusKm = action.radiusKm,
                        zoomMin = 10,
                        zoomMax = 16,
                        sizeBytes = (1024 * 1024 * (3..12).random()).toLong(), // Random size placeholder 3MB-12MB
                        isDownloaded = true,
                        downloadProgress = 1.0f
                    )
                    mapRepository.saveOfflineRegion(newRegion)
                    _event.emit(MapEvent.ShowMessage("🗺️ Offline region '${action.name}' downloaded successfully!"))
                }
            }
            is MapAction.DeleteOfflineRegion -> {
                viewModelScope.launch {
                    mapRepository.deleteOfflineRegion(action.region)
                    _event.emit(MapEvent.ShowMessage("Deleted offline region: ${action.region.name}"))
                }
            }
        }
    }

    private fun applyFilters() {
        val state = _uiState.value
        var filtered = state.markers

        // 1. Filter by mood
        state.selectedMoodFilter?.let { mood ->
            filtered = filtered.filter { it.mood == mood }
        }

        // 2. Filter by type
        state.selectedTypeFilter?.let { type ->
            if (type != "All") {
                filtered = filtered.filter { it.type.equals(type, ignoreCase = true) }
            }
        }

        _uiState.update { it.copy(filteredMarkers = filtered) }
    }
}

data class MapUiState(
    val markers: List<MapMarker> = emptyList(),
    val filteredMarkers: List<MapMarker> = emptyList(),
    val centerCoordinate: LocationCoordinate = LocationCoordinate(35.6762, 139.6503), // Defaults to Tokyo
    val zoomLevel: Int = 12,
    val selectedMarker: MapMarker? = null,
    val searchQuery: String = "",
    val searchResults: List<LocationPlace> = emptyList(),
    val isSearching: Boolean = false,
    val savedPlaces: List<LocationPlace> = emptyList(),
    val offlineRegions: List<OfflineMapRegion> = emptyList(),
    val selectedMoodFilter: Mood? = null,
    val selectedTypeFilter: String? = null, // "All", "Memory", "AlbumPhoto"
    val error: String? = null,
    val isPremium: Boolean = false
)
