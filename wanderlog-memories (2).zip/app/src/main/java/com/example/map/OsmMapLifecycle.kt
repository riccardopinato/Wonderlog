package com.example.map

import android.content.Context
import org.osmdroid.config.Configuration

object OsmMapLifecycle {

    private var configured =
        false

    fun ensureConfigured(
        context: Context
    ) {

        if (
            configured
        ) {
            return
        }

        Configuration
            .getInstance()
            .apply {

                userAgentValue =
                    OpenStreetMapConfig
                        .USER_AGENT

                load(
                    context.applicationContext,
                    context
                        .getSharedPreferences(
                            "osmdroid",
                            Context.MODE_PRIVATE
                        )
                )
            }

        configured =
            true
    }
}
