package com.example

import com.example.cloud.CloudIdFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class CloudIdFactoryTest {

    @Test
    fun journeyId_isDeterministic() {

        val first =
            CloudIdFactory.journey(
                ownerId = "user1",
                localId = "trip1"
            )

        val second =
            CloudIdFactory.journey(
                ownerId = "user1",
                localId = "trip1"
            )

        assertEquals(
            first,
            second
        )
    }

    @Test
    fun differentEntityTypes_doNotCollide() {

        val journey =
            CloudIdFactory.journey(
                "user1",
                "123"
            )

        val memory =
            CloudIdFactory.memory(
                "user1",
                "123"
            )

        val photo =
            CloudIdFactory.photo(
                "user1",
                "123"
            )

        assertNotEquals(
            journey,
            memory
        )

        assertNotEquals(
            journey,
            photo
        )

        assertNotEquals(
            memory,
            photo
        )
    }
}
