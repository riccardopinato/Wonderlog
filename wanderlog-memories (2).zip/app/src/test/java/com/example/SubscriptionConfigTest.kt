package com.example

import com.example.premium.SubscriptionConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SubscriptionConfigTest {

    @Test
    fun defaultLimits_areConfiguredCorrectly() {

        assertEquals(
            3,
            SubscriptionConfig
                .FREE_JOURNEYS_LIMIT
        )

        assertEquals(
            5,
            SubscriptionConfig
                .FREE_ALBUM_PHOTOS_PER_JOURNEY
        )

        assertEquals(
            "premium",
            SubscriptionConfig
                .PREMIUM_ENTITLEMENT_ID
        )

        assertTrue(
            SubscriptionConfig
                .LIFETIME_PRODUCT_ID
                .isNotBlank()
        )
    }
}
