package com.example

import com.example.storage.BitmapSampling
import org.junit.Assert.assertEquals
import org.junit.Test

class BitmapSamplingTest {

    @Test
    fun sampleSize_isOneForSmallImages() {

        assertEquals(
            1,
            BitmapSampling
                .calculateInSampleSize(
                    width = 800,
                    height = 600,
                    targetMaxDimension = 1600
                )
        )
    }

    @Test
    fun sampleSize_scalesPowersOfTwo() {

        assertEquals(
            2,
            BitmapSampling
                .calculateInSampleSize(
                    width = 4000,
                    height = 3000,
                    targetMaxDimension = 1600
                )
        )

        assertEquals(
            4,
            BitmapSampling
                .calculateInSampleSize(
                    width = 8000,
                    height = 6000,
                    targetMaxDimension = 1600
                )
        )
    }

    @Test
    fun invalidInput_returnsOne() {

        assertEquals(
            1,
            BitmapSampling
                .calculateInSampleSize(
                    width = 0,
                    height = 0,
                    targetMaxDimension = 1600
                )
        )
    }
}
