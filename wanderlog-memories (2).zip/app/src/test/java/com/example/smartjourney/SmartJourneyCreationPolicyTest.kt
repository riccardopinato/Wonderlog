package com.example.smartjourney

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartJourneyCreationPolicyTest {

    private val policy =
        SmartJourneyCreationPolicy()

    @Test
    fun freeUserWith83PhotosGetsFreeAllowance() {

        val result =
            policy.evaluate(
                currentJourneyCount =
                    0,

                selectedPhotoCount =
                    83,

                isPremium =
                    false
            )

        assertTrue(
            result
                .journeyCreationAllowed
        )

        assertEquals(
            5,
            result
                .allowedPhotoCount
        )

        assertEquals(
            78,
            result
                .blockedPhotoCount
        )

        assertTrue(
            result
                .requiresUpgrade
        )
    }

    @Test
    fun freeJourneyLimitBlocksNewJourney() {

        val result =
            policy.evaluate(
                currentJourneyCount =
                    3,

                selectedPhotoCount =
                    4,

                isPremium =
                    false
            )

        assertFalse(
            result
                .journeyCreationAllowed
        )

        assertTrue(
            result
                .journeyLimitReached
        )

        assertTrue(
            result
                .requiresUpgrade
        )
    }

    @Test
    fun premiumUserCanImport83Photos() {

        val result =
            policy.evaluate(
                currentJourneyCount =
                    10,

                selectedPhotoCount =
                    83,

                isPremium =
                    true
            )

        assertTrue(
            result
                .journeyCreationAllowed
        )

        assertEquals(
            83,
            result
                .allowedPhotoCount
        )

        assertEquals(
            0,
            result
                .blockedPhotoCount
        )
    }

    @Test
    fun premiumJourneyStillUsesConfiguredPhotoLimit() {

        val result =
            policy.evaluate(
                currentJourneyCount =
                    10,

                selectedPhotoCount =
                    120,

                isPremium =
                    true
            )

        assertEquals(
            100,
            result
                .allowedPhotoCount
        )

        assertEquals(
            20,
            result
                .blockedPhotoCount
        )

        assertFalse(
            result
                .requiresUpgrade
        )
    }
}
