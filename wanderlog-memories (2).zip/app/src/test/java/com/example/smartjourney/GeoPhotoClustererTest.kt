package com.example.smartjourney

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoPhotoClustererTest {

    private val clusterer = GeoPhotoClusterer(
        SmartJourneyBuildOptions(
            geoClusterRadiusMeters = 2500.0,
            maxStopTimeGapMinutes = 240L,
            minimumPhotosPerStop = 1
        )
    )

    @Test
    fun testEmptyPhotosReturnsEmptyClusters() {
        val result = clusterer.cluster(emptyList())
        assertTrue(result.isEmpty())
    }

    @Test
    fun testNearbyPhotosClusteredTogether() {
        val baseTime = 1000000L
        // Two points in Paris separated by ~300 meters
        val p1 = SmartJourneySourcePhoto(
            sourceUri = "uri1",
            originalIndex = 0,
            capturedAt = baseTime,
            modifiedAt = null,
            latitude = 48.8584, // Eiffel Tower
            longitude = 2.2945
        )
        val p2 = SmartJourneySourcePhoto(
            sourceUri = "uri2",
            originalIndex = 1,
            capturedAt = baseTime + 60_000L,
            modifiedAt = null,
            latitude = 48.8590, // ~100m away
            longitude = 2.2950
        )

        val clusters = clusterer.cluster(listOf(p1, p2))
        assertEquals(1, clusters.size)
        assertEquals(2, clusters[0].photos.size)
    }

    @Test
    fun testDistantPhotosFormSeparateClusters() {
        val baseTime = 1000000L
        val p1 = SmartJourneySourcePhoto(
            sourceUri = "uri1",
            originalIndex = 0,
            capturedAt = baseTime,
            modifiedAt = null,
            latitude = 48.8584, // Paris
            longitude = 2.2945
        )
        val p2 = SmartJourneySourcePhoto(
            sourceUri = "uri2",
            originalIndex = 1,
            capturedAt = baseTime + 60_000L,
            modifiedAt = null,
            latitude = 51.5074, // London (>300km away)
            longitude = -0.1278
        )

        val clusters = clusterer.cluster(listOf(p1, p2))
        assertEquals(2, clusters.size)
    }
}
