package com.example.smartjourney

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class SmartJourneyDraftEditorTest {

    private val sampleDraft = SmartJourneyDraft(
        id = "draft_1",
        suggestedTitle = "Kyoto July 2026",
        title = "Kyoto July 2026",
        destination = "Kyoto",
        startDate = LocalDate.of(2026, 7, 1),
        endDate = LocalDate.of(2026, 7, 2),
        days = listOf(
            SmartJourneyDayDraft(
                index = 0,
                date = LocalDate.of(2026, 7, 1),
                title = "Day 1",
                stops = listOf(
                    SmartJourneyStopDraft(
                        id = "stop_1",
                        dayIndex = 0,
                        title = "Fushimi Inari",
                        latitude = 34.9671,
                        longitude = 135.7727,
                        placeLabel = "Fushimi Inari",
                        photoIds = listOf("p1", "p2"),
                        createMemory = true
                    ),
                    SmartJourneyStopDraft(
                        id = "stop_2",
                        dayIndex = 0,
                        title = "Gion",
                        latitude = 35.0037,
                        longitude = 135.7772,
                        placeLabel = "Gion",
                        photoIds = listOf("p3"),
                        createMemory = true
                    )
                )
            )
        ),
        photos = listOf(
            SmartJourneyPhoto("p1", SmartJourneySourcePhoto("uri1", 0, null, null, null, null), 0, "stop_1"),
            SmartJourneyPhoto("p2", SmartJourneySourcePhoto("uri2", 1, null, null, null, null), 0, "stop_1"),
            SmartJourneyPhoto("p3", SmartJourneySourcePhoto("uri3", 2, null, null, null, null), 0, "stop_2")
        ),
        createMemoryDrafts = true
    )

    @Test
    fun testRenameJourney() {
        val updated = SmartJourneyDraftEditor.renameJourney(sampleDraft, "Summer in Japan")
        assertEquals("Summer in Japan", updated.title)
    }

    @Test
    fun testRenameStop() {
        val updated = SmartJourneyDraftEditor.renameStop(sampleDraft, "stop_1", "Torii Gates Walk")
        val stop = updated.days[0].stops.first { it.id == "stop_1" }
        assertEquals("Torii Gates Walk", stop.title)
        assertTrue(stop.manuallyEdited)
    }

    @Test
    fun testSetPhotoIncluded() {
        val updated = SmartJourneyDraftEditor.setPhotoIncluded(sampleDraft, "p1", false)
        val photo = updated.photos.first { it.id == "p1" }
        assertFalse(photo.included)
        assertEquals(1, updated.excludedPhotoCount)
        assertEquals(2, updated.includedPhotos.size)
    }

    @Test
    fun testSetMemoryDraftEnabled() {
        val updated = SmartJourneyDraftEditor.setMemoryDraftEnabled(sampleDraft, "stop_1", false)
        val stop = updated.days[0].stops.first { it.id == "stop_1" }
        assertFalse(stop.createMemory)
    }

    @Test
    fun testSetAllMemoryDrafts() {
        val updated = SmartJourneyDraftEditor.setAllMemoryDrafts(sampleDraft, false)
        assertFalse(updated.createMemoryDrafts)
        assertTrue(updated.days[0].stops.all { !it.createMemory })
    }

    @Test
    fun testMergeAdjacentStops() {
        val merged = SmartJourneyDraftEditor.mergeAdjacentStops(sampleDraft, 0, "stop_1", "stop_2")
        assertEquals(1, merged.days[0].stops.size)
        val singleStop = merged.days[0].stops[0]
        assertEquals(3, singleStop.photoIds.size)
        assertEquals(listOf("p1", "p2", "p3"), singleStop.photoIds)
    }

    @Test
    fun testMovePhoto() {
        val moved = SmartJourneyDraftEditor.movePhoto(sampleDraft, "p1", "stop_2")
        val stop1 = moved.days[0].stops.first { it.id == "stop_1" }
        val stop2 = moved.days[0].stops.first { it.id == "stop_2" }
        assertEquals(listOf("p2"), stop1.photoIds)
        assertEquals(listOf("p3", "p1"), stop2.photoIds)
        val movedPhoto = moved.photos.first { it.id == "p1" }
        assertEquals("stop_2", movedPhoto.stopId)
    }

    @Test
    fun testExcludedPhotoStateSurvivesMove() {
        val excludedDraft = SmartJourneyDraftEditor.setPhotoIncluded(sampleDraft, "p1", false)
        val photoBeforeMove = excludedDraft.photos.first { it.id == "p1" }
        assertFalse(photoBeforeMove.included)

        val moved = SmartJourneyDraftEditor.movePhoto(excludedDraft, "p1", "stop_2")
        val stop1 = moved.days[0].stops.first { it.id == "stop_1" }
        val stop2 = moved.days[0].stops.first { it.id == "stop_2" }
        assertFalse(stop1.photoIds.contains("p1"))
        assertTrue(stop2.photoIds.contains("p1"))

        val photoAfterMove = moved.photos.first { it.id == "p1" }
        assertEquals("stop_2", photoAfterMove.stopId)
        assertFalse(photoAfterMove.included)
    }

    @Test
    fun testMergePreservesIncludedAndExcludedStates() {
        val excludedDraft = SmartJourneyDraftEditor.setPhotoIncluded(sampleDraft, "p1", false)
        val merged = SmartJourneyDraftEditor.mergeAdjacentStops(excludedDraft, 0, "stop_1", "stop_2")
        assertEquals(1, merged.days[0].stops.size)
        val singleStop = merged.days[0].stops[0]
        assertTrue(singleStop.photoIds.contains("p1"))
        assertTrue(singleStop.photoIds.contains("p2"))
        assertTrue(singleStop.photoIds.contains("p3"))

        val p1 = merged.photos.first { it.id == "p1" }
        val p2 = merged.photos.first { it.id == "p2" }
        val p3 = merged.photos.first { it.id == "p3" }
        assertFalse(p1.included)
        assertTrue(p2.included)
        assertTrue(p3.included)
    }
}
