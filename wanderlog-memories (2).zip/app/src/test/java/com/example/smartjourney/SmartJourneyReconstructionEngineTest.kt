package com.example.smartjourney

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneOffset

class SmartJourneyReconstructionEngineTest {

    private val engine = SmartJourneyReconstructionEngine()

    @Test
    fun testReconstructGeneratesDraftWithDaysAndStops() = runBlocking {
        val day = LocalDate.of(2026, 7, 10)
        val t1 = day.atTime(10, 0).toInstant(ZoneOffset.UTC).toEpochMilli()
        val t2 = day.atTime(11, 0).toInstant(ZoneOffset.UTC).toEpochMilli()

        val photos = listOf(
            SmartJourneySourcePhoto(
                sourceUri = "content://media/1",
                originalIndex = 0,
                capturedAt = t1,
                modifiedAt = null,
                latitude = 48.8584,
                longitude = 2.2945,
                placeLabel = "Eiffel Tower"
            ),
            SmartJourneySourcePhoto(
                sourceUri = "content://media/2",
                originalIndex = 1,
                capturedAt = t2,
                modifiedAt = null,
                latitude = 48.8585,
                longitude = 2.2946,
                placeLabel = "Eiffel Tower"
            )
        )

        val draft = engine.reconstruct(photos) { _, _ -> "Paris" }

        assertNotNull(draft)
        assertEquals(1, draft.days.size)
        assertEquals(1, draft.days[0].stops.size)
        assertEquals(2, draft.photos.size)
        assertTrue(draft.title.contains("Paris") || draft.destination.contains("Paris"))
    }
}
