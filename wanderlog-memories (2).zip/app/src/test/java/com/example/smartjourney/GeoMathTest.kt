package com.example.smartjourney

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoMathTest {

    @Test
    fun testDistanceBetweenSamePointsIsZero() {
        val distance = GeoMath.distanceMeters(48.8566, 2.3522, 48.8566, 2.3522)
        assertEquals(0.0, distance, 0.01)
    }

    @Test
    fun testDistanceBetweenKnownPoints() {
        // Distance between Paris and London is roughly 343 km (343,000m - 345,000m)
        val distance = GeoMath.distanceMeters(48.8566, 2.3522, 51.5074, -0.1278)
        assertTrue(distance > 340_000.0 && distance < 350_000.0)
    }

    @Test
    fun testCentroidEmptyListReturnsNull() {
        assertNull(GeoMath.centroid(emptyList()))
    }

    @Test
    fun testCentroidComputesAverage() {
        val coords = listOf(
            Pair(10.0, 20.0),
            Pair(20.0, 40.0)
        )
        val centroid = GeoMath.centroid(coords)
        assertNotNull(centroid)
        assertEquals(15.0, centroid!!.first, 0.001)
        assertEquals(30.0, centroid.second, 0.001)
    }

    @Test
    fun testIsValidCoordinate() {
        assertTrue(GeoMath.isValidCoordinate(0.0, 0.0))
        assertTrue(GeoMath.isValidCoordinate(45.0, 90.0))
        assertTrue(GeoMath.isValidCoordinate(-90.0, -180.0))
        assertTrue(GeoMath.isValidCoordinate(90.0, 180.0))

        assertFalse(GeoMath.isValidCoordinate(null, 10.0))
        assertFalse(GeoMath.isValidCoordinate(10.0, null))
        assertFalse(GeoMath.isValidCoordinate(91.0, 0.0))
        assertFalse(GeoMath.isValidCoordinate(-91.0, 0.0))
        assertFalse(GeoMath.isValidCoordinate(0.0, 181.0))
        assertFalse(GeoMath.isValidCoordinate(0.0, -181.0))
    }
}
