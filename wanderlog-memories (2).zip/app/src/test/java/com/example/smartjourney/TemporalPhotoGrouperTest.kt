package com.example.smartjourney

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

class TemporalPhotoGrouperTest {

    private val utcZone = ZoneId.of("UTC")
    private val grouper = TemporalPhotoGrouper(utcZone)

    @Test
    fun testEmptyPhotosReturnsEmptyGroups() {
        val result = grouper.group(emptyList())
        assertTrue(result.isEmpty())
    }

    @Test
    fun testPhotosOnSameDayGroupedTogether() {
        val day = LocalDate.of(2026, 7, 10)
        val t1 = day.atTime(10, 0).toInstant(ZoneOffset.UTC).toEpochMilli()
        val t2 = day.atTime(14, 30).toInstant(ZoneOffset.UTC).toEpochMilli()

        val photos = listOf(
            SmartJourneySourcePhoto(
                sourceUri = "uri1",
                originalIndex = 0,
                capturedAt = t1,
                modifiedAt = null,
                latitude = null,
                longitude = null
            ),
            SmartJourneySourcePhoto(
                sourceUri = "uri2",
                originalIndex = 1,
                capturedAt = t2,
                modifiedAt = null,
                latitude = null,
                longitude = null
            )
        )

        val groups = grouper.group(photos)
        assertEquals(1, groups.size)
        assertEquals(day, groups[0].date)
        assertEquals(2, groups[0].photos.size)
    }

    @Test
    fun testPhotosOnDifferentDaysSeparated() {
        val day1 = LocalDate.of(2026, 7, 10)
        val day2 = LocalDate.of(2026, 7, 11)
        val t1 = day1.atTime(10, 0).toInstant(ZoneOffset.UTC).toEpochMilli()
        val t2 = day2.atTime(11, 0).toInstant(ZoneOffset.UTC).toEpochMilli()

        val photos = listOf(
            SmartJourneySourcePhoto(
                sourceUri = "uri1",
                originalIndex = 0,
                capturedAt = t1,
                modifiedAt = null,
                latitude = null,
                longitude = null
            ),
            SmartJourneySourcePhoto(
                sourceUri = "uri2",
                originalIndex = 1,
                capturedAt = t2,
                modifiedAt = null,
                latitude = null,
                longitude = null
            )
        )

        val groups = grouper.group(photos)
        assertEquals(2, groups.size)
        assertEquals(day1, groups[0].date)
        assertEquals(day2, groups[1].date)
    }

    @Test
    fun testExcludedPhotosIgnored() {
        val day = LocalDate.of(2026, 7, 10)
        val t1 = day.atTime(10, 0).toInstant(ZoneOffset.UTC).toEpochMilli()

        val photos = listOf(
            SmartJourneySourcePhoto(
                sourceUri = "uri1",
                originalIndex = 0,
                capturedAt = t1,
                modifiedAt = null,
                latitude = null,
                longitude = null,
                included = false
            )
        )

        val groups = grouper.group(photos)
        assertTrue(groups.isEmpty())
    }
}
