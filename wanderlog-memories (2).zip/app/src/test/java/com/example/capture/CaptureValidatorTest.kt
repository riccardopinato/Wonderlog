package com.example.capture

import org.junit.Assert.*
import org.junit.Test

class CaptureValidatorTest {

    @Test
    fun validate_withoutJourney_returnsInvalid() {
        val draft = CaptureDraft(
            items = listOf(CaptureIncomingItem(id = "1", type = CaptureContentType.TEXT, text = "Hello")),
            journeyId = null
        )
        val result = CaptureValidator.validate(draft)
        assertFalse(result.valid)
        assertEquals("Choose a Journey.", result.message)
    }

    @Test
    fun validate_textWithoutMemoryDestination_returnsInvalid() {
        val draft = CaptureDraft(
            items = listOf(CaptureIncomingItem(id = "1", type = CaptureContentType.TEXT, text = "Hello")),
            journeyId = "j1",
            memoryId = null,
            createNewMemory = false
        )
        val result = CaptureValidator.validate(draft)
        assertFalse(result.valid)
        assertEquals("Choose a Memory or create a new one.", result.message)
    }

    @Test
    fun validate_imagesToAlbumWithoutMemory_returnsValid() {
        val draft = CaptureDraft(
            items = listOf(CaptureIncomingItem(id = "1", type = CaptureContentType.IMAGE, uri = "content://img")),
            journeyId = "j1",
            memoryId = null,
            createNewMemory = false
        )
        val result = CaptureValidator.validate(draft)
        assertTrue(result.valid)
    }

    @Test
    fun validate_createNewMemoryValidContent_returnsValid() {
        val draft = CaptureDraft(
            items = listOf(CaptureIncomingItem(id = "1", type = CaptureContentType.TEXT, text = "Nice day")),
            journeyId = "j1",
            createNewMemory = true,
            memoryTitle = "Sunset walk"
        )
        val result = CaptureValidator.validate(draft)
        assertTrue(result.valid)
    }
}
