package com.example.capture

import org.junit.Assert.*
import org.junit.Test

class SharedLocationParserTest {

    @Test
    fun parse_geoUri_returnsValidLocation() {
        val input = "Here is the spot: geo:41.8902,12.4922"
        val location = SharedLocationParser.parse(input)
        assertNotNull(location)
        assertEquals(41.8902, location!!.latitude, 0.0001)
        assertEquals(12.4922, location.longitude, 0.0001)
    }

    @Test
    fun parse_googleMapsAtPattern_returnsValidLocation() {
        val input = "Check out this place: https://maps.google.com/?cid=12345@48.8584,2.2945"
        val location = SharedLocationParser.parse(input)
        assertNotNull(location)
        assertEquals(48.8584, location!!.latitude, 0.0001)
        assertEquals(2.2945, location.longitude, 0.0001)
    }

    @Test
    fun parse_queryParamCoordinates_returnsValidLocation() {
        val input = "https://www.google.com/maps?q=35.6762,139.6503"
        val location = SharedLocationParser.parse(input)
        assertNotNull(location)
        assertEquals(35.6762, location!!.latitude, 0.0001)
        assertEquals(139.6503, location.longitude, 0.0001)
    }

    @Test
    fun parse_invalidText_returnsNull() {
        val input = "Just casual travel text without coordinates"
        val location = SharedLocationParser.parse(input)
        assertNull(location)
    }
}
