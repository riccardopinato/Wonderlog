package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.domain.model.AlbumPhoto
import com.example.storage.AlbumPhotoManager
import com.example.storage.PhotoImportException
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PhotoEngineTest {

    @Test
    fun testDuplicatePhotoPreCheck() {
        val existingPhoto1 = AlbumPhoto(
            id = "photo_1",
            journeyId = "journey_123",
            localUri = "/path/to/photo_1.jpg",
            thumbnailUri = "/path/to/thumb_1.jpg",
            originalUri = "content://media/external/images/media/1",
            fileName = "beach.jpg",
            mimeType = "image/jpeg",
            width = 1920,
            height = 1080,
            fileSize = 1024L * 500L,
            createdAt = System.currentTimeMillis() - 10000,
            updatedAt = System.currentTimeMillis() - 10000,
            capturedAt = System.currentTimeMillis() - 10000,
            gpsLatitude = 37.7749,
            gpsLongitude = -122.4194,
            locationName = "San Francisco, CA"
        )

        val existingPhotos = listOf(existingPhoto1)

        // Pre-check duplicate based on same originalUri
        val isDuplicateOriginalUri = existingPhotos.any { p ->
            p.originalUri == "content://media/external/images/media/1"
        }
        assertTrue(isDuplicateOriginalUri)

        // Pre-check duplicate based on same filename and filesize
        val isDuplicateFile = existingPhotos.any { p ->
            p.fileName == "beach.jpg" && p.fileSize == 1024L * 500L
        }
        assertTrue(isDuplicateFile)

        // Not duplicate
        val isDuplicateDiff = existingPhotos.any { p ->
            p.fileName == "forest.jpg" && p.fileSize == 1024L * 500L
        }
        assertFalse(isDuplicateDiff)
    }

    @Test
    fun testDuplicatePhotoDeepCheck() {
        val existingPhoto1 = AlbumPhoto(
            id = "photo_1",
            journeyId = "journey_123",
            localUri = "/path/to/photo_1.jpg",
            thumbnailUri = "/path/to/thumb_1.jpg",
            originalUri = "content://media/external/images/media/1",
            fileName = "beach.jpg",
            mimeType = "image/jpeg",
            width = 1920,
            height = 1080,
            fileSize = 1024L * 500L,
            createdAt = System.currentTimeMillis() - 10000,
            updatedAt = System.currentTimeMillis() - 10000,
            capturedAt = 1680000000000L,
            gpsLatitude = 37.7749,
            gpsLongitude = -122.4194,
            locationName = "San Francisco, CA"
        )

        val existingPhotos = listOf(existingPhoto1)

        val testCapturedAt = 1680000000000L
        val testWidth = 1920
        val testHeight = 1080

        // Deep check logic inside AlbumPhotoManager: same capturedAt, width and height
        val isDeepDuplicate = existingPhotos.any { p ->
            p.capturedAt == testCapturedAt && p.width == testWidth && p.height == testHeight
        }
        assertTrue(isDeepDuplicate)

        // Different dimensions -> not duplicate
        val isDeepDuplicateDiffDim = existingPhotos.any { p ->
            p.capturedAt == testCapturedAt && p.width == 1280 && p.height == 720
        }
        assertFalse(isDeepDuplicateDiffDim)
    }
}
