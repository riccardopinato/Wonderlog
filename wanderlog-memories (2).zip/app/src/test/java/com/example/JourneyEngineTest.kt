package com.example

import com.example.domain.model.Trip
import com.example.domain.model.Memory
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class JourneyEngineTest {

    @Test
    fun testJourneyModelDefaultValues() {
        val now = System.currentTimeMillis()
        val trip = Trip(
            id = "test_1",
            destinationName = "Rome",
            country = "Italy",
            startDate = "2026-07-01",
            endDate = "2026-07-10",
            coverImage = "cover_rome",
            description = "Ancient Rome Exploration",
            latitude = 41.9,
            longitude = 12.5
        )

        // Ensure expanded attributes have correct defaults
        assertEquals("Rome", trip.title)
        assertEquals("Rome", trip.destination)
        assertFalse(trip.favorite)
        assertFalse(trip.archived)
        assertEquals("Preset_0", trip.accentTheme)
        assertTrue(trip.createdAt <= now + 1000)
        assertTrue(trip.updatedAt <= now + 1000)
        assertNotNull(trip.statistics)
    }

    @Test
    fun testJourneyValidationLogic() {
        val trip = Trip(
            id = "test_1",
            destinationName = "Paris",
            country = "France",
            startDate = "2026-07-01",
            endDate = "2026-07-10",
            coverImage = "cover_paris",
            description = "City of Lights",
            latitude = 48.8,
            longitude = 2.3
        )

        // Validation for title and country length
        assertTrue(trip.destinationName.isNotBlank())
        assertTrue(trip.country.isNotBlank())
        
        // Date chronological validation: startDate is before endDate
        assertTrue(trip.startDate < trip.endDate)
    }

    @Test
    fun testSearchFilteringByMultipleFields() {
        val trip1 = Trip(
            id = "t1",
            destinationName = "Tokyo",
            country = "Japan",
            startDate = "2026-07-01",
            endDate = "2026-07-10",
            coverImage = "cover_tokyo",
            description = "Cyberpunk future street photography",
            latitude = 35.6,
            longitude = 139.6
        )

        val trip2 = Trip(
            id = "t2",
            destinationName = "Rome",
            country = "Italy",
            startDate = "2026-07-01",
            endDate = "2026-07-10",
            coverImage = "cover_rome",
            description = "Historic architectural walkthroughs",
            latitude = 41.9,
            longitude = 12.5
        )

        val query1 = "cyberpunk"
        val query2 = "Italy"

        // Filter Trip 1
        val matches1 = trip1.destinationName.contains(query1, ignoreCase = true) ||
                trip1.country.contains(query1, ignoreCase = true) ||
                trip1.description.contains(query1, ignoreCase = true)

        assertTrue(matches1)

        // Filter Trip 2
        val matches2 = trip2.destinationName.contains(query2, ignoreCase = true) ||
                trip2.country.contains(query2, ignoreCase = true) ||
                trip2.description.contains(query2, ignoreCase = true)

        assertTrue(matches2)
    }

    @Test
    fun testDuplicationLogic() {
        val original = Trip(
            id = "original_id",
            destinationName = "New York",
            country = "USA",
            startDate = "2026-07-01",
            endDate = "2026-07-10",
            coverImage = "cover_ny",
            description = "Central Park and Broadway",
            latitude = 40.7,
            longitude = -74.0,
            favorite = true,
            accentGradientIndex = 2
        )

        // Replicate ViewModel duplicate function logic
        val duplicate = original.copy(
            id = "trip_${UUID.randomUUID()}",
            destinationName = "Copy of ${original.destinationName}",
            title = "Copy of ${original.title}",
            destination = "Copy of ${original.destination}",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            favorite = false, // duplicates start fresh
            archived = false
        )

        assertNotEquals(original.id, duplicate.id)
        assertEquals("Copy of New York", duplicate.destinationName)
        assertEquals("Copy of New York", duplicate.title)
        assertEquals(original.country, duplicate.country)
        assertEquals(original.accentGradientIndex, duplicate.accentGradientIndex)
        assertFalse(duplicate.favorite)
        assertFalse(duplicate.archived)
    }
}
