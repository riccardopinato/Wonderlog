package com.example.mapmemories

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MapMemoryRepositoryTest {

    private val fakeDataSource = object : MapMemoryDataSource {
        override suspend fun loadJourneyPhotos(journeyId: String): List<MapMemoryItem> {
            return listOf(
                MapMemoryItem(
                    id = "photo_1",
                    type = MapMemoryItemType.PHOTO,
                    journeyId = journeyId,
                    title = "Photo 1",
                    subtitle = null,
                    coordinate = MapCoordinate(46.0, 12.0),
                    timestamp = 2000L,
                    dayIndex = 1
                )
            )
        }

        override suspend fun loadJourneyMemories(journeyId: String): List<MapMemoryItem> {
            return listOf(
                MapMemoryItem(
                    id = "memory_1",
                    type = MapMemoryItemType.MEMORY,
                    journeyId = journeyId,
                    title = "Memory 1",
                    subtitle = "Location 1",
                    coordinate = MapCoordinate(45.0, 11.0),
                    timestamp = 1000L,
                    dayIndex = 0
                )
            )
        }
    }

    private val repository = MapMemoryRepositoryImpl(fakeDataSource)

    @Test
    fun loadJourneyMap_mergesAndSortsItemsAndComputesDays() = runBlocking {
        val result = repository.loadJourneyMap("trip_123")
        assertTrue(result.isSuccess)

        val data = result.getOrThrow()
        assertEquals(2, data.items.size)
        // Check order: memory_1 (1000L) before photo_1 (2000L)
        assertEquals("memory_1", data.items[0].id)
        assertEquals("photo_1", data.items[1].id)

        // Check days
        assertEquals(2, data.availableDays.size)
        assertEquals(0, data.availableDays[0].dayIndex)
        assertEquals("Day 1", data.availableDays[0].label)
        assertEquals(1, data.availableDays[1].dayIndex)
        assertEquals("Day 2", data.availableDays[1].label)
    }
}
