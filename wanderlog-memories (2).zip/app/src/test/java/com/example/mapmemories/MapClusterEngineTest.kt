package com.example.mapmemories

import org.junit.Assert.assertEquals
import org.junit.Test

class MapClusterEngineTest {

    private val engine =
        MapClusterEngine(
            clusterRadiusMeters =
                1_000.0
        )

    @Test
    fun nearbyItems_createOneCluster() {

        val items =
            listOf(
                item(
                    "1",
                    45.0,
                    11.0
                ),
                item(
                    "2",
                    45.001,
                    11.001
                )
            )

        assertEquals(
            1,
            engine
                .cluster(
                    items
                )
                .size
        )
    }

    @Test
    fun distantItems_createSeparateClusters() {

        val items =
            listOf(
                item(
                    "1",
                    45.0,
                    11.0
                ),
                item(
                    "2",
                    46.0,
                    12.0
                )
            )

        assertEquals(
            2,
            engine
                .cluster(
                    items
                )
                .size
        )
    }

    @Test
    fun sameItems_createStableClusterId() {

        val items =
            listOf(
                item(
                    "1",
                    45.0,
                    11.0
                ),
                item(
                    "2",
                    45.001,
                    11.001
                )
            )

        val first =
            engine
                .cluster(
                    items
                )
                .single()

        val second =
            engine
                .cluster(
                    items
                )
                .single()

        assertEquals(
            first.id,
            second.id
        )
    }

    @Test
    fun sameMembersDifferentInputOrder_keepSameClusterId() {

        val a =
            item(
                "1",
                45.0,
                11.0
            )

        val b =
            item(
                "2",
                45.001,
                11.001
            )

        val first =
            engine
                .cluster(
                    listOf(
                        a,
                        b
                    )
                )
                .single()

        val second =
            engine
                .cluster(
                    listOf(
                        b,
                        a
                    )
                )
                .single()

        assertEquals(
            first.id,
            second.id
        )
    }

    private fun item(
        id: String,
        lat: Double,
        lon: Double
    ) =
        MapMemoryItem(
            id =
                id,
            type =
                MapMemoryItemType.PHOTO,
            journeyId =
                "trip",
            title =
                null,
            subtitle =
                null,
            coordinate =
                MapCoordinate(
                    lat,
                    lon
                ),
            timestamp =
                1_000L
        )
}
