package com.example.mapmemories

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class JourneyDayResolverTest {

    @Test
    fun sameDay_isDayZero() {

        val date =
            LocalDate.of(
                2026,
                8,
                10
            )

        assertEquals(
            0,
            JourneyDayResolver
                .resolve(
                    date,
                    date
                )
        )
    }

    @Test
    fun twoDaysLater_isDayTwo() {

        assertEquals(
            2,
            JourneyDayResolver
                .resolve(
                    LocalDate.of(
                        2026,
                        8,
                        10
                    ),
                    LocalDate.of(
                        2026,
                        8,
                        12
                    )
                )
        )
    }

    @Test
    fun earlierItem_returnsNull() {

        assertNull(
            JourneyDayResolver
                .resolve(
                    LocalDate.of(
                        2026,
                        8,
                        10
                    ),
                    LocalDate.of(
                        2026,
                        8,
                        9
                    )
                )
        )
    }
}
