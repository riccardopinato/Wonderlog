package com.example.mapmemories

import org.junit.Assert.assertEquals
import org.junit.Test

class JourneyRouteBuilderTest {

    @Test
    fun clusters_areOrderedByTime() {

        val builder =
            JourneyRouteBuilder(
                minimumPointDistanceMeters =
                    0.0
            )

        val late =
            cluster(
                "late",
                300L,
                46.0,
                12.0
            )

        val early =
            cluster(
                "early",
                100L,
                45.0,
                11.0
            )

        val route =
            builder.build(
                listOf(
                    late,
                    early
                )
            )

        assertEquals(
            "early",
            route
                .first()
                .clusterId
        )
    }

    private fun cluster(
        id: String,
        time: Long,
        lat: Double,
        lon: Double
    ) =
        MapMemoryCluster(
            id =
                id,
            coordinate =
                MapCoordinate(
                    lat,
                    lon
                ),
            items =
                listOf(
                    MapMemoryItem(
                        id =
                            "$id-item",
                        type =
                            MapMemoryItemType.PHOTO,
                        journeyId =
                            "trip",
                        title =
                            null,
                        subtitle =
                            null,
                        coordinate =
                            MapCoordinate(
                                lat,
                                lon
                            ),
                        timestamp =
                            time
                    )
                ),
            dominantTitle =
                id,
            dayIndexes =
                emptySet()
        )
}
