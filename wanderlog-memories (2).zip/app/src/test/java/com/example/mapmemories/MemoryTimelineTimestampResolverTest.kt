package com.example.mapmemories

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MemoryTimelineTimestampResolverTest {

    @Test
    fun memoryDateTimestampPreferredOverCreatedAtAndUpdatedAt() {
        val memoryDateTimestamp = 1_700_000_000_000L
        val createdAt = 1_800_000_000_000L
        val updatedAt = 1_900_000_000_000L

        val resolved = MemoryTimelineTimestampResolver.resolve(
            memoryDateTimestamp = memoryDateTimestamp,
            createdAt = createdAt,
            updatedAt = updatedAt
        )

        assertEquals(memoryDateTimestamp, resolved)
    }

    @Test
    fun createdAtUsedWhenMemoryDateTimestampNull() {
        val createdAt = 1_800_000_000_000L
        val updatedAt = 1_900_000_000_000L

        val resolved = MemoryTimelineTimestampResolver.resolve(
            memoryDateTimestamp = null,
            createdAt = createdAt,
            updatedAt = updatedAt
        )

        assertEquals(createdAt, resolved)
    }

    @Test
    fun updatedAtUsedWhenMemoryDateNullAndCreatedAtZero() {
        val updatedAt = 1_900_000_000_000L

        val resolved = MemoryTimelineTimestampResolver.resolve(
            memoryDateTimestamp = null,
            createdAt = 0L,
            updatedAt = updatedAt
        )

        assertEquals(updatedAt, resolved)
    }

    @Test
    fun returnsNullWhenAllTimestampsInvalid() {
        val resolved = MemoryTimelineTimestampResolver.resolve(
            memoryDateTimestamp = null,
            createdAt = 0L,
            updatedAt = 0L
        )

        assertNull(resolved)
    }
}
