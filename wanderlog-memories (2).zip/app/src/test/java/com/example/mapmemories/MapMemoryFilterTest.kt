package com.example.mapmemories

import org.junit.Assert.assertEquals
import org.junit.Test

class MapMemoryFilterTest {

    @Test
    fun photoFilter_removesMemories() {

        val items =
            listOf(
                item(
                    "photo",
                    MapMemoryItemType.PHOTO,
                    0
                ),
                item(
                    "memory",
                    MapMemoryItemType.MEMORY,
                    0
                )
            )

        val result =
            MapMemoryFilter
                .apply(
                    items =
                        items,
                    filter =
                        MapMemoryFilterState(
                            contentFilter =
                                MapMemoryContentFilter
                                    .PHOTOS
                        )
                )

        assertEquals(
            1,
            result.size
        )

        assertEquals(
            MapMemoryItemType.PHOTO,
            result
                .first()
                .type
        )
    }

    @Test
    fun dayFilter_onlyReturnsSelectedDay() {

        val items =
            listOf(
                item(
                    "a",
                    MapMemoryItemType.PHOTO,
                    0
                ),
                item(
                    "b",
                    MapMemoryItemType.PHOTO,
                    1
                )
            )

        val result =
            MapMemoryFilter
                .apply(
                    items =
                        items,
                    filter =
                        MapMemoryFilterState(
                            selectedDayIndex =
                                1
                        )
                )

        assertEquals(
            1,
            result.size
        )

        assertEquals(
            "b",
            result
                .first()
                .id
        )
    }

    private fun item(
        id: String,
        type:
            MapMemoryItemType,
        day:
            Int
    ) =
        MapMemoryItem(
            id =
                id,
            type =
                type,
            journeyId =
                "trip",
            title =
                null,
            subtitle =
                null,
            coordinate =
                MapCoordinate(
                    45.0,
                    11.0
                ),
            timestamp =
                1_000L,
            dayIndex =
                day
        )
}
