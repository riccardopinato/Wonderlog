package com.example

import com.example.cloud.CloudMergeDecision
import com.example.cloud.CloudMergeEngine
import org.junit.Assert.assertEquals
import org.junit.Test

class CloudMergeEngineTest {

    @Test
    fun noLocalEntity_insertsCloud() {

        assertEquals(
            CloudMergeDecision
                .INSERT_CLOUD,

            CloudMergeEngine
                .decide(
                    localUpdatedAt =
                        null,

                    localSyncStatus =
                        null,

                    cloudUpdatedAt =
                        100,

                    cloudDeletedAt =
                        null
                )
        )
    }

    @Test
    fun newerCloud_updatesSyncedLocal() {

        assertEquals(
            CloudMergeDecision
                .APPLY_CLOUD,

            CloudMergeEngine
                .decide(
                    localUpdatedAt =
                        100,

                    localSyncStatus =
                        "SYNCED",

                    cloudUpdatedAt =
                        200,

                    cloudDeletedAt =
                        null
                )
        )
    }

    @Test
    fun newerLocal_isPreserved() {

        assertEquals(
            CloudMergeDecision
                .KEEP_LOCAL,

            CloudMergeEngine
                .decide(
                    localUpdatedAt =
                        300,

                    localSyncStatus =
                        "SYNCED",

                    cloudUpdatedAt =
                        200,

                    cloudDeletedAt =
                        null
                )
        )
    }

    @Test
    fun pendingLocalAndNewerCloud_createsConflict() {

        assertEquals(
            CloudMergeDecision
                .CONFLICT,

            CloudMergeEngine
                .decide(
                    localUpdatedAt =
                        100,

                    localSyncStatus =
                        "PENDING_UPLOAD",

                    cloudUpdatedAt =
                        200,

                    cloudDeletedAt =
                        null
                )
        )
    }

    @Test
    fun cloudTombstone_doesNotDeleteLocalData() {

        assertEquals(
            CloudMergeDecision
                .SKIP,

            CloudMergeEngine
                .decide(
                    localUpdatedAt =
                        100,

                    localSyncStatus =
                        "SYNCED",

                    cloudUpdatedAt =
                        200,

                    cloudDeletedAt =
                        200
                )
        )
    }
}
