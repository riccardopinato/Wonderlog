package com.example

import com.example.cloud.CloudSyncGuard
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CloudSyncGuardTest {

    @Test
    fun canStartBackup_requiresAllFlags() {

        assertTrue(
            CloudSyncGuard
                .canStartBackup(
                    authenticated =
                        true,

                    premium =
                        true,

                    automaticBackupEnabled =
                        true
                )
        )

        assertFalse(
            CloudSyncGuard
                .canStartBackup(
                    authenticated =
                        false,

                    premium =
                        true,

                    automaticBackupEnabled =
                        true
                )
        )

        assertFalse(
            CloudSyncGuard
                .canStartBackup(
                    authenticated =
                        true,

                    premium =
                        false,

                    automaticBackupEnabled =
                        true
                )
        )

        assertFalse(
            CloudSyncGuard
                .canStartBackup(
                    authenticated =
                        true,

                    premium =
                        true,

                    automaticBackupEnabled =
                        false
                )
        )
    }

    @Test
    fun canRestore_requiresAuthAndPremium() {

        assertTrue(
            CloudSyncGuard
                .canRestore(
                    authenticated =
                        true,

                    premium =
                        true
                )
        )

        assertFalse(
            CloudSyncGuard
                .canRestore(
                    authenticated =
                        false,

                    premium =
                        true
                )
        )

        assertFalse(
            CloudSyncGuard
                .canRestore(
                    authenticated =
                        true,

                    premium =
                        false
                )
        )
    }
}
