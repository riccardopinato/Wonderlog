package com.example

import com.example.data.local.DatabaseMigrations
import org.junit.Assert.assertEquals
import org.junit.Test

class DatabaseMigrationTest {

    @Test
    fun migration_4_5_hasCorrectVersions() {

        assertEquals(
            4,
            DatabaseMigrations
                .MIGRATION_4_5
                .startVersion
        )

        assertEquals(
            5,
            DatabaseMigrations
                .MIGRATION_4_5
                .endVersion
        )
    }
}
