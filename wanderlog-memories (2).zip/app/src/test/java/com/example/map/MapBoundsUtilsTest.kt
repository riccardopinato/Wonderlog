package com.example.map

import com.example.mapmemories.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class MapBoundsUtilsTest {

    @Test
    fun boundsContainAllClusters() {

        val clusters =
            listOf(
                cluster(
                    "a",
                    45.0,
                    11.0
                ),
                cluster(
                    "b",
                    46.0,
                    12.0
                )
            )

        val bounds =
            MapBoundsUtils
                .fromClusters(
                    clusters
                )

        assertNotNull(
            bounds
        )

        assertEquals(
            46.0,
            bounds!!
                .latNorth,
            0.0001
        )

        assertEquals(
            45.0,
            bounds
                .latSouth,
            0.0001
        )

        assertEquals(
            12.0,
            bounds
                .lonEast,
            0.0001
        )

        assertEquals(
            11.0,
            bounds
                .lonWest,
            0.0001
        )
    }

    private fun cluster(
        id: String,
        lat: Double,
        lon: Double
    ) =
        MapMemoryCluster(
            id =
                id,

            coordinate =
                MapCoordinate(
                    lat,
                    lon
                ),

            items =
                emptyList(),

            dominantTitle =
                id,

            dayIndexes =
                emptySet()
        )
}
