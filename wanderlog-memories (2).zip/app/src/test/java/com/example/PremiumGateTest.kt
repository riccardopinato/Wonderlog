package com.example

import com.example.cloud.CloudSyncGuard
import com.example.premium.EntitlementChecker
import com.example.premium.PremiumFeature
import com.example.premium.SubscriptionConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PremiumGateTest {

    private val entitlementChecker = EntitlementChecker()

    @Test
    fun cloudBackup_requiresPremium() {
        assertFalse(
            entitlementChecker.hasFeature(
                PremiumFeature.CLOUD_BACKUP,
                isPremium = false
            )
        )
        assertTrue(
            entitlementChecker.hasFeature(
                PremiumFeature.CLOUD_BACKUP,
                isPremium = true
            )
        )
    }

    @Test
    fun photoLimit_differsForFreeAndPremium() {
        val freeLimit = entitlementChecker.albumPhotoLimit(isPremium = false)
        val premiumLimit = entitlementChecker.albumPhotoLimit(isPremium = true)

        assertEquals(SubscriptionConfig.FREE_ALBUM_PHOTOS_PER_JOURNEY, freeLimit)
        assertTrue(premiumLimit > freeLimit)
        assertEquals(5, SubscriptionConfig.getLimits(false).albumPhotosLimit)
        assertEquals(100, SubscriptionConfig.getLimits(true).albumPhotosLimit)
    }

    @Test
    fun cloudSyncGuard_blocksNonPremiumBackupAndRestore() {
        assertFalse(
            CloudSyncGuard.canStartBackup(
                authenticated = true,
                premium = false,
                automaticBackupEnabled = true
            )
        )
        assertTrue(
            CloudSyncGuard.canStartBackup(
                authenticated = true,
                premium = true,
                automaticBackupEnabled = true
            )
        )

        assertFalse(
            CloudSyncGuard.canRestore(
                authenticated = true,
                premium = false
            )
        )
        assertTrue(
            CloudSyncGuard.canRestore(
                authenticated = true,
                premium = true
            )
        )
    }
}
