# ============================================================
# WONDERLOG RELEASE R8 / PROGUARD
# ============================================================

# Keep useful source information for readable crash traces.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Generic annotations/signatures used by Retrofit, Moshi,
# Kotlin serialization and other reflective libraries.
-keepattributes Signature
-keepattributes RuntimeVisibleAnnotations
-keepattributes RuntimeInvisibleAnnotations
-keepattributes AnnotationDefault
-keepattributes InnerClasses
-keepattributes EnclosingMethod

# ------------------------------------------------------------
# Kotlin serialization
# ------------------------------------------------------------
# Generated serializers are referenced by the runtime.
-if @kotlinx.serialization.Serializable class **
-keepclassmembers class <1> {
    static <1>$Companion Companion;
}

-if @kotlinx.serialization.Serializable class ** {
    static **$Companion Companion;
}
-keepclasseswithmembers class **$Companion {
    kotlinx.serialization.KSerializer serializer(...);
}

# ------------------------------------------------------------
# Moshi
# ------------------------------------------------------------
# Wonderlog uses Moshi code generation. Keep annotated models
# if reflection is ever used as fallback.
-keepclasseswithmembers,allowshrinking,allowoptimization class * {
    @com.squareup.moshi.* <methods>;
}

# ------------------------------------------------------------
# Retrofit
# ------------------------------------------------------------
-keepattributes Exceptions
-keepclasseswithmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

# ------------------------------------------------------------
# Room
# ------------------------------------------------------------
# Room generates implementation code through KSP.
# Avoid stripping database implementation metadata.
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *

# ------------------------------------------------------------
# RevenueCat
# ------------------------------------------------------------
# RevenueCat publishes consumer rules, so no broad class keep
# is required. Keep model signatures used across SDK callbacks.
-keepattributes Signature

# ------------------------------------------------------------
# Android Parcelable / CREATOR safety
# ------------------------------------------------------------
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

# ------------------------------------------------------------
# Do NOT add broad:
# -keep class com.example.** { *; }
#
# That would largely disable shrinking/obfuscation.
# ------------------------------------------------------------
