# PERFORMANCE.md

## 1. Purpose
This document outlines standard engineering guidelines to guarantee optimal app performance, fluid frame rates (60/120fps), fast startup times, efficient database interactions, and optimal battery utilization.

## 2. Core Performance Directives

### A. Compose Recomposition Optimization
* **Minimize Recomposition Boundaries**: Always use `remember` for expensive operations inside Composable functions.
* **Derived States**: Use `derivedStateOf` to handle UI states that depend on other state objects that change rapidly (e.g., tracking a scroll position, validating dynamic inputs).
* **Immutable Annotations**: Ensure stable domain structures are annotated with `@Stable` or `@Immutable` when passed across Composable bounds to enable smart recomposition skipping.

### B. High-Efficiency Image Loading & Storage
* **Coil Integration**: Use Coil (`AsyncImage`) for all asynchronous network and storage image operations to leverage automatic caching, resizing, and memory recycling.
* **Size Optimization**: Compress user-added media files before saving them locally (e.g., using WebP format) to prevent bloating the device storage.

### C. Fast Database Queries & Caching
* **Index Queries**: Define SQL indices on frequently searched or ordered columns (e.g., foreign keys, dates).
* **Asynchronous Execution**: Ensure all Room DAO functions execute on background threads via Kotlin Coroutines (`suspend` functions and `Flow`).
* **Avoid Large Objects**: Never store massive raw binary images directly in SQLite database columns. Store media as files on the local disk, and write the path string in the SQLite database column.

### D. Efficient Background Work & Battery Conservation
* **WorkManager**: Delegate non-immediate or large-scale jobs (e.g., sync queues, cleanups) to WorkManager to ensure optimal battery utilization, allowing the OS to batch operations.
* **Location & Sensors**: Unregister GPS location listeners and device sensors immediately when the UI is no longer active to prevent continuous CPU wakes and battery depletion.

### E. Lazy Loading & Pagination
* Use `LazyColumn` and `LazyRow` components for collections, rather than scrolling columns, to recycle items properly.
* Implement pagination strategies for large historic data lists to limit initial memory footprints.
