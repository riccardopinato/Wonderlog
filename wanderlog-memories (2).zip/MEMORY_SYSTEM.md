# Wonderlog Memory System 📝

Memories represent the true psychological value of Wonderlog. While a journey organizes a vacation structurally, memories capture the fleeting emotional micro-events of that vacation.

---

## 1. The Structure of a Memory

Each memory is represented as a complete self-contained data class containing descriptive, emotional, and geographic metadata:

```kotlin
data class Memory(
    val id: String,               // UUID string for conflict-free sync
    val journeyId: String,        // Parent Journey reference
    val title: String,            // User's title (e.g., "Finding the secret cafe")
    val date: Long,               // Epoch timestamp
    val textReflection: String,   // Deep prose entry
    val mood: MoodTag,            // Emotion: Inspired, Peaceful, Adventurous, Lost, etc.
    val locationName: String,     // Geocoded place name (e.g., "Trastevere, Rome")
    val latitude: Double?,        // GPS Latitude
    val longitude: Double?,       // GPS Longitude
    val photos: List<String>      // List of local file path strings
)
```

---

## 2. Emotional Mood Spectrum (MoodTag)
Instead of standard dry categorizations (e.g., Food, Sightseeing, Transport), Wonderlog categorizes memories by their emotional color. This encourages introspective writing and builds beautiful statistics.

* **Inspired (🎨 Blue-to-Magenta)**: Triggered by spectacular views, galleries, or architectural wonders.
* **Peaceful (🌸 Soft Green)**: Calm sunsets, quiet gardens, empty morning cafes.
* **Adventurous (🔥 Hot Orange)**: Hiking, exploration, spontaneous trains, road-trips.
* **Nostalgic (🍂 Warm Brown)**: Old bookshops, memories that feel like a return to the past, quiet evenings.
* **Lost (🌪️ Charcoal Grey)**: Getting caught in the rain, taking the wrong bus, confusing situations that turn into stories.

---

## 3. Safe Editor Guidelines (Auto-Drafting)
Writing a deep memory can take time. To ensure travelers never lose their written reflections due to configuration changes, phone calls, or battery shut-downs, the editor must support auto-drafting:

* Store actively typed title, text reflection, and selected photos in a temporary database table or local cache.
* If the user leaves the screen without explicitly discarding or saving, the next time they tap "Add Memory", prefill the form with their last drafted state.
* Show a small, elegant visual notice: *"We restored your unsaved draft. Tap discard to start fresh."*
