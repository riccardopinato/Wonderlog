# OFFLINE_FIRST.md

## 1. Purpose
This document defines our standard offline-first design and synchronization model. Mobile users expect applications to work flawlessly in remote regions, transit hubs, and offline environments. Offline-first principles establish immediate UI responsiveness while guaranteeing ultimate consistency with remote servers.

## 2. Core Offline-First Architecture

### A. Local DB as Single Source of Truth (SSOT)
* **Write Local First**: All user actions (creates, updates, deletes) must commit immediately to the local SQLite/Room database first.
* **Observe Flow**: ViewModels must collect data as active Kotlin Flow objects from the local database repository, prompting instant, snappy UI updates.
* **Never Await Network**: UI elements must never display loading spinners while waiting for a remote POST confirmation before updating on-screen data.

### B. Background Sync & Conflict Resolution
* **Change Tracking Flags**: Database entities must include synchronization metadata:
  * `syncState`: Enum values representing `SYNCED`, `PENDING_INSERT`, `PENDING_UPDATE`, or `PENDING_DELETE`.
  * `lastUpdated`: Numeric timestamp tracking local mutations.
* **WorkManager Batching**: WorkManager tasks run in the background, filtering local records flagged with `PENDING_*` states and dispatching mutations to the remote API.
* **Conflict Strategy**: 
  * Simple model: *Last-Write-Wins* (LWW) utilizing timestamps.
  * Complex model: Prompt user with conflict resolution screens when remote edits differ substantially from local records.

### C. Offline Media Strategy
* Avoid saving raw high-resolution media to memory.
* Cache compressed media assets in the device's sandboxed local storage folder and references the absolute file path inside SQLite rows.
* Upload cached files asynchronously when standard unmetered Wi-Fi connections are restored.
