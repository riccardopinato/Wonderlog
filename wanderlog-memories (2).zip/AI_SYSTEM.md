# Wonderlog AI System Architecture 🤖

Generative AI in Wonderlog serves as a creative assistant, not a human replacement. We use AI to remove entry friction (such as writing blocks or tedious captioning) while keeping the traveler in full control of their stories.

---

## 1. Provider-Independent Abstraction Layer

To prevent vendor lock-in to a single AI provider (e.g., Gemini, OpenAI, or local models), all generative operations are decoupled behind abstract interfaces inside the Domain layer:

```kotlin
interface GenerativeTextRepository {
    suspend fun generateStory(destination: String, memories: List<Memory>): Result<String>
    suspend fun generateCaption(photoUri: String, contextMood: MoodTag): Result<String>
}
```

This architecture makes swapping the API backing (e.g., from Gemini REST to on-device Gemini Nano) trivial, requiring zero modification to ViewModels or Compose UI screens.

---

## 2. Implemented AI Features

### A. AI Travel Stories (Trip Poetic Stories)
* **Goal**: Consolidate short memories, location names, and emotional moods from a journey into a coherent, multi-paragraph poetic travel summary.
* **Prompt Rule**: Frame prompt models to use warm, nostalgic, novelistic tones (e.g., *"Create a premium, emotional, poetic travel summary for Venice..."*).

### B. AI Caption Generator
* **Goal**: Suggest elegant, non-cliché captions for photos based on the selected emotional mood.
* **Prompt Rule**: Avoid sterile generic tags (e.g., *"Beach in Mexico"*). Suggest reflective lines (e.g., *"Watching the shoreline fade under a quiet amber horizon. Venice."*).

### C. AI Cover Image Selection & Duplicate Filter
* **Goal**: Analyze images inside a journey to suggest the most visually striking option as the cover image while filtering out duplicate or blurry shots.

---

## 3. Strict Creative Safety Rules

1. **Always Editable**: Generated text must **always** be displayed inside editable fields. Users can tweak, rewrite, or completely discard AI drafts before saving.
2. **Graceful Fallbacks**: If the API call fails due to quota limits or lack of connection, always return a high-fidelity local template fallback:
   * *Example*: *"Our journey to Florence was a tapestry of unforgettable moments. We wandered through spectacular locales, feeling deeply connected..."*
3. **Progress Indicators**: Display elegant, translucent progress spinners with calming placeholder copy (e.g., *"Weaving your travel story..."*) during remote generative requests.
