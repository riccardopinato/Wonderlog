# Wonderlog Known Scope Limitations ⚠️

Like any high-fidelity engineering product, Wonderlog balances specific visual, offline, and monetization objectives against technical trade-offs. This document outlines those limitations to help future development cycles prepare suitable workarounds.

---

## 1. Map Render Caching Limitations
* **Limitation**: Free tile rendering requires an online cellular or Wi-Fi connection unless tiles have been previously cached.
* **Workaround**: Encourage users to pre-cache region slices before embarking on voyages, and build robust UI fallbacks (such as a clean error placard) if a map fails to load tile images during deep off-grid trips.

---

## 2. Reverse Geocoding Rate Limits
* **Limitation**: The open-source Nominatim reverse geocoder is subject to standard usage policies and rate-limiting blocks under high concurrency.
* **Workaround**: Implement cache models in the Repository so coordinates that have been geocoded once are saved locally. Implement a fallback manual text-input field so users can type their location name directly if geocoder calls time out or fail.

---

## 3. Photo Storage & Device Disk Capacity
* **Limitation**: Because all WebP images are cached directly in the app’s sandboxed local container (`context.filesDir`), compiling thousands of memories will eventually consume local device disk space.
* **Workaround**: Implement an option inside Settings to allow users to clear temporary image caches, or optimize WebP export quality (reducing it dynamically to Quality 70 if local memory runs low).

---

## 4. On-Device AI Performance Tiers
* **Limitation**: On-device AI processing models (like Gemini Nano) are heavily dependent on modern hardware and are not available on low-to-mid-range Android devices.
* **Workaround**: Maintain a clean REST API fallback backing (such as Gemini 2.5 Flash over HTTPS), gracefully shifting between local and remote processing layers depending on the active device capability.
