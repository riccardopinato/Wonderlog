# PROJECT_RULES.md

## 1. Purpose
This document establishes the non-negotiable architectural and operational policies that govern all development activities within this project. Adhering to these rules guarantees high maintainability, pristine design consistency, and optimal performance across all platforms.

## 2. Permanent Project Rules

### Rule 1: Strict Modularity & Separation of Concerns
Code must be cleanly separated into clearly defined layers: Data, Domain, and Presentation.
* **Data Layer**: Responsible for REST clients, database entities, DAO definitions, local files, cache strategies, and DTO-to-Domain mappers.
* **Domain Layer**: The purest layer. Contains pure Kotlin models, repository interfaces, business use-cases, and application rules. Must have *zero* dependencies on Android framework libraries or UI components.
* **Presentation Layer**: Pure Jetpack Compose UI screens, composable components, typography, color schemes, and StateFlow-based ViewModels.

### Rule 2: Zero Duplicated Logic (DRY)
Duplicate code is a critical architectural failure.
* Combine related functional logics into common utility classes or custom domain use cases.
* Reuse existing Jetpack Compose components instead of rebuilding custom ones from scratch.

### Rule 3: No Hardcoded Business Limits
All subscription and system constraints must be configurable via central mechanisms (e.g., `SubscriptionConfig`).
* **Never** hardcode numerical limits (e.g., `if (photoCount > 5)`) inside UI screens or ViewModel state-machine files.
* Ensure limits can be modified or retrieved remotely in future updates without editing screen logic.

### Rule 4: No UI Logic in Data Layer / No Business Logic in UI Components
Keep boundaries clean and solid:
* UI code must only handle layout, typography, animations, state collection, and visual aesthetics.
* ViewModels or Use Cases must orchestrate business workflows and state machines.
* Under no circumstances should database queries, network requests, or direct API tokens exist in a Composable function.

### Rule 5: No Secrets in Code (Strict Security)
* Credentials, private keys, API keys, and connection strings must never be hardcoded or committed to git.
* Access all keys at runtime via `BuildConfig` using secure secrets management (e.g., Android Secrets Gradle Plugin / `.env` files).

### Rule 6: Naming Conventions & Code Cleanliness
* Use camelCase for all variables, methods, and functions.
* Use PascalCase for all class names, file names (e.g., `MainActivity`), and Composable functions (e.g., `PremiumUpgradeDialog`).
* Use snake_case for all Android resources (XML layout names, strings, drawables) and Compose test tags.
* Keep classes small (< 300 lines of code where possible). If a class is too large, decompose it.

## 3. Best Practices & Mistakes to Avoid
* **Mistake**: Direct access to database DAOs in ViewModels.
  * *Correction*: Always access databases via Domain Repository Interfaces, which are implemented in the Data Layer.
* **Mistake**: Over-engineering simple screens.
  * *Correction*: Adhere to the Single-View constraint for simple requests. Do not introduce secondary drawers, navigation grids, or server synchronizers unless requested.
