# Wonderlog Emotional User Flows 🌊

Wonderlog rejects dry, form-heavy, administrative layouts. Keeping a journal must feel poetic, immediate, and satisfying. The user experience is designed to reduce input friction, keeping the traveler in an emotional state of creative reflection.

---

## 1. Core Onboarding to First Entry Flow

```
   ┌────────────────────────────────────────────────────────┐
   │                  ONBOARDING CAROUSEL                   │
   │  • High-fidelity visual slideshow                      │
   │  • Quick prompt to understand vision                   │
   └───────────────────────────┬────────────────────────────┘
                               │ Tap "Start Journaling"
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │                    EMPTY DASHBOARD                     │
   │  • Beautiful watercolor background                     │
   │  • Minimal "Where is your heart wandering?" prompt     │
   └───────────────────────────┬────────────────────────────┘
                               │ Tap "+" Button
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │                 QUICK CREATE JOURNEY                   │
   │  • Only ask: Destination & Dates (No long checklists)   │
   │  • Confirm with custom spring button                   │
   └───────────────────────────┬────────────────────────────┘
                               │ Journey opens instantly
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │                   JOURNEY WORKSPACE                    │
   │  • Dynamic cover header fades in                       │
   │  • Beautiful empty-state invitation                    │
   └───────────────────────────┬────────────────────────────┘
                               │ Tap "Add First Memory"
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │                    ADD NEW MEMORY                      │
   │  • Multi-select photos (Autofill dates & GPS coordinates)│
   │  • Tap emotional Mood Emoji (Peaceful, Adventurous)    │
   │  • Write short prose or tap "AI Caption"               │
   └───────────────────────────┬────────────────────────────┘
                               │ Tap "Save Memory"
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │               JOURNEY TIMELINE & MAPS                  │
   │  • Timeline slides in with staggered images            │
   │  • Interactive Map draws immediate paths between pins  │
   └────────────────────────────────────────────────────────┘
```

---

## 2. Rules for Low-Friction Interactions

### No Dead Ends
* When a user has completed a step, always suggest the next logical action (e.g., after creating a journey, immediately prompt them to add a memory; after creating a memory, immediately show the updated map and timeline).

### Automatic EXIF Geocoding
* Travelers should not have to type coordinate numbers or search for street names manually.
* When they import a photo, the app scans EXIF metadata. If coordinates are found, they are reverse-geocoded using Nominatim to prefill the memory location field.

### Optional AI Assistance
* If a user is too tired to write a long reflection, they can write 3 quick bullets (e.g., "sunset, cold beer, high mountain") and tap the AI magic wand icon.
* The system uses Gemini to draft a beautifully worded, 1-paragraph poetic memory reflection which remains fully editable.
