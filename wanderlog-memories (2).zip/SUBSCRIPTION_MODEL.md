# Wonderlog Subscription Model & Mechanics 💳

Wonderlog is monetized via a premium subscription tier alongside a generous, value-first free tier. The monetization mechanics are designed to be ethical, highly configurable, and robust against offline exploits.

---

## 1. Subscription Tier Configuration

Our business rules are declared inside the centralized `com.example.premium.SubscriptionConfig` helper object, decoupling business rules from presentation screens:

```kotlin
object SubscriptionConfig {
    val freeLimits = SubscriptionLimits(
        journeysLimit = 3,
        albumPhotosLimit = 5,
        memoriesLimit = 5
    )

    val premiumLimits = SubscriptionLimits(
        journeysLimit = Int.MAX_VALUE,
        albumPhotosLimit = 100,
        memoriesLimit = Int.MAX_VALUE
    )
}
```

---

## 2. Technical Check Mechanics

### A. Non-Hardcoded Limit Guards
* Before adding a new Journey, Album Photo, or Memory, the corresponding ViewModel checks if the user's current list count exceeds the configurable limit:
  ```kotlin
  val isPremium = premiumManager.isPremium.value
  val limits = SubscriptionConfig.getLimits(isPremium)
  val currentCount = journeyRepository.getJourneysCount()

  if (currentCount >= limits.journeysLimit) {
      // Direct ViewModel to launch PremiumUpgradeDialog!
  } else {
      // Proceed to creation screen
  }
  ```

### B. Reactive Lock Overlays
* Premium screens collect the active status flow (`isPremium: Flow<Boolean>`).
* If `isPremium` resolves to `false`, the UI dynamically overlays lock badges (`ic_lock`) on advanced features:
  * PDF Export Button.
  * Premium Theme Swatches.
  * Offline Maps Toggle.
  * AI Story Assistant Trigger.

---

## 3. Play Store & Billing Integration
* **Billing Client Wrapper**: Wrap Google Play Billing / RevenueCat API connections inside a dedicated `PremiumManager` implementation.
* **Offline Verification Caching**: Cache subscription tokens locally inside EncryptedSharedPreferences to prevent verification failure when the user is off-grid during travel.
* **State Recovery**: Upon launching, the Billing Client polls existing purchase tokens, updating the local database cache instantly if a subscription state has changed.
