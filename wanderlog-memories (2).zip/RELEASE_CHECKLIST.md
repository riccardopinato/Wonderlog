# RELEASE_CHECKLIST.md

## 1. Purpose
This checklist must be executed and signed off by the lead release engineer, QA lead, and product manager before compiling any production build (AAB) destined for distribution to the Google Play Store.

## 2. Pre-Release Verification Checklist

### A. Build & Stability
- [ ] **Clean Compilation**: Compile with no errors and zero warning regressions (`compile_applet`).
- [ ] **ProGuard & R8 Rules**: Verify that minification/obfuscation configurations (`minifyEnabled true`) are active and rule mappings are correct.
- [ ] **Build Identifier**: Increment `versionCode` and update `versionName` in `app/build.gradle.kts`.

### B. Monetization & Limit Integrations
- [ ] **Subscription Verifications**: Ensure Google Play Billing or Stripe sandbox parameters are mapped correctly.
- [ ] **Subscription Limits**: Double-check `SubscriptionConfig` to ensure limit boundaries are strictly enforced.
- [ ] **Upgrade Dialogs**: Verify the premium upgrade dialog handles dismissal, purchases, and unlocks flawlessly.

### C. Performance & Diagnostics
- [ ] **Leak Audits**: Run LeakCanary tests on core user flows to verify zero memory leaks.
- [ ] **Startup Optimization**: Profile cold startup times to ensure they remain under 2.5 seconds on mid-range target devices.
- [ ] **Resource Optimization**: Ensure unused images, draft vectors, and redundant dependencies are fully removed.

### D. Privacy, Permissions & Security
- [ ] **Least Privilege**: Audit `AndroidManifest.xml` to ensure only essential permissions are declared.
- [ ] **Dynamic Requests**: Verify that the application requests permissions dynamically with clean explanations before access.
- [ ] **Sensitive Logs**: Ensure all private console log outputs are stripped in production builds.

### E. Store & Release Assets
- [ ] **Screenshots**: High-fidelity marketing screenshots representing the latest UI styling.
- [ ] **Copy & Description**: Localization of promotional text and privacy policy links updated in the developer console.
- [ ] **App Icon**: Ensure custom adaptive high-resolution foreground and background icons are integrated.
