# Wonderlog Core Technical Decisions 🧬

This document details the engineering and architectural decisions made by the Senior Software Architecture team for Wonderlog, explaining *why* specific technologies were chosen over popular alternatives.

---

## 1. Local Database: Room over Realm or direct SQLite
* **Decision**: Implement Jetpack Room with Kotlin Symbol Processing (KSP).
* **Rationale**:
  * Seamless compiler verification of SQL queries at build time.
  * Native support for standard Kotlin Coroutine asynchronous structures and live reactive Flows.
  * Direct compatibility with modern Android MVVM Presentation layers without producing memory leak risks.

---

## 2. Mapping Engine: OpenStreetMap (osmdroid) over Google Maps
* **Decision**: Integrate OpenStreetMap with standard `osmdroid` libraries.
* **Rationale**:
  * **Privacy**: Location coordinates remain 100% local. They are never sent to third-party commercial servers for tracking.
  * **Offline Tiles**: Enables pre-downloading offline map slices directly to device cache folders.
  * **Cost**: Fully free and open-source, avoiding heavy billing thresholds and API key maintenance overheads.

---

## 3. Reverse Geocoding: Nominatim over Google Places
* **Decision**: Direct abstract interface querying Nominatim APIs.
* **Rationale**:
  * Complements the open-source mapping engine.
  * Zero license key requirements for low-density querying.
  * Easily replaceable behind abstract repositories if we expand to Google Places or Mapbox in the future.

---

## 4. Image Format: WebP (Quality 82, Compressed) over Raw JPEG
* **Decision**: Compress all imported images to WebP inside a sandboxed folder.
* **Rationale**:
  * Reduces raw file sizes by up to 60% with zero noticeable visual loss on phone screen densities.
  * Conserves device local disk space, crucial for offline-first diaries housing thousands of travel photos.
  * Standardizes naming and directory schemas, making future cloud synchronization faster and cheaper.

---

## 5. Architectural Modularity: Package-by-Feature
* **Decision**: Organize Kotlin packages around isolated functional features (e.g., `com.example.journey`, `com.example.memory`, `com.example.maps`) rather than technical groupings (e.g., `/views/`, `/models/`).
* **Rationale**:
  * Prevents cross-module spaghetti dependencies.
  * Maximizes team parallel workflow efficiency, allowing developers to modify feature screens and entities without triggering build conflicts.
  * Simplifies context modeling for AI Agents during surgical code edits.
