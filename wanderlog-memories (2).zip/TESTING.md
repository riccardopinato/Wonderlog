# TESTING.md

## 1. Purpose
This document establishes our testing strategy, quality assurance parameters, and the standardized checklist required to certify a feature "Done" and ready for production release.

## 2. Standard Testing Hierarchy

### A. Local JVM Unit Tests
* **Core Logic**: Write standard JUnit tests for repositories, ViewModels, and state machines.
* **Mock Dependencies**: Mock database DAOs and API client interfaces to test domain logic independently from external services.

### B. Robolectric Testing
* **Shadow Architecture**: Leverage Robolectric to test Android lifecycle behavior, navigation flows, and database interactions directly inside local JVM environments without needing emulators.

### C. Roborazzi Screenshot Verification
* **Visual Regressions**: Capture reference screenshots of primary screens and key premium modal UI components.
* **Continuous Integration**: Verify new layout commits against reference screenshots to prevent unexpected visual shifts across screen densities.

### D. Offline Behavior & Limits Verification
* **Edge Case Scenarios**: Verify application resilience in airplane mode. Ensure all local additions succeed offline and sync logic resumes correctly.
* **Limit Testing**: Write specialized tests to verify that `SubscriptionConfig` rules trigger the upgrade dialog when users exceed free limits.

## 3. Definition of Done Checklist

Every pull request or major feature edit must pass this checklist before QA approval:

- [ ] **Compilation**: The app builds without compilation errors (`compile_applet`).
- [ ] **Architecture**: New modules and layers adhere strictly to boundaries defined in `ARCHITECTURE.md`.
- [ ] **No Hardcoding**: All numerical constraints use configurable parameters from `SubscriptionConfig`.
- [ ] **Resource Rules**: Strings are declared in `strings.xml` and interactive elements utilize snake_case `testTag` IDs.
- [ ] **UI Polish**: Spacing, typography, and glassmorphic designs align with the dynamic aesthetics defined in `DESIGN_SYSTEM.md`.
- [ ] **No Secrets**: Zero credentials, tokens, or API keys are written inside the code layers.
- [ ] **Performance Review**: Smart `remember` parameters prevent redundant recompositions; big image files are loaded via `Coil`.
- [ ] **Documentation Sync**: Any changes to architecture, features, or monetization limits are documented in corresponding markdown files.
