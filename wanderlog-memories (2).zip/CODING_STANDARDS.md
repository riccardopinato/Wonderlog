# CODING_STANDARDS.md

## 1. Purpose
This document outlines standard guidelines to guarantee that Kotlin code remains clean, readable, self-documenting, performant, and highly testable. Consistent coding standards ensure frictionless teamwork among engineering personnel and maximize AI agent token efficiency.

## 2. Naming & Case Conventions
* **Classes, Interfaces, Sealed Classes**: PascalCase (e.g., `MemoryRepository`).
* **Variables, Fields, Functions, Parameters**: camelCase (e.g., `isPremiumUser`, `addMemory`).
* **Constants, Enum Entries**: UPPER_SNAKE_CASE (e.g., `MAX_FREE_TRIPS`).
* **XML Resources, Layouts, Drawables, Test Tags**: lower_snake_case (e.g., `ic_premium_badge`, `save_memory_button`).

## 3. State Management & Jetpack Compose
* **State Holders**: Always use ViewModel to hold and orchestrate UI screen state.
* **Exposing State**: Expose UI State as an immutable `StateFlow<UIState>` inside ViewModels. Use private `MutableStateFlow` to manage modifications internally.
* **Collecting State**: Always collect StateFlows inside Composables using lifecycle-aware collection tools (e.g., `collectAsStateWithLifecycle()`).
* **State Mutation**: Never mutate state values directly in screens. Delegate state mutation calls to the ViewModel through intent triggers or public method calls.

## 4. Null Safety & Type Safety
* Leverage Kotlin's robust nullable system. Avoid unsafe casting operations (`as`) and prefer safe casting checks (`as?`).
* Use Kotlin Sealed Interfaces/Classes to manage UI state variables explicitly:
```kotlin
sealed interface MemoryUiState {
    object Loading : MemoryUiState
    data class Success(val memories: List<Memory>) : MemoryUiState
    data class Error(val message: String) : MemoryUiState
}
```

## 5. Robust Error Handling
* Wrap network, database, and OS interactions inside safe Kotlin `try-catch` structures.
* Propagate descriptive error states gracefully to the UI so users receive useful directions, rather than letting the application crash with silent stack trace dumps.
* Avoid logging sensitive data, credentials, or API keys inside catch statements.

## 6. Avoiding Over-engineering
* Build exactly what is requested. Never write generic interfaces or abstract templates for features that only have a single concrete implementation, unless explicitly requested.
* Keep class structures modular, decoupled, and cleanly separated. Avoid complex nested classes or dense functional patterns that decrease readability for future developers and AI agents.
