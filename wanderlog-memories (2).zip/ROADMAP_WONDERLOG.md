# Wonderlog Implementation Roadmap 🗺️

This document outlines the multi-sprint implementation timeline for taking Wonderlog from initial foundation blocks to a high-fidelity, polished, production-ready Android launch.

---

## 1. Release Milestone Phases

```
┌────────────────────────────────────────────────────────┐
│                        SPRINT 1                        │
│             (Foundation & Local Database)              │
│  • Local Room Entities: Journey, Memory, Photo         │
│  • Base UI Navigation (Glass Bottom Bar, Onboarding)  │
│  • Theme configuration (Slate Dark Theme base)         │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                        SPRINT 2                        │
│                 (Core Media & Maps MVP)                │
│  • Multi-Photo Picker & EXIF auto-geocoding parsing    │
│  • OpenStreetMap rendering (markers, chronological paths)│
│  • Statistics Canvas charts (Mood distribution)        │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                        SPRINT 3                        │
│                  (AI Enhancer & PDF)                   │
│  • Decoupled Gemini Text Repository (Stories & Captions)│
│  • PDF Document Travel Book compiling                  │
│  • Auto-drafting safety in the Memory Editor           │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│                        SPRINT 4                        │
│               (Premium, Hardening & Launch)            │
│  • SubscriptionConfig limit validations & paywalls    │
│  • Local JVM unit tests & Roborazzi screenshot audits  │
│  • R8 obfuscation and production compilation checks   │
└────────────────────────────────────────────────────────┘
```

---

## 2. Immediate Active Objective (Sprint 1 Details)
Our current developmental focus is **Sprint 1**:
1. **Database Schema Setup**: Create `JourneyEntity`, `MemoryEntity`, and `PhotoEntity` tables with cascading relationships.
2. **Design Language Setup**: Implement the custom premium Slate Dark Theme inside `Theme.kt`, importing geometric and monospace font pairings.
3. **Core Dashboard Layout**: Build the primary Journey List screen featuring the beautiful empty watercolor state.
4. **Onboarding Experience**: Assemble the fading carousel onboarding slider.
