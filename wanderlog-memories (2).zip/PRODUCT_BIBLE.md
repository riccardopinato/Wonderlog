# Wonderlog Product Bible 📖

> **CRITICAL**: This is the single source of truth for the Wonderlog project. Every future AI agent, developer, and designer MUST read this file in its entirety before analyzing, editing, or introducing any features to the codebase. If a conflict arises between this file and any other document, **this Product Bible takes absolute precedence**.

---

## 1. Vision & Mission
Wonderlog is a **premium travel journal** designed to preserve memories, emotions, places, and experiences from user journeys. 
* It is **NOT** a photo gallery.
* It is **NOT** a social network.
* It is **NOT** another Google Photos replacement.
Wonderlog exists to elevate memory-keeping into an art form, making the reflection of past travels feel premium, tactile, and highly emotional.

For a full breakdown, see [VISION.md](VISION.md) and [MISSION.md](MISSION.md).

---

## 2. Core Philosophies

### A. Journey Philosophy
A Journey is not merely a metadata container. It is a living chapter of a user's life. It holds albums, photos, memories, coordinate trails, statistics, and stories. The transition into a Journey should feel like stepping into a dedicated physical scrapbook.

### B. Memory Philosophy
Memories are the emotional heartbeat of Wonderlog. They capture the specific feeling of a place and moment, associated with mood tags, weather memories, and geographic locations.

### C. Photo Philosophy
Photos in Wonderlog are curated memory anchors, not raw dumps. The application encourages selective curating of up to 5 photos per memory in the Free tier and up to 100 in the Premium tier to ensure high narrative value.

### D. Design & UI/UX Philosophy
We reject generic flat Android layouts. Wonderlog uses an **iPhone-inspired luxury visual layout** with semi-translucent glass, subtle offset layers, rich radial gradients, tactile haptic feedback, and fluid spring transitions. The application must look and feel worthy of an App Store Feature slot.

### E. AI Philosophy
AI is a subtle, optional enhancer. It never replaces the core human experience of writing or curating. It acts as an assistant to suggest beautiful poetic summaries, generate immersive captions, or automate timeline compilations, without locking the user into a specific vendor API.

### F. Offline-First Philosophy
Wonderlog is fully functional offline. Journeys are created, memories are written, and locations are pinned entirely on-device, storing all states inside a local Room SQLite database as the single source of truth.

---

## 3. Core Product Principles
Every feature implemented in Wonderlog must reinforce at least one of these principles:
1. **Photo-Centric**: High-fidelity media presentation.
2. **Emotion-Driven**: Focused on mood, context, and thoughts.
3. **Offline-First**: Zero reliance on a live network for standard journaling.
4. **Minimal Input**: Easy, low-friction entry to capture moments quickly.
5. **Beautiful**: Eye-catching design, spacious margins, premium glassmorphism.
6. **Private**: User's data belongs completely to them. No tracking or profiling.
7. **Fast**: Zero lagging, instant UI updates, quick startup under 2.5 seconds.
8. **Premium**: High visual perception that naturally drives conversion.
9. **Simple**: Focused user flows, no administrative complexity.
10. **Scalable**: Modularity that accommodates future cloud replication (Supabase).
11. **Future-Proof**: Provider-independent AI interfaces and database keys.

---

## 4. Product Non-Goals
We do **not** build:
* Public feeds, sharing links, comments, or likes (No social media clutter).
* Bulk backup of raw device camera folders (Not a photo storage dump).
* Complex spreadsheet-like itinerary organizers or split-billing modules (Keep it emotional, not administrative).

---

## 5. Visual Identity & Aesthetic Guidelines
* **Typography**: Geometric serif display headers paired with clean monospaced indicator subtexts.
* **Gradients**: Sunset oranges, luxury magenta, and lavender watercolors on dark slate canvases.
* **Microinteractions**: Subtle expand/collapse springs, ripple effects, and haptic clicks when locking/unlocking.
* For implementation details, see [DESIGN_LANGUAGE.md](DESIGN_LANGUAGE.md).

---

## 6. Technical & Coding Principles
* **Separation of Layers**: Strict MVVM with pure Kotlin Domain models, independent repositories, and a local Room database.
* **Zero Hardcoded Limits**: Retain configurable subscription boundaries in `SubscriptionConfig`.
* **Test Tags**: Assign test tags (snake_case) to all primary actions for robust local verification.

---

## 7. Monetization Strategy
Wonderlog uses a value-based, non-aggressive upgrade model. Free users can experience the app fully for 2-3 journeys. After reaching the limits (3 journeys, 5 photos per journey, 5 memories per journey), users are met with a beautiful side-by-side comparison upgrade sheet.

For a full breakdown, see [FREE_PREMIUM.md](FREE_PREMIUM.md) and [SUBSCRIPTION_MODEL.md](SUBSCRIPTION_MODEL.md).

---

## 8. Instructions for Future AI Agents
1. **Check Limits**: Never modify the UI to include hardcoded limit numbers. Always query `SubscriptionConfig`.
2. **Read First**: Always read this `PRODUCT_BIBLE.md` and [DESIGN_LANGUAGE.md](DESIGN_LANGUAGE.md) before writing Compose code.
3. **Preserve Aesthetics**: Do not replace glass components or gradient buttons with unstyled gray layouts. Keep the luxury visual feeling intact.
