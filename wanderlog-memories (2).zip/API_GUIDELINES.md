# API_GUIDELINES.md

## 1. Purpose
This document outlines standard protocols for network transactions, API abstraction layers, error handling, caching, and rate limiting to ensure applications remain highly modular and resilient to external API shifts.

## 2. API Communication Layers

```
┌────────────────────────────────────────────────────────┐
│                        SERVICES                        │
│   (Retrofit / Ktor clients communicating with APIs)    │
└───────────────────────────┬────────────────────────────┘
                            │ returns DTOs (Data Models)
                            ▼
┌────────────────────────────────────────────────────────┐
│                        REPOSITORIES                    │
│   (Map DTOs to pure Domain Models via clean mappers)    │
└───────────────────────────┬────────────────────────────┘
                            │ returns pure Domain objects
                            ▼
┌────────────────────────────────────────────────────────┐
│                        VIEWMODELS                      │
│   (Collect data, manage state flow and handle errors)  │
└────────────────────────────────────────────────────────┘
```

## 3. Communication Guidelines

### A. Provider Abstraction
* **No Vendor Lock-In**: Interfaces must abstract all core service requests.
* **Inject Drivers**: Concrete API drivers must be injected into Repository classes using clean Constructor Injection, making it trivial to swap remote providers.

### B. Map DTOs to Domain Objects
* Do not propagate raw API response structures (DTOs) directly to UI elements or store them inside domain databases.
* Write pure extension mapper functions (`toDomain()`) inside the data layer to sanitize, validate, and convert external JSON data into robust Domain Models.

### C. Rate Limits, Retries, and Error Handling
* **Retry Strategy**: Configure client intercepters to catch network dropouts and automatically retry request envelopes using exponential backoff schemes.
* **Quota Management**: Handle `HTTP 429 Too Many Requests` responses gracefully. Present informative warnings in the UI if quota constraints are breached, recommending alternative actions.
* **Graceful Timeouts**: Configure safe, modern timeout parameters (e.g., 30 seconds for content uploads) to release connections quickly.
