# Wonderlog Photo System Architecture 📷

Wonderlog is highly photo-centric. Photos are not treated as dry data attachments; they are core visual anchors that trigger travel memory recall. This document outlines the technical architecture of the photo processing pipeline.

---

## 1. Photo Pipeline Lifecycle

```
   ┌────────────────────────────────────────────────────────┐
   │                    IMAGE SELECTION                     │
   │  • Android Photo Picker (Multi-selection API)          │
   │  • Camera Capture Intent                               │
   └───────────────────────────┬────────────────────────────┘
                               │ Source Uri returned
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │                 METADATA EXTRACTION                    │
   │  • Parse EXIF headers using androidx.exifinterface     │
   │  • Extract: GPS Coordinates, Timestamp, Camera Model   │
   └───────────────────────────┬────────────────────────────┘
                               │ Processing begins
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │               COMPRESSION & OPTIMIZATION               │
   │  • Scale to maximum 1920px width/height                │
   │  • Compress to WebP (Quality 82) to conserve local disk│
   └───────────────────────────┬────────────────────────────┘
                               │ Saving assets
                               ▼
   ┌────────────────────────────────────────────────────────┐
   │                   SANDBOX PERSISTENCE                  │
   │  • Write WebP file to application internal files folder│
   │  • Save relative file path inside SQLite Database      │
   └────────────────────────────────────────────────────────┘
```

---

## 2. Technical Decisions & Rules

### A. Strict Local Storage (No Raw DB Blobs)
* **Never** store raw image bytes or base64 strings directly in SQLite columns. Doing so causes SQLiteCursor page bloating, leading to slow queries and frame drops.
* Always save the file to `context.filesDir` (specifically in `/photos/`), and write the relative file path string (e.g., `photos/greece_trip_123.webp`) in the Database.

### B. Intelligent Auto-Geocoding (EXIF Parsing)
* On image selection, instantiate `ExifInterface` over the file input stream.
* Query latitude/longitude and date attributes:
  ```kotlin
  val latLong = FloatArray(2)
  if (exif.getLatLong(latLong)) {
      val lat = latLong[0]
      val lng = latLong[1]
      // Prefill coordinate fields in the Memory Form!
  }
  ```

### C. Image Loading via Coil
* Standardize the use of Coil (`AsyncImage`) to render all image assets. Coil provides built-in memory caches, thumbnail downscaling, and fading transitions to maintain smooth 60fps lists.

### D. Cloud Backup & Synchronization Strategy
* Photos are saved locally with UUID-based file names.
* In the premium cloud expansion tier, the synchronizer uploads internal images to a Supabase Storage bucket, pairing file names with database sync rows to maintain visual alignment across devices.
