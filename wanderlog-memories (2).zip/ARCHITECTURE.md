# ARCHITECTURE.md

## 1. Purpose
This document provides a detailed blueprint of our standard Model-View-ViewModel (MVVM) and Clean Architecture framework. It serves as the definitive reference for structuring code, handling state, injecting dependencies, and managing local/cloud data boundaries.

## 2. Standard Architectural Pattern

```
┌────────────────────────────────────────────────────────┐
│                   PRESENTATION LAYER                   │
│                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐  │
│  │   Jetpack Compose    │───>│      ViewModel       │  │
│  │     (UI Views)       │    │   (UI State Engine)  │  │
│  └──────────────────────┘    └──────────────────────┘  │
└───────────────────────────────────│────────────────────┘
                                    │ collects state / dispatches intents
                                    ▼
┌────────────────────────────────────────────────────────┐
│                      DOMAIN LAYER                      │
│                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐  │
│  │    Business Use      │───>│      Repository      │  │
│  │    Cases (Optional)  │    │     (Interfaces)     │  │
│  └──────────────────────┘    └──────────────────────┘  │
└───────────────────────────────────│────────────────────┘
                                    │ implemented by
                                    ▼
┌────────────────────────────────────────────────────────┐
│                       DATA LAYER                       │
│                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐  │
│  │      Local DB        │    │    Remote API        │  │
│  │     (Room/DAOs)      │    │   (Retrofit/Ktor)    │  │
│  └──────────────────────┘    └──────────────────────┘  │
└────────────────────────────────────────────────────────┘
```

## 3. Layer Breakdown & Operational Rules

### A. Data Layer
* **Role**: The boundary interacting with raw data sources.
* **When to use**: Undergoing SQLite transactions, caching files, calling REST endpoints, or checking local device system states (connectivity, GPS).
* **Components**:
  * **DAOs / API Interfaces**: Expose raw SQL or REST routes.
  * **DTOs (Data Transfer Objects)**: Represent JSON schemas or raw DB columns.
  * **Mappers**: Pure extension functions converting DTOs to pure Domain Models.

### B. Domain Layer
* **Role**: The core business heart of the application. High stability, zero external dependency.
* **When to use**: Expressing pure data logic, calculations, domain validation rules, and repository contracts.
* **Components**:
  * **Domain Models**: Pure Kotlin data classes representing real-world abstractions.
  * **Repository Interfaces**: Define abstract data operations, return Kotlin Flows of Domain Models.
  * **Use Cases (Interactors)**: Optional single-responsibility orchestrators implementing specialized business rules.

### C. Presentation Layer
* **Role**: Rendering pixels on-screen and coordinating user input.
* **When to use**: Designing screens, layouts, menus, buttons, managing screen-local animation, collecting flows.
* **Components**:
  * **ViewModels**: Maintain UI state inside `StateFlow<UIState>` structures. Survive configuration changes.
  * **Compose Screens**: Declarative views collecting UI state as Compose state.
  * **UI State Models**: Sealed classes or immutable data classes reflecting different UI states (Loading, Success, Error).

## 4. Key Architectural Managers & Services
* **Services**: Encapsulate system APIs (e.g., GPS Location services, Android system notification controllers).
* **Managers**: Central orchestrators controlling cross-cutting logic (e.g., `PremiumManager`, `PhotoStorageManager`).
* **Repositories**: Concrete implementations of Domain Repository interfaces coordinating local and remote caching priorities.

## 5. Offline-First & Future Cloud Synchronization
* Local database represents the absolute Single Source of Truth (SSOT).
* When offline, all additions and edits write immediately to local SQLite.
* Future background synchronizers poll changes, pushing mutations to a retry queue while resolving timestamps gracefully on the server.
